#!/usr/bin/env python3
"""Small DietPi web manager for one Squeezelite player on a NanoPi NEO."""

import asyncio
import hashlib
import hmac
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import tarfile
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

import aiohttp
from aiohttp import web

CONFIG_PATH = Path(os.getenv("LYRION_NANOPI_CONFIG", "/etc/lyrion-nanopi/config.json"))
PORT = int(os.getenv("LYRION_NANOPI_PORT", "9099"))
HTTP_PORT = int(os.getenv("LYRION_NANOPI_HTTP_PORT", "80"))
DEFAULTS = {
    "server": "",
    "player_name": "NanoPi Player",
    "output": "analog",
    "alsa_params": "200:4:32:0",
    "extended_rates": False,
    "fixed_volume": True,
}
player_process = None
discovery_transport = None
events = []
DISCOVERY_PORT = 9099
COMMISSION_MAGIC = b"LYRION_GADGET_COMMISSION_v1"
APP_VERSION = "1.011"
SETUP_PASSWORD = os.getenv("LYRION_NANOPI_PASSWORD", "LyrionGadget")
UPDATE_MANIFEST_URL = os.getenv(
    "LYRION_NANOPI_UPDATE_URL",
    "https://api.github.com/repos/Shakey001/LyrionGadget-Releases/contents/nanopi-player-update.json?ref=main",
)
UPDATE_ROOT = Path("/var/lib/lyrion-nanopi/updates")
UPDATE_MAX_BYTES = 12 * 1024 * 1024
UPDATE_REQUIRED = {"app.py", "web/index.html", "web/app.css", "web/app.js"}


def log(message):
    events.insert(0, message)
    del events[30:]


def alsa_outputs():
    """Return only the two fixed MS-1 onboard playback paths."""
    try:
        text = subprocess.run(
            ["aplay", "-l"], text=True, capture_output=True, timeout=4, check=False
        ).stdout
    except (OSError, subprocess.SubprocessError):
        text = ""

    found = {}
    pattern = re.compile(r"^card\s+(\d+):\s*([^\s\[]+).*device\s+(\d+):\s*([^\[]+)", re.I)
    for line in text.splitlines():
        match = pattern.search(line)
        if not match:
            continue
        card_num, card_id, device_num, label = match.groups()
        haystack = f"{card_id} {label}".lower()
        key = "spdif" if "spdif" in haystack else "analog" if "codec" in haystack else None
        if key and key not in found:
            found[key] = {
                "key": key,
                "device": f"hw:CARD={card_id},DEV={device_num}",
                "label": f"{label.strip()} — card {card_num}, device {device_num}",
            }
    return [found[key] for key in ("analog", "spdif") if key in found]


def load_config():
    try:
        saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        saved = {}

    # Migrate the proof-of-concept configuration without retaining dual mode.
    output = str(saved.get("output", "")).lower()
    if output not in {"analog", "spdif"}:
        output = "analog"
        for row in saved.get("outputs", []):
            if isinstance(row, dict) and row.get("enabled") and row.get("key") in {"analog", "spdif"}:
                output = row["key"]
                break
    player_name = saved.get("player_name", saved.get("single_name", DEFAULTS["player_name"]))
    try:
        alsa_params = normalize_alsa_params(saved.get("alsa_params", DEFAULTS["alsa_params"]))
    except ValueError:
        alsa_params = DEFAULTS["alsa_params"]
    return {
        "server": str(saved.get("server", DEFAULTS["server"])).strip(),
        "player_name": str(player_name)[:48],
        "output": output,
        "alsa_params": alsa_params,
        "extended_rates": bool(saved.get("extended_rates", DEFAULTS["extended_rates"])),
        "fixed_volume": bool(saved.get("fixed_volume", DEFAULTS["fixed_volume"])),
    }


def save_config(config):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(CONFIG_PATH)


def normalize_alsa_params(value):
    text = str(value if value is not None else "").strip()
    if not text:
        return DEFAULTS["alsa_params"]
    if text.startswith("-a"):
        text = text[2:].strip()
    if not re.fullmatch(r"[0-9:]{0,32}", text) or ":" not in text:
        raise ValueError("Invalid ALSA parameters")
    return text


def validate_alsa_params(value):
    try:
        return normalize_alsa_params(value)
    except ValueError:
        raise web.HTTPBadRequest(text="Invalid ALSA parameters")


def player_mac():
    try:
        seed = Path("/etc/machine-id").read_text(encoding="utf-8").strip()
    except OSError:
        seed = socket.gethostname()
    raw = bytearray(hashlib.sha256((seed + ":player").encode()).digest()[:6])
    raw[0] = (raw[0] | 2) & 254
    return ":".join(f"{value:02x}" for value in raw)


def gadget_id():
    """Match Lyrion Gadget IDs: Lyrion plus the final four hardware-MAC digits."""
    net_root = Path("/sys/class/net")
    try:
        for path in sorted(net_root.glob("*/address")):
            if path.parent.name == "lo":
                continue
            chars = re.sub(r"[^0-9A-F]", "", path.read_text(encoding="ascii").upper())
            if len(chars) == 12 and chars != "0" * 12:
                return "Lyrion" + chars[-4:]
    except OSError:
        pass
    return "Lyrion" + player_mac().replace(":", "")[-4:].upper()


def auth_token():
    try:
        machine_id = Path("/etc/machine-id").read_text(encoding="ascii").strip()
    except OSError:
        machine_id = socket.gethostname()
    return hmac.new(machine_id.encode(), SETUP_PASSWORD.encode(), hashlib.sha256).hexdigest()


def request_is_authenticated(request):
    supplied = request.cookies.get("lyrion_nanopi_auth", "")
    return bool(supplied) and hmac.compare_digest(supplied, auth_token())


def version_tuple(value):
    return tuple(int(part) for part in re.findall(r"\d+", str(value)))


def validated_https_url(value, label):
    parsed = urlparse(str(value).strip())
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise RuntimeError(f"{label} must be a valid HTTPS URL")
    return parsed.geturl()


async def download_bytes(url, maximum):
    body = bytearray()
    timeout = aiohttp.ClientTimeout(total=45, connect=12)
    headers = {
        "Accept": "application/vnd.github.raw+json",
        "User-Agent": "Lyrion-NanoPi-Player",
        "Cache-Control": "no-cache",
    }
    async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
        async with session.get(validated_https_url(url, "Download URL"), allow_redirects=True) as response:
            if response.status != 200:
                raise RuntimeError(f"download returned HTTP {response.status}")
            length = int(response.headers.get("Content-Length", "0") or 0)
            if length > maximum:
                raise RuntimeError("download is larger than the allowed package size")
            async for chunk in response.content.iter_chunked(65536):
                body.extend(chunk)
                if len(body) > maximum:
                    raise RuntimeError("download is larger than the allowed package size")
    return bytes(body)


async def fetch_update_manifest():
    separator = "&" if "?" in UPDATE_MANIFEST_URL else "?"
    fresh_url = f"{UPDATE_MANIFEST_URL}{separator}cb={int(time.time())}"
    raw = await download_bytes(fresh_url, 256 * 1024)
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise RuntimeError(f"manifest is not valid JSON: {error}")
    if not isinstance(manifest, dict):
        raise RuntimeError("manifest must contain a JSON object")
    version = str(manifest.get("version", "")).strip()
    package_url = validated_https_url(manifest.get("package_url") or manifest.get("url"), "Package URL")
    digest = str(manifest.get("sha256", "")).strip().lower()
    if not version:
        raise RuntimeError("manifest is missing version")
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise RuntimeError("manifest SHA-256 is invalid")
    return {
        "version": version,
        "package_url": package_url,
        "sha256": digest,
        "notes": str(manifest.get("notes", "")).strip(),
        "available": version_tuple(version) > version_tuple(APP_VERSION),
    }


def extract_update(package_path, stage_dir):
    allowed_roots = {"app.py", "web"}
    names = set()
    with tarfile.open(package_path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            clean = member.name.replace("\\", "/").lstrip("./")
            root = clean.split("/", 1)[0]
            if (not clean or root not in allowed_roots or ".." in clean.split("/")
                    or member.issym() or member.islnk()
                    or not (member.isfile() or member.isdir())):
                raise RuntimeError(f"unsafe package entry: {member.name}")
            member.name = clean
            names.add(clean)
        missing = UPDATE_REQUIRED - names
        if missing:
            raise RuntimeError("package is missing: " + ", ".join(sorted(missing)))
        for member in members:
            target = (stage_dir / member.name).resolve()
            if stage_dir.resolve() not in target.parents and target != stage_dir.resolve():
                raise RuntimeError("unsafe package path")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"could not read {member.name}")
            with source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            os.chmod(target, member.mode & 0o777)


def backup_manager():
    backup_dir = UPDATE_ROOT / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup = backup_dir / f"nanopi-player-{APP_VERSION}-{int(time.time())}.tgz"
    with tarfile.open(backup, "w:gz") as archive:
        for name in ("app.py", "web"):
            source = Path("/opt/lyrion-nanopi") / name
            if source.exists():
                archive.add(source, arcname=name)
    return backup


def normalize_analog_output():
    """Set the MS-1 line output path to fixed 0 dB and unmuted."""
    amixer = shutil.which("amixer")
    if not amixer:
        return
    for control in ("Line Out", "DAC"):
        subprocess.run(
            [amixer, "-c", "Codec", "sset", control, "100%", "unmute"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=4,
            check=False,
        )


def discover_gadgets_sync():
    """Ask Lyrion Gadget brokers on the LAN to announce themselves."""
    found = {}
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.35)
        sock.bind(("", 0))
        sock.sendto(COMMISSION_MAGIC, ("255.255.255.255", DISCOVERY_PORT))
        # A short bounded receive window collects all responding brokers.
        while True:
            try:
                payload, peer = sock.recvfrom(4096)
            except socket.timeout:
                break
            try:
                row = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, ValueError):
                continue
            if row.get("t") != "gadget_announce":
                continue
            if str(row.get("mode", "")).lower() == "player_only":
                continue
            lms_base = str(row.get("lms_base", "")).strip()
            parsed = urlparse(lms_base if "://" in lms_base else "http://" + lms_base)
            server = parsed.hostname or peer[0]
            if server in {"127.0.0.1", "localhost", "0.0.0.0"}:
                server = peer[0]
            found[server] = {
                "server": server,
                "name": str(row.get("name") or row.get("hostname") or "Lyrion Gadget"),
                "broker": peer[0],
                "version": str(row.get("version", "")),
            }
    finally:
        sock.close()
    return list(found.values())


def local_ip_for_peer(peer_ip):
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect((peer_ip, 9))
        return probe.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        probe.close()


class PlayerDiscoveryProtocol(asyncio.DatagramProtocol):
    """Announce this appliance to Lyrion Gadget Finder as a player-only unit."""

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, addr):
        # Commissioning discovery is used by Lyrion Gadget Finder. Do not answer
        # broker discovery: RTI drivers must not mistake this player for a broker.
        if data != COMMISSION_MAGIC:
            return
        config = load_config()
        running = player_process is not None and player_process.returncode is None
        payload = {
            "t": "gadget_announce",
            "ip": local_ip_for_peer(addr[0]),
            "port": PORT,
            "name": gadget_id(),
            "broker_id": gadget_id(),
            "hostname": socket.gethostname(),
            "version": APP_VERSION,
            "mode": "player_only",
            "device_type": "player_only",
            "pi_model": "NanoPi NEO / RTI MS-1",
            "configured_players": 1,
            "running_players": 1 if running else 0,
            "player_name": config["player_name"],
            "player_mac": player_mac(),
            "output": config["output"],
        }
        if config["server"]:
            payload["lms_base"] = f"http://{config['server']}:9000"
        self.transport.sendto(json.dumps(payload, separators=(",", ":")).encode(), addr)


async def set_lms_fixed_volume(server, fixed):
    """Use the same LMS preference as Lyrion Gadget's fixed-output control."""
    base = server if ":" in server and not re.fullmatch(r"\d+\.\d+\.\d+\.\d+", server) else f"{server}:9000"
    url = f"http://{base}/jsonrpc.js"
    commands = []
    if fixed:
        commands.append(["mixer", "volume", "100"])
    commands.append(["playerpref", "digitalVolumeControl", "0" if fixed else "1"])
    try:
        async with aiohttp.ClientSession() as session:
            for command in commands:
                body = {"id": 1, "method": "slim.request", "params": [player_mac(), command]}
                async with session.post(url, json=body, timeout=4) as response:
                    if response.status >= 400:
                        raise RuntimeError(f"LMS returned HTTP {response.status}")
        log("Fixed volume at 100% enabled" if fixed else "LMS volume control enabled")
    except Exception as error:
        log(f"Could not apply LMS volume setting: {error}")


async def stop_player():
    global player_process
    if player_process and player_process.returncode is None:
        player_process.terminate()
        try:
            await asyncio.wait_for(player_process.wait(), timeout=5)
        except asyncio.TimeoutError:
            player_process.kill()
            await player_process.wait()
    player_process = None


async def start_player():
    global player_process
    await stop_player()
    config = load_config()
    if not config["server"]:
        log("Waiting for a Lyrion server address")
        return

    binary = shutil.which("squeezelite")
    if not binary:
        log("DietPi Squeezelite is not installed")
        return

    outputs = {row["key"]: row for row in alsa_outputs()}
    selected = outputs.get(config["output"])
    if not selected:
        log(f"The selected {config['output']} output was not detected")
        return

    if config["output"] == "analog":
        normalize_analog_output()

    # One direct hardware stream only. Extended rates stay optional because
    # the NanoPi/DietPi path can be more sensitive than the pCP players.
    args = [
        binary,
        "-s", config["server"],
        "-o", selected["device"],
        "-n", config["player_name"],
        "-m", player_mac(),
        "-a", config["alsa_params"],
    ]
    if config["extended_rates"]:
        args.extend([
            "-r", "44100,48000,88200,96000,176400,192000:750",
            "-Z", "192000",
        ])
    player_process = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
    )
    log(f"Started {config['player_name']} on {config['output'].upper()}")


async def server_check(server):
    if not server:
        return False
    host = server.split(":", 1)[0].strip("[]")
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection(host, 9000), timeout=2.5)
        writer.close()
        await writer.wait_closed()
        return True
    except (OSError, asyncio.TimeoutError):
        return False


async def api_status(_request):
    config = load_config()
    return web.json_response({
        "hostname": socket.gethostname(),
        "architecture": os.uname().machine,
        "server": config["server"],
        "playerName": config["player_name"],
        "playerMac": player_mac(),
        "output": config["output"],
        "alsaParams": config["alsa_params"],
        "extendedRates": config["extended_rates"],
        "fixedVolume": config["fixed_volume"],
        "outputs": alsa_outputs(),
        "running": player_process is not None and player_process.returncode is None,
        "serverOnline": await server_check(config["server"]),
        "events": events,
        "appVersion": APP_VERSION,
    })


async def api_save(request):
    body = await request.json()
    server = str(body.get("server", "")).strip().replace("http://", "").replace("https://", "").split("/")[0]
    if server and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,253}", server):
        raise web.HTTPBadRequest(text="Invalid server address")
    player_name = re.sub(r"[^A-Za-z0-9 _.-]", "", str(body.get("playerName", DEFAULTS["player_name"])))[:48].strip() or DEFAULTS["player_name"]
    output = str(body.get("output", "analog")).lower()
    alsa_params = validate_alsa_params(body.get("alsaParams", DEFAULTS["alsa_params"]))
    extended_rates = bool(body.get("extendedRates", DEFAULTS["extended_rates"]))
    fixed_volume = bool(body.get("fixedVolume", True))
    if output not in {"analog", "spdif"}:
        raise web.HTTPBadRequest(text="Invalid audio output")
    if output not in {row["key"] for row in alsa_outputs()}:
        raise web.HTTPBadRequest(text="Selected audio output was not detected")
    save_config({
        "server": server,
        "player_name": player_name,
        "output": output,
        "alsa_params": alsa_params,
        "extended_rates": extended_rates,
        "fixed_volume": fixed_volume,
    })
    await start_player()
    if server:
        await asyncio.sleep(1)
        await set_lms_fixed_volume(server, fixed_volume)
    return web.json_response({"ok": True})


async def api_discover(_request):
    rows = await asyncio.to_thread(discover_gadgets_sync)
    return web.json_response({"ok": True, "gadgets": rows})


async def api_update_check(_request):
    try:
        manifest = await fetch_update_manifest()
        return web.json_response({"ok": True, "current_version": APP_VERSION, **manifest})
    except Exception as error:
        return web.json_response({"ok": False, "error": str(error)}, status=400)


async def api_update_install(_request):
    package_path = None
    stage_dir = None
    try:
        manifest = await fetch_update_manifest()
        if not manifest["available"]:
            return web.json_response({
                "ok": False,
                "error": f"version {manifest['version']} is not newer than {APP_VERSION}",
            }, status=409)
        package = await download_bytes(manifest["package_url"], UPDATE_MAX_BYTES)
        digest = hashlib.sha256(package).hexdigest()
        if not hmac.compare_digest(digest, manifest["sha256"]):
            raise RuntimeError("downloaded package SHA-256 does not match the manifest")

        UPDATE_ROOT.mkdir(parents=True, exist_ok=True)
        package_path = UPDATE_ROOT / f"nanopi-player-{manifest['version']}.tgz"
        temporary = package_path.with_suffix(".tmp")
        temporary.write_bytes(package)
        temporary.replace(package_path)
        stage_dir = Path(tempfile.mkdtemp(prefix="stage-", dir=UPDATE_ROOT))
        extract_update(package_path, stage_dir)
        backup = backup_manager()
        script = UPDATE_ROOT / "apply-update.sh"
        qstage = shlex.quote(str(stage_dir))
        qbackup = shlex.quote(str(backup))
        script.write_text(f"""#!/bin/sh
set -eu
sleep 2
install -m 0644 {qstage}/app.py /opt/lyrion-nanopi/app.py
install -d /opt/lyrion-nanopi/web
cp -a {qstage}/web/. /opt/lyrion-nanopi/web/
systemctl restart lyrion-nanopi.service
sleep 5
if ! systemctl is-active --quiet lyrion-nanopi.service; then
  restore_dir=$(mktemp -d)
  tar -xzf {qbackup} -C "$restore_dir"
  install -m 0644 "$restore_dir/app.py" /opt/lyrion-nanopi/app.py
  cp -a "$restore_dir/web/." /opt/lyrion-nanopi/web/
  systemctl restart lyrion-nanopi.service
  rm -rf "$restore_dir"
  exit 1
fi
rm -rf {qstage}
""", encoding="utf-8")
        os.chmod(script, 0o700)
        update_unit = f"lyrion-nanopi-update-{int(time.time())}"
        result = subprocess.run(
            ["systemd-run", "--unit", update_unit, "--collect", "/bin/sh", str(script)],
            text=True, capture_output=True, timeout=10, check=False,
        )
        if result.returncode != 0:
            raise RuntimeError("could not start the protected updater: " + (result.stderr.strip() or result.stdout.strip()))
        return web.json_response({
            "ok": True,
            "current_version": APP_VERSION,
            "target_version": manifest["version"],
            "message": "Update downloaded and verified. The player manager will restart.",
        })
    except Exception as error:
        if stage_dir and stage_dir.exists():
            shutil.rmtree(stage_dir, ignore_errors=True)
        return web.json_response({"ok": False, "error": str(error)}, status=400)


async def api_restart(_request):
    await start_player()
    return web.json_response({"ok": True})


async def login(request):
    error = ""
    if request.method == "POST":
        form = await request.post()
        if hmac.compare_digest(str(form.get("password", "")), SETUP_PASSWORD):
            response = web.HTTPFound("/")
            response.set_cookie(
                "lyrion_nanopi_auth", auth_token(), max_age=2592000,
                httponly=True, samesite="Strict",
            )
            return response
        error = '<p class="login-error">Incorrect password.</p>'
    html = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lyrion Player Setup</title><link rel="stylesheet" href="/assets/app.css"></head><body>
<header class="brand-header"><div class="brand-strip"><img src="/assets/lyrion.png" alt="Lyrion"><img src="/assets/avpro.png" alt="AVPro"><img src="/assets/rti.png" alt="RTI"><img src="/assets/skunkworks.png" alt="Skunk Works"></div><div class="brand-bar"><div class="brand-bar-inner"><div class="brand-title">Lyrion NanoPi Player</div></div></div></header>
<main class="page-shell"><h2>Lyrion Player Setup</h2><p>Enter the installer password to configure this unit.</p><form method="post" action="/login" style="max-width:560px">{error}<label class="field">Password<input name="password" type="password" autocomplete="current-password" autofocus required></label><button type="submit" style="margin-top:14px">Open Setup</button></form></main></body></html>""".format(error=error)
    return web.Response(text=html, content_type="text/html")


async def logout(_request):
    response = web.HTTPFound("/login")
    response.del_cookie("lyrion_nanopi_auth")
    return response


@web.middleware
async def auth_middleware(request, handler):
    if request.path.startswith("/assets/") or request.path in {"/login", "/logout"}:
        return await handler(request)
    if request_is_authenticated(request):
        return await handler(request)
    if request.path.startswith("/api/"):
        return web.json_response({"ok": False, "error": "Login required"}, status=401)
    raise web.HTTPFound("/login")


async def index(_request):
    response = web.FileResponse(Path(__file__).with_name("web") / "index.html")
    response.headers["Cache-Control"] = "no-store"
    return response


async def update_page(_request):
    html = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lyrion Player Update</title><link rel="stylesheet" href="/assets/app.css"></head><body>
<header class="brand-header"><div class="brand-strip"><img src="/assets/lyrion.png" alt="Lyrion"><img src="/assets/avpro.png" alt="AVPro"><img src="/assets/rti.png" alt="RTI"><img src="/assets/skunkworks.png" alt="Skunk Works"></div><div class="brand-bar"><div class="brand-bar-inner"><div class="brand-title">Lyrion NanoPi Player</div><a href="/logout" style="color:#c7ced8;font-size:12px">Logout</a></div></div></header>
<main class="page-shell"><h2>Player Update</h2><div class="page-nav"><a href="/" style="display:inline-block;padding:8px 13px;border:1px solid var(--line);border-radius:6px;background:#fff;color:var(--accent-dark);text-decoration:none">Player Setup</a><b>Update</b></div><form><h3>Lyrion NanoPi Player</h3><p class="help">Updates only the Lyrion NanoPi Player app and web pages. Your working system and audio setup are left unchanged.</p><div class="device-summary"><div><span>Installed version</span><strong>{APP_VERSION}</strong></div><div><span>Update source</span><strong>Lyrion</strong></div><div><span>Safety</span><strong>Verified with automatic recovery</strong></div></div><div style="display:flex;gap:10px;margin-top:18px"><button id="check" type="button">Check for Updates</button><button id="install" type="button" disabled>Download and Install</button></div><pre id="updateStatus" class="events" style="margin-top:14px;white-space:pre-wrap">Ready to check.</pre></form></main>
<script>
const statusBox=document.getElementById('updateStatus'),check=document.getElementById('check'),install=document.getElementById('install');let available=null;
check.onclick=async()=>{{install.disabled=true;statusBox.textContent='Checking GitHub release feed…';try{{const r=await fetch('/api/update/check',{{cache:'no-store'}}),d=await r.json();if(!d.ok)throw new Error(d.error||'Check failed');available=d;statusBox.textContent='Installed: '+d.current_version+'\\nAvailable: '+d.version+(d.notes?'\\n\\n'+d.notes:'')+(d.available?'\\n\\nUpdate is ready.':'\\n\\nNo newer update is available.');install.disabled=!d.available}}catch(e){{statusBox.textContent='Update check failed: '+e.message}}}};
install.onclick=async()=>{{if(!available||!confirm('Install NanoPi manager '+available.version+' now? Playback will briefly disconnect.'))return;check.disabled=install.disabled=true;statusBox.textContent='Downloading and verifying package…';try{{const r=await fetch('/api/update/install',{{method:'POST'}}),d=await r.json();if(!d.ok)throw new Error(d.error||'Install failed');statusBox.textContent=d.message+'\\nWaiting for version '+d.target_version+'…';let tries=0,t=setInterval(async()=>{{tries++;try{{const s=await fetch('/api/status?update='+Date.now(),{{cache:'no-store'}}),j=await s.json();if(j.appVersion===d.target_version){{clearInterval(t);statusBox.textContent='Update complete. Version '+j.appVersion+' is running. Refreshing…';setTimeout(()=>location.replace('/update?updated='+Date.now()),1200)}}}}catch(_e){{}}if(tries>60){{clearInterval(t);statusBox.textContent+='\\nRestart is taking longer than expected. Refresh this page.'}}}},2000)}}catch(e){{statusBox.textContent='Install failed: '+e.message;check.disabled=false}}}};
</script></body></html>"""
    return web.Response(text=html, content_type="text/html")


async def static_file(request):
    name = request.match_info["name"]
    if name not in {
        "app.css", "app.js", "lyrion.png", "avpro.png", "rti.png", "skunkworks.png"
    }:
        raise web.HTTPNotFound()
    response = web.FileResponse(Path(__file__).with_name("web") / name)
    if name in {"app.css", "app.js"}:
        response.headers["Cache-Control"] = "no-store"
    return response


async def on_startup(_app):
    global discovery_transport
    loop = asyncio.get_running_loop()
    try:
        discovery_transport, _ = await loop.create_datagram_endpoint(
            PlayerDiscoveryProtocol,
            local_addr=("0.0.0.0", DISCOVERY_PORT),
            allow_broadcast=True,
        )
        log("Player-only network discovery enabled")
    except OSError as error:
        log(f"Player-only discovery unavailable: {error}")
    config = load_config()
    if not config["server"]:
        rows = await asyncio.to_thread(discover_gadgets_sync)
        if len(rows) == 1:
            config["server"] = rows[0]["server"]
            save_config(config)
            log(f"Found {rows[0]['name']} at {rows[0]['server']}")
    await start_player()
    config = load_config()
    if config["server"]:
        asyncio.create_task(set_lms_fixed_volume(config["server"], config["fixed_volume"]))


async def on_cleanup(_app):
    global discovery_transport
    if discovery_transport:
        discovery_transport.close()
        discovery_transport = None
    await stop_player()


app = web.Application(client_max_size=32 * 1024, middlewares=[auth_middleware])
app.router.add_route("*", "/login", login)
app.router.add_get("/logout", logout)
app.router.add_get("/", index)
app.router.add_get("/setup", index)
app.router.add_get("/update", update_page)
app.router.add_get("/assets/{name}", static_file)
app.router.add_get("/api/status", api_status)
app.router.add_post("/api/config", api_save)
app.router.add_get("/api/discover", api_discover)
app.router.add_get("/api/update/check", api_update_check)
app.router.add_post("/api/update/install", api_update_install)
app.router.add_post("/api/restart", api_restart)
app.on_startup.append(on_startup)
app.on_cleanup.append(on_cleanup)

async def run_web_servers():
    """Serve the manager on both normal HTTP and the discovery port."""
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    if HTTP_PORT != PORT:
        try:
            await web.TCPSite(runner, "0.0.0.0", HTTP_PORT).start()
            log(f"Web manager available on ports {HTTP_PORT} and {PORT}")
        except OSError as error:
            log(f"Plain HTTP port {HTTP_PORT} unavailable: {error}")
    try:
        await asyncio.Event().wait()
    finally:
        await runner.cleanup()


if __name__ == "__main__":
    asyncio.run(run_web_servers())
