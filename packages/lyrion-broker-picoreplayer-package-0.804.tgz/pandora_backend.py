"""Pandora API compatibility service for the legacy Fusion LMS plugin."""

import threading
import time
from typing import Any, Dict, List


AIR_PARTNER = {
    "API_HOST": "internal-tuner.pandora.com/services/json/",
    "DECRYPTION_KEY": "U#IO$RZPAB%VX2",
    "ENCRYPTION_KEY": "2%3WCL*JU$MP]4",
    "PARTNER_USER": "pandora one",
    "PARTNER_PASSWORD": "TVCKIBGS9AO9TSYLNNFUML0743LH82D",
    "DEVICE": "D01",
    "AUDIO_QUALITY": "highQuality",
}

IOS_PARTNER = {
    "API_HOST": "tuner.pandora.com/services/json/",
    "DECRYPTION_KEY": "20zE1E47BE57$51",
    "ENCRYPTION_KEY": "721^26xE22776",
    "PARTNER_USER": "iphone",
    "PARTNER_PASSWORD": "P2E4FC0EAD3*878N92B2CDp34I0B1@388137C",
    "DEVICE": "IP01",
    "AUDIO_QUALITY": "highQuality",
}


class PandoraBackend:
    def __init__(self):
        self._lock = threading.RLock()
        self._clients: Dict[int, Dict[str, Any]] = {}
        self._playlists: Dict[str, List[Any]] = {}

    def invalidate(self) -> None:
        with self._lock:
            self._clients.clear()
            self._playlists.clear()

    def _client(self, account: int, config: Dict[str, Any]):
        username = str(config.get("username") or "").strip()
        password = str(config.get("password") or "")
        if not config.get("enabled") or not username or not password:
            raise RuntimeError("Pandora account is not configured")

        signature = (username, password)
        cached = self._clients.get(account)
        if cached and cached.get("signature") == signature:
            return cached["client"]

        from pandora.clientbuilder import SettingsDictBuilder

        client = SettingsDictBuilder(dict(AIR_PARTNER)).build()
        user = client.login(username, password)
        if not bool(user.get("isSubscriber")):
            client = SettingsDictBuilder(dict(IOS_PARTNER)).build()
            client.login(username, password)

        self._clients[account] = {
            "client": client,
            "signature": signature,
            "created": time.time(),
        }
        return client

    @staticmethod
    def _station(station: Any) -> Dict[str, Any]:
        return {
            "stationName": station.name,
            "stationId": station.id,
            "stationToken": station.token,
            "artUrl": station.art_url or "",
            "allowAddMusic": bool(station.can_add_music),
            "allowRename": bool(station.can_rename),
            "allowDelete": bool(station.can_delete),
        }

    @staticmethod
    def _track(track: Any, station_token: str) -> Dict[str, Any]:
        additional_urls = getattr(track, "additional_audio_urls", None) or {}
        mp3_url = ""
        for key, url in additional_urls.items():
            key_name = getattr(key, "value", str(key))
            if key_name == "HTTP_128_MP3":
                mp3_url = url
                break
        audio_url = mp3_url or getattr(track, "audio_url", "") or ""
        if getattr(track, "is_ad", False):
            track.prepare_playback()
            return {
                "songName": getattr(track, "title", "") or "Pandora Advertisement",
                "albumName": "",
                "artistName": getattr(track, "company_name", "") or "Pandora",
                "albumArtUrl": getattr(track, "image_url", "") or "",
                "artUrl": getattr(track, "image_url", "") or "",
                "trackGain": 0,
                "trackLength": 0,
                "trackToken": "",
                "stationId": getattr(track, "station_id", "") or station_token,
                "stationToken": station_token,
                "additionalAudioUrl": audio_url,
                "audioUrl": audio_url,
                "allowFeedback": False,
                "allowTiredOfTrack": False,
                "allowBookmarkTrack": False,
                "canSkip": False,
            }
        return {
            "songName": track.song_name or "",
            "albumName": track.album_name or "",
            "artistName": track.artist_name or "",
            "albumArtUrl": track.album_art_url or "",
            "artUrl": track.album_art_url or "",
            "trackGain": track.track_gain or 0,
            "trackLength": track.track_length or 0,
            "trackToken": track.track_token or "",
            "stationId": track.station_id or station_token,
            "stationToken": station_token,
            "additionalAudioUrl": audio_url,
            "audioUrl": audio_url,
            "allowFeedback": bool(track.allow_feedback),
            "allowTiredOfTrack": True,
            "allowBookmarkTrack": True,
            "canSkip": True,
        }

    def _next_track(self, client: Any, account: int, station_token: str) -> Dict[str, Any]:
        queue_key = f"{account}:{station_token}"
        tracks = self._playlists.get(queue_key) or []
        while not tracks:
            from pandora.models.playlist import AdditionalAudioUrl
            playlist = client.get_playlist(
                station_token,
                [AdditionalAudioUrl.HTTP_128_MP3],
            )
            tracks = [
                item for item in playlist
                if getattr(item, "audio_url", None)
            ]
            if not tracks:
                raise RuntimeError("Pandora returned no playable tracks")
        track = tracks.pop(0)
        self._playlists[queue_key] = tracks
        return self._track(track, station_token)

    @staticmethod
    def _search(client: Any, text: str, include_near: bool) -> Dict[str, Any]:
        result = client.search(text, include_near_matches=include_near)
        artists = [
            {
                "artistName": item.artist,
                "musicToken": item.token,
                "score": item.score,
            }
            for item in (result.artists or [])
        ]
        songs = [
            {
                "songName": item.song_name,
                "artistName": item.artist,
                "musicToken": item.token,
                "score": item.score,
            }
            for item in (result.songs or [])
        ]
        return {
            "artists": artists,
            "songs": songs,
            "nearMatchesAvailable": bool(result.nearest_matches_available),
        }

    def handle(self, account: int, action: str, params: Dict[str, str], config: Dict[str, Any]) -> Any:
        with self._lock:
            client = self._client(account, config)
            station_token = params.get("stationToken") or params.get("StationToken") or ""
            track_token = params.get("trackToken") or params.get("tracktoken") or ""

            if action == "get_account_name":
                return str(config.get("username") or "")
            if action == "list_user_stations":
                return [self._station(station) for station in client.get_station_list()]
            if action == "get_station":
                return self._station(client.get_station(station_token))
            if action == "get_next_track":
                return self._next_track(client, account, station_token)
            if action == "search_music":
                return self._search(
                    client,
                    params.get("searchText") or "",
                    str(params.get("includeNear") or "").lower() == "true",
                )
            if action == "list_genre_stations":
                genres = []
                for category, stations in client.get_genre_stations().items():
                    genres.append({
                        "categoryName": category,
                        "stations": [
                            {
                                "stationName": station.name,
                                "stationId": station.id,
                                "stationToken": station.token,
                                "artUrl": "",
                            }
                            for station in stations
                        ],
                    })
                return genres
            if action == "create_station":
                station = client.create_station(search_token=params.get("musicToken"))
                return self._station(station)
            if action == "create_station_from":
                from pandora.models.station import Station
                station = Station.from_json(client, client(
                    "station.createStation",
                    trackToken=params.get("musicToken"),
                    musicType=params.get("musicType") or "song",
                ))
                return self._station(station)
            if action == "add_music_to_station":
                return client.add_music(params.get("musicToken"), station_token)
            if action == "rename_station":
                return client.rename_station(station_token, params.get("name") or "")
            if action == "delete_station":
                self._playlists.pop(f"{account}:{station_token}", None)
                return client.delete_station(station_token)
            if action == "rate_track":
                return client.add_feedback(track_token, str(params.get("positive")) == "1")
            if action == "sleep_song":
                return client.sleep_song(track_token)
            if action == "explain_track":
                explanation = client.explain_track(track_token)
                if isinstance(explanation, dict):
                    return explanation.get("explanation") or explanation.get("text") or str(explanation)
                return str(explanation)
            if action == "add_bookmark":
                if params.get("kind") == "artist":
                    return client.add_artist_bookmark(track_token)
                return client.add_song_bookmark(track_token)
            raise ValueError(f"Unsupported Pandora action: {action}")
