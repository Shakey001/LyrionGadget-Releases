#!/usr/bin/env python3
"""
Lyrion Broker (WS-first) + CometD push + WS control (v0.433d)

Fixes "no push" by:
- Using /slim/<clientId>/response as the CometD response channel (not /request)
- Explicitly /meta/subscribe to that response channel after handshake
- Always doing a one-time player scan+subscribe at startup (even if RESCAN_SECS=0)

Env:
  LMS_BASE=http://127.0.0.1:9000
  BROKER_HOST=0.0.0.0
  BROKER_PORT=9099
  BROKER_DIFF=0|1
  STATUS_TAGS=alydKJ   (recommended; matches RTI Music style)
  STATUS_SUBSCRIBE_SECS=300
  RESCAN_SECS=0        (0 disables periodic rescan; startup scan still happens)
  FORCE_STATUS_AFTER_COMMAND=0|1
"""

import asyncio
import copy
import json
import base64
import hashlib
import hmac
import html as html_lib
import io
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import tarfile
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
import uuid
import zipfile
from collections import OrderedDict
from typing import Any, Dict, List, Optional, Set, Tuple

from aiohttp import web, ClientSession, ClientTimeout, WSMsgType
from PIL import Image, ImageOps
from pandora_backend import PandoraBackend

APP_VERSION = "0.804"

LEGAL_TERMS_VERSION = "2026-06-28"

LICENSE_TRIAL_DAYS = 7
LICENSE_BETA_TRIAL_DAYS = {"beta": 30, "beta2": 60}
LICENSE_PUBLIC_N_B64 = "1LxM7t7lr7oHSkkhu7f8kHweEvrVlj9NVMGhsdPAgHvqlZMS1BDEjb5u4SiQL0wGf9DaMrBzQif8EFyt-YPtJCEnlG5OOo5w3tXsKdkDG7usnguYlRNEm7Z8XQ_65R0bKJqGwkXM6NJmFXzWzwUJKvrgOivCuH-_MqnFJaj1BqfR4IO2Fv3ZbM8QBuTleFrklOpG1KItCk44kX_8p9_zKvvDgmaB4eyk26g2ZI2PTCupA5-eAW6VIjLVNk4uvTc8WWsMY2FXuPDRD57z-36JUIcCzNQ0RL7uKZ4Ok4uC0LG9f2bknISIFoLB373qGFSJt7uMCAn_3LMYRZ86tsj7Gw"
LICENSE_PUBLIC_E = 65537
LICENSE_SHA256_DIGEST_INFO = bytes.fromhex("3031300d060960864801650304020105000420")

# --- UDP discovery responder (for RTI ID config stream) ---
DISCOVERY_UDP_PORT = int(os.environ.get("BROKER_DISCOVERY_UDP_PORT", "9099"))
DISCOVERY_MAGIC = b"LYRION_BROKER_DISCOVER_v1"
DISCOVERY_NAME = os.environ.get("BROKER_NAME", "").strip()

LISTEN_HOST = os.getenv("BROKER_HOST", "0.0.0.0")
LISTEN_PORT = int(os.getenv("BROKER_PORT", "9099"))
BROKER_PUBLIC_BASE = os.getenv("BROKER_PUBLIC_BASE", "").strip().rstrip("/")

LMS_BASE = os.getenv("LMS_BASE", "http://127.0.0.1:9000").rstrip("/")
LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
LMS_COMETD = LMS_BASE + "/cometd"
LOCAL_LMS_BASE = "http://127.0.0.1:9000"
# Setup UI persistent config (when LMS_BASE env var is NOT set)
SETUP_JSON_PATH = os.getenv("BROKER_SETUP_JSON", "/opt/lyriongadget/broker_setup.json")
ADVANCED_SETUP_PASSWORD = os.getenv("BROKER_ADVANCED_PASSWORD", "LyrionGadget")
ADVANCED_AUTH_COOKIE = "lyrion_advanced_auth"
ADVANCED_AUTH_MAX_AGE = 8 * 60 * 60
PCP_CONFIG_PATH = "/usr/local/etc/pcp/pcp.cfg"
PCP_BROKER_LAUNCH_PATH = "/mnt/mmcblk0p2/tce/lyriongadget/launch-lyrion-broker-pcp.sh"
ASOUND_CONFIG_PATH = "/etc/asound.conf"
FILETOOL_LIST_PATH = "/opt/.filetool.lst"
DAC8X_ASOUND_BEGIN = "# BEGIN LYRION GADGET DAC8X"
DAC8X_ASOUND_END = "# END LYRION GADGET DAC8X"
MAX_UNIT_PLAYERS = 4
PI3_MAX_UNIT_PLAYERS = 3
CLONE_MAX_PLAYERS = 3
RTI_MAX_PLAYERS = 9
UPDATE_MAX_PACKAGE_BYTES = 32 * 1024 * 1024
DEFAULT_UPDATE_MANIFEST_URL = os.environ.get(
    "BROKER_UPDATE_MANIFEST_URL",
    "https://raw.githubusercontent.com/Shakey001/LyrionGadget-Releases/main/update.json",
).strip()
UPDATE_REQUIRED_FILES = {
    "lyrion_broker.py",
    "pandora_backend.py",
    "repair-picoreplayer.sh",
    "requirements.txt",
    "start-lyrion-broker-pcp.sh",
}

# Home menu keys (webpage controls which appear on RTI "Home" list)
HOME_MENU_DEFAULT = [
    {"key": "mymusic", "label": "My Music", "enabled": True, "order": 10, "type": "core", "source_label": "My Music"},
    {"key": "radio", "label": "Radio", "enabled": True, "order": 20, "type": "core", "source_label": "Radio"},
    {"key": "favorites", "label": "Favorites", "enabled": True, "order": 30, "type": "core", "source_label": "Favorites"},
]

RPC_TIMEOUT = float(os.getenv("RPC_TIMEOUT", "8"))

DEFAULT_PLAYERID = (os.getenv("DEFAULT_PLAYERID", "") or "").strip()

TRACK_META_CACHE: Dict[str, Dict[str, Any]] = {}
TRACK_META_CACHE_MAX = int(os.getenv("TRACK_META_CACHE_MAX", "2000"))

BROKER_ID = ""
LYRION_VERSION = ""

_np_station_by_playerid: Dict[str, str] = {}
_np_source_by_playerid: Dict[str, str] = {}
_pandora_station_by_playerid: Dict[str, str] = {}
_pandora_station_by_url: Dict[str, str] = {}
_random_mix_queue_players: Set[str] = set()
_podcast_refresh_generation: Dict[str, int] = {}
_podcast_players: Set[str] = set()
_np_path_by_playerid: Dict[str, str] = {}
pandora_backend = PandoraBackend()
_pandora_plugin_zip_cache: Dict[Tuple[str, str], bytes] = {}


def _b64u_decode(value: str) -> bytes:
    raw = _safe_str(value).strip()
    return base64.urlsafe_b64decode(raw + ("=" * ((4 - len(raw) % 4) % 4)))


def _normalize_license_mac(value: Any) -> str:
    chars = "".join(ch for ch in _safe_str(value).upper() if ch in "0123456789ABCDEF")
    if len(chars) != 12 or chars == "000000000000":
        return ""
    return ":".join(chars[i:i + 2] for i in range(0, 12, 2))


def _device_license_mac() -> str:
    override = _normalize_license_mac(os.getenv("BROKER_LICENSE_MAC", ""))
    if override:
        return override
    candidates: List[Tuple[int, str, str]] = []
    net_root = "/sys/class/net"
    try:
        for name in os.listdir(net_root):
            if name == "lo":
                continue
            try:
                with open(os.path.join(net_root, name, "address"), "r", encoding="ascii") as f:
                    mac = _normalize_license_mac(f.read())
            except Exception:
                continue
            if not mac:
                continue
            priority = 0 if name in ("eth0", "end0") else 1 if name.startswith(("eth", "en")) else 2 if name.startswith("wlan") else 3
            candidates.append((priority, name, mac))
    except Exception:
        pass
    if candidates:
        candidates.sort()
        return candidates[0][2]
    node = uuid.getnode()
    return _normalize_license_mac(f"{node:012X}")


def _verify_license_key(key: Any, device_mac: str) -> Tuple[bool, str]:
    text = _safe_str(key).strip()
    if not text:
        return False, "no_key"
    if text.lower() in LICENSE_BETA_TRIAL_DAYS:
        return False, "beta_trial"
    try:
        prefix, payload_b64, signature_b64 = text.split(".", 2)
        if prefix != "LYR1":
            return False, "bad_format"
        payload_bytes = _b64u_decode(payload_b64)
        signature = _b64u_decode(signature_b64)
        payload = json.loads(payload_bytes.decode("utf-8"))
        if not isinstance(payload, dict) or _safe_int(payload.get("v"), 0) != 1:
            return False, "bad_payload"
        if _normalize_license_mac(payload.get("mac")) != _normalize_license_mac(device_mac):
            return False, "wrong_mac"
        expires = _safe_int(payload.get("expires"), 0)
        if expires and time.time() > expires:
            return False, "key_expired"

        modulus = int.from_bytes(_b64u_decode(LICENSE_PUBLIC_N_B64), "big")
        size = (modulus.bit_length() + 7) // 8
        if len(signature) != size:
            return False, "bad_signature"
        encoded = pow(int.from_bytes(signature, "big"), LICENSE_PUBLIC_E, modulus).to_bytes(size, "big")
        digest_info = LICENSE_SHA256_DIGEST_INFO + hashlib.sha256(payload_bytes).digest()
        padding_len = size - len(digest_info) - 3
        expected = b"\x00\x01" + (b"\xff" * padding_len) + b"\x00" + digest_info
        if padding_len < 8 or not hmac.compare_digest(encoded, expected):
            return False, "bad_signature"
        return True, "licensed"
    except Exception:
        return False, "bad_format"


def _license_status(now: Optional[float] = None) -> Dict[str, Any]:
    current = time.time() if now is None else float(now)
    mac = _device_license_mac()
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    key_valid, key_reason = _verify_license_key(license_key, mac)
    trial_days = LICENSE_BETA_TRIAL_DAYS.get(license_key.lower(), LICENSE_TRIAL_DAYS)
    trial_start = float(_setup_cache.get("license_trial_started_at") or 0)
    trial_end = trial_start + (trial_days * 86400) if trial_start > 0 else 0
    remaining = max(0, int(trial_end - current)) if trial_end else trial_days * 86400
    trial_valid = bool(trial_end and current < trial_end)
    return {
        "valid": bool(key_valid or trial_valid),
        "state": "licensed" if key_valid else "trial" if trial_valid else "expired",
        "reason": key_reason if not key_valid and not trial_valid else "",
        "device_mac": mac,
        "trial_days": trial_days,
        "trial_started_at": int(trial_start),
        "trial_ends_at": int(trial_end),
        "trial_seconds_remaining": remaining,
        "key_valid": key_valid,
    }


def _legal_terms_accepted() -> bool:
    return (
        bool(_setup_cache.get("legal_accepted", False))
        and _safe_str(_setup_cache.get("legal_terms_version")) == LEGAL_TERMS_VERSION
    )


def _ensure_license_trial_started() -> None:
    if float(_setup_cache.get("license_trial_started_at") or 0) > 0:
        return
    _setup_cache["license_trial_started_at"] = int(time.time())
    _save_setup_config()

def _clean_text(v: Any) -> str:
    s = _safe_str(v).strip()
    if not s:
        return ""
    if s.lower() in ("null", "none", "undefined", "n/a"):
        return ""
    return s

def _is_internal_label(s: str) -> bool:
    n = _norm_key(s)
    return n in ("pyrrha", "apppyrrha", "pandora", "frpandora0", "appfrpandora0", "spotty", "spotify")

def _provider_from_payload(payload: Dict[str, Any]) -> str:
    try:
        for obj in (payload.get("remoteMeta") or {}, payload, _current_playlist_item(payload) or {}):
            btns = obj.get("buttons") if isinstance(obj, dict) else None
            if isinstance(btns, dict):
                for bk in ("repeat", "shuffle"):
                    b = btns.get(bk)
                    if isinstance(b, dict):
                        cmd = b.get("command")
                        if isinstance(cmd, list) and cmd:
                            head = _safe_str(cmd[0]).strip().lower()
                            if head.startswith("fr_pandora"):
                                return "pandora"
                            if head.startswith("spotty") or head.startswith("spotify"):
                                return "spotify"
        cur = _current_playlist_item(payload) or {}
        rm = payload.get("remoteMeta") or {}
        current_path = " ".join(
            _safe_str(cur.get(k)).strip().lower()
            for k in ("url", "file", "uri", "path")
            if isinstance(cur, dict)
        )
        if current_path.startswith("file://"):
            return "mymusic"
        hay = " ".join(_safe_str(x).strip().lower() for x in (
            payload.get("url"), payload.get("file"), payload.get("uri"), payload.get("path"),
            payload.get("remote_url"), payload.get("source"), payload.get("plugin"),
            payload.get("artwork_url"), payload.get("artwork_url2"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            rm.get("source") if isinstance(rm, dict) else "",
            rm.get("artwork_url") if isinstance(rm, dict) else "",
            rm.get("artwork_url2") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
            cur.get("type") if isinstance(cur, dict) else "",
            cur.get("artwork_url") if isinstance(cur, dict) else "",
        ))
        if "spotify:" in hay or "spotty" in hay:
            return "spotify"
        if "fr_pandora" in hay or "pandora" in hay or "pyrrha" in hay:
            return "pandora"
        if "airplay://" in hay or "raop://" in hay or "shairtunes" in hay:
            return "airplay"
        if "podcast:" in hay or "podcasts:" in hay or "/podcast" in hay:
            return "podcast"
        if "tunein" in hay or "/plugins/tunein/" in hay or "secure shoutcast" in hay:
            return "radio"
        if (
            "iheart" in hay
            or "iheartradio" in hay
            or "ihrhls" in hay
            or "iheart.com" in hay
        ):
            return "iheart"
        if _safe_int(payload.get("remote"), 0) != 0 and _safe_int(payload.get("playlist_tracks"), 0) <= 1:
            return "radio"
        if isinstance(cur, dict):
            if _safe_int(cur.get("track_id"), 0) > 0 or _safe_int(cur.get("id"), 0) > 0:
                return "mymusic"
        if isinstance(payload.get("playlist_loop"), list) and _safe_int(payload.get("playlist_tracks"), 0) > 0:
            return "mymusic"
    except Exception:
        pass
    return ""

def _configured_source_label(provider: str) -> str:
    p = _norm_key(provider)
    if not p:
        return ""
    try:
        rows = _setup_cache.get("home_menu") or _home_menu_cache or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            key = _norm_key(row.get("key"))
            vals = [key, row.get("label"), row.get("source_label")]
            joined = " ".join([_safe_str(x) for x in vals]).lower()
            matched = key == p
            if p == "pandora":
                matched = "pandora" in joined or "pyrrha" in joined or "fr_pandora" in joined
            elif p == "pyrrha":
                matched = "pyrrha" in joined
            elif p == "spotify":
                matched = "spotty" in joined or "spotify" in joined
            if matched:
                lab = _clean_text(row.get("label") or row.get("source_label"))
                if lab and not _is_internal_label(lab):
                    return lab
    except Exception:
        pass
    return ""

def _payload_is_pyrrha(payload: Dict[str, Any]) -> bool:
    try:
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        cur = _current_playlist_item(payload) or {}
        vals = [
            payload.get("np_path"), payload.get("path"), payload.get("url"), payload.get("file"), payload.get("uri"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
        ]
        for item in payload.get("playlist_loop") or []:
            if isinstance(item, dict):
                vals.extend([item.get("url"), item.get("file"), item.get("uri")])
        return any(_safe_str(v).strip().lower().startswith("pyrrha:") for v in vals)
    except Exception:
        return False

def _payload_pandora_instance_index(payload: Dict[str, Any]) -> Optional[int]:
    try:
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        cur = _current_playlist_item(payload) or {}
        vals = [
            payload.get("np_path"), payload.get("path"), payload.get("url"), payload.get("file"), payload.get("uri"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
        ]
        for item in payload.get("playlist_loop") or []:
            if isinstance(item, dict):
                vals.extend([item.get("url"), item.get("file"), item.get("uri")])
        for v in vals:
            m = _re.match(r"^\s*frpandora([0-3])\s*:", _safe_str(v), flags=_re.I)
            if m:
                return _safe_int(m.group(1), -1)
    except Exception:
        pass
    return None

def _configured_pandora_instance_label(index: Optional[int]) -> str:
    if index is None or index < 0 or index > 3:
        return _configured_source_label("pandora")
    letter = chr(65 + index)
    tokens = {
        f"frpandora{index}",
        f"fr_pandora_{index}",
        f"pandora{letter.lower()}",
        f"pandora {letter.lower()}",
    }
    try:
        rows = _setup_cache.get("home_menu") or _home_menu_cache or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            joined = " ".join(_safe_str(x).lower() for x in (row.get("key"), row.get("label"), row.get("source_label")))
            norm_joined = _norm_key(joined)
            if (
                f"frpandora{index}" in norm_joined
                or f"fr_pandora_{index}" in joined
                or f"pandora{letter.lower()}" in norm_joined
                or any(t in joined for t in tokens)
            ):
                lab = _clean_text(row.get("label") or row.get("source_label"))
                if lab and not _is_internal_label(lab):
                    return lab
    except Exception:
        pass
    try:
        accounts = _pandora_accounts_cache()
        if index < len(accounts):
            name = _clean_text(accounts[index].get("name"))
            if name:
                return name
    except Exception:
        pass
    return f"Pandora {letter}"

def _cached_source_for_provider(pid: str, provider: str) -> str:
    cached = _clean_text(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()))
    if not cached:
        return ""
    c = _norm_key(cached)
    p = _norm_key(provider)
    if p == "pandora" and ("pandora" in c or "pyrrha" in c):
        return cached
    if p == "pyrrha" and "pyrrha" in c:
        return cached
    if p == "spotify" and ("spotify" in c or "spotty" in c):
        return cached
    if p == "radio" and ("radio" in c or "tunein" in c or "iheart" in c):
        return cached
    if p == "iheart" and ("iheart" in c or "radio" in c):
        return cached if "iheart" in c else ""
    if p == "podcast" and ("podcast" in c or "podcasts" in c):
        return cached
    if p == "mymusic" and c in ("mymusic", "mymusiclibrary", "library"):
        return cached
    return ""

def _current_player_provider(pid: str, payload: Optional[Dict[str, Any]] = None) -> str:
    snap = payload if isinstance(payload, dict) and payload else (_last_status_by_key.get(pid) or _last_status_by_key.get(pid.lower()) or {})
    provider = _provider_from_payload(snap) if isinstance(snap, dict) else ""
    if provider:
        return provider
    src = _norm_key(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()) or "")
    if "pandora" in src or "pyrrha" in src:
        return "pandora"
    if "spotify" in src or "spotty" in src:
        return "spotify"
    if "iheart" in src:
        return "iheart"
    if "podcast" in src:
        return "podcast"
    if "radio" in src or "tunein" in src:
        return "radio"
    return ""

def _random_mix_active(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    raw = payload.get("randomplay")
    text = _safe_str(raw).strip().lower()
    if text not in ("", "0", "off", "false", "none", "disable", "disabled"):
        return True
    playlist_mode = _safe_str(
        payload.get("playlist mode", payload.get("playlist_mode"))
    ).strip().lower()
    return "random" in playlist_mode


def _is_podcast_item(item: Any) -> bool:
    if not isinstance(item, dict):
        return False
    hay = " ".join(_safe_str(item.get(key)).lower() for key in (
        "url", "uri", "file", "path", "artwork_url", "artwork_url2", "type", "source"
    ))
    return "/podcast" in hay or "podcast:" in hay or "podcasts:" in hay


def _is_podcast_episode_actions(actions: Any) -> bool:
    if not isinstance(actions, dict):
        return False
    # TuneIn podcast categories expose both play and go/items. The go target
    # means this is a browse node even when touchToPlaySingle is also present.
    if isinstance(actions.get("go"), dict):
        return False
    play = actions.get("play") if isinstance(actions.get("play"), dict) else {}
    play_cmd = play.get("cmd") if isinstance(play.get("cmd"), list) else []
    play_params = play.get("params") if isinstance(play.get("params"), dict) else {}
    if (
        len(play_cmd) >= 3
        and _safe_str(play_cmd[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(play_cmd[1]).strip().lower() == "playlist"
        and _safe_str(play_cmd[2]).strip().lower() == "play"
        and _safe_int(play_params.get("touchToPlaySingle"), 0) == 1
    ):
        return True

    # Older podcast rows identify an episode through playControl and do not
    # expose a separate drill destination.
    for name, action in actions.items():
        if not isinstance(action, dict):
            continue
        cmd = action.get("cmd") if isinstance(action.get("cmd"), list) else []
        params = action.get("params") if isinstance(action.get("params"), dict) else {}
        head = _safe_str(cmd[0]).strip().lower() if cmd else ""
        menu = _safe_str(params.get("menu")).strip().lower()
        if (
            name.lower() == "playcontrol"
            and (head in ("podcast", "podcasts") or menu in ("podcast", "podcasts"))
        ):
            return True
    return False


async def _verify_random_mix_start(pid: str, args: Any, response: Any) -> Any:
    if (
        not isinstance(args, list)
        or len(args) < 2
        or _safe_str(args[0]).strip().lower() != "randomplay"
        or _safe_str(args[1]).strip().lower() in ("disable", "off")
    ):
        return response
    await asyncio.sleep(0.9)
    try:
        check = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
        payload = (check.get("result") or {}) if isinstance(check, dict) else {}
        if not _random_mix_active(payload):
            dbg(f"RANDOM MIX start not active for {pid}; retrying {_safe_str(args[1])} once")
            return await lms.rpc(pid, args)
    except Exception as e:
        dbg(f"RANDOM MIX start verification failed: {type(e).__name__}: {_safe_str(e)}")
    return response

def _provider_from_action_args(args: Any) -> str:
    if not isinstance(args, list) or not args:
        return ""
    head = _safe_str(args[0]).strip().lower()
    joined = " ".join(_safe_str(x).strip().lower() for x in args)
    if head.startswith("fr_pandora") or head == "pyrrha" or "menu:fr_pandora" in joined or "menu:pyrrha" in joined:
        return "pandora"
    if head in ("spotty", "spotify") or "spotify:" in joined or "menu:spotty" in joined:
        return "spotify"
    if head in ("iheartradio", "fr_iheartradio") or "iheart" in joined:
        return "radio"
    if head in ("playlistcontrol", "browselibrary") or "menu:1" in joined or "track_id:" in joined or "album_id:" in joined or "artist_id:" in joined or "playlist_id:" in joined:
        return "mymusic"
    return ""

def _recursive_first(obj: Any, keys: Tuple[str, ...], max_depth: int = 4) -> str:
    try:
        if max_depth < 0:
            return ""
        if isinstance(obj, dict):
            for k in keys:
                if k in obj:
                    s = _clean_text(obj.get(k))
                    if s:
                        return s
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    s = _recursive_first(v, keys, max_depth - 1)
                    if s:
                        return s
        elif isinstance(obj, list):
            for v in obj:
                if isinstance(v, (dict, list)):
                    s = _recursive_first(v, keys, max_depth - 1)
                    if s:
                        return s
    except Exception:
        pass
    return ""

def _now_playing_path(payload: Dict[str, Any], rm: Dict[str, Any], cur: Dict[str, Any]) -> str:
    for obj in (payload, rm, cur):
        if not isinstance(obj, dict):
            continue
        for key in ("path", "url", "file", "track_path", "stream_url", "remote_url", "uri"):
            path = _clean_text(obj.get(key))
            if path:
                return path
    return ""

def _iheart_station_from_payload(payload: Dict[str, Any]) -> str:
    try:
        current_title = _clean_text(payload.get("current_title"))
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        current_track = _clean_text(rm.get("title") if isinstance(rm, dict) else "")
        for item in payload.get("playlist_loop") or []:
            if not isinstance(item, dict):
                continue
            title = _clean_text(item.get("title")).splitlines()[0].strip()
            if not title or _is_internal_label(title):
                continue
            if _clean_text(item.get("artist")):
                continue
            if title == current_title or title == current_track:
                continue
            hay = " ".join(_safe_str(item.get(k)).lower() for k in ("url", "file", "uri", "artwork_url", "artwork_url2"))
            if not any(token in hay for token in ("iheart", "ihrhls", "revma.", "streamtheworld.com", "amperwave", "audacy")):
                continue
            title = _re.sub(r"\s*\((?:secure\s+)?shoutcast\)\s*$", "", title, flags=_re.I).strip()
            return title
        if isinstance(rm, dict) and not _clean_text(rm.get("artist")) and _safe_int(rm.get("duration"), 0) <= 0:
            title = _clean_text(rm.get("title")).splitlines()[0].strip()
            if title and not _is_internal_label(title) and title != current_title:
                return title
        if current_title and " - " not in current_title and not _is_internal_label(current_title):
            return current_title.splitlines()[0].strip()
    except Exception:
        pass
    return ""

def _normalize_player_display_fields(pid: str, payload: Dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        return
    rm = payload.get("remoteMeta") or {}
    cur = _current_playlist_item(payload) or {}

    genre = _clean_text(payload.get("genre") or (rm.get("genre") if isinstance(rm, dict) else "") or cur.get("genre") or payload.get("genres") or (rm.get("genres") if isinstance(rm, dict) else ""))
    if genre:
        payload["np_genre"] = genre

    path = _now_playing_path(payload, rm if isinstance(rm, dict) else {}, cur if isinstance(cur, dict) else {})
    if path:
        _np_path_by_playerid[pid] = path
        payload["np_path"] = path
    else:
        payload["np_path"] = ""

    provider = _provider_from_payload(payload)
    if provider == "mymusic" and _safe_int(payload.get("remote"), 0) != 0:
        cached_provider = _current_player_provider(pid, payload={})
        if cached_provider in ("iheart", "radio") and _safe_int(payload.get("duration"), 0) <= 0:
            provider = cached_provider
    current_id = _safe_str(cur.get("id")).strip() if isinstance(cur, dict) else ""
    if provider in ("spotify", "pandora") or (current_id.isdigit() and _safe_int(current_id, 0) > 0):
        _podcast_players.discard(pid.lower())
    if not provider:
        known_art = _safe_str(_main_art_source_by_playerid.get(pid) or _main_art_source_by_playerid.get(pid.lower())).lower()
        rm_duration = (rm.get("duration") if isinstance(rm, dict) else None)
        cached_source = _norm_key(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()))
        if "iheart" in known_art or (
            cached_source == "radio"
            and _safe_int(payload.get("remote"), 0) != 0
            and _safe_int(payload.get("duration") if payload.get("duration") is not None else rm_duration, 0) <= 0
        ):
            provider = "radio"
    source = ""
    if provider == "pandora":
        if _payload_is_pyrrha(payload):
            source = _configured_source_label("pyrrha") or _cached_source_for_provider(pid, "pyrrha") or "Pyrrha"
        else:
            source = _configured_pandora_instance_label(_payload_pandora_instance_index(payload)) or _cached_source_for_provider(pid, "pandora") or "Pandora"
    elif provider == "spotify":
        source = _configured_source_label("spotify") or _cached_source_for_provider(pid, "spotify") or "Spotify"
    elif provider == "iheart":
        source = _configured_source_label("iheart") or _cached_source_for_provider(pid, "iheart") or "iHeartRadio"
    elif provider == "podcast":
        source = _configured_source_label("podcast") or _cached_source_for_provider(pid, "podcast") or "Podcasts"
    elif provider == "airplay":
        source = _configured_source_label("airplay") or _cached_source_for_provider(pid, "airplay") or "Airplay 2"
    elif provider == "radio":
        source = _configured_source_label("radio") or _cached_source_for_provider(pid, "radio") or "Radio"
    elif provider == "mymusic":
        source = _configured_source_label("mymusic") or "My Music"
    else:
        source = _clean_text(payload.get("np_source") or payload.get("source") or (rm.get("source") if isinstance(rm, dict) else "") or payload.get("service") or payload.get("plugin"))
    if provider:
        payload["is_live_radio"] = provider in ("radio", "iheart")
        payload["genre"] = genre
        payload["np_genre"] = genre
        safe_path = path
        if not safe_path or len(safe_path) > 512:
            safe_path = provider
        payload["np_path"] = safe_path
        _np_path_by_playerid[pid] = safe_path
    generic = _norm_key(source)
    if provider not in ("radio", "iheart") and generic in ("playthisstation", "play", "radio", "station"):
        source = _cached_source_for_provider(pid, provider)
    if source:
        _np_source_by_playerid[pid] = source
        payload["np_source"] = source

    station = _clean_text(payload.get("station") or payload.get("station_name"))
    if not station and isinstance(rm, dict):
        station = _clean_text(rm.get("station") or rm.get("station_name"))
    if not station:
        cand_remote = _clean_text(payload.get("remote_title") or (rm.get("remote_title") if isinstance(rm, dict) else ""))
        if cand_remote and not _is_internal_label(cand_remote) and _norm_key(cand_remote) not in ("playthisstation", "play", "radio", "station"):
            station = cand_remote
    if provider == "iheart" and not station:
        station = _iheart_station_from_payload(payload)
    if not station:
        cand = _clean_text(payload.get("source") or (rm.get("source") if isinstance(rm, dict) else ""))
        bad = {
            _clean_text(payload.get("title")),
            _clean_text(payload.get("current_title")),
            _clean_text(payload.get("np_source")),
            _clean_text(_np_source_by_playerid.get(pid)),
            "Play this station",
            "Play",
            "Radio",
            "Station",
        }
        if cand and cand not in bad and not _is_internal_label(cand):
            station = cand
    if provider == "airplay":
        station = "Use AirPlay device for control"
        _np_station_by_playerid[pid] = station
        _np_station_by_playerid[pid.lower()] = station
        payload["np_station"] = station
    elif station:
        _np_station_by_playerid[pid] = station
        payload["np_station"] = station
    elif provider == "pandora":
        path_key = _pandora_url_key(payload.get("np_path") or path)
        st = _clean_text(
            _pandora_station_by_url.get(path_key)
            or _pandora_station_by_playerid.get(pid)
            or _pandora_station_by_playerid.get(pid.lower())
            or _np_station_by_playerid.get(pid)
            or _np_station_by_playerid.get(pid.lower())
        )
        payload["np_station"] = st
    elif provider == "iheart":
        st = _clean_text(_np_station_by_playerid.get(pid) or _np_station_by_playerid.get(pid.lower()))
        payload["np_station"] = st
    elif provider in ("mymusic", "spotify", "podcast", "pandora"):
        _np_station_by_playerid.pop(pid, None)
        _np_station_by_playerid.pop(pid.lower(), None)
        payload["np_station"] = ""
    else:
        st = _clean_text(_np_station_by_playerid.get(pid))
        if st:
            payload["np_station"] = st

    btns = None
    for obj in (payload, rm, cur):
        if isinstance(obj, dict) and isinstance(obj.get("buttons"), dict):
            btns = obj.get("buttons")
            break

    def is_pandora_rate_button(name: str, value: int) -> bool:
        if not isinstance(btns, dict):
            return False
        button = btns.get(name)
        if not isinstance(button, dict):
            return False
        command = button.get("command")
        return (
            isinstance(command, list)
            and len(command) >= 3
            and _provider_from_action_args(command) == "pandora"
            and _safe_str(command[1]).strip().lower() == "rate"
            and _safe_int(command[2], -1) == value
        )

    can_rate_positive = (
        is_pandora_rate_button("repeat", 1)
    )
    can_rate_negative = (
        is_pandora_rate_button("shuffle", 0)
    )
    payload["canRatePositive"] = can_rate_positive
    payload["canThumbsUp"] = can_rate_positive
    payload["canRateNegative"] = can_rate_negative
    payload["canThumbsDown"] = can_rate_negative
    payload["canRate"] = can_rate_positive or can_rate_negative


async def _supplement_player_display_fields(pid: str, payload: Dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        return
    need_path = not _clean_text(payload.get("np_path"))
    need_source = not _clean_text(payload.get("np_source"))
    need_station = not _clean_text(payload.get("np_station"))
    if not (need_path or need_source or need_station):
        return
    try:
        r = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
        full = (r.get("result") or {}) if isinstance(r, dict) else {}
        if not isinstance(full, dict) or not full:
            return
        _normalize_art_fields(full)
        _enrich_status_payload(full, pid)
        _normalize_player_display_fields(pid, full)
        if need_path:
            rm = full.get("remoteMeta") or {}
            cur = _current_playlist_item(full) or {}
            path = _clean_text(full.get("np_path") or _now_playing_path(full, rm if isinstance(rm, dict) else {}, cur if isinstance(cur, dict) else {}))
            if path:
                _np_path_by_playerid[pid] = path
                payload["np_path"] = path
        if need_source:
            src = _clean_text(full.get("np_source"))
            if src:
                _np_source_by_playerid[pid] = src
                payload["np_source"] = src
        if need_station:
            st = _clean_text(full.get("np_station"))
            if st:
                _np_station_by_playerid[pid] = st
                payload["np_station"] = st
    except Exception:
        pass


# RTI Music style tags (album/artist/title/duration/artwork/etc). Override if you want.
STATUS_TAGS = os.getenv("STATUS_TAGS", "aglydKJpu")

# How many playlist items to include in CometD subscribe status responses (queue window)
STATUS_SUBSCRIBE_COUNT = int(os.getenv("STATUS_SUBSCRIBE_COUNT", "50"))
if STATUS_SUBSCRIBE_COUNT < 1: STATUS_SUBSCRIBE_COUNT = 1
if STATUS_SUBSCRIBE_COUNT > 200: STATUS_SUBSCRIBE_COUNT = 200
STATUS_SUBSCRIBE_SECS = int(os.getenv("STATUS_SUBSCRIBE_SECS", "300"))
if STATUS_SUBSCRIBE_SECS < 0: STATUS_SUBSCRIBE_SECS = 0
if STATUS_SUBSCRIBE_SECS > 3600: STATUS_SUBSCRIBE_SECS = 3600
STATUS_SUBSCRIBE_RENEW_MARGIN_SECS = float(os.getenv("STATUS_SUBSCRIBE_RENEW_MARGIN_SECS", "30"))
if STATUS_SUBSCRIBE_RENEW_MARGIN_SECS < 1: STATUS_SUBSCRIBE_RENEW_MARGIN_SECS = 1

# How often to rescan LMS for new players and subscribe them (seconds)
RESCAN_SECS = float(os.getenv("RESCAN_SECS", "0"))

# 0 = passthrough full payload on change (no broker diff)
# 1 = broker diff (only changed keys; first full)
BROKER_DIFF = (os.getenv("BROKER_DIFF", "1").strip() == "1")

# 0 = trust CometD long-poll status changes after commands.
# 1 = also do one-shot status reads after selected write commands for debugging/legacy panels.
FORCE_STATUS_AFTER_COMMAND = (os.getenv("FORCE_STATUS_AFTER_COMMAND", "0").strip() == "1")

# CometD status pushes from LMS often omit queue mode fields when another
# controller changes them. Probe lightly so RTI stays in sync with external UI.
TRANSPORT_MODE_VERIFY_DELAY_SECS = float(os.getenv("TRANSPORT_MODE_VERIFY_DELAY_SECS", "0.45"))
if TRANSPORT_MODE_VERIFY_DELAY_SECS < 0.1:
    TRANSPORT_MODE_VERIFY_DELAY_SECS = 0.1
if TRANSPORT_MODE_VERIFY_DELAY_SECS > 5:
    TRANSPORT_MODE_VERIFY_DELAY_SECS = 5

# RTI XP can receive WebSocket data before its upgrade callback has settled.
# Give the driver a small quiet window after prepare() before sending hello/status.
RTI_WS_FIRST_SEND_DELAY_SECS = float(os.getenv("RTI_WS_FIRST_SEND_DELAY_SECS", "0.75"))
if RTI_WS_FIRST_SEND_DELAY_SECS < 0:
    RTI_WS_FIRST_SEND_DELAY_SECS = 0
if RTI_WS_FIRST_SEND_DELAY_SECS > 10:
    RTI_WS_FIRST_SEND_DELAY_SECS = 10



def dbg(msg: str) -> None:
    try:
        print(msg, flush=True)
    except Exception:
        pass



def _compute_broker_id() -> str:
    try:
        node = uuid.getnode()
        # Treat the hardware MAC as authoritative enough for a stable broker ID.
        tail = ("%012X" % int(node))[-4:]
        return "Lyrion" + tail
    except Exception:
        return "Lyrion0000"


async def _fetch_lyrion_version() -> str:
    try:
        r = await lms.rpc("", ["serverstatus", 0, 1])
        res = (r.get("result") or {}) if isinstance(r, dict) else {}
        for k in ("version", "serverversion", "server_version"):
            v = _safe_str(res.get(k)).strip()
            if v:
                return v
    except Exception as e:
        dbg("Lyrion version fetch failed: " + _safe_str(e))
    return ""


async def _refresh_server_meta() -> None:
    global BROKER_ID, LYRION_VERSION
    if not BROKER_ID:
        BROKER_ID = _compute_broker_id()
    try:
        ver = await _fetch_lyrion_version()
        if ver:
            LYRION_VERSION = ver
    except Exception:
        pass


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def _safe_str(x: Any) -> str:
    if x is None:
        return ""
    try:
        return str(x)
    except Exception:
        return ""




def _is_loopback_host(h: str) -> bool:
    h = _safe_str(h).strip().lower()
    return h in ("", "127.0.0.1", "localhost", "::1")


def _guess_local_base(port: int = 9000) -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = _safe_str(s.getsockname()[0]).strip()
        finally:
            s.close()
        if ip and not _is_loopback_host(ip):
            return f"http://{ip}:{port}"
    except Exception:
        pass
    return ""


def _public_lms_base() -> str:
    # Priority: saved setup/public -> env hint -> effective LMS_BASE when non-loopback -> guessed local host
    saved = _safe_str(_setup_cache.get("public_lms_base")).strip().rstrip("/") if isinstance(_setup_cache, dict) else ""
    if saved:
        return saved
    envb = _safe_str(os.getenv("PUBLIC_LMS_BASE")).strip().rstrip("/")
    if envb:
        return envb
    try:
        pu = urllib.parse.urlsplit(LMS_BASE)
        if pu.scheme and pu.netloc and not _is_loopback_host(pu.hostname or ""):
            return LMS_BASE.rstrip("/")
        if pu.scheme and pu.port:
            guessed = _guess_local_base(pu.port)
            if guessed:
                return guessed.rstrip("/")
    except Exception:
        pass
    guessed = _guess_local_base(9000)
    if guessed:
        return guessed.rstrip("/")
    return ""


def _public_broker_base() -> str:
    base = _safe_str(BROKER_PUBLIC_BASE).strip().rstrip("/")
    if base:
        return base
    guessed = _guess_local_base(LISTEN_PORT)
    if guessed:
        return guessed.rstrip("/")
    return f"http://127.0.0.1:{LISTEN_PORT}"


def _b64u_text(s: str) -> str:
    raw = _safe_str(s).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_text_dec(s: str) -> str:
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8")


def _broker_main_art_url(playerid: str, version: Any = "", size: int = 500) -> str:
    base = _public_broker_base().rstrip("/")
    q = {"playerid": _safe_str(playerid), "size": str(size)}
    v = _safe_str(version)
    if v:
        q["v"] = v
    return base + "/art/main?" + urllib.parse.urlencode(q)


def _broker_list_art_url(item_id: str, version: Any = "") -> str:
    base = _public_broker_base().rstrip("/")
    q = {"id": _safe_str(item_id)}
    v = _safe_str(version)
    if v:
        q["v"] = v
    return base + "/art/list?" + urllib.parse.urlencode(q)


def _player_list_art_id(playerid: str) -> str:
    return "p." + _b64u_text(_safe_str(playerid).strip())


def _extract_cover_id_from_pathish(u: str) -> str:
    s = _safe_str(u).strip()
    if not s:
        return ""
    try:
        p = urllib.parse.urlsplit(s)
        path = p.path or s
    except Exception:
        path = s
    m = _re.search(r"/music/([^/]+)/cover(?:_[0-9]+x[0-9]+_o)?$", path, flags=_re.IGNORECASE)
    if m:
        return _safe_str(m.group(1))
    return ""


def _resize_local_cover_path(path: str, size: int) -> str:
    p = _safe_str(path).strip()
    if not p:
        return p
    if _re.search(r"/music/[^/]+/cover(?:_[0-9]+x[0-9]+_o)?$", p, flags=_re.IGNORECASE):
        p = _re.sub(r"/cover(?:_[0-9]+x[0-9]+_o)?$", f"/cover_{size}x{size}_o", p, flags=_re.IGNORECASE)
    return p


def _fallback_art_path(size: int) -> str:
    return f"/music/0/cover_{size}x{size}_o"


def _candidate_item_ids(it: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    for k in ("coverid", "cover_id", "artwork_track_id", "id"):
        v = _safe_str(it.get(k)).strip()
        if v and v not in out:
            out.append(v)
    src = _safe_str(it.get("artwork_url") or "").strip()
    cid = _extract_cover_id_from_pathish(src)
    if cid and cid not in out:
        out.append(cid)
    return out


def _item_list_art_id(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return "0"

    src = _safe_str(it.get("artwork_url") or "").strip()
    if src and not _is_broker_art_url(src):
        norm = _normalize_art_url(src)
        # For remote/Spotty/radio/imageproxy artwork, preserve the source URL
        # instead of collapsing to /music/<id>/cover from the item id. Remote
        # ids are often negative numeric values and resolve to generic icons.
        if norm.startswith("http://") or norm.startswith("https://"):
            try:
                p = urllib.parse.urlsplit(norm)
                host = (p.hostname or "").lower()
            except Exception:
                p = urllib.parse.SplitResult("", "", norm, "", "")
                host = ""
            lms_host = ""
            broker_host = ""
            try:
                lms_host = (urllib.parse.urlsplit(LMS_BASE).hostname or "").lower()
            except Exception:
                pass
            try:
                broker_host = (urllib.parse.urlsplit(_public_broker_base()).hostname or "").lower()
            except Exception:
                pass
            if host and host not in ("127.0.0.1", "localhost", "::1", lms_host, broker_host):
                return "u." + _b64u_text(norm)

        # Local LMS cover paths can still use a compact cover id.
        cid = _extract_cover_id_from_pathish(norm)
        if cid and ":" not in cid and "/" not in cid and "?" not in cid and "&" not in cid:
            return cid

        # Non-local absolute/opaque paths should stay URL-backed.
        if norm and (norm.startswith("http://") or norm.startswith("https://") or "/imageproxy/" in norm):
            return "u." + _b64u_text(norm)

    for v in _candidate_item_ids(it):
        if ":" not in v and "/" not in v and "?" not in v and "&" not in v:
            return v

    if src and not _is_broker_art_url(src):
        return "u." + _b64u_text(_normalize_art_url(src))
    return "0"


def _current_playlist_item(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict):
        return None
    loop = payload.get("playlist_loop")
    cur_idx = _safe_str(payload.get("playlist_cur_index"))
    if not isinstance(loop, list):
        return None
    picked = None
    for it in loop:
        if not isinstance(it, dict):
            continue
        if cur_idx and _safe_str(it.get("playlist index")) == cur_idx:
            picked = it
            break
    if picked is None:
        for it in loop:
            if isinstance(it, dict):
                picked = it
                break
    return picked if isinstance(picked, dict) else None


def _is_broker_art_url(src: str) -> bool:
    s = _safe_str(src).strip()
    return bool(s and ("/art/main" in s or "/art/list" in s))


def _main_art_version(payload: Dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        return ""
    parts: List[str] = []
    for v in (
        payload.get("playlist_timestamp"),
        payload.get("playlist_cur_index"),
        payload.get("current_title"),
    ):
        sv = _safe_str(v).strip()
        if sv:
            parts.append(sv)
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        for v in (rm.get("id"), rm.get("title"), rm.get("album"), rm.get("artist"), rm.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    picked = _current_playlist_item(payload)
    if isinstance(picked, dict):
        for v in (picked.get("playlist index"), picked.get("id"), picked.get("title"), picked.get("album"), picked.get("artist"), picked.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    version = "|".join(parts[:8])
    if not version:
        return ""
    return hashlib.sha1(version.encode("utf-8", errors="ignore")).hexdigest()[:16]


def _choose_main_art_source(playerid: str, payload: Dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        return ""

    # Prefer the explicit now-playing artwork first. For Spotty/radio/remote
    # sources this is usually the only authoritative image and can differ from
    # playlist/list-item cover lookups.
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        src = _safe_str(rm.get("artwork_url") or "").strip()
        if src and not _is_broker_art_url(src):
            return src

    src = _safe_str(payload.get("artwork_url") or "").strip()
    if src and not _is_broker_art_url(src):
        return src

    # Then try the current playlist item. This helps local library playback,
    # but should not override explicit remoteMeta art above.
    picked = _current_playlist_item(payload)
    if isinstance(picked, dict):
        src = _safe_str(picked.get("artwork_url") or "").strip()
        if src and not _is_broker_art_url(src):
            return src
        iid = _item_list_art_id(picked)
        if iid and iid != "0" and not iid.startswith("u."):
            return f"/music/{iid}/cover_500x500_o"

    # Finally fall back to local LMS cover lookup by id where available.
    if isinstance(rm, dict):
        iid = _safe_str(rm.get("id") or "").strip()
        if iid and ":" not in iid and "/" not in iid and "?" not in iid and "&" not in iid:
            return f"/music/{iid}/cover_500x500_o"
    return ""


def _rewrite_status_art_for_broker(payload: Any, playerid: str) -> None:
    if not isinstance(payload, dict):
        return
    pid = _safe_str(playerid).strip()
    if not pid:
        return
    main_version = _main_art_version(payload)
    list_version = _safe_str(payload.get("playlist_timestamp") or payload.get("playlist_cur_index") or main_version or "")
    src = _choose_main_art_source(pid, payload)
    if src:
        _main_art_source_by_playerid[pid] = src
    payload["artwork_url"] = _broker_main_art_url(pid, main_version, 500)
    payload["artwork_url2"] = _broker_main_art_url(pid, main_version, 1080)
    rm = payload.get("remoteMeta")
    if not isinstance(rm, dict):
        rm = {}
        payload["remoteMeta"] = rm
    rm["artwork_url"] = _broker_main_art_url(pid, main_version, 500)
    rm["artwork_url2"] = _broker_main_art_url(pid, main_version, 1080)

    loop = payload.get("playlist_loop")
    provider = _provider_from_payload(payload)
    live_radio_queue = (
        bool(payload.get("is_live_radio"))
        or provider in ("radio", "iheart")
        or (
            provider not in ("pandora", "spotify", "podcast")
            and
            _safe_int(payload.get("remote"), 0) != 0
            and _safe_int(payload.get("playlist_tracks"), 0) <= 1
        )
    )
    if isinstance(loop, list):
        for it in loop:
            if not isinstance(it, dict):
                continue
            if live_radio_queue:
                # TuneIn can put its complete metadata query string in the
                # queue artwork URL. Keep RTI on /art/list but use a compact
                # player-backed id instead of embedding that long URL.
                it["artwork_url"] = _broker_list_art_url(_player_list_art_id(pid), main_version or list_version)
            else:
                it["artwork_url"] = _broker_list_art_url(_item_list_art_id(it), list_version)




def _queue_refresh_signature(payload: Dict[str, Any], pid: str = "") -> str:
    if not isinstance(payload, dict):
        return ""
    parts: List[str] = []
    for v in (payload.get("playlist_cur_index"), payload.get("playlist_tracks"), payload.get("current_title")):
        sv = _safe_str(v).strip()
        if sv:
            parts.append(sv)
    if pid.lower() in _podcast_players:
        return "|".join(parts)
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        for v in (rm.get("id"), rm.get("title"), rm.get("album"), rm.get("artist"), rm.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    picked = _current_playlist_item(payload)
    if isinstance(picked, dict):
        for v in (picked.get("playlist index"), picked.get("id"), picked.get("title"), picked.get("album"), picked.get("artist")):
            sv = _safe_str(v).strip()
            if sv:
                parts.append(sv)
    return "|".join(parts[:10])


async def _broadcast_queue_snapshot_for_player(pid: str, pname: str) -> None:
    try:
        st = await full_queue_status_for_push(pid)
        if not isinstance(st, dict) or not st:
            return
        await ws_broadcast({
            "t": "queue",
            "ok": True,
            "playerid": pid,
            "player_name": pname,
            "view": "1",
            "payload": st
        })
    except Exception:
        pass


def _schedule_podcast_selection_refresh(pid: str, expected_title: str) -> None:
    key = pid.lower()
    _podcast_players.add(key)
    expected_title = _safe_str(expected_title).splitlines()[0].strip()
    generation = _podcast_refresh_generation.get(key, 0) + 1
    _podcast_refresh_generation[key] = generation

    async def refresh_when_ready() -> None:
        for delay in (0.35, 0.75, 1.25, 2.0, 3.0, 4.0):
            await asyncio.sleep(delay)
            if _podcast_refresh_generation.get(key) != generation:
                return
            try:
                st = await lms.status(pid, 1)
                actual = _clean_text(
                    st.get("current_title")
                    or ((st.get("remoteMeta") or {}).get("title") if isinstance(st.get("remoteMeta"), dict) else "")
                )
                if actual and _norm_key(actual) == _norm_key(expected_title):
                    await _broadcast_queue_snapshot_for_player(
                        pid, _playerid_to_name.get(key, "")
                    )
                    return
            except Exception:
                continue

    asyncio.create_task(refresh_when_ready())


async def _collapse_iheart_queue_later(pid: str) -> None:
    try:
        await asyncio.sleep(3.0)
        st = await full_queue_status_for_push(pid, 200)
        loop = st.get("playlist_loop") if isinstance(st, dict) else None
        if not isinstance(loop, list) or len(loop) <= 1:
            return
        iheart_hay = " ".join(
            _safe_str(v).strip().lower()
            for item in loop if isinstance(item, dict)
            for v in (item.get("url"), item.get("file"), item.get("artwork_url"), item.get("title"))
        )
        if "iheart" not in iheart_hay and "streamtheworld.com" not in iheart_hay:
            return
        current = _safe_int(st.get("playlist_cur_index"), 0)
        for index in range(len(loop) - 1, -1, -1):
            if index != current:
                await lms.rpc(pid, ["playlist", "delete", index])
    except Exception as e:
        dbg(f"iHeart queue cleanup failed playerid={pid}: {_safe_str(e)}")

def _source_to_fetch_url(src: str, size: int) -> str:
    s = _safe_str(src).strip()
    if not s:
        return LMS_BASE.rstrip("/") + _fallback_art_path(size)

    # Already a broker art URL - fall back to latest known source behavior.
    if "/art/main" in s or "/art/list" in s:
        return LMS_BASE.rstrip("/") + _fallback_art_path(size)

    try:
        p = urllib.parse.urlsplit(s)
    except Exception:
        p = urllib.parse.SplitResult("", "", s, "", "")

    if p.scheme in ("http", "https"):
        host = (p.hostname or "").lower()
        netloc = (p.netloc or "").lower()
        lms_host = ""
        lms_netloc = ""
        try:
            lms_parts = urllib.parse.urlsplit(LMS_BASE)
            lms_host = (lms_parts.hostname or "").lower()
            lms_netloc = (lms_parts.netloc or "").lower()
        except Exception:
            lms_host = ""
            lms_netloc = ""
        broker_host = ""
        broker_netloc = ""
        try:
            broker_parts = urllib.parse.urlsplit(_public_broker_base())
            broker_host = (broker_parts.hostname or "").lower()
            broker_netloc = (broker_parts.netloc or "").lower()
        except Exception:
            broker_host = ""
            broker_netloc = ""
        public_lms_host = ""
        public_lms_netloc = ""
        try:
            public_lms_parts = urllib.parse.urlsplit(_public_lms_base())
            public_lms_host = (public_lms_parts.hostname or "").lower()
            public_lms_netloc = (public_lms_parts.netloc or "").lower()
        except Exception:
            public_lms_host = ""
            public_lms_netloc = ""

        local_netlocs = {v for v in (lms_netloc, broker_netloc, public_lms_netloc) if v}
        is_loopback = host in ("127.0.0.1", "localhost", "::1")
        if is_loopback or netloc in local_netlocs:
            path = p.path or "/"
            if path.startswith("/music/"):
                path = _resize_local_cover_path(path, size)
            if not path.startswith("/"):
                path = "/" + path
            return LMS_BASE.rstrip("/") + path + ((("?" + p.query) if p.query else ""))
        return s

    path = s
    if not path.startswith("/"):
        path = "/" + path
    if path.startswith("/music/"):
        path = _resize_local_cover_path(path, size)
    return LMS_BASE.rstrip("/") + path


_ART_CACHE_MAX = 192
_art_resized_cache: "OrderedDict[str, Tuple[bytes, str]]" = OrderedDict()


def _art_cache_get(key: str) -> Optional[Tuple[bytes, str]]:
    try:
        hit = _art_resized_cache.get(key)
        if hit is None:
            return None
        _art_resized_cache.move_to_end(key)
        return hit
    except Exception:
        return None


def _art_cache_put(key: str, body: bytes, ctype: str) -> None:
    try:
        _art_resized_cache[key] = (body, ctype)
        _art_resized_cache.move_to_end(key)
        while len(_art_resized_cache) > _ART_CACHE_MAX:
            _art_resized_cache.popitem(last=False)
    except Exception:
        pass


def _target_square_size(kind: str, size: int) -> int:
    s = _safe_int(size, 0)
    if kind == "list":
        if s < 50:
            s = 160
        if s > 200:
            s = 200
        return s
    if s < 50:
        s = 500
    if s > 2000:
        s = 2000
    return s


def _resize_image_bytes(body: bytes, size: int) -> Tuple[bytes, str]:
    with Image.open(io.BytesIO(body)) as img:
        img.load()
        fmt = (img.format or "").upper()
        mode = (img.mode or "").upper()
        resample = getattr(Image, "Resampling", Image).LANCZOS
        fitted = ImageOps.fit(img, (size, size), method=resample, centering=(0.5, 0.5))

        alpha = ("A" in mode) or (fmt in ("PNG", "WEBP") and "transparency" in img.info)
        out = io.BytesIO()
        if alpha:
            fitted.save(out, format="PNG", optimize=True)
            return out.getvalue(), "image/png"
        if fitted.mode not in ("RGB", "L"):
            fitted = fitted.convert("RGB")
        fitted.save(out, format="JPEG", quality=88, optimize=True, progressive=True)
        return out.getvalue(), "image/jpeg"


async def _fetch_image_response(url: str, size: int, kind: str) -> web.Response:
    await lms.start()
    assert lms._session is not None
    target = _target_square_size(kind, size)
    cache_key = f"{kind}|{target}|{url}"
    cached = _art_cache_get(cache_key)
    if cached is not None:
        body, ctype = cached
        return web.Response(body=body, content_type=ctype, headers={"Cache-Control": "public, max-age=300"})
    try:
        # LMS can briefly serve the previous cover after its status metadata
        # has already advanced. Since each main-art URL is versioned, wait for
        # that transition before filling its otherwise long-lived cache entry.
        if kind == "main":
            await asyncio.sleep(0.75)
        async with lms._session.get(url) as resp:
            body = await resp.read()
            if resp.status != 200 or not body:
                raise RuntimeError(f"art_fetch_http_{resp.status}")
            try:
                resized_body, ctype = _resize_image_bytes(body, target)
            except Exception:
                resized_body = body
                ctype = _safe_str(resp.headers.get("Content-Type") or "image/jpeg")
            _art_cache_put(cache_key, resized_body, ctype)
            return web.Response(body=resized_body, content_type=ctype, headers={"Cache-Control": "public, max-age=300"})
    except Exception:
        return web.Response(status=404, text="art_not_found")


async def _fetch_list_image_or_default(src: str, size: int) -> web.Response:
    url = _source_to_fetch_url(src, size)
    resp = await _fetch_image_response(url, size, "list")
    if resp.status != 404:
        return resp
    fallback_url = LMS_BASE.rstrip("/") + _fallback_art_path(size)
    return await _fetch_image_response(fallback_url, size, "list")


async def art_main(req: web.Request) -> web.Response:
    pid = _safe_str(req.query.get("playerid") or "").strip()
    if not pid:
        return web.Response(status=400, text="missing_playerid")

    # Prefer the preserved pre-rewrite source captured during status handling.
    # Recomputing from the rewritten snapshot can collapse remote artwork back
    # to generic /music/<id>/cover lookups.
    src = _safe_str(_main_art_source_by_playerid.get(pid)).strip()
    if not src:
        snap = _last_status_by_key.get(pid) or {}
        if isinstance(snap, dict):
            src = _choose_main_art_source(pid, snap)
    size = _target_square_size("main", _safe_int(req.query.get("size"), 500))
    url = _source_to_fetch_url(src, size)
    return await _fetch_image_response(url, size, "main")


async def art_list(req: web.Request) -> web.Response:
    item_id = _safe_str(req.query.get("id") or "").strip()
    if not item_id:
        return web.Response(status=400, text="missing_id")
    src = ""
    if item_id == "0":
        src = ""
    elif item_id.startswith("u."):
        try:
            src = _b64u_text_dec(item_id[2:])
        except Exception:
            src = ""
    elif item_id.startswith("p."):
        try:
            pid = _b64u_text_dec(item_id[2:])
        except Exception:
            pid = ""
        src = _safe_str(_main_art_source_by_playerid.get(pid) or _main_art_source_by_playerid.get(pid.lower())).strip()
    elif item_id.startswith("http://") or item_id.startswith("https://") or item_id.startswith("/"):
        src = item_id
    else:
        src = f"/music/{item_id}/cover_200x200_o"
    size = _target_square_size("list", _safe_int(req.query.get("size"), 160))
    return await _fetch_list_image_or_default(src, size)

# ---------------- Setup config helpers ----------------

_setup_cache: Dict[str, Any] = {}
_home_menu_cache: List[Dict[str, Any]] = []

def _iheart_region_setting(value: Any = None) -> str:
    region = _safe_str(_setup_cache.get("iheart_region") if value is None else value).strip().upper()
    if region == "MC":
        region = "MX"
    return region if region in ("US", "NZ", "AU", "CA", "MX") else ""


def _iheart_skip_intro_when_filtered() -> bool:
    return bool(_setup_cache.get("iheart_skip_intro_when_filtered", False))


def _iheart_label_region(label: Any) -> str:
    upper = _safe_str(label).upper()
    for candidate in ("US", "NZ", "AU", "CA", "MX", "MC"):
        if f"({candidate})" in upper:
            return "MX" if candidate == "MC" else candidate
    return ""


def _filter_iheart_region_items(items: List[Any]) -> List[Any]:
    region = _iheart_region_setting()
    if not region:
        return items

    filtered: List[Any] = []
    for item in items:
        if not isinstance(item, dict):
            filtered.append(item)
            continue
        tagged_region = _iheart_label_region(_pick_label(item))
        if not tagged_region or tagged_region == region:
            filtered.append(item)
    return filtered


def _iheart_genre_follow_item(items: List[Any], region: str = "") -> Optional[Dict[str, Any]]:
    fallback: Optional[Dict[str, Any]] = None
    for item in items:
        if not isinstance(item, dict):
            continue
        go_action = (item.get("actions") or {}).get("go")
        if not isinstance(go_action, dict):
            continue
        label_key = _norm_key(_pick_label(item))
        if "genre" not in label_key or "podcast" in label_key:
            continue
        if (
            ("station" in label_key and ("live" in label_key or "genre" in label_key))
            or "radiobygenre" in label_key
        ):
            tagged_region = _iheart_label_region(_pick_label(item))
            if region and tagged_region == region:
                return item
            if fallback is None and (not region or not tagged_region):
                fallback = item
    return fallback

def _filter_spotty_menu_items(items: List[Any]) -> List[Any]:
    if not bool(_setup_cache.get("hide_spotty_transfer_playback", True)):
        return items
    filtered: List[Any] = []
    for item in items:
        if not isinstance(item, dict):
            filtered.append(item)
            continue
        if _norm_key(_pick_label(item)) == "transferplayback":
            continue
        filtered.append(item)
    return filtered


def _pandora_accounts_cache() -> List[Dict[str, Any]]:
    saved = _setup_cache.get("pandora_accounts")
    saved = saved if isinstance(saved, list) else []
    out: List[Dict[str, Any]] = []
    for index in range(4):
        row = saved[index] if index < len(saved) and isinstance(saved[index], dict) else {}
        out.append({
            "enabled": bool(row.get("enabled", False)),
            "name": _safe_str(row.get("name") or f"Pandora {chr(65 + index)}").strip(),
            "username": _safe_str(row.get("username")).strip(),
            "password": _safe_str(row.get("password")),
        })
    return out


def _broker_mode() -> str:
    mode = _safe_str(_setup_cache.get("broker_mode")).strip().lower()
    return mode if mode in ("full", "light") else "full"


def _broker_light_mode() -> bool:
    return _broker_mode() == "light"


def _jivelite_player_slot_setting(value: Any = None) -> str:
    raw = _safe_str(_setup_cache.get("jivelite_player_slot") if value is None else value).strip().lower()
    if raw in ("", "auto"):
        return "auto"
    if raw in ("none", "off", "disabled"):
        return "none"
    slot = _safe_int(raw, 0)
    if 1 <= slot <= MAX_UNIT_PLAYERS:
        return str(slot)
    return "auto"


def _load_setup_config() -> None:
    """Load broker setup JSON from disk into caches. Safe to call multiple times."""
    global _setup_cache, _home_menu_cache, LMS_BASE, LMS_JSONRPC, LMS_COMETD

    # Start with defaults
    _setup_cache = {
        "lms_base": "",
        "broker_mode": "full",
        "public_lms_base": "",
        "home_menu": list(HOME_MENU_DEFAULT),
        "track_drilldown": False,
        "hide_spotty_transfer_playback": True,
        "mymusic_menu": [],
        "radio_menu": [],
        "iheart_region": "",
        "iheart_skip_intro_when_filtered": False,
        "show_analog_outputs": False,
        "license_key": "",
        "license_trial_started_at": 0,
        "legal_accepted": False,
        "legal_accepted_at": 0,
        "legal_terms_version": "",
        "pandora_accounts": [],
        "local_player_mode": "",
        "local_player_friendly_names": {},
        "local_player_rows": [],
        "jivelite_player_slot": "auto",
    }

    try:
        with open(SETUP_JSON_PATH, "r", encoding="utf-8") as f:
            disk = json.load(f)
        if isinstance(disk, dict):
            _setup_cache.update(disk)
    except Exception:
        pass

    # Home menu cache (sorted)
    hm = _setup_cache.get("home_menu")
    if not isinstance(hm, list) or not hm:
        hm = list(HOME_MENU_DEFAULT)
    # sanitize rows
    clean: List[Dict[str, Any]] = []
    for row in hm:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key"))
        if not key:
            continue
        clean.append({
            "key": key,
            "label": _safe_str(row.get("label")) or key,
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
            "type": _safe_str(row.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core",
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "icon": _safe_str(row.get("icon") or ""),
        })
    clean.sort(key=lambda r: (r.get("order", 100), r.get("label", "")))
    _home_menu_cache = clean

    # A blank saved value explicitly means LMS is local to the broker.
    lmsb = _safe_str(_setup_cache.get("lms_base")).rstrip("/")
    if not lmsb:
        lmsb = LOCAL_LMS_BASE
    LMS_BASE = lmsb
    LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
    LMS_COMETD = LMS_BASE + "/cometd"


def _save_setup_config() -> None:
    """Persist setup JSON to disk."""
    payload = {
        "lms_base": _safe_str(_setup_cache.get("lms_base")).strip(),
        "broker_mode": _broker_mode(),
        "public_lms_base": _safe_str(_setup_cache.get("public_lms_base")).strip(),
        "update_manifest_url": _safe_str(_setup_cache.get("update_manifest_url")).strip(),
        "home_menu": (_setup_cache.get("home_menu") if isinstance(_setup_cache.get("home_menu"), list) else (_home_menu_cache if isinstance(_home_menu_cache, list) else list(HOME_MENU_DEFAULT))),
        "track_drilldown": bool(_setup_cache.get("track_drilldown", False)),
        "hide_spotty_transfer_playback": bool(_setup_cache.get("hide_spotty_transfer_playback", True)),
        "mymusic_menu": _mymusic_menu_cache(),
        "radio_menu": _radio_menu_cache(),
        "iheart_region": _iheart_region_setting(),
        "iheart_skip_intro_when_filtered": _iheart_skip_intro_when_filtered(),
        "show_analog_outputs": bool(_setup_cache.get("show_analog_outputs", False)),
        "license_key": _safe_str(_setup_cache.get("license_key")).strip(),
        "license_trial_started_at": _safe_int(_setup_cache.get("license_trial_started_at"), 0),
        "legal_accepted": bool(_setup_cache.get("legal_accepted", False)),
        "legal_accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        "legal_terms_version": _safe_str(_setup_cache.get("legal_terms_version")),
        "pandora_accounts": _pandora_accounts_cache(),
        "local_player_mode": _safe_str(_setup_cache.get("local_player_mode")).lower(),
        "local_player_friendly_names": (
            _setup_cache.get("local_player_friendly_names")
            if isinstance(_setup_cache.get("local_player_friendly_names"), dict)
            else {}
        ),
        "local_player_rows": (
            _setup_cache.get("local_player_rows")
            if isinstance(_setup_cache.get("local_player_rows"), list)
            else []
        ),
        "jivelite_player_slot": _jivelite_player_slot_setting(),
    }
    tmp_path = SETUP_JSON_PATH + ".tmp"
    os.makedirs(os.path.dirname(SETUP_JSON_PATH), exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(tmp_path, SETUP_JSON_PATH)


def _mymusic_menu_cache() -> List[Dict[str, Any]]:
    rows = _setup_cache.get("mymusic_menu")
    out: List[Dict[str, Any]] = []
    if not isinstance(rows, list):
        return out
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key") or row.get("id")).strip()
        if not key:
            continue
        out.append({
            "key": key,
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "alias": _safe_str(row.get("alias") or row.get("label") or row.get("source_label") or key),
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
        })
    return out


def _radio_menu_cache() -> List[Dict[str, Any]]:
    rows = _setup_cache.get("radio_menu")
    out: List[Dict[str, Any]] = []
    if not isinstance(rows, list):
        return out
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key") or row.get("id")).strip()
        if not key:
            continue
        out.append({
            "key": key,
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "alias": _safe_str(row.get("alias") or row.get("label") or row.get("source_label") or key),
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
        })
    return out


def _merge_mymusic_menu_with_discovered(discovered: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    saved_by_key: Dict[str, Dict[str, Any]] = {}
    for row in _mymusic_menu_cache():
        key = _safe_str(row.get("key")).strip()
        if key:
            saved_by_key[key] = row
    out: List[Dict[str, Any]] = []
    next_order = 10
    for it in discovered:
        key = _safe_str(it.get("key") or it.get("id")).strip()
        if not key:
            continue
        source_label = _safe_str(it.get("source_label") or it.get("label") or key)
        saved = saved_by_key.get(key) or {}
        order = _safe_int(saved.get("order"), _safe_int(it.get("order"), next_order))
        out.append({
            "key": key,
            "source_label": source_label,
            "alias": _safe_str(saved.get("alias") or source_label),
            "enabled": bool(saved.get("enabled", True)),
            "order": order,
        })
        next_order += 10
    out.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return out


def _merge_radio_menu_with_discovered(discovered: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    saved_by_key = {
        _safe_str(row.get("key")).strip(): row
        for row in _radio_menu_cache()
        if _safe_str(row.get("key")).strip()
    }
    out: List[Dict[str, Any]] = []
    next_order = 10
    for it in discovered:
        key = _safe_str(it.get("key") or it.get("id")).strip()
        if not key:
            continue
        source_label = _safe_str(it.get("source_label") or it.get("label") or key)
        saved = saved_by_key.get(key) or {}
        out.append({
            "key": key,
            "source_label": source_label,
            "alias": _safe_str(saved.get("alias") or source_label),
            "enabled": bool(saved.get("enabled", True)),
            "order": _safe_int(saved.get("order"), _safe_int(it.get("order"), next_order)),
        })
        next_order += 10
    out.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return out


async def _pick_setup_playerid(req: Optional[web.Request] = None) -> str:
    pid = ""
    if req is not None:
        try:
            pid = _safe_str(req.query.get("playerid") or req.query.get("player") or "").strip()
        except Exception:
            pid = ""
    if pid:
        return pid
    if DEFAULT_PLAYERID:
        return DEFAULT_PLAYERID
    try:
        players = await lms.get_players()
        return pick_default_player(players)
    except Exception:
        return ""


async def _discover_mymusic_menu_rows(pid: str) -> List[Dict[str, Any]]:
    top = await _top_menu_raw(pid)
    raw = _extract_menu_items(top)
    rows: List[Dict[str, Any]] = []
    for it in raw:
        if _safe_str(it.get("node")) != "myMusic":
            continue
        key = _safe_str(it.get("id") or "").strip()
        if not key:
            continue
        rows.append({
            "key": key,
            "source_label": _pick_label(it),
            "alias": _pick_label(it),
            "enabled": True,
            "order": _safe_int(it.get("weight"), 100),
        })
    rows.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return rows


async def _discover_mymusic_menu_merged(pid: str) -> List[Dict[str, Any]]:
    return _merge_mymusic_menu_with_discovered(await _discover_mymusic_menu_rows(pid))


async def _discover_radio_menu_rows(pid: str) -> List[Dict[str, Any]]:
    top = await _top_menu_raw(pid)
    rows: List[Dict[str, Any]] = []
    for it in _extract_menu_items(top):
        if _safe_str(it.get("node")) != "radios":
            continue
        key = _safe_str(it.get("id") or "").strip()
        if not key:
            continue
        rows.append({
            "key": key,
            "source_label": _pick_label(it),
            "alias": _pick_label(it),
            "enabled": True,
            "order": _safe_int(it.get("weight"), 100),
        })
    rows.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return rows


async def _discover_radio_menu_merged(pid: str) -> List[Dict[str, Any]]:
    return _merge_radio_menu_with_discovered(await _discover_radio_menu_rows(pid))




async def _myapps_raw(pid: str) -> Dict[str, Any]:
    r = await lms.rpc(pid, ["myapps", "items", 0, 200])
    return (r.get("result") or {})


def _core_home_rows() -> List[Dict[str, Any]]:
    out=[]
    for row in _home_menu_cache:
        key=_safe_str(row.get("key")).strip().lower()
        if key in ("mymusic","radio","favorites"):
            out.append(dict(row))
    if not out:
        out=[dict(r) for r in HOME_MENU_DEFAULT]
    out.sort(key=lambda r: (_safe_int(r.get("order"),100), _safe_str(r.get("label"))))
    return out


def _core_home_icon(key: Any) -> str:
    k = _safe_str(key).strip().lower()
    if k == "mymusic":
        return _normalize_icon_url("/html/images/musicfolder.png")
    if k == "radio":
        return _normalize_icon_url("/plugins/TuneIn/html/images/radio.png")
    if k == "favorites":
        return _normalize_icon_url("/html/images/favorites.png")
    return ""


async def _discover_home_app_rows(pid: str) -> List[Dict[str, Any]]:
    raw = _extract_menu_items(await _myapps_raw(pid))
    top_items: List[Dict[str, Any]] = []
    try:
        top_items = _extract_menu_items(await _top_menu_raw(pid))
    except Exception:
        pass
    top_art_by_label: Dict[str, str] = {}
    top_art_by_id: Dict[str, str] = {}
    for top_item in top_items:
        art = _pick_art(top_item)
        if not art:
            continue
        label_key = _norm_key(_pick_label(top_item))
        item_key = _norm_key(top_item.get("id"))
        if label_key:
            top_art_by_label[label_key] = art
        if item_key:
            top_art_by_id[item_key] = art
    rows=[]
    for i,it in enumerate(raw):
        key=_safe_str(it.get("id") or "").strip()
        if not key:
            continue
        label=_pick_label(it)
        icon = (
            top_art_by_label.get(_norm_key(label))
            or top_art_by_id.get(_norm_key(key))
            or _pick_art(it)
            or ""
        )
        rows.append({
            "key": "app:" + key,
            "label": label,
            "source_label": label,
            "enabled": False,
            "order": 100 + i*10,
            "type": "app",
            "icon": icon,
        })
    return rows


async def _merge_home_menu_with_live_apps(pid: str) -> List[Dict[str, Any]]:
    saved_by_key={}
    saved_by_source={}
    for row in (_setup_cache.get("home_menu") or []):
        if not isinstance(row, dict):
            continue
        key=_safe_str(row.get("key")).strip()
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        if key:
            saved_by_key[key]=dict(row)
        if src:
            saved_by_source[src]=dict(row)
    out=[]
    for row in _core_home_rows():
        key=_safe_str(row.get("key")).strip()
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        saved=saved_by_key.get(key) or saved_by_source.get(src) or {}
        rr=dict(row)
        if saved:
            rr["label"]=_safe_str(saved.get("label") or rr.get("label") or key)
            rr["enabled"]=bool(saved.get("enabled", rr.get("enabled", True)))
            rr["order"]=_safe_int(saved.get("order"), _safe_int(rr.get("order"),100))
            rr["icon"]=_safe_str(saved.get("icon") or rr.get("icon") or _core_home_icon(key))
        else:
            rr["icon"]=_safe_str(rr.get("icon") or _core_home_icon(key))
        out.append(rr)
    for row in await _discover_home_app_rows(pid):
        key=_safe_str(row.get("key")).strip()
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        saved=saved_by_key.get(key) or saved_by_source.get(src) or {}
        rr=dict(row)
        if saved:
            rr["label"]=_safe_str(saved.get("label") or rr.get("label") or key)
            rr["enabled"]=bool(saved.get("enabled", rr.get("enabled", False)))
            rr["order"]=_safe_int(saved.get("order"), _safe_int(rr.get("order"),100))
            rr["icon"]=_safe_str(rr.get("icon") or saved.get("icon") or "")
        out.append(rr)
    out.sort(key=lambda r: (_safe_int(r.get("order"),100), _safe_str(r.get("label"))))
    return out


async def _sources_in_use(pid: str) -> Dict[str, bool]:
    """Return stable source flags for RTI auto-configuration."""
    flags = {
        "airplay": False,
        "bbc_sounds": False,
        "favorites": False,
        "iheart": False,
        "mymusic": False,
        "pandora": False,
        "pandora_a": False,
        "pandora_b": False,
        "pandora_c": False,
        "pandora_d": False,
        "podcasts": False,
        "pyrrha": False,
        "qobuz": False,
        "radio": False,
        "siriusxm": False,
        "soundmachine": False,
        "soundcloud": False,
        "spotify": False,
        "tidal": False,
        "deezer": False,
    }
    try:
        rows = await _merge_home_menu_with_live_apps(pid)
    except Exception:
        rows = list(_home_menu_cache)

    for row in rows:
        if not isinstance(row, dict) or not bool(row.get("enabled", False)):
            continue
        row_key = _norm_key(row.get("key"))
        hay = _norm_key(" ".join(
            _safe_str(row.get(key))
            for key in ("key", "label", "source_label", "icon")
        ))
        if "mymusic" in hay:
            flags["mymusic"] = True
        elif "favorite" in hay:
            flags["favorites"] = True
        elif row_key == "radio":
            flags["radio"] = True
        if "spotty" in hay or "spotify" in hay:
            flags["spotify"] = True
        if "frpandora" in hay or "pandora" in hay:
            flags["pandora"] = True
            for index, letter in enumerate(("a", "b", "c", "d")):
                if "frpandora{}".format(index) in hay or "pandora{}".format(letter) in hay:
                    flags["pandora_" + letter] = True
        if "pyrrha" in hay:
            flags["pyrrha"] = True
        if "iheart" in hay:
            flags["iheart"] = True
        if "podcast" in hay:
            flags["podcasts"] = True
        if "bbcsound" in hay:
            flags["bbc_sounds"] = True
        if "qobuz" in hay:
            flags["qobuz"] = True
        if "sirius" in hay:
            flags["siriusxm"] = True
        if "soundmachine" in hay:
            flags["soundmachine"] = True
        if "tidal" in hay:
            flags["tidal"] = True
        if "deezer" in hay:
            flags["deezer"] = True
        if "soundcloud" in hay:
            flags["soundcloud"] = True

    try:
        await lms.start()
        assert lms._session is not None
        async with lms._session.get(
            LMS_BASE + "/plugins/ShairTunes2W/settings/basic.html",
            allow_redirects=False,
        ) as response:
            flags["airplay"] = response.status == 200
    except Exception:
        flags["airplay"] = False
    return flags


async def _apply_lms_base(new_base: str) -> None:
    """Apply LMS base URL and force reconnects (RPC session + CometD)."""
    global LMS_BASE, LMS_JSONRPC, LMS_COMETD, _cometd_client_id, _cometd_response_channel, _cometd_session

    nb = _safe_str(new_base).strip().rstrip("/")
    if not nb:
        return
    if nb == LMS_BASE:
        return

    LMS_BASE = nb
    LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
    LMS_COMETD = LMS_BASE + "/cometd"

    # Reset LMS RPC session
    try:
        await lms.close()
    except Exception:
        pass

    # Force CometD loop to re-handshake by closing the session and clearing ids
    _cometd_client_id = None
    _cometd_response_channel = None
    try:
        if _cometd_session and not _cometd_session.closed:
            await _cometd_session.close()
    except Exception:
        pass


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return default


import re as _re

def _normalize_art_url(url: str) -> str:
    """Normalize artwork URLs for RTI panels."""
    u = (url or "").strip()
    if not u:
        return u

    # /imageproxy/<percent-encoded-https-url>/image.jpg  ->  https://...
    if "/imageproxy/" in u:
        try:
            after = u.split("/imageproxy/", 1)[1]
            after = _re.sub(r"/image\.(jpg|jpeg|png)$", "", after, flags=_re.IGNORECASE)
            after = urllib.parse.unquote(after)
            u = after.strip()
        except Exception:
            pass

    # strip trailing /image.xxx if still present
    u = _re.sub(r"/image\.(jpg|jpeg|png)$", "", u, flags=_re.IGNORECASE)

    pub = _public_lms_base().rstrip("/")
    base = pub or LMS_BASE

    # Rewrite loopback URLs to a reachable LMS base
    if u.startswith("http://127.0.0.1") or u.startswith("http://localhost"):
        if pub:
            try:
                p_old = urllib.parse.urlsplit(u)
                p_new = urllib.parse.urlsplit(pub)
                u = urllib.parse.urlunsplit((p_new.scheme, p_new.netloc, p_old.path, p_old.query, p_old.fragment))
            except Exception:
                pass
        return u

    if u.startswith("/"):
        return base + u
    if not _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        return base + "/" + u.lstrip("/")
    return u


def _normalize_icon_url(url: str) -> str:
    """Normalize menu/icon URLs so RTI gets a simple absolute URL."""
    u = (url or "").strip()
    if not u:
        return u

    # remove LMS image suffix first
    u = _re.sub(r"/image\.(jpg|jpeg|png|gif)$", "", u, flags=_re.IGNORECASE)

    # If LMS wrapped an external imageproxy URL, unwrap to the direct image URL
    if "/imageproxy/" in u:
        try:
            after = u.split("/imageproxy/", 1)[1]
            after = urllib.parse.unquote(after).strip()
            if _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", after):
                return after
        except Exception:
            pass

    pub = _public_lms_base().rstrip("/")
    base = pub or LMS_BASE

    # Local LMS library art in browse rows is usually music/<id>/cover.
    # RTI does better with the explicit sized cover URL.
    if u.startswith("music/") and u.endswith("/cover"):
        return base + "/" + u + "_100x100_o"
    if u.startswith("/music/") and u.endswith("/cover"):
        return base + u + "_100x100_o"

    # Rewrite loopback URLs to a reachable LMS base
    if u.startswith("http://127.0.0.1") or u.startswith("http://localhost"):
        if pub:
            try:
                p_old = urllib.parse.urlsplit(u)
                p_new = urllib.parse.urlsplit(pub)
                u = urllib.parse.urlunsplit((p_new.scheme, p_new.netloc, p_old.path, p_old.query, p_old.fragment))
            except Exception:
                pass
        return u

    if u.startswith("/"):
        return base + u
    if u.startswith("plugins/"):
        return base + "/" + u
    if not _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        return base + "/" + u.lstrip("/")
    return u


def _normalize_art_fields(obj: Any) -> None:
    """Walk a status payload and normalize art/icon URL fields."""
    if not isinstance(obj, dict):
        return

    for k in list(obj.keys()):
        v = obj.get(k)
        if isinstance(v, str):
            lk = k.lower()
            if ("art" in lk and "url" in lk) or lk in ("artwork_url", "coverart", "cover_url"):
                obj[k] = _normalize_art_url(v)
            elif lk in ("icon", "icon-id", "icon_url"):
                obj[k] = _normalize_icon_url(v)
        elif isinstance(v, dict):
            _normalize_art_fields(v)
        elif isinstance(v, list):
            for it in v:
                _normalize_art_fields(it)

    # Common LMS nested lists
    for lk in ("playlist_loop", "item_loop", "loop_loop"):
        v = obj.get(lk)
        if isinstance(v, list):
            for it in v:
                _normalize_art_fields(it)
def _default_cover_url() -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    return base + "/music/0/cover_500x500_o"


def _item_art_url(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return _default_cover_url()
    v = _safe_str(it.get("artwork_url") or "").strip()
    if v:
        return _normalize_art_url(v)
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    atid = _safe_str(it.get("artwork_track_id") or it.get("coverid") or it.get("cover_id") or "").strip()
    if atid:
        return f"{base}/music/{atid}/cover_500x500_o"
    if _safe_str(it.get("coverart")).strip() in ("1", "true", "True"):
        tid = _safe_str(it.get("id") or "").strip()
        if tid:
            return f"{base}/music/{tid}/cover_100x100_o"
    return _default_cover_url()


def _enrich_status_payload(obj: Any, pid: str = "") -> None:
    """Make local-library payloads look more like stream/Spotty payloads."""
    if not isinstance(obj, dict):
        return

    loop = obj.get("playlist_loop")
    if isinstance(loop, list):
        for it in loop:
            if not isinstance(it, dict):
                continue
            art = _item_art_url(it)
            if art:
                it["artwork_url"] = art

    cur_idx = _safe_str(obj.get("playlist_cur_index"))
    cur_item = None
    if isinstance(loop, list) and loop:
        for it in loop:
            if not isinstance(it, dict):
                continue
            if _safe_str(it.get("playlist index")) == cur_idx:
                cur_item = it
                break
        if cur_item is None:
            cur_item = loop[0] if isinstance(loop[0], dict) else None

    if isinstance(cur_item, dict):
        title = _safe_str(cur_item.get("title"))
        artist = _safe_str(cur_item.get("artist"))
        album = _safe_str(cur_item.get("album"))
        year = cur_item.get("year")
        duration = cur_item.get("duration")
        iid = cur_item.get("id")
        art = _item_art_url(cur_item)

        if title and not _safe_str(obj.get("current_title")):
            obj["current_title"] = title

        rm = obj.get("remoteMeta")
        if not isinstance(rm, dict):
            rm = {}
            obj["remoteMeta"] = rm
        if iid is not None and rm.get("id") in (None, ""):
            rm["id"] = iid
        if title and not _safe_str(rm.get("title")):
            rm["title"] = title
        if artist and not _safe_str(rm.get("artist")):
            rm["artist"] = artist
        if album and not _safe_str(rm.get("album")):
            rm["album"] = album
        if year not in (None, "") and rm.get("year") in (None, ""):
            rm["year"] = year
        if duration not in (None, "") and rm.get("duration") in (None, ""):
            rm["duration"] = duration
        if art and not _safe_str(rm.get("artwork_url")):
            rm["artwork_url"] = art

        # Podcast deltas often omit these fields. Emit explicit blanks so
        # metadata from the previously playing library track cannot survive.
        if _is_podcast_item(cur_item) or _is_podcast_item(rm) or pid.lower() in _podcast_players:
            if not artist:
                cur_item["artist"] = ""
                rm["artist"] = ""
                obj["artist"] = ""
            if not album:
                cur_item["album"] = ""
                rm["album"] = ""
                obj["album"] = ""

    # Normalize again after synthesis
    _normalize_art_fields(obj)


class LMSClient:
    def __init__(self) -> None:
        self._session: Optional[ClientSession] = None
        self._id = 0

    async def start(self) -> None:
        if self._session is None or self._session.closed:
            self._session = ClientSession(timeout=ClientTimeout(total=RPC_TIMEOUT))

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def rpc(self, playerid: str, params: List[Any]) -> Dict[str, Any]:
        await self.start()
        assert self._session is not None
        self._id += 1
        canonical_playerid = _safe_str(playerid).strip().lower()
        payload = {"id": self._id, "method": "slim.request", "params": [canonical_playerid, params]}
        dbg(f"RPC POST {payload}")
        async with self._session.post(LMS_JSONRPC, json=payload) as resp:
            txt = await resp.text()
            dbg(f"RPC HTTP {resp.status} {txt[:200]}")
            if resp.status != 200:
                raise RuntimeError(f"LMS RPC HTTP {resp.status}: {txt[:200]}")
            return json.loads(txt)

    async def get_players(self) -> List[Dict[str, Any]]:
        r = await self.rpc("", ["players", 0, 999])
        loop = (((r.get("result") or {}).get("players_loop")) or [])
        outp: List[Dict[str, Any]] = []
        for p in loop:
            outp.append({
                "playerid": _safe_str(p.get("playerid")),
                "name": _safe_str(p.get("name")),
                "connected": _safe_int(p.get("connected"), 0),
                "power": _safe_int(p.get("power"), 0),
            })
        return outp

    async def status(self, playerid: str, count: int = 1) -> Dict[str, Any]:
        cnt = _safe_int(count, 1)
        if cnt < 1: cnt = 1
        if cnt > 999: cnt = 999
        r = await self.rpc(playerid, ["status", "-", cnt, f"tags:{STATUS_TAGS}"])
        return (r.get("result") or {})

    async def track_metadata(self, track_id: str) -> Dict[str, Any]:
        tid = _safe_str(track_id).strip()
        if not tid:
            return {}
        cached = TRACK_META_CACHE.get(tid)
        if isinstance(cached, dict) and cached:
            return dict(cached)

        def _merge_songinfo_dict(meta: Dict[str, Any], info: Dict[str, Any]) -> None:
            if not isinstance(info, dict):
                return
            aliases = {
                "title": ["title", "track", "name"],
                "artist": ["artist", "artistname", "contributor", "artist_name"],
                "album": ["album", "albumtitle", "album_name"],
                "genre": ["genre", "genrename"],
                "duration": ["duration", "secs", "seconds"],
                "track_id": ["track_id", "trackid", "id"],
                "album_id": ["album_id", "albumid"],
                "coverid": ["coverid", "cover_id", "artwork_track_id"],
                "artwork_url": ["artwork_url", "art", "icon", "icon-id", "image"]
            }
            # direct keyed dicts
            for outk, keys in aliases.items():
                if meta.get(outk) not in (None, ""):
                    continue
                for k in keys:
                    v = info.get(k)
                    if v not in (None, ""):
                        meta[outk] = v
                        break
            # LMS songinfo_loop often comes back as name/value or id/value pairs.
            raw_key = _safe_str(info.get("name") or info.get("id") or info.get("key") or info.get("title")).strip().lower()
            raw_val = info.get("value")
            if raw_key and raw_val not in (None, ""):
                key_map = {
                    "title": "title", "track": "title", "name": "title",
                    "artist": "artist", "artistname": "artist", "contributor": "artist",
                    "album": "album", "albumtitle": "album",
                    "genre": "genre", "genrename": "genre",
                    "duration": "duration", "secs": "duration", "seconds": "duration",
                    "track_id": "track_id", "trackid": "track_id",
                    "album_id": "album_id", "albumid": "album_id",
                    "coverid": "coverid", "cover_id": "coverid", "artwork_track_id": "coverid",
                    "artwork_url": "artwork_url", "icon": "artwork_url", "image": "artwork_url"
                }
                mk = key_map.get(raw_key)
                if mk and meta.get(mk) in (None, ""):
                    meta[mk] = raw_val

        # songinfo is the most reliable way to enrich album drilldown rows that only expose
        # action payloads plus a concrete track_id.
        r = await self.rpc("", ["songinfo", 0, 100, f"track_id:{tid}"])
        res = (r.get("result") or {}) if isinstance(r, dict) else {}
        loop = res.get("songinfo_loop") or res.get("titles_loop") or res.get("tracks_loop") or []
        meta: Dict[str, Any] = {}
        if isinstance(loop, list) and loop:
            for info in loop:
                if isinstance(info, dict):
                    _merge_songinfo_dict(meta, info)
        # Some LMS builds expose useful top-level values on result too.
        if isinstance(res, dict):
            _merge_songinfo_dict(meta, res)
        # normalize strings
        for k in ("title", "artist", "album", "genre", "track_id", "album_id", "coverid", "artwork_url"):
            if k in meta and meta[k] is not None:
                meta[k] = _safe_str(meta[k])
        if meta.get("duration") not in (None, ""):
            try:
                meta["duration"] = float(meta.get("duration"))
            except Exception:
                pass
        if not _safe_str(meta.get("track_id")):
            meta["track_id"] = tid
        art = _track_album_art_url(meta) or _pick_art(meta) or _local_cover_art_url(meta)
        if art:
            meta["art"] = art
        if meta:
            TRACK_META_CACHE[tid] = dict(meta)
            if len(TRACK_META_CACHE) > TRACK_META_CACHE_MAX:
                try:
                    first_key = next(iter(TRACK_META_CACHE.keys()))
                    TRACK_META_CACHE.pop(first_key, None)
                except Exception:
                    pass
        dbg("TRACK META track_id=%s keys=%s title=%s artist=%s album=%s genre=%s duration=%s" % (
            tid,
            ",".join(sorted(meta.keys())),
            _safe_str(meta.get("title")),
            _safe_str(meta.get("artist")),
            _safe_str(meta.get("album")),
            _safe_str(meta.get("genre")),
            _safe_str(meta.get("duration"))
        ))
        return dict(meta)


    async def cmd(self, playerid: str, name: str, args: List[Any]) -> Dict[str, Any]:
        name = (name or "").strip().lower()
        cmd: List[Any]

        # --- Transport / basic controls ---
        if name in ("play", "pause", "stop"):
            cmd = [name]
        elif name == "next":
            cmd = ["playlist", "index", "+1"]
        elif name in ("prev", "previous"):
            cmd = ["playlist", "index", "-1"]
        elif name == "power":
            raw = _safe_str(args[0]).strip().lower() if args else "1"
            if raw == "toggle":
                st = await self.status(playerid, 1)
                cur = _safe_int((st.get("result") or {}).get("power"), 0)
                val = 0 if cur else 1
            elif raw in ("on", "true", "yes"):
                val = 1
            elif raw in ("off", "false", "no"):
                val = 0
            else:
                val = _safe_int(raw, 1)
            cmd = ["power", val]
        elif name == "mute":
            raw = _safe_str(args[0]).strip().lower() if args else "1"
            if raw == "toggle":
                st = await self.status(playerid, 1)
                cur = _safe_int((st.get("result") or {}).get("mixer muting"), _safe_int((st.get("result") or {}).get("muting"), 0))
                val = 0 if cur else 1
            elif raw in ("on", "true", "yes", "mute"):
                val = 1
            elif raw in ("off", "false", "no", "unmute"):
                val = 0
            else:
                val = _safe_int(raw, 1)
            cmd = ["mixer", "muting", val]
        elif name == "volume":
            raw = _safe_str(args[0]).strip() if args else "0"
            val = raw if raw.startswith(("+", "-")) else _safe_int(raw, 0)
            cmd = ["mixer", "volume", val]
        elif name in ("repeat", "shuffle"):
            raw = _safe_str(args[0]).strip().lower() if args else "next"
            key = name
            if raw == "next":
                snap = _last_status_by_key.get(playerid) or {}
                cur_raw = snap.get(f"playlist {key}", snap.get(f"playlist_{key}", snap.get(key, None)))
                if cur_raw is None:
                    st = await self.status(playerid, 1)
                    cur_raw = st.get(f"playlist {key}", st.get(f"playlist_{key}", st.get(key, 0)))
                cur = _safe_int(cur_raw, 0)
                val = (cur + 1) % 3
            elif raw in ("off", "none", "0", "false"):
                val = 0
            elif raw in ("song", "one", "track", "1", "true", "on"):
                val = 1
            elif name == "repeat" and raw in ("playlist", "all", "2"):
                val = 2
            elif name == "shuffle" and raw in ("album", "2"):
                val = 2
            elif name == "shuffle" and raw == "all":
                val = 1
            else:
                val = _safe_int(raw, 0)
            cmd = ["playlist", key, val]
            r = await self.rpc(playerid, cmd)
            return {"result": {f"playlist {key}": val, f"playlist_{key}": val, key: val, "lms_result": r.get("result") or {}}}
        elif name in ("position", "time"):
            raw = _safe_str(args[0]).strip() if args else "0"
            mode = _safe_str(args[1]).strip().lower() if len(args) > 1 else ""
            if mode == "percent":
                st = await self.status(playerid, 1)
                dur = _safe_int((st.get("result") or {}).get("duration"), 0)
                raw = str(int((dur * _safe_int(raw, 0)) / 100)) if dur > 0 else "0"
            cmd = ["time", raw]
        elif name == "sync":
            master = _safe_str(args[0]).strip() if args else ""
            if not master:
                raise ValueError("missing sync master")
            cmd = ["sync", master]
        elif name == "unsync":
            cmd = ["sync", "-"]
        elif name == "sync_toggle":
            slave = _safe_str(args[0]).strip() if args else ""
            if not slave:
                raise ValueError("missing sync slave")
            slave_status = await self.status(slave, 1)
            current_master = _safe_str(slave_status.get("sync_master")).strip()
            if current_master:
                return await self.rpc(slave, ["sync", "-"])
            cmd = ["sync", slave]
        elif name == "sync_all":
            action = _safe_str(args[0]).strip().lower() if args else "all"
            players = await self.get_players()
            result: Dict[str, Any] = {"players": []}
            for p in players:
                pid = _safe_str(p.get("playerid"))
                if not pid or pid == playerid:
                    continue
                if action in ("none", "off", "unsync"):
                    rr = await self.rpc(pid, ["sync", "-"])
                else:
                    rr = await self.rpc(playerid, ["sync", pid])
                result["players"].append({"playerid": pid, "result": rr.get("result") or {}})
            return {"result": result}
        elif name == "rate":
            # Provider-specific rating is driven by remoteMeta button payloads; keep this
            # command harmless until the live button command mapping is known.
            return {"result": {"rate": "noop"}}

        # --- Queue / list controls (new) ---
        elif name in ("queue_goto", "goto"):
            idx = _safe_int(args[0], 0) if args else 0
            cmd = ["playlist", "index", idx]
        elif name in ("queue_remove", "remove"):
            idx = _safe_int(args[0], 0) if args else 0
            cmd = ["playlist", "delete", idx]
        elif name in ("queue_clear", "clear"):
            cmd = ["playlist", "clear"]
        elif name in ("queue_fetch", "queue"):
            # Implemented by ws_rti handler (special-cased) — not here.
            cmd = []

        # --- Library / browse (menu/items) ---
        elif name in ("menu", "library"):
            # Pass-through 'menu' RPC. args should be a list of menu args, e.g.
            #   [0, 50, "direct:1"]
            #   [0, 50, "direct:1", "item_id:..."]
            cmd = ["menu"] + (args or [])

        elif name == "items":
            # Pass-through 'items' RPC (LMS menu browsing). args should be list args, e.g.
            #   [0, 100, "menu:1"]
            #   [0, 100, "menu:1", "item_id:..."]
            cmd = ["items"] + (args or [])

        elif name in ("artists","albums","genres","playlists","titles","tracks","years"):
            # Stable library browse commands (JSON-RPC)
            # args format: [offset, limit, ...optional filters like "artist_id:3", "album_id:1", "playlist_id:40"]
            cmd = [name] + (args or [])

        elif name == "playlistcontrol":
            # Compatibility shim for older/newer RTI driver JS that sends raw playlistcontrol
            # over the WS cmd path for selected track actions.
            # Example args: ["cmd:load", "track_id:22175", "menu:1"]
            cmd = ["playlistcontrol"] + (args or [])

        else:
            raise ValueError(f"unknown cmd '{name}'")

        if cmd:
            dbg(f"LMS CMD playerid={playerid} cmd={cmd}")
            return await self.rpc(playerid, cmd)

        return {"result": {}}


lms = LMSClient()


def pick_default_player(players: List[Dict[str, Any]]) -> str:
    if DEFAULT_PLAYERID:
        return DEFAULT_PLAYERID
    for p in players:
        if _safe_int(p.get("connected"), 0) == 1:
            return _safe_str(p.get("playerid"))
    return _safe_str(players[0].get("playerid")) if players else ""


_ws_clients: Set[web.WebSocketResponse] = set()

_main_art_source_by_playerid: Dict[str, str] = {}

_rti_ws_diag: Dict[str, Any] = {
    "connects": 0,
    "disconnects": 0,
    "active": 0,
    "last_peer": "",
    "last_connect_ts": 0.0,
    "last_disconnect_ts": 0.0,
    "last_disconnect_after_secs": 0.0,
    "last_send_ts": 0.0,
    "last_send_type": "",
    "last_send_bytes": 0,
    "last_error": "",
}


async def ws_broadcast(obj: Any) -> None:
    if not _ws_clients:
        return
    if not _license_status().get("valid"):
        for ws in list(_ws_clients):
            try:
                await ws.close(code=4003, message=b"license expired")
            except Exception:
                pass
        _ws_clients.clear()
        return
    msg = _json_dumps(obj) + "\n"
    dead: List[web.WebSocketResponse] = []
    for ws in list(_ws_clients):
        try:
            await ws.send_str(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _ws_clients.discard(ws)


# --- CometD state ---
_cometd_session: Optional[ClientSession] = None
_cometd_client_id: str = ""
_cometd_msg_id: int = 0
_cometd_connected: bool = False
_cometd_response_channel: str = ""  # /slim/<clientId>/response

_last_status_by_key: Dict[str, Dict[str, Any]] = {}
_last_queue_refresh_sig_by_playerid: Dict[str, str] = {}
_transport_mode_verify_tasks: Dict[str, asyncio.Task] = {}
_transport_command_verify_tasks: Dict[str, asyncio.Task] = {}
_sync_status_refresh_task: Optional[asyncio.Task] = None
_name_to_playerid: Dict[str, str] = {}  # player_name -> playerid (MAC)
_playerid_to_name: Dict[str, str] = {}  # playerid (MAC) -> player_name
_cometd_subscribed_playerids: Set[str] = set()
_cometd_subscription_expires: Dict[str, float] = {}
_cometd_last_rescan: float = 0.0


async def fresh_status_for_push(playerid: str, count: int = STATUS_SUBSCRIBE_COUNT) -> Dict[str, Any]:
    st = await lms.status(playerid, count)
    if isinstance(st, dict) and st:
        st.setdefault("sync_master", "")
        st.setdefault("sync_slaves", "")
        _normalize_art_fields(st)
        _enrich_status_payload(st, playerid)
        _rewrite_status_art_for_broker(st, playerid)
        _normalize_player_display_fields(playerid, st)
        _last_status_by_key[playerid] = dict(st)
    return st

async def verify_transport_modes_later(playerid: str, player_name: str, channel: str) -> None:
    try:
        await asyncio.sleep(TRANSPORT_MODE_VERIFY_DELAY_SECS)
        st = await lms.status(playerid, 1)
        if not isinstance(st, dict) or not st:
            return
        prev = _last_status_by_key.setdefault(playerid, {})
        payload: Dict[str, Any] = {}
        for key in ("repeat", "shuffle"):
            raw = st.get(f"playlist {key}", st.get(f"playlist_{key}", st.get(key, None)))
            if raw is None:
                continue
            val = _safe_int(raw, 0)
            old = prev.get(f"playlist {key}", prev.get(f"playlist_{key}", prev.get(key, None)))
            if old is None or _safe_int(old, -1) != val:
                payload[f"playlist {key}"] = val
                payload[f"playlist_{key}"] = val
                payload[key] = val
                prev[f"playlist {key}"] = val
                prev[f"playlist_{key}"] = val
                prev[key] = val
        if payload:
            await ws_broadcast_status({
                "t": "push",
                "src": "broker",
                "channel": channel or _cometd_response_channel or "/slim/_/response",
                "playerid": playerid,
                "player_name": player_name,
                "full": False,
                "complete": False,
                "payload": payload
            })
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"transport mode delayed verify failed for {playerid}: {_safe_str(e)}")
    finally:
        _transport_mode_verify_tasks.pop(playerid, None)

def schedule_transport_mode_verify(playerid: str, player_name: str, channel: str, payload: Dict[str, Any]) -> None:
    if not playerid or not isinstance(payload, dict):
        return
    if ("playlist repeat" in payload or "playlist_repeat" in payload) and ("playlist shuffle" in payload or "playlist_shuffle" in payload):
        return
    task = _transport_mode_verify_tasks.get(playerid)
    if task is not None and not task.done():
        return
    _transport_mode_verify_tasks[playerid] = asyncio.create_task(verify_transport_modes_later(playerid, player_name, channel))


async def verify_transport_command_later(playerid: str, player_name: str, command: str, before: Dict[str, Any]) -> None:
    try:
        before_sig = _queue_refresh_signature(before, playerid)
        before_mode = _safe_str(before.get("mode")).strip().lower()
        expected_mode = {"play": "play", "pause": "pause", "stop": "stop"}.get(command, "")
        for delay in (0.35, 0.9, 2.0):
            await asyncio.sleep(delay)
            try:
                st = await lms.status(playerid, 1)
            except Exception:
                continue
            if not isinstance(st, dict) or not st:
                continue
            st.setdefault("sync_master", "")
            st.setdefault("sync_slaves", "")
            _normalize_art_fields(st)
            _enrich_status_payload(st, playerid)
            _rewrite_status_art_for_broker(st, playerid)
            _normalize_player_display_fields(playerid, st)

            current_sig = _queue_refresh_signature(st, playerid)
            current_mode = _safe_str(st.get("mode")).strip().lower()
            confirmed = (
                (command in ("next", "prev") and bool(current_sig) and current_sig != before_sig) or
                (bool(expected_mode) and current_mode == expected_mode and current_mode != before_mode)
            )
            previous = dict(_last_status_by_key.get(playerid) or before)
            payload = _diff(previous, st)
            _last_status_by_key[playerid] = dict(st)
            if payload:
                await ws_broadcast_status({
                    "t": "push",
                    "src": "broker",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": playerid,
                    "player_name": player_name,
                    "full": False,
                    "complete": False,
                    "payload": payload,
                })
            if confirmed:
                if current_sig and current_sig != before_sig:
                    _last_queue_refresh_sig_by_playerid[playerid] = current_sig
                    await _broadcast_queue_snapshot_for_player(playerid, player_name)
                break
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"TRANSPORT VERIFY failed playerid={playerid} command={command}: {_safe_str(e)}")
    finally:
        _transport_command_verify_tasks.pop(playerid, None)


def schedule_transport_command_verify(playerid: str, player_name: str, command: str) -> None:
    if not playerid:
        return
    old = _transport_command_verify_tasks.get(playerid)
    if old is not None and not old.done():
        old.cancel()
    before = dict(_last_status_by_key.get(playerid) or {})
    _transport_command_verify_tasks[playerid] = asyncio.create_task(
        verify_transport_command_later(playerid, player_name, command, before)
    )


async def full_queue_status_for_push(playerid: str, count: int = 200) -> Dict[str, Any]:
    cnt = _safe_int(count, 200)
    if cnt < 1:
        cnt = 1
    if cnt > 999:
        cnt = 999
    r = await lms.rpc(playerid, ["status", 0, cnt, f"tags:{STATUS_TAGS}"])
    st = (r.get("result") or {}) if isinstance(r, dict) else {}
    if isinstance(st, dict) and st:
        st.setdefault("sync_master", "")
        st.setdefault("sync_slaves", "")
        _normalize_art_fields(st)
        _enrich_status_payload(st, playerid)
        _rewrite_status_art_for_broker(st, playerid)
        _normalize_player_display_fields(playerid, st)
    return st


async def cometd_post(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    global _cometd_session
    if _cometd_session is None or _cometd_session.closed:
        _cometd_session = ClientSession(timeout=ClientTimeout(total=70))
    assert _cometd_session is not None
    async with _cometd_session.post(LMS_COMETD, json=msgs) as resp:
        txt = await resp.text()
        if resp.status != 200:
            raise RuntimeError(f"CometD HTTP {resp.status}: {txt[:200]}")
        return json.loads(txt)


def next_cometd_id() -> str:
    global _cometd_msg_id
    _cometd_msg_id += 1
    return str(_cometd_msg_id)


async def cometd_meta_subscribe(channel: str) -> None:
    if not channel:
        return
    res = await cometd_post([{
        "channel": "/meta/subscribe",
        "clientId": _cometd_client_id,
        "subscription": channel,
        "id": next_cometd_id()
    }])
    ok = any(m.get("channel") == "/meta/subscribe" and m.get("successful") is True for m in res)
    if ok:
        dbg(f"CometD subscribed to {channel}")
    else:
        dbg(f"CometD subscribe FAILED for {channel}: {res}")


async def cometd_handshake() -> None:
    global _cometd_client_id, _cometd_connected, _cometd_response_channel
    _cometd_connected = False
    res = await cometd_post([{
        "channel": "/meta/handshake",
        "id": next_cometd_id(),
        "version": "1.0",
        "supportedConnectionTypes": ["long-polling"]
    }])
    for m in res:
        if m.get("channel") == "/meta/handshake" and m.get("successful") is True and m.get("clientId"):
            _cometd_client_id = _safe_str(m.get("clientId"))
            _cometd_response_channel = f"/slim/{_cometd_client_id}/response"
            dbg(f"CometD handshake OK clientId={_cometd_client_id}")
            dbg(f"CometD mode: subscribe:{STATUS_SUBSCRIBE_SECS}, broker_diff={'ON' if BROKER_DIFF else 'OFF'}")
            _cometd_subscribed_playerids.clear()
            _cometd_subscription_expires.clear()
            _last_status_by_key.clear()
            global _cometd_last_rescan
            _cometd_last_rescan = 0.0
            await cometd_meta_subscribe(_cometd_response_channel)
            return
    raise RuntimeError(f"CometD handshake failed: {res}")


async def cometd_connect_once() -> List[Dict[str, Any]]:
    global _cometd_connected
    res = await cometd_post([{
        "channel": "/meta/connect",
        "clientId": _cometd_client_id,
        "connectionType": "long-polling",
        "id": next_cometd_id()
    }])
    for m in res:
        if m.get("channel") == "/meta/connect" and m.get("successful") is True:
            _cometd_connected = True
    return res


async def cometd_status_subscribe(playerid: str) -> None:
    if STATUS_SUBSCRIBE_SECS <= 0:
        return
    req = [{
        "channel": "/slim/request",
        "clientId": _cometd_client_id,
        "id": next_cometd_id(),
        "data": {
            "response": _cometd_response_channel,
            "request": [playerid, ["status", "-", str(STATUS_SUBSCRIBE_COUNT), f"tags:{STATUS_TAGS}", f"subscribe:{STATUS_SUBSCRIBE_SECS}"]]
        }
    }]
    res = await cometd_post(req)
    ok = any(m.get("channel") == "/slim/request" and m.get("successful") is True for m in res)
    if ok:
        _cometd_subscribed_playerids.add(playerid)
        try:
            _cometd_subscription_expires[playerid] = asyncio.get_running_loop().time() + float(STATUS_SUBSCRIBE_SECS)
        except Exception:
            pass
        dbg(f"CometD status subscribe request for {playerid} -> {_cometd_response_channel} (tags:{STATUS_TAGS}, subscribe:{STATUS_SUBSCRIBE_SECS})")
    else:
        dbg(f"CometD status subscribe FAILED for {playerid}: {res}")


async def cometd_scan_and_subscribe_connected() -> None:
    try:
        players = await lms.get_players()
    except Exception as e:
        dbg(f"CometD get_players error: {_safe_str(e)}")
        return

    global _name_to_playerid, _playerid_to_name
    _name_to_playerid = {}
    _playerid_to_name = {}
    for p in players:
        if _safe_int(p.get("connected"), 0) != 1:
            continue
        pid = _safe_str(p.get("playerid"))
        pname = _safe_str(p.get("name"))
        if pid and pname:
            prev_pid = _safe_str(_name_to_playerid.get(pname))
            if prev_pid and prev_pid != pid:
                dbg("WARN duplicate player_name mapping name=%s old=%s new=%s" % (pname, prev_pid, pid))
            _name_to_playerid[pname] = pid
            _name_to_playerid[pname.lower()] = pid
            _playerid_to_name[pid] = pname
            _playerid_to_name[pid.lower()] = pname
        if not pid or pid in _cometd_subscribed_playerids:
            continue
        try:
            await cometd_status_subscribe(pid)
        except Exception as e:
            dbg(f"CometD subscribe error for {pid}: {_safe_str(e)}")


async def cometd_periodic_rescan_and_subscribe() -> None:
    global _cometd_last_rescan
    if RESCAN_SECS <= 0:
        return
    try:
        now = asyncio.get_running_loop().time()
    except Exception:
        return
    if _cometd_last_rescan and (now - _cometd_last_rescan) < RESCAN_SECS:
        return
    _cometd_last_rescan = now
    await cometd_scan_and_subscribe_connected()


async def cometd_renew_status_subscriptions() -> None:
    if STATUS_SUBSCRIBE_SECS <= 0:
        return
    try:
        now = asyncio.get_running_loop().time()
    except Exception:
        return

    # Refresh the player list if this is an empty startup/recovery window.
    if not _playerid_to_name:
        await cometd_scan_and_subscribe_connected()
        return

    for pid in list(_playerid_to_name.keys()):
        if pid.lower() != pid:
            continue
        expires = _cometd_subscription_expires.get(pid, 0.0)
        if not expires or now >= (expires - STATUS_SUBSCRIBE_RENEW_MARGIN_SECS):
            try:
                await cometd_status_subscribe(pid)
            except Exception as e:
                _cometd_subscribed_playerids.discard(pid)
                _cometd_subscription_expires.pop(pid, None)
                dbg(f"CometD renew subscribe error for {pid}: {_safe_str(e)}")
            await asyncio.sleep(0.05)


def _diff(prev: Dict[str, Any], cur: Dict[str, Any]) -> Dict[str, Any]:
    d: Dict[str, Any] = {}
    for k, v in cur.items():
        if k not in prev or prev.get(k) != v:
            d[k] = v
    for k in ("np_source", "np_station", "np_path", "is_live_radio"):
        if k in cur:
            d[k] = cur.get(k)
    return d


def _rti_status_payload(payload: Any) -> Dict[str, Any]:
    """Keep RTI status pushes small; queue/list data is sent as separate messages."""
    if not isinstance(payload, dict):
        return {}

    out: Dict[str, Any] = {}
    keep = (
        "playerid", "player_name", "name",
        "mode", "power", "time", "duration",
        "playlist_cur_index", "playlist_tracks",
        "current_title", "title", "artist", "album", "year", "genre",
        "trackartist", "albumartist", "composer", "conductor",
        "remote_title", "station", "station_name", "np_station", "np_source", "np_path",
        "is_live_radio",
        "artwork_url", "artworkUrl", "artwork_url2", "coverid",
        "mixer volume", "mixer_volume", "volume",
        "playlist repeat", "playlist_repeat", "repeat",
        "playlist shuffle", "playlist_shuffle", "shuffle",
        "sync_master", "sync_slaves",
        "rate", "rating", "canRate", "canRatePositive", "canRateNegative",
        "canThumbsUp", "canThumbsDown", "bitrate", "samplerate",
    )
    for key in keep:
        if key in payload:
            out[key] = payload.get(key)

    rm = payload.get("remoteMeta")
    if isinstance(rm, dict):
        out_rm: Dict[str, Any] = {}
        rm_keep = (
            "id", "title", "artist", "album", "year", "duration",
            "remote_title", "station", "station_name",
            "artwork_url", "artwork_url2",
            "rate", "rating", "canRate", "canRatePositive", "canRateNegative",
            "canThumbsUp", "canThumbsDown",
        )
        for key in rm_keep:
            if key in rm:
                out_rm[key] = rm.get(key)
        if out_rm:
            out["remoteMeta"] = out_rm

    return out


async def ws_broadcast_status(obj: Dict[str, Any]) -> None:
    if not isinstance(obj, dict):
        return
    msg = dict(obj)
    if isinstance(msg.get("payload"), dict):
        msg["payload"] = _rti_status_payload(msg.get("payload"))
    await ws_broadcast(msg)


async def _refresh_sync_status_after_command() -> None:
    global _sync_status_refresh_task
    try:
        await asyncio.sleep(0.45)
        players = await lms.get_players()
        connected = [p for p in players if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))]

        async def fetch_one(player: Dict[str, Any]) -> None:
            pid = _safe_str(player.get("playerid"))
            pname = _safe_str(player.get("name")) or _playerid_to_name.get(pid.lower(), "")
            try:
                st = await lms.status(pid, 1)
            except Exception as e:
                dbg(f"SYNC REFRESH status failed playerid={pid}: {_safe_str(e)}")
                return
            if not isinstance(st, dict):
                return
            sync_payload = {
                "sync_master": _safe_str(st.get("sync_master")).strip(),
                "sync_slaves": _safe_str(st.get("sync_slaves")).strip(),
            }
            prev = _last_status_by_key.setdefault(pid, {})
            changed = any(_safe_str(prev.get(k)).strip() != v for k, v in sync_payload.items())
            prev.update(sync_payload)
            if changed:
                await ws_broadcast_status({
                    "t": "push",
                    "src": "broker",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": pid,
                    "player_name": pname,
                    "full": False,
                    "complete": False,
                    "payload": sync_payload,
                })

        await asyncio.gather(*(fetch_one(p) for p in connected))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"SYNC REFRESH failed: {_safe_str(e)}")
    finally:
        _sync_status_refresh_task = None


def schedule_sync_status_refresh() -> None:
    global _sync_status_refresh_task
    if _sync_status_refresh_task is not None and not _sync_status_refresh_task.done():
        _sync_status_refresh_task.cancel()
    _sync_status_refresh_task = asyncio.create_task(_refresh_sync_status_after_command())


async def cometd_loop(_app: web.Application) -> None:
    global _cometd_client_id, _cometd_connected
    while True:
        try:
            if not _cometd_client_id:
                await cometd_handshake()
                # one-time scan+subscribe ALWAYS
                await cometd_scan_and_subscribe_connected()

            await cometd_periodic_rescan_and_subscribe()
            await cometd_renew_status_subscriptions()

            res = await cometd_connect_once()

            for m in res:
                ch = _safe_str(m.get("channel"))
                if not ch or ch.startswith("/meta/"):
                    continue

                data = m.get("data") or {}
                if not isinstance(data, dict):
                    continue


                # Normalize artwork URLs so RTI doesn't see /imageproxy/.../image.jpg
                _normalize_art_fields(data)

                if ch == _cometd_response_channel:
                    pid = _safe_str(data.get("playerid"))
                    pname = _safe_str(data.get("player_name")) or _safe_str(data.get("player")) or ""
                    if not pid and pname:
                        pid = _safe_str(_name_to_playerid.get(pname)) or _safe_str(_name_to_playerid.get(pname.lower()))
                        if pid:
                            dbg("COMETD RECOVER playerid=%s from player_name=%s channel=%s" % (pid, pname, ch))
                    if not pid:
                        dbg("COMETD DROP missing playerid channel=%s player_name=%s keys=%s raw=%s" % (
                            ch,
                            pname,
                            ",".join(sorted([_safe_str(k) for k in data.keys()])),
                            _json_dumps(data)
                        ))
                        continue

                    _enrich_status_payload(data, pid)
                    _rewrite_status_art_for_broker(data, pid)
                    _normalize_player_display_fields(pid, data)
                    schedule_transport_mode_verify(pid, pname, ch, data)

                    try:
                        qsig = _queue_refresh_signature(data, pid)
                        if qsig:
                            last_qsig = _last_queue_refresh_sig_by_playerid.get(pid)
                            if last_qsig != qsig:
                                _last_queue_refresh_sig_by_playerid[pid] = qsig
                                await _broadcast_queue_snapshot_for_player(pid, pname)
                    except Exception:
                        pass

                    if not BROKER_DIFF:
                        _last_status_by_key[pid] = dict(data)
                        await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": True, "payload": data})
                        continue

                    prev = _last_status_by_key.get(pid)
                    if prev is None:
                        _last_status_by_key[pid] = dict(data)
                        await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": True, "payload": data})
                    else:
                        d = _diff(prev, data)
                        if d:
                            prev.update(data)
                            await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": False, "payload": d})

        except asyncio.CancelledError:
            break
        except Exception as e:
            dbg(f"CometD loop error: {_safe_str(e)}")
            _cometd_client_id = ""  # force new handshake
            _cometd_connected = False
            await asyncio.sleep(3)


async def health(_req: web.Request) -> web.Response:
    license_info = _license_status()
    unit_name = _pcp_config_hostname()
    light_mode = _broker_light_mode()
    cometd_connected = bool(_cometd_connected) and not light_mode
    return web.json_response({
        "ok": True,
        "app": "lyrion_broker",
        "ver": APP_VERSION,
        "lyrion_ver": LYRION_VERSION,
        "broker_id": BROKER_ID,
        "hostname": unit_name or _default_unit_hostname(),
        "license": license_info,
        "legal": {
            "accepted": _legal_terms_accepted(),
            "terms_version": LEGAL_TERMS_VERSION,
            "accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        },
        "listen": f"{LISTEN_HOST}:{LISTEN_PORT}",
        "lms_base": LMS_BASE,
        "mode": {
            "broker_mode": _broker_mode(),
            "broker_diff": BROKER_DIFF,
            "status_subscribe_secs": STATUS_SUBSCRIBE_SECS,
            "force_status_after_command": FORCE_STATUS_AFTER_COMMAND,
            "rti_ws_first_send_delay_secs": RTI_WS_FIRST_SEND_DELAY_SECS,
            "pi_model": _raspberry_pi_model(),
            "local_player_limit": _local_player_limit(),
            "broker_startup": "user_command_3" if _broker_uses_user_command_slot() else "bootlocal_watchdog",
        },
        "rti_ws": dict(_rti_ws_diag),
        "cometd": {
            "url": "" if light_mode else LMS_COMETD,
            "clientId": "" if light_mode else _cometd_client_id,
            "response_channel": "" if light_mode else _cometd_response_channel,
            "connected": cometd_connected,
        }
    })


def _rti_connected_players(players: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    connected_players = [
        p for p in players
        if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
    ]
    local_prefix = ":".join(_safe_str(_license_status().get("device_mac")).lower().split(":")[:5])

    def player_slot_key(player: Dict[str, Any]) -> Tuple[int, int, str]:
        playerid = _safe_str(player.get("playerid")).lower()
        parts = playerid.split(":")
        if len(parts) == 6 and ":".join(parts[:5]) == local_prefix:
            match = re.fullmatch(r"a([0-3])", parts[5])
            if match:
                return (0, int(match.group(1)), _safe_str(player.get("name")).lower())
        name = _safe_str(player.get("name")).lower()
        match = re.search(r"(\d+)", name)
        return (1, int(match.group(1)) if match else 9999, name)

    connected_players.sort(key=player_slot_key)
    return connected_players[:RTI_MAX_PLAYERS]


def _player_inventory_warnings(players: List[Dict[str, Any]]) -> List[str]:
    connected_players = [
        p for p in players
        if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
    ]
    warnings: List[str] = []
    seen: Dict[str, List[str]] = {}
    for player in connected_players:
        mac = _safe_str(player.get("playerid")).strip().lower()
        if not mac:
            continue
        seen.setdefault(mac, []).append(_safe_str(player.get("name")) or mac)
    duplicates = {
        mac: names for mac, names in seen.items()
        if len(names) > 1
    }
    if duplicates:
        warnings.append(
            "Duplicate LMS player MAC addresses detected: " + "; ".join(
                "{} ({})".format(mac, ", ".join(names))
                for mac, names in sorted(duplicates.items())
            )
        )
    if len(connected_players) > RTI_MAX_PLAYERS:
        warnings.append(
            "RTI supports {} mapped players. {} connected players were found; only the first {} are exported.".format(
                RTI_MAX_PLAYERS,
                len(connected_players),
                RTI_MAX_PLAYERS,
            )
        )
    return warnings


async def api_players(_req: web.Request) -> web.Response:
    """Return LMS players in the exact shape needed for RTI driver setup."""
    try:
        if _broker_light_mode():
            return web.json_response({
                "ok": True,
                "players": [],
                "warnings": ["Broker Light does not export RTI server/player mapping."],
                "connected_count": 0,
                "exported_count": 0,
                "max_players": RTI_MAX_PLAYERS,
            })
        players = await lms.get_players()
        out: List[Dict[str, Any]] = []
        connected_players = _rti_connected_players(players)
        for i, p in enumerate(connected_players):
            playerid = _safe_str(p.get("playerid"))
            out.append({
                "index": i,
                "rti_player": f"Player {i + 1}",
                "rti_name_setting": f"Player{i}_Name",
                "rti_mac_setting": f"Player{i}_MAC",
                "name": _safe_str(p.get("name")),
                "playerid": playerid,
                "mac": playerid,
                "connected": _safe_int(p.get("connected"), 0),
                "power": _safe_int(p.get("power"), 0),
            })
        return web.json_response({
            "ok": True,
            "players": out,
            "warnings": _player_inventory_warnings(players),
            "connected_count": len([
                p for p in players
                if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
            ]),
            "exported_count": len(out),
            "max_players": RTI_MAX_PLAYERS,
        })
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e)}, status=500)


async def api_system_players_status(_req: web.Request) -> web.Response:
    try:
        rows = _pcp_player_sessions()
        macs = {
            _safe_str(row.get("mac")).strip().lower()
            for row in rows
            if _safe_str(row.get("mac")).strip()
        }
        running_macs = _running_squeezelite_macs(macs) if macs else set()
        running_processes = _managed_squeezelite_processes(macs) if macs else []
        ready = bool(rows) and len(running_macs) >= len(macs)
        return web.json_response({
            "ok": True,
            "configured": len(rows),
            "running": len(running_macs),
            "process_count": len(running_processes),
            "duplicate_processes": max(0, len(running_processes) - len(running_macs)),
            "ready": ready,
        })
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e)}, status=500)


async def api_pandora_v1(req: web.Request) -> web.Response:
    if not _license_status().get("valid"):
        return web.Response(text="Broker license expired", status=403)
    try:
        account = _safe_int(req.query.get("account"), -1)
        action = _safe_str(req.query.get("action")).strip()
        if account < 0 or account > 3:
            return web.Response(text="Invalid Pandora account", status=400)
        if not action:
            return web.Response(text="Missing Pandora action", status=400)
        _load_setup_config()
        config = _pandora_accounts_cache()[account]
        params = {str(key): _safe_str(value) for key, value in req.query.items()}
        result = await asyncio.to_thread(
            pandora_backend.handle,
            account,
            action,
            params,
            config,
        )
        if isinstance(result, str):
            return web.Response(text=result, content_type="text/plain")
        return web.json_response(result if result is not None else {})
    except Exception as e:
        dbg("PANDORA API account=%s action=%s error=%s" % (
            _safe_str(req.query.get("account")),
            _safe_str(req.query.get("action")),
            _safe_str(e),
        ))
        return web.Response(text=_safe_str(e) or "Pandora request failed", status=502)


def _pandora_plugin_zip(letter: str) -> str:
    clean_letter = _safe_str(letter).strip().upper()
    if clean_letter not in ("A", "B", "C", "D"):
        return ""
    return os.path.join(os.path.dirname(__file__), "pandora_plugins", f"Pandora-{clean_letter}.zip")


def _pandora_plugin_zip_bytes(letter: str, broker_base: str) -> bytes:
    clean_letter = _safe_str(letter).strip().upper()
    clean_base = _safe_str(broker_base).strip().rstrip("/")
    cache_key = (clean_letter, clean_base)
    cached = _pandora_plugin_zip_cache.get(cache_key)
    if cached is not None:
        return cached
    source_path = _pandora_plugin_zip(clean_letter)
    if not source_path or not os.path.isfile(source_path):
        return b""

    output = io.BytesIO()
    with zipfile.ZipFile(source_path, "r") as source, zipfile.ZipFile(output, "w") as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename in ("Plugin.pm", "ProtocolHandler.pm"):
                text = data.decode("utf-8")
                text = _re.sub(
                    r"https?://[^'\"\s]+/api/pandora/v1",
                    clean_base + "/api/pandora/v1",
                    text,
                )
                data = text.encode("utf-8")
            elif info.filename == "install.xml":
                text = data.decode("utf-8")
                text = _re.sub(r"<version>[^<]+</version>", "<version>1.1.10</version>", text, count=1)
                text = _re.sub(
                    r"<description>[^<]*</description>",
                    "<description>Play music from Pandora. A paid Pandora account is recommended for ad-free playback.</description>",
                    text,
                    count=1,
                )
                text = _re.sub(
                    r"<creator>[^<]*</creator>",
                    "<creator>Original plugin by Fusion Research. Modified by Skunk Works with assistance from OpenAI Codex.</creator>",
                    text,
                    count=1,
                )
                text = _re.sub(r"\s*<email>[^<]*</email>", "", text, count=1)
                data = text.encode("utf-8")
            elif info.filename == "strings.txt":
                text = data.decode("utf-8")
                text = _re.sub(
                    r"PLUGIN_FR_PANDORA_DESC(?=\r?\n)",
                    "PLUGIN_FR_PANDORA_DESC_V2",
                    text,
                    count=1,
                )
                text = text.replace(
                    "Play music from Pandora. Requires a Pandora One account.",
                    "Play music from Pandora. A paid Pandora account is recommended for ad-free playback.",
                )
                text = text.replace(
                    "No Pandora One credentials are defined for this account.",
                    "No Pandora credentials are defined for this account.",
                )
                data = text.encode("utf-8")
            info.create_system = 3
            if info.filename.endswith("/"):
                info.external_attr = (0o40755 << 16) | 0x10
            else:
                info.external_attr = 0o100644 << 16
            target.writestr(info, data)
    result = output.getvalue()
    _pandora_plugin_zip_cache[cache_key] = result
    return result


async def api_pandora_plugin_zip(req: web.Request) -> web.StreamResponse:
    letter = _safe_str(req.match_info.get("letter")).strip().upper()
    data = _pandora_plugin_zip_bytes(letter, f"{req.scheme}://{req.host}")
    if not data:
        raise web.HTTPNotFound()
    return web.Response(
        body=data,
        content_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="Pandora-{letter}.zip"'},
    )


async def api_pandora_repository(req: web.Request) -> web.Response:
    base = f"{req.scheme}://{req.host}"
    plugin_rows = []
    for index, letter in enumerate(("A", "B", "C", "D")):
        data = _pandora_plugin_zip_bytes(letter, base)
        if not data:
            continue
        sha = hashlib.sha1(data).hexdigest()
        plugin_rows.append(f"""
    <plugin name="FR_Pandora_{index}" version="1.1.10" minTarget="7.5" maxTarget="*">
      <title lang="EN">Pandora {letter}</title>
      <desc lang="EN">Broker-backed Pandora account {index}. Paid account recommended for ad-free playback.</desc>
      <category>musicservices</category>
      <url>{base}/api/pandora/plugins/Pandora-{letter}.zip</url>
      <sha>{sha}</sha>
      <creator>Original plugin by Fusion Research. Modified by Skunk Works with assistance from OpenAI Codex.</creator>
    </plugin>""")
    xml = """<?xml version="1.0"?>
<extensions>
  <details><title lang="EN">Lyrion Broker Pandora A-D</title></details>
  <plugins>
{plugins}
  </plugins>
</extensions>
""".format(plugins="\n".join(plugin_rows))
    return web.Response(text=xml, content_type="application/xml")




# ---------------- Setup web UI (Option A: broker-only config) ----------------

def _html_escape(s: Any) -> str:
    s = _safe_str(s)
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;")
             .replace("'", "&#39;"))


_SETUP_STYLE = """
  :root {
    color-scheme: light;
    --ink: #17202b;
    --muted: #657286;
    --line: #d7dee8;
    --panel: #ffffff;
    --canvas: #edf1f6;
    --accent: #5f2aa6;
    --accent-dark: #442078;
    --success: #18794e;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0 !important;
    padding: 0 !important;
    max-width: none !important;
    color: var(--ink);
    background: var(--canvas);
    font-family: Inter, "Segoe UI", Arial, sans-serif !important;
  }
  .brand-header {
    background: #050607;
    border-bottom: 3px solid var(--accent);
    box-shadow: 0 5px 18px rgba(19, 26, 36, .24);
  }
  .brand-strip {
    display: grid;
    grid-template-columns: 1.35fr 1.35fr 1fr .82fr;
    align-items: center;
    gap: clamp(14px, 3vw, 42px);
    width: min(1180px, calc(100% - 32px));
    min-height: 112px;
    margin: 0 auto;
    padding: 14px 6px;
  }
  .brand-strip img {
    display: block;
    width: 100%;
    height: 76px;
    object-fit: contain;
  }
  .brand-strip img:last-child { height: 88px; }
  .brand-bar {
    border-top: 1px solid #23262c;
    background: #0e1013;
  }
  .brand-bar-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    width: min(1180px, calc(100% - 32px));
    margin: 0 auto;
    padding: 12px 6px;
  }
  .brand-title { color: #fff; font-size: 18px; font-weight: 700; }
  .brand-meta {
    color: #aeb7c5;
    font-size: 13px;
    text-align: right;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }
  .unit-pill {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    border: 1px solid #4b5563;
    background: #1f2937;
    color: #e5e7eb;
    white-space: nowrap;
  }
  .unit-pill::before {
    content: "";
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    box-shadow: 0 0 9px currentColor;
  }
  .unit-pill.ok { border-color: #166534; background: #052e16; color: #86efac; }
  .unit-pill.error { border-color: #991b1b; background: #450a0a; color: #fca5a5; }
  .page-shell {
    width: min(1180px, calc(100% - 32px));
    margin: 24px auto 44px;
  }
  .page-nav {
    display: flex;
    gap: 8px;
    margin-bottom: 18px;
  }
  .page-nav a, .page-nav b {
    display: inline-block;
    padding: 8px 13px;
    border: 1px solid var(--line);
    border-radius: 6px;
    background: #fff;
    color: var(--accent-dark);
    text-decoration: none;
  }
  .page-nav b { background: var(--accent); border-color: var(--accent); color: #fff; }
  form, .quick-links {
    padding: 22px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--panel);
    box-shadow: 0 2px 8px rgba(25, 39, 58, .06);
  }
  h2 { margin: 0 0 8px; font-size: 25px; }
  h3 {
    margin: 26px 0 12px !important;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--line);
    color: #29384b;
    font-size: 18px;
  }
  input[type="text"], input[type="password"], input[type="number"], textarea, select {
    min-height: 38px;
    max-width: 100%;
    padding: 8px 10px !important;
    border: 1px solid #b9c4d2;
    border-radius: 5px;
    background: #fff;
    color: var(--ink);
    font: inherit;
  }
  input:focus, textarea:focus, select:focus {
    border-color: var(--accent);
    outline: 3px solid rgba(95, 42, 166, .13);
  }
  button {
    min-height: 38px;
    padding: 8px 15px !important;
    border: 1px solid var(--accent) !important;
    border-radius: 5px !important;
    background: var(--accent) !important;
    color: #fff !important;
    font-weight: 650;
    cursor: pointer;
  }
  button:hover { background: var(--accent-dark) !important; }
  button.needs-account {
    border-color: #b45309 !important;
    background: #f59e0b !important;
    color: #111827 !important;
  }
  button.needs-account:hover {
    background: #d97706 !important;
    color: #111827 !important;
  }
  button:disabled, button:disabled:hover {
    border-color: #aeb7c3 !important;
    background: #c9cfd7 !important;
    color: #687383 !important;
    cursor: not-allowed;
    opacity: .82;
  }
  table {
    width: 100%;
    border: 1px solid var(--line) !important;
    border-collapse: separate !important;
    border-spacing: 0;
    border-radius: 6px;
    overflow: hidden;
  }
  th {
    padding: 9px 8px !important;
    border-bottom: 1px solid var(--line) !important;
    background: #f2f4f8 !important;
    color: #3a4759;
    font-size: 12px;
    text-align: left;
    text-transform: uppercase;
  }
  td { padding: 8px !important; border-top: 1px solid #e8edf3 !important; }
  tbody tr:hover { background: #f8f9fc; }
  code {
    padding: 2px 5px;
    border-radius: 4px;
    background: #eef1f5;
    color: #38465a;
  }
  .save-dock {
    position: sticky !important;
    bottom: 10px !important;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 14px;
    margin: 24px -10px -10px !important;
    padding: 12px 14px !important;
    border: 1px solid #bcc9d8 !important;
    border-radius: 7px;
    background: rgba(247, 249, 252, .96) !important;
    box-shadow: 0 5px 20px rgba(23, 32, 43, .16);
    backdrop-filter: blur(8px);
  }
  .quick-links { margin-top: 18px; }
  .quick-links h3 { margin-top: 0 !important; }
  .quick-links ul { columns: 2; padding-left: 20px; }
  .quick-links li { margin: 8px 0; }
  .service-card {
    max-width: 620px;
    margin-top: 22px;
    padding: 15px;
    border: 1px solid var(--line);
    border-radius: 7px;
    background: #f8fafc;
  }
  .service-card-heading {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-bottom: 13px;
  }
  .service-card-heading img {
    width: 54px;
    height: 54px;
    flex: 0 0 54px;
    object-fit: contain;
    border-radius: 7px;
    background: #fff;
  }
  .service-card-heading h3 {
    margin: 0 !important;
    padding: 0;
    border: 0;
  }
  a { color: var(--accent-dark); }
  @media (max-width: 760px) {
    .brand-strip { grid-template-columns: 1fr 1fr; min-height: 0; gap: 8px 18px; }
    .brand-strip img, .brand-strip img:last-child { height: 54px; }
    .brand-bar-inner { align-items: flex-start; flex-direction: column; gap: 5px; }
    .brand-meta { text-align: left; }
    .page-shell { width: min(100% - 20px, 1180px); margin-top: 14px; }
    form, .quick-links { padding: 14px; overflow-x: auto; }
    .quick-links ul { columns: 1; }
    .save-dock { left: 0; right: 0; align-items: stretch; flex-direction: column; }
  }
"""


def _setup_brand_header(version: str, detail: str = "") -> str:
    try:
        unit_name = _pcp_config_hostname()
    except Exception:
        unit_name = _safe_str(socket.gethostname()).strip()
    if not unit_name:
        unit_name = "Unknown Unit"
    light_mode = _broker_light_mode()
    connected = bool(globals().get("_cometd_connected")) and not light_mode
    unit_status = "Broker Light" if light_mode else ("LMS Connected" if connected else "LMS Disconnected")
    unit_class = "ok" if connected or light_mode else "error"
    unit_pill = '<span id="unitStatusPill" class="unit-pill {}" data-unit="{}">{} | {}</span>'.format(
        unit_class,
        _html_escape(unit_name),
        _html_escape(unit_name),
        unit_status,
    )
    meta = "{} <span>Broker v{}</span>".format(unit_pill, _html_escape(version))
    if detail:
        meta += " <span>|</span> <span>" + detail + "</span>"
    return """
<header class="brand-header">
  <div class="brand-strip">
    <img src="/setup/assets/lyrion.png" alt="Lyrion">
    <img src="/setup/assets/avpro.png" alt="AVPro">
    <img src="/setup/assets/rti.png" alt="RTI">
    <img src="/setup/assets/skunkworks.png" alt="Skunk Works">
  </div>
  <div class="brand-bar">
    <div class="brand-bar-inner">
      <div class="brand-title">Lyrion RTI Broker</div>
      <div class="brand-meta">__BRAND_META__</div>
    </div>
  </div>
</header>
<script>
(function(){
  var pill = document.getElementById('unitStatusPill');
  if (!pill) return;
  var forcedUntil = 0;
  var forcedConnected = false;
    function setUnitState(unit, connected, label) {
    pill.classList.toggle('ok', !!connected);
    pill.classList.toggle('error', !connected);
    pill.textContent = (unit || pill.getAttribute('data-unit') || 'Unknown Unit') +
      ' | ' + (label || (connected ? 'LMS Connected' : 'LMS Disconnected'));
  }
  async function pollUnitState() {
    try {
      var res = await fetch('/health', {cache: 'no-store'});
      if (!res.ok) throw new Error('health ' + res.status);
      var data = await res.json();
      var lightMode = !!(data.mode && data.mode.broker_mode === 'light');
      var connected = lightMode || !!(data.cometd && data.cometd.connected);
      if (Date.now() < forcedUntil) connected = forcedConnected;
      setUnitState(data.hostname, connected, lightMode ? 'Broker Light' : '');
      window.dispatchEvent(new CustomEvent('lyrion-health', {
        detail: {brokerReachable: true, lmsConnected: connected, data: data}
      }));
    } catch (error) {
      setUnitState(pill.getAttribute('data-unit'), false);
      window.dispatchEvent(new CustomEvent('lyrion-health', {
        detail: {brokerReachable: false, lmsConnected: false}
      }));
    }
  }
  window.setInterval(pollUnitState, 3000);
  window.addEventListener('lyrion-force-lms-state', function(event) {
    var detail = (event && event.detail) || {};
    if (detail.clear) {
      forcedUntil = 0;
      pollUnitState();
      return;
    } else {
      forcedConnected = !!detail.connected;
      forcedUntil = Date.now() + (detail.untilMs || 15000);
    }
    setUnitState(detail.unit || pill.getAttribute('data-unit'), !!detail.connected);
  });
  pollUnitState();
})();
</script>""".replace("__BRAND_META__", meta)


async def setup_asset(req: web.Request) -> web.StreamResponse:
    filename = _safe_str(req.match_info.get("filename")).lower()
    allowed = {"lyrion.png", "avpro.png", "rti.png", "skunkworks.png"}
    if filename not in allowed:
        raise web.HTTPNotFound()
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets", filename)
    if not os.path.isfile(path):
        raise web.HTTPNotFound()
    return web.FileResponse(path, headers={"Cache-Control": "public, max-age=86400"})


async def root_page(_req: web.Request) -> web.Response:
    raise web.HTTPFound("/setup")


def _read_pcp_config() -> Dict[str, str]:
    values: Dict[str, str] = {}
    try:
        with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
            for raw_line in handle:
                line = raw_line.strip()
                match = re.match(r'^([A-Z0-9_]+)="(.*)"$', line)
                if match:
                    values[match.group(1)] = match.group(2)
    except Exception:
        pass
    return values


def _default_unit_hostname() -> str:
    broker_id = BROKER_ID or _compute_broker_id()
    return broker_id if re.fullmatch(r"[A-Za-z0-9-]{1,26}", broker_id) else "LyrionGadget"


def _is_generic_hostname(hostname: Any) -> bool:
    value = _safe_str(hostname).strip().split(".", 1)[0].lower()
    if value in ("", "pcp", "picoreplayer", "raspberrypi", "localhost", "lyriongadget"):
        return True
    if re.fullmatch(r"lyrion[0-9a-f]{4}", value):
        return True
    if re.fullmatch(r"lyriongadget[0-9]+", value):
        return True
    return False


def _pcp_config_hostname() -> str:
    configured = _safe_str(_read_pcp_config().get("HOST")).strip()
    if configured:
        return configured
    return _safe_str(socket.gethostname()).strip().split(".", 1)[0]


def _raspberry_pi_model() -> str:
    for path in ("/proc/device-tree/model", "/sys/firmware/devicetree/base/model"):
        try:
            with open(path, "rb") as handle:
                return handle.read().decode("utf-8", errors="replace").replace("\x00", "").strip()
        except Exception:
            continue
    return ""


def _raspberry_pi_major() -> int:
    match = re.search(r"Raspberry Pi\s+(\d+)", _raspberry_pi_model(), flags=re.I)
    return _safe_int(match.group(1), 0) if match else 0


def _local_player_limit() -> int:
    return PI3_MAX_UNIT_PLAYERS if _raspberry_pi_major() == 3 else MAX_UNIT_PLAYERS


def _broker_uses_user_command_slot() -> bool:
    return _raspberry_pi_major() == 3


def _parse_squeezelite_command(command: str, slot: int) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "slot": slot,
        "name": "",
        "output": "",
        "mac": "",
        "server": "",
        "audio_params": "",
        "command": command,
    }
    try:
        args = shlex.split(command)
        for option, key in (("-n", "name"), ("-o", "output"), ("-m", "mac"), ("-s", "server")):
            if option in args:
                index = args.index(option)
                if index + 1 < len(args):
                    row[key] = _safe_str(args[index + 1])
        if "-a" in args:
            index = args.index("-a")
            if index + 1 < len(args):
                row["audio_params"] = _safe_str(args[index + 1])
    except Exception:
        pass
    row["mac"] = _safe_str(row.get("mac")).strip().lower()
    return row


def _pcp_player_sessions() -> List[Dict[str, Any]]:
    config = _read_pcp_config()
    if not config:
        return []
    sessions = [{
        "slot": 1,
        "name": _safe_str(config.get("NAME")),
        "output": _safe_str(config.get("OUTPUT")),
        "mac": _safe_str(config.get("MAC_ADDRESS")).strip().lower(),
        "server": _safe_str(config.get("SERVER_IP")),
        "audio_params": _safe_str(config.get("ALSA_PARAMS")),
        "command": "",
    }]
    for index in range(1, 5):
        encoded = _safe_str(config.get("USER_COMMAND_{}".format(index))).strip()
        if not encoded:
            continue
        command = urllib.parse.unquote_plus(encoded)
        if "squeezelite" not in command.lower():
            continue
        sessions.append(_parse_squeezelite_command(command, index + 1))
    return sessions


def _alsa_cards() -> List[Dict[str, str]]:
    cards: List[Dict[str, str]] = []
    try:
        with open("/proc/asound/cards", "r", encoding="utf-8", errors="replace") as handle:
            lines = handle.read().splitlines()
        index = 0
        while index < len(lines):
            match = re.match(r"^\s*(\d+)\s+\[([^\]]+)\s*\]:\s*(.+?)\s+-\s+(.*)$", lines[index])
            if not match:
                index += 1
                continue
            detail = lines[index + 1].strip() if index + 1 < len(lines) else ""
            path_match = re.search(r"\bat\s+([^,]+)", detail)
            cards.append({
                "index": match.group(1),
                "id": match.group(2).strip(),
                "driver": match.group(3).strip(),
                "name": match.group(4).strip(),
                "detail": detail,
                "path": path_match.group(1).strip() if path_match else "",
            })
            index += 2
    except Exception:
        pass
    return cards


def _alsa_output_for_card(card: Dict[str, str]) -> str:
    card_id = _safe_str(card.get("id")).strip()
    driver = _safe_str(card.get("driver")).lower()
    if not card_id:
        return ""
    if "hdmi" in driver or "hdmi" in card_id.lower():
        return "hdmi:CARD={}".format(card_id)
    return "hw:CARD={},DEV=0".format(card_id)


def _is_low_quality_analog_card(card: Dict[str, str]) -> bool:
    text = " ".join(
        _safe_str(card.get(key)).lower()
        for key in ("id", "driver", "name", "detail")
    )
    return (
        "bcm2835" in text
        or "headphone" in text
        or "headphones" in text
    )


def _dac8x_card() -> Optional[Dict[str, str]]:
    if _raspberry_pi_major() != 5:
        return None
    for card in _alsa_cards():
        text = " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        )
        if "dac8x" in text:
            return card
    return None


def _dac8x_outputs() -> List[Dict[str, str]]:
    card = _dac8x_card()
    if not card:
        return []
    pairs = (
        ("dac8x_12", "DAC8x Outputs 1/2", 0, 1),
        ("dac8x_34", "DAC8x Outputs 3/4", 2, 3),
        ("dac8x_56", "DAC8x Outputs 5/6", 4, 5),
        ("dac8x_78", "DAC8x Outputs 7/8", 6, 7),
    )
    rows: List[Dict[str, str]] = []
    for pcm_name, label, left, right in pairs:
        row = dict(card)
        row["output"] = pcm_name
        row["label"] = "{} - {}".format(label, card.get("name"))
        row["virtual"] = "dac8x"
        row["dac8x_left"] = str(left)
        row["dac8x_right"] = str(right)
        rows.append(row)
    return rows


def _dac8x_asound_block(card_id: str) -> str:
    entries = []
    base = """pcm.dac8x_dmix {
    type dmix
    ipc_key 7908
    ipc_perm 0666
    slave {
        pcm "hw:CARD=%s,DEV=0"
        rate 48000
        channels 8
        period_time 0
        period_size 1024
        buffer_size 8192
    }
    bindings {
        0 0
        1 1
        2 2
        3 3
        4 4
        5 5
        6 6
        7 7
    }
}""" % card_id
    for name, left, right in (
        ("dac8x_12", 0, 1),
        ("dac8x_34", 2, 3),
        ("dac8x_56", 4, 5),
        ("dac8x_78", 6, 7),
    ):
        route_name = "{}_route".format(name)
        entries.append(
            """pcm.{name} {{
    type plug
    slave.pcm "{route_name}"
}}

pcm.{route_name} {{
    type route
    slave {{
        pcm "dac8x_dmix"
        channels 8
    }}
    ttable.0.{left} 1
    ttable.1.{right} 1
}}""".format(
                name=name,
                route_name=route_name,
                left=left,
                right=right,
            )
        )
    return DAC8X_ASOUND_BEGIN + "\n" + base + "\n\n" + "\n\n".join(entries) + "\n" + DAC8X_ASOUND_END + "\n"


def _replace_managed_block(text: str, begin: str, end: str, block: str) -> str:
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end) + r"\n?", flags=re.S)
    clean = pattern.sub("", text).rstrip() + "\n\n"
    return clean + block


def _strip_dac8x_asound_defs(text: str) -> str:
    for begin, end in (
        (DAC8X_ASOUND_BEGIN, DAC8X_ASOUND_END),
        ("# BEGIN LYRION DAC8X", "# END LYRION DAC8X"),
    ):
        text = re.sub(re.escape(begin) + r".*?" + re.escape(end) + r"\n?", "", text, flags=re.S)
    lines = text.splitlines()
    kept: List[str] = []
    index = 0
    while index < len(lines):
        line = lines[index]
        if re.match(r"^\s*pcm\.dac8x(?:_[A-Za-z0-9]+)?\s*\{", line):
            depth = line.count("{") - line.count("}")
            index += 1
            while index < len(lines) and depth > 0:
                depth += lines[index].count("{") - lines[index].count("}")
                index += 1
            continue
        kept.append(line)
        index += 1
    return "\n".join(kept).rstrip() + "\n"


def _replace_dac8x_asound_block(text: str, block: str) -> str:
    return _strip_dac8x_asound_defs(text).rstrip() + "\n\n" + block


def _ensure_filetool_entry(entry: str) -> None:
    try:
        existing = ""
        if os.path.exists(FILETOOL_LIST_PATH):
            with open(FILETOOL_LIST_PATH, "r", encoding="utf-8", errors="replace") as handle:
                existing = handle.read()
        lines = [line.strip() for line in existing.splitlines()]
        if entry in lines:
            return
        with open(FILETOOL_LIST_PATH, "a", encoding="utf-8", newline="\n") as handle:
            if existing and not existing.endswith("\n"):
                handle.write("\n")
            handle.write(entry + "\n")
    except Exception as error:
        raise RuntimeError("Could not update pCP backup file list: {}".format(_safe_str(error)))


def _ensure_dac8x_asound_config(outputs: List[str]) -> bool:
    if not any(_safe_str(output).strip().startswith("dac8x_") for output in outputs):
        return False
    card = _dac8x_card()
    if not card:
        raise RuntimeError("DAC8x outputs were selected, but no DAC8x ALSA card was detected")
    card_id = _safe_str(card.get("id")).strip()
    if not card_id:
        raise RuntimeError("DAC8x ALSA card did not expose a stable card id")
    original = ""
    if os.path.exists(ASOUND_CONFIG_PATH):
        with open(ASOUND_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
            original = handle.read()
    updated = _replace_dac8x_asound_block(original, _dac8x_asound_block(card_id))
    if updated != original:
        tmp_path = ASOUND_CONFIG_PATH + ".lyrion-new"
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, ASOUND_CONFIG_PATH)
    _ensure_filetool_entry("etc/asound.conf")
    _ensure_filetool_entry("opt/.filetool.lst")
    return updated != original


def _available_alsa_outputs() -> List[Dict[str, str]]:
    outputs = []
    show_analog = bool(_setup_cache.get("show_analog_outputs", False))
    for card in _alsa_cards():
        if not show_analog and _is_low_quality_analog_card(card):
            continue
        if "dac8x" in " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        ):
            continue
        output = _alsa_output_for_card(card)
        if not output:
            continue
        row = dict(card)
        row["output"] = output
        row["label"] = "{} - {}".format(card.get("id"), card.get("name"))
        outputs.append(row)
    outputs.extend(_dac8x_outputs())
    return outputs


def _clone_outputs() -> Tuple[List[str], List[str]]:
    cards = _available_alsa_outputs()
    usb_one = next((
        row for row in cards
        if row.get("path", "").endswith("-1.4") and "usb" in row.get("driver", "").lower()
    ), None)
    usb_two = next((
        row for row in cards
        if row.get("path", "").endswith("-1.3") and "usb" in row.get("driver", "").lower()
    ), None)
    hifiberry = next((
        row for row in cards
        if "hifiberry" in (
            _safe_str(row.get("id")) + " " +
            _safe_str(row.get("name")) + " " +
            _safe_str(row.get("detail"))
        ).lower()
    ), None)
    rows = (usb_one, usb_two, hifiberry)
    labels = ("Output 1 USB port 1-1.4", "Output 2 USB port 1-1.3", "Output 3 HiFiBerry DAC+")
    missing = [labels[index] for index, row in enumerate(rows) if row is None]
    return [
        _safe_str(row.get("output")) if isinstance(row, dict) else ""
        for row in rows
    ], missing


def _alsa_control_names(card_index: str) -> Set[str]:
    try:
        result = subprocess.run(
            ["amixer", "-c", str(card_index), "scontrols"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return set()
    controls: Set[str] = set()
    for line in (result.stdout or "").splitlines():
        match = re.search(r"Simple mixer control '([^']+)'", line)
        if match:
            controls.add(match.group(1))
    return controls


def _amixer_sset(card_index: str, control: str, *values: str) -> str:
    result = subprocess.run(
        ["amixer", "-c", str(card_index), "sset", control, *values],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=8,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stdout or "").strip()[-300:] or "amixer failed")
    return result.stdout or ""


def _normalize_mixer_levels_for_outputs(outputs: List[str], save_backup: bool = True) -> Dict[str, Any]:
    selected = {_safe_str(output).strip() for output in outputs if _safe_str(output).strip()}
    cards = [
        card for card in _available_alsa_outputs()
        if _safe_str(card.get("output")).strip() in selected
    ]
    changed: List[str] = []
    warnings: List[str] = []
    for card in cards:
        card_index = _safe_str(card.get("index")).strip()
        if not card_index:
            continue
        controls = _alsa_control_names(card_index)
        text = " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        )
        commands: List[Tuple[str, Tuple[str, ...]]] = []
        if "usb" in text or "c-media" in text or "cmedia" in text:
            commands.extend([
                ("Speaker", ("100%", "unmute")),
                ("Mic", ("0%", "mute")),
                ("Auto Gain Control", ("off",)),
            ])
        elif "hifiberry" in text or "sndrpihifiberry" in text:
            commands.extend([
                ("Digital", ("100%", "unmute")),
                ("Analogue", ("100%",)),
            ])
        elif "hdmi" in text:
            commands.extend([
                ("PCM", ("100%", "unmute")),
                ("Digital", ("100%", "unmute")),
                ("Master", ("100%", "unmute")),
            ])
        else:
            commands.extend([
                ("PCM", ("100%", "unmute")),
                ("Speaker", ("100%", "unmute")),
                ("Master", ("100%", "unmute")),
                ("Digital", ("100%", "unmute")),
            ])
        for control, values in commands:
            if control not in controls:
                continue
            try:
                _amixer_sset(card_index, control, *values)
                changed.append("{}: {}".format(card.get("id") or card_index, control))
            except Exception as error:
                warnings.append("{} {}: {}".format(card.get("id") or card_index, control, _safe_str(error)))
    if save_backup:
        backup = subprocess.run(
            ["/usr/bin/filetool.sh", "-b"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=60,
            check=False,
        )
        if backup.returncode != 0:
            raise RuntimeError("Mixer levels changed, but pCP backup failed: {}".format((backup.stdout or "")[-300:]))
    return {"changed": changed, "warnings": warnings}


async def _normalize_mixer_levels_after_startup() -> None:
    try:
        elapsed = 0.0
        for delay in (5.0, 18.0):
            await asyncio.sleep(max(0.0, delay - elapsed))
            elapsed = delay
            outputs = [
                _safe_str(row.get("output"))
                for row in _pcp_player_sessions()
                if _safe_str(row.get("output")).strip()
            ]
            if not outputs:
                continue
            result = await asyncio.to_thread(_normalize_mixer_levels_for_outputs, outputs, False)
            dbg(
                "Startup mixer normalize after {:.0f}s: {} controls{}".format(
                    delay,
                    len(result.get("changed", [])),
                    " warnings={}".format("; ".join(result.get("warnings", [])[:3]))
                    if result.get("warnings") else "",
                )
            )
    except asyncio.CancelledError:
        raise
    except Exception as error:
        dbg("Startup mixer normalize failed: {}".format(_safe_str(error)))


def _managed_player_mac(slot: int) -> str:
    device_mac = _safe_str(_license_status().get("device_mac")).lower()
    parts = device_mac.split(":")
    if len(parts) != 6:
        return ""
    return ":".join(parts[:5] + ["a{}".format(max(0, min(slot - 1, MAX_UNIT_PLAYERS - 1)))])


def _replace_pcp_config_values(text: str, updates: Dict[str, str]) -> str:
    remaining = dict(updates)
    lines = text.splitlines()
    output_lines = []
    for line in lines:
        match = re.match(r'^([A-Z0-9_]+)=".*"$', line)
        if match and match.group(1) in remaining:
            key = match.group(1)
            output_lines.append('{}="{}"'.format(key, remaining.pop(key)))
        else:
            output_lines.append(line)
    for key, value in remaining.items():
        output_lines.append('{}="{}"'.format(key, value))
    return "\n".join(output_lines) + "\n"


def _validate_player_text(value: Any, label: str) -> str:
    text = _safe_str(value).strip()
    if not text:
        raise ValueError("{} is required".format(label))
    if len(text) > 48 or any(char in text for char in ('"', "\r", "\n")):
        raise ValueError("{} contains unsupported characters".format(label))
    return text


def _player_startup_name(value: Any, slot: int) -> str:
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", _safe_str(value).strip())
    name = re.sub(r"_+", "_", name).strip("_.-")
    return (name or "Player_{}".format(slot))[:48]


def _default_audio_params_for_output(output: Any) -> str:
    text = _safe_str(output).strip().lower()
    if text.startswith("hdmi:"):
        return "80::32:0"
    if text.startswith("dac8x_"):
        return "80:4::1:"
    return "80:4::0:"


def _is_hdmi_output(output: Any) -> bool:
    text = _safe_str(output).strip().lower()
    return (
        text.startswith("hdmi:")
        or "vc4hdmi" in text
        or "vc4-hdmi" in text
        or "card=hdmi" in text
    )


def _player_lms_server_host() -> str:
    server = urllib.parse.urlsplit(LMS_BASE).hostname or "127.0.0.1"
    if _is_loopback_host(server):
        public_lms = urllib.parse.urlsplit(_public_lms_base())
        public_host = _safe_str(public_lms.hostname).strip()
        if public_host and not _is_loopback_host(public_host):
            server = public_host
    return server


def _lms_target_display() -> str:
    saved = _safe_str(_setup_cache.get("lms_base")).strip().rstrip("/")
    if saved:
        return saved
    if _broker_light_mode():
        return ""
    return LOCAL_LMS_BASE


def _normalize_lms_base_input(value: Any, allow_blank: bool) -> str:
    text = _safe_str(value).strip().rstrip("/")
    if not text:
        return "" if allow_blank else LOCAL_LMS_BASE
    if not re.match(r"^https?://", text, flags=re.I):
        text = "http://" + text
    parts = urllib.parse.urlsplit(text)
    if not parts.hostname:
        raise ValueError("LMS target must be a valid URL or host/IP")
    netloc = parts.netloc
    if ":" not in netloc:
        netloc = parts.hostname + ":9000"
    return urllib.parse.urlunsplit((parts.scheme or "http", netloc, "", "", ""))


def _managed_squeezelite_processes(mac_values: Set[str]) -> List[int]:
    wanted = {value.lower() for value in mac_values if value}
    pids = []
    try:
        for name in os.listdir("/proc"):
            if not name.isdigit():
                continue
            try:
                with open("/proc/{}/cmdline".format(name), "rb") as handle:
                    args = [
                        part.decode("utf-8", errors="replace")
                        for part in handle.read().split(b"\0")
                        if part
                    ]
                if not args or "squeezelite" not in os.path.basename(args[0]).lower():
                    continue
                if "-m" not in args:
                    continue
                index = args.index("-m")
                mac_parts = args[index + 1:index + 7]
                if index + 1 >= len(args):
                    mac = ""
                elif ":" in args[index + 1]:
                    mac = args[index + 1].lower()
                elif len(mac_parts) == 6 and all(re.fullmatch(r"[0-9A-Fa-f]{2}", part) for part in mac_parts):
                    mac = ":".join(mac_parts).lower()
                else:
                    mac = args[index + 1].lower()
                if mac in wanted:
                    pids.append(int(name))
            except Exception:
                continue
    except Exception:
        pass
    return pids


def _running_squeezelite_macs(mac_values: Set[str]) -> Set[str]:
    wanted = {value.lower() for value in mac_values if value}
    running: Set[str] = set()
    try:
        for name in os.listdir("/proc"):
            if not name.isdigit():
                continue
            try:
                with open("/proc/{}/cmdline".format(name), "rb") as handle:
                    args = [
                        part.decode("utf-8", errors="replace")
                        for part in handle.read().split(b"\0")
                        if part
                    ]
                if not args or "squeezelite" not in os.path.basename(args[0]).lower():
                    continue
                if "-m" not in args:
                    continue
                index = args.index("-m")
                mac_parts = args[index + 1:index + 7]
                if index + 1 >= len(args):
                    mac = ""
                elif ":" in args[index + 1]:
                    mac = args[index + 1].lower()
                elif len(mac_parts) == 6 and all(re.fullmatch(r"[0-9A-Fa-f]{2}", part) for part in mac_parts):
                    mac = ":".join(mac_parts).lower()
                else:
                    mac = args[index + 1].lower()
                if mac in wanted:
                    running.add(mac)
            except Exception:
                continue
    except Exception:
        pass
    return running


def _wait_for_squeezelite_macs(mac_values: Set[str], expected_count: int, timeout: float = 15.0) -> List[int]:
    deadline = time.time() + max(1.0, timeout)
    pids: List[int] = []
    while time.time() < deadline:
        pids = _managed_squeezelite_processes(mac_values)
        if len(_running_squeezelite_macs(mac_values)) >= expected_count:
            return pids
        time.sleep(0.5)
    return pids


def _squeezelite_args(row: Dict[str, str], extra: bool = True) -> List[str]:
    args = [
        "/usr/local/bin/squeezelite",
        "-n", row.get("startup_name") or row["name"],
        "-o", row["output"],
    ]
    if extra:
        args.extend(["-a", row.get("audio_params") or _default_audio_params_for_output(row.get("output"))])
    args.extend(["-m", row["mac"], "-s", row["server"]])
    return args


def _squeezelite_user_command(row: Dict[str, str]) -> str:
    return (
        '/usr/local/bin/squeezelite -n {name} -o {output} '
        '-a {audio_params} -m {mac} -s {server}'
    ).format(
        name=row.get("startup_name") or row["name"],
        output=row["output"],
        audio_params=row.get("audio_params") or _default_audio_params_for_output(row.get("output")),
        mac=row["mac"],
        server=row["server"],
    )


def _restart_pcp_main() -> str:
    pcp_binary = shutil.which("pcp") or "/usr/local/bin/pcp"
    result = subprocess.run(
        [pcp_binary, "slr"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=20,
        check=False,
    )
    return result.stdout or ""


def _launch_extra_sessions(rows: List[Dict[str, Any]]) -> None:
    for row in rows[1:]:
        if not bool(row.get("enabled", True)):
            continue
        command = _safe_str(row.get("command")).strip()
        args = shlex.split(command) if command else _squeezelite_args(row, extra=True)
        subprocess.Popen(
            args,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )


def _stop_managed_squeezelite(mac_values: Set[str]) -> None:
    for pid in _managed_squeezelite_processes(mac_values):
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass
    time.sleep(1.0)


def _restore_local_players(
    backup_path: str,
    old_rows: List[Dict[str, Any]],
    cleanup_macs: Set[str],
) -> None:
    _stop_managed_squeezelite(cleanup_macs)
    shutil.copyfile(backup_path, PCP_CONFIG_PATH)
    _restart_pcp_main()
    time.sleep(1.5)
    _launch_extra_sessions(old_rows)
    time.sleep(1.5)


def _jivelite_config_paths() -> List[str]:
    candidates = (
        "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
        "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
    )
    return [candidate for candidate in candidates if os.path.isfile(candidate)]


def _update_jivelite_player(player: Dict[str, str]) -> bool:
    paths = _jivelite_config_paths()
    if not paths:
        return False
    changed = False
    try:
        for path in paths:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                original = handle.read()
            updated = re.sub(
                r'playerId="[^"]*"',
                'playerId="{}"'.format(player["mac"]),
                original,
            )
            updated = re.sub(
                r'currentPlayer="[^"]*"',
                'currentPlayer="{}"'.format(player["mac"]),
                updated,
            )
            updated = re.sub(
                r'playerInit=\{name="[^"]*"',
                'playerInit={{name="{}"'.format(player["name"]),
                updated,
            )
            if updated == original:
                continue
            shutil.copyfile(path, path + ".lyrion-backup")
            with open(path, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(updated)
                handle.flush()
                os.fsync(handle.fileno())
            changed = True
        return changed
    except Exception as error:
        dbg("JiveLite player mapping skipped: {}".format(_safe_str(error)))
        return False


def _restart_jivelite_if_present() -> None:
    if not shutil.which("pcp"):
        return
    try:
        subprocess.run(
            ["/usr/local/bin/pcp", "jivelite", "restart"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
    except Exception:
        pass


def _apply_local_players(mode: str, rows: List[Dict[str, str]], jivelite_slot: str = "auto") -> Dict[str, Any]:
    if not os.path.isfile(PCP_CONFIG_PATH):
        raise RuntimeError("pCP configuration was not found")
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()

    backup_dir = os.path.join(os.path.dirname(SETUP_JSON_PATH), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    backup_path = os.path.join(backup_dir, "pcp.cfg.{}".format(int(time.time())))
    with open(backup_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(original)

    for row in rows:
        row["mac"] = _safe_str(row.get("mac")).strip().lower()

    dac8x_config_changed = _ensure_dac8x_asound_config([
        _safe_str(row.get("output")) for row in rows if bool(row.get("enabled", True))
    ])

    old_rows = _pcp_player_sessions()
    old_macs = {row.get("mac", "") for row in old_rows}
    server = rows[0]["server"]
    main = rows[0]
    updates = {
        "NAME": main.get("startup_name") or main["name"],
        "OUTPUT": main["output"],
        "MAC_ADDRESS": main["mac"],
        "SERVER_IP": server,
        "SQUEEZELITE": "yes",
        "ALSA_PARAMS": main.get("audio_params") or _default_audio_params_for_output(main.get("output")),
    }
    broker_command_slot = 3 if _broker_uses_user_command_slot() else 0
    for index in range(1, 5):
        key = "USER_COMMAND_{}".format(index)
        if index == broker_command_slot:
            updates[key] = urllib.parse.quote_plus(PCP_BROKER_LAUNCH_PATH, safe="")
        elif index < len(rows) and bool(rows[index].get("enabled", True)):
            command = _squeezelite_user_command(rows[index])
            updates[key] = urllib.parse.quote_plus(command, safe="")
        else:
            updates[key] = ""

    updated = _replace_pcp_config_values(original, updates)
    temp_path = PCP_CONFIG_PATH + ".lyrion-new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, PCP_CONFIG_PATH)

    enabled_rows = [row for row in rows if bool(row.get("enabled", True))]
    new_macs = {row["mac"] for row in enabled_rows}
    _stop_managed_squeezelite(old_macs)
    restart_output = _restart_pcp_main()
    main_running = bool(_wait_for_squeezelite_macs({main["mac"]}, 1))
    if not main_running:
        _restore_local_players(backup_path, old_rows, old_macs | new_macs)
        raise RuntimeError(
            "pCP did not start the expected main player; the original configuration was restored: {}".format(
                restart_output[-300:]
            )
        )

    _launch_extra_sessions(rows)
    expected_macs = new_macs
    running_pids = _wait_for_squeezelite_macs(expected_macs, len(enabled_rows))
    if len(running_pids) != len(enabled_rows):
        _restore_local_players(backup_path, old_rows, old_macs | new_macs)
        raise RuntimeError(
            "Only {} of {} players started; the original configuration was restored".format(
                len(running_pids), len(enabled_rows)
            )
        )
    mixer_result = _normalize_mixer_levels_for_outputs([
        _safe_str(row.get("output")) for row in enabled_rows
    ])

    jivelite_slot = _jivelite_player_slot_setting(jivelite_slot)
    jivelite_player = None
    if mode != "clone" and jivelite_slot != "none":
        hdmi_rows = [row for row in enabled_rows if _is_hdmi_output(row.get("output"))]
        if jivelite_slot.isdigit():
            jivelite_player = next((
                row for row in hdmi_rows
                if _safe_int(row.get("slot"), 0) == _safe_int(jivelite_slot, 0)
            ), None)
        if jivelite_player is None:
            jivelite_player = hdmi_rows[0] if hdmi_rows else None
    jivelite_updated = bool(
        jivelite_player and _update_jivelite_player(jivelite_player)
    )
    if jivelite_updated:
        _restart_jivelite_if_present()
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("Players restarted, but pCP backup failed: {}".format(backup.stdout[-300:]))
    _setup_cache["local_player_mode"] = mode
    _setup_cache["local_player_rows"] = [
        {
            "slot": index + 1,
            "enabled": bool(row.get("enabled", True)),
            "name": _safe_str(row.get("name")),
            "output": _safe_str(row.get("output")),
            "audio_params": _safe_str(row.get("audio_params")),
            "mac": _safe_str(row.get("mac")).lower(),
        }
        for index, row in enumerate(rows)
    ]
    _setup_cache["jivelite_player_slot"] = jivelite_slot
    _save_setup_config()
    return {
        "backup": backup_path,
        "players": len(enabled_rows),
        "jivelite_updated": jivelite_updated,
        "jivelite_target": _safe_str(jivelite_player.get("name") if jivelite_player else ""),
        "mixer_changed": len(mixer_result.get("changed", [])),
        "mixer_warnings": mixer_result.get("warnings", []),
        "dac8x_asound_changed": dac8x_config_changed,
    }


async def _player_fixed_volume(playerid: str) -> bool:
    response = await lms.rpc(playerid, ["playerpref", "digitalVolumeControl", "?"])
    value = (response.get("result") or {}).get("_p2")
    return _safe_int(value, 1) == 0


async def _apply_friendly_player_names(rows: List[Dict[str, str]]) -> None:
    pending = {
        _safe_str(row.get("mac")).strip().lower(): _safe_str(row.get("name")).strip()
        for row in rows
        if _safe_str(row.get("mac")).strip() and _safe_str(row.get("name")).strip()
    }
    deadline = asyncio.get_running_loop().time() + 15.0
    while pending and asyncio.get_running_loop().time() < deadline:
        players = await lms.get_players()
        connected = {
            _safe_str(player.get("playerid")).strip().lower()
            for player in players
            if _safe_int(player.get("connected"), 0) == 1
        }
        for playerid in list(pending):
            if playerid not in connected:
                continue
            await lms.rpc(playerid, ["name", pending[playerid]])
            pending.pop(playerid, None)
        if pending:
            await asyncio.sleep(0.5)
    if pending:
        raise RuntimeError(
            "Players started, but LMS did not reconnect for friendly naming: {}".format(
                ", ".join(sorted(pending))
            )
        )


async def _restore_friendly_player_names() -> None:
    async def repair_once() -> int:
        saved = _setup_cache.get("local_player_friendly_names")
        if not isinstance(saved, dict) or not saved:
            return 0
        active_macs = {
            _safe_str(row.get("mac")).strip().lower()
            for row in _pcp_player_sessions()
            if _safe_str(row.get("mac")).strip()
        }
        desired = {
            _safe_str(mac).strip().lower(): _safe_str(name).strip()
            for mac, name in saved.items()
            if _safe_str(mac).strip().lower() in active_macs and _safe_str(name).strip()
        }
        if not desired:
            return 0
        changed = 0
        players = await lms.get_players()
        for player in players:
            playerid = _safe_str(player.get("playerid")).strip().lower()
            if playerid not in desired or _safe_int(player.get("connected"), 0) != 1:
                continue
            current_name = _safe_str(player.get("name")).strip()
            friendly_name = desired[playerid]
            if current_name == friendly_name:
                continue
            await lms.rpc(playerid, ["name", friendly_name])
            changed += 1
        return changed

    try:
        await asyncio.sleep(4.0)
        while True:
            try:
                changed = await repair_once()
                if changed:
                    dbg("Friendly player names repaired: {}".format(changed))
                    await cometd_scan_and_subscribe_connected()
            except Exception as error:
                dbg("Friendly player name repair failed: {}".format(_safe_str(error)))
            await asyncio.sleep(30.0)
    except asyncio.CancelledError:
        raise
    except Exception as error:
        dbg("Friendly player name restore failed: {}".format(_safe_str(error)))


async def setup_players_page(req: web.Request) -> web.Response:
    sessions = _pcp_player_sessions()
    cards = _alsa_cards()
    available_outputs = _available_alsa_outputs()
    dac8x_detected = bool(_dac8x_card())
    clone_output_values, clone_missing = _clone_outputs()
    pi_model = _raspberry_pi_model()
    local_player_limit = _local_player_limit()
    requested_mode = _safe_str(req.query.get("mode")).lower()
    mode = requested_mode or ("open" if clone_missing else "clone")
    if mode not in ("clone", "open"):
        mode = "open" if clone_missing else "clone"
    if mode == "clone" and clone_missing:
        mode = "open"
    saved_player_rows = _setup_cache.get("local_player_rows")
    if not isinstance(saved_player_rows, list):
        saved_player_rows = []
    saved_count = max(
        [_safe_int(row.get("slot"), 0) for row in saved_player_rows if isinstance(row, dict)] or [0]
    )
    default_count = max(3, saved_count, len(sessions))
    requested_count = max(1, min(_safe_int(req.query.get("count"), default_count), local_player_limit))
    if mode == "clone":
        requested_count = min(requested_count, CLONE_MAX_PLAYERS)

    try:
        lms_players = await lms.get_players()
    except Exception:
        lms_players = []
    saved_friendly_names = _setup_cache.get("local_player_friendly_names")
    friendly_name_by_mac = {
        _safe_str(mac).strip().lower(): _safe_str(name).strip()
        for mac, name in (saved_friendly_names.items() if isinstance(saved_friendly_names, dict) else [])
        if _safe_str(mac).strip() and _safe_str(name).strip()
    }
    friendly_name_by_mac.update({
        _safe_str(player.get("playerid")).strip().lower(): _safe_str(player.get("name")).strip()
        for player in lms_players
        if _safe_str(player.get("playerid")).strip()
    })

    fixed_volume_by_mac: Dict[str, bool] = {}
    if sessions:
        states = await asyncio.gather(
            *(_player_fixed_volume(_safe_str(row.get("mac"))) for row in sessions),
            return_exceptions=True,
        )
        for row, state in zip(sessions, states):
            if isinstance(state, bool):
                fixed_volume_by_mac[_safe_str(row.get("mac")).lower()] = state

    current_rows = []
    for row in sessions:
        mac = _safe_str(row.get("mac")).strip().lower()
        checked = " checked" if fixed_volume_by_mac.get(mac, False) else ""
        current_rows.append(
            "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td>"
            "<td><code>{output}</code></td><td>{server}</td>"
            '<td><input class="fixed-volume" type="checkbox" data-mac="{mac}"{checked}></td>'
            '<td><button class="test-output" type="button" data-slot="{slot}" '
            'data-mac="{mac}" data-output="{output}">Test Output</button></td></tr>'.format(
                slot=row["slot"],
                name=_html_escape(
                    friendly_name_by_mac.get(mac)
                    or row["name"]
                    or "Player {}".format(row["slot"])
                ),
                mac=_html_escape(mac),
                output=_html_escape(row["output"]),
                server=_html_escape(row["server"]),
                checked=checked,
            )
        )
    if not current_rows:
        current_rows.append('<tr><td colspan="7">pCP configuration was not found on this host.</td></tr>')

    jivelite_present = bool(_jivelite_config_paths())

    card_rows = []
    for card in cards:
        card_rows.append(
            "<tr><td>{index}</td><td><code>{card_id}</code></td><td>{name}</td>"
            "<td><code>{path}</code></td><td>{detail}</td></tr>".format(
                index=_html_escape(card["index"]),
                card_id=_html_escape(card["id"]),
                name=_html_escape(card["name"]),
                path=_html_escape(card["path"]),
                detail=_html_escape(card["detail"]),
            )
        )
    if not card_rows:
        card_rows.append('<tr><td colspan="5">No ALSA cards were detected.</td></tr>')

    clone_labels = ("USB DAC - fixed Output 1 port", "USB DAC - fixed Output 2 port", "HiFiBerry DAC+")
    preview_rows = []
    preview_config: List[Dict[str, str]] = []
    for slot in range(1, requested_count + 1):
        saved_row = next((
            row for row in saved_player_rows
            if isinstance(row, dict) and _safe_int(row.get("slot"), 0) == slot
        ), {})
        active_row = next((row for row in sessions if row["slot"] == slot), {})
        enabled = True if slot == 1 else bool(
            saved_row.get("enabled", bool(active_row) if saved_player_rows else True)
        )
        if mode == "clone":
            output = clone_labels[slot - 1]
            mac = _managed_player_mac(slot)
            name = (
                friendly_name_by_mac.get(mac)
                or _safe_str(saved_row.get("name"))
                or "Player {}".format(slot)
            )
            output_control = (
                '<input type="hidden" class="player-output" value="{}"><code>{}</code>'.format(
                    _html_escape(clone_output_values[slot - 1]),
                    _html_escape(output),
                )
            )
        else:
            current = active_row or saved_row
            output = _safe_str(current.get("output")) or "Select a detected output"
            current_mac = _safe_str(current.get("mac")).strip().lower()
            name = (
                friendly_name_by_mac.get(current_mac)
                or _safe_str(current.get("name"))
                or "Player {}".format(slot)
            )
            options = ['<option value="">Select a detected output</option>']
            for device in available_outputs:
                value = _safe_str(device.get("output"))
                selected = " selected" if value == output else ""
                options.append('<option value="{}"{}>{}</option>'.format(
                    _html_escape(value),
                    selected,
                    _html_escape(device.get("label")),
                ))
            output_control = '<select class="player-output">{}</select>'.format("".join(options))
        selected_output = clone_output_values[slot - 1] if mode == "clone" else _safe_str(output)
        audio_params = (
            _safe_str(active_row.get("audio_params"))
            or _safe_str(saved_row.get("audio_params"))
            or _default_audio_params_for_output(selected_output)
        )
        preview_config.append({
            "slot": slot,
            "name": name,
            "startup_name": _player_startup_name(name, slot),
            "mac": _managed_player_mac(slot),
            "output": selected_output,
            "audio_params": audio_params,
            "server": _player_lms_server_host(),
            "enabled": enabled,
        })
        preview_rows.append(
            '<tr class="player-row" data-slot="{slot}"><td>{slot}</td>'
            '<td><input class="player-enabled" type="checkbox"{enabled}{required}></td>'
            '<td><input class="player-name" type="text" maxlength="48" value="{name}"></td>'
            '<td><code class="player-mac">{mac}</code></td><td>{output}</td>'
            '<td><input class="player-audio-params" type="text" maxlength="32" value="{audio_params}"></td></tr>'.format(
                slot=slot,
                enabled=" checked" if enabled else "",
                required=" disabled title=\"Player 1 is the required primary player\"" if slot == 1 else "",
                name=_html_escape(name),
                mac=_html_escape(_managed_player_mac(slot)),
                output=output_control,
                audio_params=_html_escape(audio_params),
            )
        )

    hdmi_preview_rows = [
        row for row in preview_config
        if bool(row.get("enabled", True)) and _is_hdmi_output(row.get("output"))
    ]
    saved_jivelite_slot = _jivelite_player_slot_setting()
    jivelite_control = ""
    if mode == "clone":
        jivelite_note = "JiveLite is not used in MS-3 Clone mode; HDMI display mapping is left unchanged."
    elif not jivelite_present:
        jivelite_note = "JiveLite was not detected. Install and configure it in pCP if this unit needs a local HDMI display."
    elif not hdmi_preview_rows:
        jivelite_note = "JiveLite is installed, but no enabled HDMI player is selected. JiveLite mapping is left unchanged."
    elif len(hdmi_preview_rows) == 1:
        row = hdmi_preview_rows[0]
        jivelite_note = "JiveLite is installed. Auto maps it to the enabled HDMI player: {}.".format(
            _safe_str(row.get("name") or "Player {}".format(row.get("slot")))
        )
        selected_auto = " selected" if saved_jivelite_slot == "auto" else ""
        selected_none = " selected" if saved_jivelite_slot == "none" else ""
        selected_slot = " selected" if saved_jivelite_slot == str(row.get("slot")) else ""
        jivelite_control = (
            '<label style="display:inline-block;margin-top:8px;">JiveLite Display Player '
            '<select id="jivelitePlayerSlot" class="player-jivelite">'
            '<option value="auto"{}>Auto - HDMI player</option>'
            '<option value="none"{}>Leave unchanged</option>'
            '<option value="{}"{}>Slot {} - {}</option>'
            '</select></label>'
        ).format(
            selected_auto,
            selected_none,
            _html_escape(row.get("slot")),
            selected_slot,
            _html_escape(row.get("slot")),
            _html_escape(row.get("name") or "Player {}".format(row.get("slot"))),
        )
    else:
        jivelite_note = "JiveLite is installed. Select which HDMI player should drive the local display."
        options = [
            '<option value="auto"{}>Auto - first HDMI player</option>'.format(
                " selected" if saved_jivelite_slot == "auto" else ""
            ),
            '<option value="none"{}>Leave unchanged</option>'.format(
                " selected" if saved_jivelite_slot == "none" else ""
            ),
        ]
        for row in hdmi_preview_rows:
            slot_value = str(row.get("slot"))
            selected = " selected" if saved_jivelite_slot == slot_value else ""
            options.append('<option value="{}"{}>Slot {} - {} ({})</option>'.format(
                _html_escape(slot_value),
                selected,
                _html_escape(slot_value),
                _html_escape(row.get("name") or "Player {}".format(slot_value)),
                _html_escape(row.get("output")),
            ))
        jivelite_control = (
            '<label style="display:inline-block;margin-top:8px;">JiveLite Display Player '
            '<select id="jivelitePlayerSlot" class="player-jivelite">{}</select></label>'
        ).format("".join(options))

    saved_player_mode = _safe_str(_setup_cache.get("local_player_mode")).lower()
    active_preview_config = [row for row in preview_config if bool(row.get("enabled", True))]
    stored_rows_match = (
        not saved_player_rows
        or (
            len(saved_player_rows) == len(preview_config)
            and all(
                bool(saved.get("enabled", True)) == bool(desired.get("enabled", True))
                and _safe_str(saved.get("name")) == desired["name"]
                and _safe_str(saved.get("output")) == desired["output"]
                and _safe_str(saved.get("audio_params")) == desired["audio_params"]
                for saved, desired in zip(saved_player_rows, preview_config)
            )
        )
    )
    configuration_matches = (
        saved_player_mode in ("", mode)
        and stored_rows_match
        and len(sessions) == len(active_preview_config)
        and all(
            _safe_str(current.get("name")) == desired["startup_name"]
            and _safe_str(current.get("mac")).lower() == desired["mac"].lower()
            and _safe_str(current.get("output")) == desired["output"]
            and _safe_str(current.get("audio_params")) == desired["audio_params"]
            and _safe_str(current.get("server")).lower() == desired["server"].lower()
            for current, desired in zip(sessions, active_preview_config)
        )
    )

    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Local Players</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
    <h2>Local Players</h2>
    <div class="page-nav"><a href="/setup">Setup</a><b>Local Players</b><a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>

    <form method="get" action="/setup/players" style="margin-bottom:18px;" id="provisioningForm">
      <h3>Provisioning Preview</h3>
      <label>Mode
        <select name="mode" onchange="this.form.submit()">
          <option value="clone"__CLONE_SELECTED____CLONE_DISABLED__>MS-3 Clone__CLONE_AVAILABILITY__</option>
          <option value="open"__OPEN_SELECTED__>Open</option>
        </select>
      </label>
      <label style="margin-left:14px;">Players
        <select name="count" onchange="this.form.submit()">
          __COUNT_OPTIONS__
        </select>
      </label>
      <table style="margin-top:16px;">
        <thead><tr><th>Slot</th><th>Enabled</th><th>Player Name</th><th>Stable MAC</th><th>Playback Device</th><th>ALSA Parameters</th></tr></thead>
        <tbody>__PREVIEW_ROWS__</tbody>
      </table>
      <div style="margin-top:12px;color:#596579;">
        Applying restarts local Squeezelite players and briefly interrupts playback.
        Friendly names may contain spaces. The broker automatically creates a safe underscore startup name
        for pCP, then applies the friendly name in LMS and RTI.
        This unit supports up to __LOCAL_PLAYER_LIMIT__ local players. __STARTUP_PROFILE__
        __OUTPUT_MODE_NOTE__
      </div>
      __CLONE_WARNING__
      <div class="save-dock">
        <span id="playerStatus">__AUTH_STATUS__</span>
        <button id="applyPlayers" type="button"__APPLY_DISABLED__>Apply Local Players</button>
      </div>
    </form>

    <div class="quick-links">
      <h3>Current pCP Sessions</h3>
      <table>
        <thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>LMS</th><th>Fixed Volume</th><th>Identify</th></tr></thead>
        <tbody>__CURRENT_ROWS__</tbody>
      </table>
      <div style="margin-top:10px;">
        <button class="player-action" type="button" data-action="restart">Restart Players</button>
        <button class="player-action" type="button" data-action="start">Start Players</button>
        <button class="player-action" type="button" data-action="stop">Stop Players</button>
        <button class="player-action" type="button" data-action="normalize">Normalize Output Levels</button>
        <button id="applyFixedVolume" type="button">Apply Volume Settings</button>
        <span id="volumeStatus" style="margin-left:10px;color:#596579;">Fixed outputs play at 100% and ignore RTI/LMS volume changes.</span>
      </div>
      <div style="font-size:12px;color:#596579;margin-top:8px;">__JIVELITE_NOTE__</div>
      <div style="font-size:12px;color:#596579;">__JIVELITE_CONTROL__</div>
      <h3>Detected ALSA Devices</h3>
      <table>
        <thead><tr><th>Card</th><th>ID</th><th>Name</th><th>Physical Path</th><th>Detail</th></tr></thead>
        <tbody>__CARD_ROWS__</tbody>
      </table>
    </div>
  </main>
  <script>
  (function () {
    var button = document.getElementById("applyPlayers");
    var status = document.getElementById("playerStatus");
    var playerEditors = Array.from(document.querySelectorAll(".player-enabled, .player-name, .player-output, .player-audio-params, .player-jivelite"));
    playerEditors.forEach(function (editor) {
      editor.addEventListener("input", function () {
        button.disabled = false;
        status.textContent = "Changes are ready to apply.";
        status.style.color = "#9a3412";
        status.style.fontWeight = "bold";
      });
      editor.addEventListener("change", function () {
        button.disabled = false;
        status.textContent = "Changes are ready to apply.";
        status.style.color = "#9a3412";
        status.style.fontWeight = "bold";
      });
    });
    button.addEventListener("click", async function () {
      if (!window.confirm("Back up pCP configuration and restart local players now?")) return;
      button.disabled = true;
      status.textContent = "Saving configuration and restarting players...";
      var players = Array.from(document.querySelectorAll(".player-row")).map(function (row) {
        return {
          enabled: row.querySelector(".player-enabled").checked,
          name: row.querySelector(".player-name").value,
          output: row.querySelector(".player-output").value,
          audio_params: row.querySelector(".player-audio-params").value
        };
      });
      var jiveliteSelect = document.getElementById("jivelitePlayerSlot");
      try {
        var response = await fetch("/api/setup/players/apply", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({
            mode: "__MODE__",
            players: players,
            jivelite_player_slot: jiveliteSelect ? jiveliteSelect.value : "auto"
          })
        });
        var data = await response.json();
        if (response.status === 401) {
          throw new Error("Open Advanced Setup and enter the password, then return here.");
        }
        if (!data.ok) throw new Error(data.error || "Apply failed");
        status.textContent = "Applied " + data.players + " players. Refreshing...";
        window.setTimeout(function () { window.location.reload(); }, 2500);
      } catch (error) {
        status.textContent = error.message;
        button.disabled = false;
      }
    });

    var volumeButton = document.getElementById("applyFixedVolume");
    var volumeStatus = document.getElementById("volumeStatus");
    var volumeBoxes = Array.from(document.querySelectorAll(".fixed-volume"));
    var volumeDirty = false;
    function markVolumeDirty() {
      volumeDirty = true;
      volumeButton.textContent = "Save Volume Changes";
      volumeButton.style.background = "#b45309";
      volumeButton.style.borderColor = "#92400e";
      volumeButton.style.color = "#fff";
      volumeStatus.textContent = "Volume changes have not been saved.";
      volumeStatus.style.color = "#9a3412";
      volumeStatus.style.fontWeight = "bold";
    }
    function clearVolumeDirty() {
      volumeDirty = false;
      volumeButton.textContent = "Apply Volume Settings";
      volumeButton.style.background = "";
      volumeButton.style.borderColor = "";
      volumeButton.style.color = "";
      volumeStatus.style.color = "#18794e";
      volumeStatus.style.fontWeight = "bold";
    }
    volumeBoxes.forEach(function (box) {
      box.addEventListener("change", markVolumeDirty);
    });
    window.addEventListener("beforeunload", function (event) {
      if (!volumeDirty) return;
      event.preventDefault();
      event.returnValue = "";
    });
    Array.from(document.querySelectorAll(".player-action")).forEach(function (actionButton) {
      actionButton.addEventListener("click", async function () {
        var action = actionButton.getAttribute("data-action");
        if (!window.confirm(actionButton.textContent + " now?")) return;
        actionButton.disabled = true;
        volumeStatus.textContent = actionButton.textContent + " requested...";
        volumeStatus.style.color = "#596579";
        try {
          var response = await fetch("/api/setup/players/action", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action: action})
          });
          var data = await response.json();
          if (!data.ok) throw new Error(data.error || "Player action failed");
          volumeStatus.textContent = data.message || "Player action completed.";
          volumeStatus.style.color = "#18794e";
          window.setTimeout(function () { window.location.reload(); }, 1500);
        } catch (error) {
          volumeStatus.textContent = error.message;
          volumeStatus.style.color = "#b42318";
          actionButton.disabled = false;
        }
      });
    });
    volumeButton.addEventListener("click", async function () {
      volumeButton.disabled = true;
      volumeStatus.textContent = "Applying volume settings...";
      var players = volumeBoxes.map(function (box) {
        return {mac: box.getAttribute("data-mac"), fixed: box.checked};
      });
      try {
        var response = await fetch("/api/setup/players/fixed-volume", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({players: players})
        });
        var data = await response.json();
        if (response.status === 401) {
          throw new Error("Open Advanced Setup and enter the password, then return here.");
        }
        if (!data.ok) throw new Error(data.error || "Volume update failed");
        volumeStatus.textContent = "Volume settings applied.";
        clearVolumeDirty();
      } catch (error) {
        volumeStatus.textContent = error.message;
        volumeStatus.style.color = "#b42318";
        volumeStatus.style.fontWeight = "bold";
      } finally {
        volumeButton.disabled = false;
      }
    });

    Array.from(document.querySelectorAll(".test-output")).forEach(function (testButton) {
      testButton.addEventListener("click", async function () {
        var originalText = testButton.textContent;
        testButton.disabled = true;
        testButton.textContent = "Testing...";
        volumeStatus.textContent = "Testing output " + testButton.getAttribute("data-slot") + "...";
        try {
          var response = await fetch("/api/setup/players/test-output", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
              slot: Number(testButton.getAttribute("data-slot")),
              mac: testButton.getAttribute("data-mac"),
              output: testButton.getAttribute("data-output")
            })
          });
          var data = await response.json();
          if (response.status === 401) {
            throw new Error("Open Advanced Setup and enter the password, then return here.");
          }
          if (!data.ok) throw new Error(data.error || "Output test failed");
          volumeStatus.textContent = "Output test completed; selected player restarted.";
          volumeStatus.style.color = "#18794e";
        } catch (error) {
          volumeStatus.textContent = error.message;
          volumeStatus.style.color = "#b42318";
        } finally {
          testButton.disabled = false;
          testButton.textContent = originalText;
        }
      });
    });
  }());
  </script>
</body>
</html>"""
    count_options = []
    max_count = CLONE_MAX_PLAYERS if mode == "clone" else local_player_limit
    for value in range(1, max_count + 1):
        selected = " selected" if value == requested_count else ""
        count_options.append('<option value="{}"{}>{}</option>'.format(value, selected, value))
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Player setup preview"))
        .replace("__CLONE_SELECTED__", " selected" if mode == "clone" else "")
        .replace("__CLONE_DISABLED__", " disabled" if clone_missing else "")
        .replace("__CLONE_AVAILABILITY__", " (Not Available)" if clone_missing else "")
        .replace("__OPEN_SELECTED__", " selected" if mode == "open" else "")
        .replace("__COUNT_OPTIONS__", "".join(count_options))
        .replace("__PREVIEW_ROWS__", "".join(preview_rows))
        .replace("__CURRENT_ROWS__", "".join(current_rows))
        .replace("__CARD_ROWS__", "".join(card_rows))
        .replace("__JIVELITE_NOTE__", _html_escape(jivelite_note))
        .replace("__JIVELITE_CONTROL__", jivelite_control)
        .replace("__MODE__", mode)
        .replace("__LOCAL_PLAYER_LIMIT__", str(local_player_limit))
        .replace(
            "__OUTPUT_MODE_NOTE__",
            _html_escape(
                "DAC8x stereo-pair outputs are available because a DAC8x card was detected; USB, HDMI, and other hats remain selectable too."
                if dac8x_detected
                else "Player choices come from detected ALSA outputs, so USB DACs, HDMI, and audio hats can be mixed as available."
            )
        )
        .replace(
            "__STARTUP_PROFILE__",
            _html_escape(
                "{} uses USER_COMMAND_3 for broker startup.".format(pi_model or "Pi3 profile")
                if _broker_uses_user_command_slot()
                else "{} uses bootlocal/watchdog for broker startup.".format(pi_model or "Pi4/Pi5 profile")
            )
        )
        .replace(
            "__CLONE_WARNING__",
            '<div style="margin-top:12px;color:#b42318;"><b>Clone Mode cannot be applied:</b> {}</div>'.format(
                _html_escape(", ".join(clone_missing))
            ) if mode == "clone" and clone_missing else ""
        )
        .replace(
            "__APPLY_DISABLED__",
            " disabled" if (mode == "clone" and clone_missing) or configuration_matches else ""
        )
        .replace(
            "__AUTH_STATUS__",
            (
                "Configuration matches current players."
                if configuration_matches
                else "Changes are ready to apply."
            )
        )
    )
    return web.Response(text=html, content_type="text/html")


async def api_setup_players_apply(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        mode = _safe_str(body.get("mode")).lower()
        if mode not in ("clone", "open"):
            raise ValueError("Invalid player mode")
        requested = body.get("players")
        if not isinstance(requested, list):
            raise ValueError("Players are required")
        maximum = CLONE_MAX_PLAYERS if mode == "clone" else _local_player_limit()
        if len(requested) < 1 or len(requested) > maximum:
            raise ValueError("{} Mode supports 1-{} players".format(mode.title(), maximum))

        allowed_outputs = {row["output"] for row in _available_alsa_outputs()}
        if mode == "clone":
            clone_outputs, missing = _clone_outputs()
            if missing:
                raise ValueError("Clone hardware is missing: {}".format(", ".join(missing)))
            selected_outputs = clone_outputs[:len(requested)]
        else:
            selected_outputs = [
                _validate_player_text(row.get("output"), "Player {} output".format(index + 1))
                for index, row in enumerate(requested)
            ]
        if any(output not in allowed_outputs for output in selected_outputs):
            raise ValueError("A selected playback device is no longer available")
        if len(set(selected_outputs)) != len(selected_outputs):
            raise ValueError("Each player must use a different playback device")

        server = _player_lms_server_host()
        jivelite_player_slot = _jivelite_player_slot_setting(body.get("jivelite_player_slot"))
        rows = []
        for index, item in enumerate(requested):
            enabled = True if index == 0 else bool(item.get("enabled", True))
            audio_params = _safe_str(item.get("audio_params")).strip()
            if not audio_params or len(audio_params) > 32 or not re.fullmatch(r"[0-9:]+", audio_params):
                raise ValueError(
                    "Player {} ALSA parameters may contain only numbers and colons".format(index + 1)
                )
            player_name = _validate_player_text(
                item.get("name"), "Player {} name".format(index + 1)
            )
            rows.append({
                "slot": index + 1,
                "enabled": enabled,
                "name": player_name,
                "startup_name": _player_startup_name(player_name, index + 1),
                "output": selected_outputs[index],
                "audio_params": audio_params,
                "mac": _managed_player_mac(index + 1),
                "server": server,
            })
        result = await asyncio.to_thread(_apply_local_players, mode, rows, jivelite_player_slot)
        enabled_rows = [row for row in rows if bool(row.get("enabled", True))]
        await _apply_friendly_player_names(enabled_rows)
        _setup_cache["local_player_friendly_names"] = {
            row["mac"]: row["name"] for row in rows
        }
        _save_setup_config()
        await cometd_scan_and_subscribe_connected()
        return web.json_response({"ok": True, **result})
    except Exception as error:
        dbg("Local player apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_players_fixed_volume(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        requested = body.get("players")
        if not isinstance(requested, list):
            raise ValueError("Players are required")
        allowed = {
            _safe_str(row.get("mac")).strip().lower()
            for row in _pcp_player_sessions()
            if _safe_str(row.get("mac")).strip()
        }
        changed = 0
        for item in requested:
            if not isinstance(item, dict):
                raise ValueError("Invalid player volume setting")
            playerid = _safe_str(item.get("mac")).strip().lower()
            if playerid not in allowed:
                raise ValueError("Unknown local player: {}".format(playerid))
            fixed = bool(item.get("fixed"))
            await lms.rpc(
                playerid,
                ["playerpref", "digitalVolumeControl", "0" if fixed else "1"],
            )
            if await _player_fixed_volume(playerid) != fixed:
                raise RuntimeError("LMS did not retain the volume setting for {}".format(playerid))
            changed += 1
        return web.json_response({"ok": True, "players": changed})
    except Exception as error:
        dbg("Fixed volume apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_players_action(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        action = _safe_str(body.get("action")).strip().lower()
        if action == "restart":
            await asyncio.to_thread(_restart_all_local_players)
            return web.json_response({"ok": True, "message": "Local players restarted."})
        if action == "start":
            result = await asyncio.to_thread(_start_all_local_players)
            return web.json_response({"ok": True, "message": "Started {} local players.".format(result["players"])})
        if action == "stop":
            result = await asyncio.to_thread(_stop_all_local_players)
            return web.json_response({"ok": True, "message": "Stopped {} local players.".format(result["players"])})
        if action == "normalize":
            outputs = [
                _safe_str(row.get("output"))
                for row in _pcp_player_sessions()
                if _safe_str(row.get("output")).strip()
            ]
            result = await asyncio.to_thread(_normalize_mixer_levels_for_outputs, outputs)
            message = "Normalized mixer levels on {} controls.".format(len(result.get("changed", [])))
            warnings = result.get("warnings") if isinstance(result.get("warnings"), list) else []
            if warnings:
                message += " Warnings: {}".format("; ".join(_safe_str(item) for item in warnings[:3]))
            return web.json_response({"ok": True, "message": message})
        raise ValueError("Unknown player action")
    except Exception as error:
        dbg("Local player action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _apply_system_hostname(hostname: str) -> None:
    if not os.path.isfile(PCP_CONFIG_PATH):
        raise RuntimeError("pCP configuration was not found")
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()

    try:
        query = urllib.parse.urlencode({"HOST": hostname, "SUBMIT": "Save"})
        with urllib.request.urlopen("http://127.0.0.1/cgi-bin/writetohost.cgi?" + query, timeout=20) as response:
            response.read()
        saved_host = _safe_str(_read_pcp_config().get("HOST")).strip()
        if saved_host.lower() != hostname.lower():
            raise RuntimeError("pCP hostname CGI did not update HOST")
    except Exception:
        updated = _replace_pcp_config_values(original, {"HOST": hostname})
        temp_path = PCP_CONFIG_PATH + ".hostname-new"
        with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, PCP_CONFIG_PATH)
        saved_host = _safe_str(_read_pcp_config().get("HOST")).strip()
        if saved_host.lower() != hostname.lower():
            with open(PCP_CONFIG_PATH, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(original)
            raise RuntimeError("Hostname save failed")
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("Hostname changed, but pCP backup failed: {}".format((backup.stdout or "")[-300:]))


def _set_pcp_lms_autostart(enabled: bool) -> str:
    if not os.path.isfile(PCP_CONFIG_PATH):
        return "pCP configuration was not found; LMS autostart was not changed"
    config = _read_pcp_config()
    bool_value = "yes" if enabled else "no"
    updates: Dict[str, str] = {}
    for key in (
        "LMSERVER",
        "LMS_SERVER",
        "LOCAL_LMS",
        "SLIMSERVER",
        "SQUEEZEBOXSERVER",
    ):
        if key in config:
            updates[key] = bool_value
    if not updates:
        return "No pCP LMS autostart key was found; runtime LMS action only"
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()
    updated = _replace_pcp_config_values(original, updates)
    if updated == original:
        return "pCP LMS autostart already {}".format("enabled" if enabled else "disabled")
    temp_path = PCP_CONFIG_PATH + ".lms-role-new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, PCP_CONFIG_PATH)
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("pCP LMS autostart changed, but backup failed: {}".format((backup.stdout or "")[-300:]))
    return "pCP LMS autostart {}".format("enabled" if enabled else "disabled")


def _pcp_set_player_server_mode(full_mode: bool) -> str:
    mode_code = "30" if full_mode else "10"
    mode_name = "Player/Server" if full_mode else "Player"
    url = "http://127.0.0.1/cgi-bin/debug.cgi?m={}".format(mode_code)
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            body = response.read(2048)
            if response.status >= 400:
                raise RuntimeError("pCP mode switch returned HTTP {}".format(response.status))
    except Exception as error:
        raise RuntimeError("pCP {} mode switch failed: {}".format(mode_name, _safe_str(error)))
    return "pCP mode set to {}".format(mode_name)


async def api_setup_system_identity(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        hostname = _safe_str(body.get("hostname")).strip()
        library_name = _safe_str(body.get("library_name")).strip()
        effective_library_name = library_name or hostname
        if (
            not hostname
            or len(hostname) > 26
            or not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", hostname)
        ):
            raise ValueError("Hostname must use 1-26 letters, numbers, or hyphens and cannot end with a hyphen")
        if len(effective_library_name) > 80 or any(char in effective_library_name for char in ("\r", "\n")):
            raise ValueError("LMS library name contains unsupported characters")

        current_host = _safe_str(_read_pcp_config().get("HOST") or socket.gethostname()).strip()
        live_host = _safe_str(socket.gethostname()).strip().split(".", 1)[0]
        hostname_changed = hostname.lower() != current_host.lower()
        if hostname_changed:
            await asyncio.to_thread(_apply_system_hostname, hostname)
        if not _broker_light_mode():
            await lms.rpc("", ["pref", "libraryname", effective_library_name])
            verify = await lms.rpc("", ["pref", "libraryname", "?"])
            retained = _safe_str((verify.get("result") or {}).get("_p2")).strip()
            if retained != effective_library_name:
                raise RuntimeError("LMS did not retain the library name")
        return web.json_response({
            "ok": True,
            "hostname": hostname,
            "library_name": "" if _broker_light_mode() else effective_library_name,
            "hostname_changed": hostname_changed,
            "reboot_required": hostname_changed or live_host.lower() != hostname.lower(),
        })
    except Exception as error:
        dbg("System identity apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _test_player_output(row: Dict[str, Any]) -> str:
    playerid = _safe_str(row.get("mac")).strip().lower()
    output = _safe_str(row.get("output")).strip()
    slot = _safe_int(row.get("slot"), 0)
    speaker_test = shutil.which("speaker-test")
    if not speaker_test:
        raise RuntimeError("speaker-test is not installed on this pCP system")

    _stop_managed_squeezelite({playerid})
    test_error = ""
    test_output = ""
    try:
        result = subprocess.run(
            [speaker_test, "-D", output, "-c", "2", "-t", "sine", "-f", "880", "-l", "1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=12,
            check=False,
        )
        test_output = result.stdout or ""
        if result.returncode != 0:
            test_error = "Audio test failed: {}".format(test_output[-500:])
    except subprocess.TimeoutExpired:
        test_error = "Audio test timed out"
    finally:
        if slot == 1:
            _restart_pcp_main()
        else:
            _launch_extra_sessions([{}, row])
        if not _wait_for_squeezelite_macs({playerid}, 1, timeout=12):
            raise RuntimeError("Audio test finished, but the selected player did not restart")
    if test_error:
        raise RuntimeError(test_error)
    return test_output[-500:]


async def api_setup_players_test_output(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        slot = _safe_int(body.get("slot"), 0)
        playerid = _safe_str(body.get("mac")).strip().lower()
        output = _safe_str(body.get("output")).strip()
        row = next((
            item for item in _pcp_player_sessions()
            if _safe_int(item.get("slot"), 0) == slot
            and _safe_str(item.get("mac")).strip().lower() == playerid
            and _safe_str(item.get("output")).strip() == output
        ), None)
        if not isinstance(row, dict):
            raise ValueError("The selected active player/output no longer matches pCP configuration")
        detail = await asyncio.to_thread(_test_player_output, row)
        return web.json_response({"ok": True, "slot": slot, "detail": detail})
    except Exception as error:
        dbg("Player output test failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_mode(req: web.Request) -> web.Response:
    try:
        _load_setup_config()
        ctype = _safe_str(req.headers.get("content-type")).lower()
        if "application/json" in ctype:
            body = await req.json()
        else:
            body = await req.post()
        requested_mode = _safe_str(body.get("broker_mode")).strip().lower()
        if requested_mode not in ("full", "light"):
            raise ValueError("Broker role must be Full or Light")
        previous_mode = _broker_mode()
        lms_base = _normalize_lms_base_input(body.get("lms_base"), allow_blank=(requested_mode == "full"))
        if requested_mode == "light" and not lms_base:
            raise ValueError("Broker Light requires an LMS Target for the main controller LMS")
        previous_lms_base = _safe_str(_setup_cache.get("lms_base")).strip() or LOCAL_LMS_BASE
        next_lms_base = "" if requested_mode == "full" and lms_base == LOCAL_LMS_BASE else lms_base
        effective_next_lms_base = next_lms_base or LOCAL_LMS_BASE
        lms_target_changed = previous_lms_base.rstrip("/").lower() != effective_next_lms_base.rstrip("/").lower()
        _setup_cache["broker_mode"] = requested_mode
        _setup_cache["lms_base"] = next_lms_base
        _save_setup_config()
        _load_setup_config()
        await _apply_lms_base(_safe_str(_setup_cache.get("lms_base")).strip() or LOCAL_LMS_BASE)

        service_message = ""
        if previous_mode != requested_mode:
            if requested_mode == "light":
                try:
                    pcp_mode_message = await asyncio.to_thread(_pcp_set_player_server_mode, False)
                    persist_message = await asyncio.to_thread(_set_pcp_lms_autostart, False)
                    runtime_message = await asyncio.to_thread(_stop_local_lms)
                    service_message = "{}. {}. {}".format(pcp_mode_message, persist_message, runtime_message)
                except Exception as error:
                    service_message = "Broker Light saved, but local LMS stop failed: {}".format(_safe_str(error))
            else:
                try:
                    pcp_mode_message = await asyncio.to_thread(_pcp_set_player_server_mode, True)
                    persist_message = await asyncio.to_thread(_set_pcp_lms_autostart, True)
                    runtime_message = await asyncio.to_thread(_start_local_lms)
                    service_message = "{}. {}. {}".format(pcp_mode_message, persist_message, runtime_message)
                except Exception as error:
                    service_message = "Full Broker saved, but local LMS start failed: {}".format(_safe_str(error))
        message = "Broker role saved as {}.".format("Broker Light" if requested_mode == "light" else "Full Broker")
        if service_message:
            message += " " + service_message
        if lms_target_changed:
            message += " LMS Target changed: re-apply Local Players so they register with the selected LMS, then re-run RTI discovery/config."
        if "application/json" not in ctype:
            raise web.HTTPFound("/setup")
        return web.json_response({"ok": True, "mode": requested_mode, "lms_base": LMS_BASE, "message": message})
    except web.HTTPFound:
        raise
    except Exception as error:
        dbg("Broker role save failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _local_ipv4_addresses() -> List[str]:
    out: List[str] = []
    try:
        result = subprocess.run(
            ["hostname", "-I"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3,
            check=False,
        )
        for token in (result.stdout or "").split():
            if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", token):
                out.append(token)
    except Exception:
        pass
    return out


def _neighbor_ipv4_addresses() -> List[str]:
    out: List[str] = []
    try:
        with open("/proc/net/arp", "r", encoding="utf-8", errors="replace") as handle:
            for line in handle.read().splitlines()[1:]:
                fields = line.split()
                if fields and re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", fields[0]):
                    out.append(fields[0])
    except Exception:
        pass
    return out


def _host_from_lms_base(value: Any) -> str:
    text = _safe_str(value).strip()
    if not text:
        return ""
    if not re.match(r"^https?://", text, flags=re.I):
        text = "http://" + text
    try:
        return _safe_str(urllib.parse.urlsplit(text).hostname)
    except Exception:
        return ""


def _probe_lms_host(host: str) -> Optional[Dict[str, str]]:
    base = "http://{}:9000".format(host)
    payload = json.dumps({"id": 1, "method": "slim.request", "params": ["", ["serverstatus", 0, 1]]}).encode("utf-8")
    try:
        request = urllib.request.Request(
            base + "/jsonrpc.js",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=1.25) as response:
            data = json.loads(response.read(8192).decode("utf-8", errors="replace"))
        result = data.get("result") if isinstance(data, dict) else {}
        if not isinstance(result, dict) or not result:
            return None
        return {
            "host": host,
            "base": base,
            "name": _safe_str(result.get("servername") or result.get("version") or "LMS"),
            "version": _safe_str(result.get("version")),
            "uuid": _safe_str(result.get("uuid")),
            "mac": _safe_str(result.get("mac")),
            "server_ip": _safe_str(result.get("ip")),
        }
    except Exception:
        return None


async def api_setup_lms_discovery(_req: web.Request) -> web.Response:
    candidates: Set[str] = set()
    for base in (
        _setup_cache.get("lms_base"),
        LMS_BASE,
        os.environ.get("LMS_BASE", ""),
    ):
        host = _host_from_lms_base(base)
        if host:
            candidates.add(host)
    for address in _local_ipv4_addresses():
        parts = address.split(".")
        if len(parts) == 4 and not address.startswith("127."):
            prefix = ".".join(parts[:3])
            candidates.update("{}.{}".format(prefix, index) for index in range(1, 255))
    candidates.update(_neighbor_ipv4_addresses())
    if not _broker_light_mode():
        candidates.update(("127.0.0.1", "localhost"))
    semaphore = asyncio.Semaphore(32)

    async def probe_one(host: str) -> Optional[Dict[str, str]]:
        async with semaphore:
            return await asyncio.to_thread(_probe_lms_host, host)

    found = await asyncio.gather(
        *(probe_one(host) for host in sorted(candidates)),
        return_exceptions=True,
    )
    deduped: OrderedDict[str, Dict[str, str]] = OrderedDict()
    for row in found:
        if not isinstance(row, dict) or not row.get("base"):
            continue
        key = _safe_str(row.get("uuid")).strip().lower()
        if not key:
            key = _safe_str(row.get("mac")).strip().lower()
        if not key:
            key = _safe_str(row.get("server_ip")).strip() or _safe_str(row.get("base")).lower()
        existing = deduped.get(key)
        if existing is None:
            deduped[key] = row
            continue
        existing_loopback = _safe_str(existing.get("host")).lower() in ("127.0.0.1", "localhost")
        row_loopback = _safe_str(row.get("host")).lower() in ("127.0.0.1", "localhost")
        if existing_loopback and not row_loopback:
            deduped[key] = row
    rows = list(deduped.values())
    rows.sort(key=lambda row: (row.get("host") in ("127.0.0.1", "localhost"), row.get("host", "")))
    return web.json_response({"ok": True, "servers": rows[:12]})


def _broker_mode_panel() -> str:
    mode = _broker_mode()
    target = _lms_target_display()
    full_checked = " checked" if mode == "full" else ""
    light_checked = " checked" if mode == "light" else ""
    target_hint = (
        "Full mode may be blank to use local LMS. Light mode should point to the main controller LMS. "
        "After changing LMS Target, re-apply Local Players so they register with that LMS, then re-run RTI discovery/config."
    )
    return """
<section class="quick-links" style="margin-bottom:18px;">
  <h3>Broker Role</h3>
  <form id="brokerModeForm" style="padding:0;border:0;box-shadow:none;margin:0;">
    <label style="display:block;margin:6px 0;"><input type="radio" name="broker_mode" value="full"__FULL_CHECKED__> Full Broker - LMS, RTI, sources, plugins, and local players</label>
    <label style="display:block;margin:6px 0;"><input type="radio" name="broker_mode" value="light"__LIGHT_CHECKED__> Broker Light - remote pCP player setup only</label>
    <label style="display:block;margin-top:12px;">LMS Target
      <input id="modeLmsBase" type="text" name="lms_base" value="__LMS_TARGET__" placeholder="192.168.88.139 or http://host:9000" style="width:420px;max-width:100%;padding:6px;box-sizing:border-box;">
    </label>
    <div style="font-size:12px;color:#666;margin-top:6px;">__TARGET_HINT__</div>
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <button id="saveBrokerMode" type="button">Save Broker Role</button>
      <button id="scanLmsServers" type="button">Find LMS Servers</button>
      <select id="lmsDiscoveryList" style="display:none;min-width:260px;"></select>
      <span id="brokerModeStatus" style="color:#596579;"></span>
    </div>
  </form>
</section>
<script>
(function(){
  var form=document.getElementById("brokerModeForm");
  if(!form)return;
  var status=document.getElementById("brokerModeStatus");
  var target=document.getElementById("modeLmsBase");
  var list=document.getElementById("lmsDiscoveryList");
  document.getElementById("saveBrokerMode").addEventListener("click",async function(){
    var selected=form.querySelector("input[name=broker_mode]:checked");
    if(!selected)return;
    if(!window.confirm("Save broker role as "+selected.value+"? This may start or stop local LMS."))return;
    status.textContent="Saving broker role...";
    try{
      var response=await fetch("/api/setup/mode",{
        method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({broker_mode:selected.value,lms_base:target.value})
      });
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Save failed");
      status.textContent=data.message||"Broker role saved.";
      window.setTimeout(function(){window.location.reload();},1800);
    }catch(error){status.textContent=error.message;status.style.color="#b42318";}
  });
  document.getElementById("scanLmsServers").addEventListener("click",async function(){
    status.textContent="Scanning local network for LMS...";
    list.style.display="none";list.innerHTML="";
    try{
      var response=await fetch("/api/setup/lms-discovery",{cache:"no-store"});
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Scan failed");
      if(!(data.servers||[]).length){status.textContent="No LMS servers found.";return;}
      (data.servers||[]).forEach(function(server){
        var option=document.createElement("option");
        option.value=server.base;
        option.textContent=(server.name||"LMS")+" - "+server.base+(server.version?" ("+server.version+")":"");
        list.appendChild(option);
      });
      list.style.display="";
      target.value=list.value;
      status.textContent="Found "+data.servers.length+" LMS server(s).";
    }catch(error){status.textContent=error.message;status.style.color="#b42318";}
  });
  list.addEventListener("change",function(){target.value=list.value;});
}());
</script>""".replace("__FULL_CHECKED__", full_checked).replace(
        "__LIGHT_CHECKED__", light_checked
    ).replace("__LMS_TARGET__", _html_escape(target)).replace(
        "__TARGET_HINT__", _html_escape(target_hint)
    )


async def setup_light_page(req: web.Request) -> web.Response:
    status = await _system_status_snapshot()
    temp_text = "{} C".format(status["temperature"]) if status["temperature"] is not None else "Unavailable"
    loadavg = status["loadavg"]
    load_text = "Unavailable" if loadavg.get("one") is None else "{:.2f} / {:.2f} / {:.2f}".format(
        loadavg.get("one") or 0.0,
        loadavg.get("five") or 0.0,
        loadavg.get("fifteen") or 0.0,
    )
    mem_total = max(_safe_int(status["memory"].get("total"), 0), 1)
    mem_avail = _safe_int(status["memory"].get("available"), 0)
    mem_used = max(mem_total - mem_avail, 0)
    memory_text = "{:.0f}% used ({:.0f} MB free)".format(
        (mem_used / mem_total) * 100.0,
        mem_avail / 1048576.0,
    )
    player_rows = "".join(
        "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td><td><code>{output}</code></td>"
        "<td style=\"color:{color};font-weight:bold;\">{state}</td></tr>".format(
            slot=_html_escape(row.get("slot")),
            name=_html_escape(row.get("name")),
            mac=_html_escape(row.get("mac")),
            output=_html_escape(row.get("output")),
            color="#18794e" if row.get("running") else "#b42318",
            state="Running" if row.get("running") else "Stopped",
        )
        for row in status["players"]
    ) or '<tr><td colspan="5">No configured local players found.</td></tr>'
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Lyrion Gadget Light</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell">
<h2>Broker Light</h2>
<div class="page-nav"><b>Status</b><a href="/setup/players">Player Setup</a><a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>
__BROKER_MODE_PANEL__
<section class="quick-links">
<h3>Device Status</h3>
<table><tbody>
<tr><th>Mode</th><td>Broker Light</td><th>Hostname</th><td>__HOSTNAME__</td></tr>
<tr><th>Broker</th><td>v__VERSION__</td><th>Uptime</th><td>__UPTIME__ minutes</td></tr>
<tr><th>CPU Temp</th><td>__TEMPERATURE__</td><th>CPU Load</th><td>__CPU_LOAD__</td></tr>
<tr><th>Memory</th><td>__MEMORY__</td><th>LMS Target</th><td><code>__LMS_BASE__</code></td></tr>
</tbody></table>

<h3>Local Players</h3>
<table><thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>Status</th></tr></thead>
<tbody>__PLAYER_ROWS__</tbody></table>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">
<a href="/setup/players"><button type="button">Configure Players</button></a>
<button class="light-action" data-action="restart_players">Restart Players</button>
<button class="light-action" data-action="restart_broker">Restart Broker</button>
<button class="light-action" data-action="reboot">Reboot Device</button>
<a href="/api/system/backup"><button type="button">Save Config Backup</button></a>
<a href="/setup/advanced"><button type="button">Advanced / Updates</button></a>
</div>
<div id="lightStatus" style="margin-top:10px;color:#596579;"></div>
</section>
</main>
<script>
(function(){
  var box=document.getElementById("lightStatus");
  function sleep(ms){return new Promise(function(resolve){window.setTimeout(resolve,ms);});}
  function setLightButtonsDisabled(disabled){
    Array.from(document.querySelectorAll(".light-action")).forEach(function(item){
      item.disabled=!!disabled;
    });
  }
  async function waitForBrokerReady(){
    var sawDown=false;
    var deadline=Date.now()+60000;
    while(Date.now()<deadline){
      try{
        var response=await fetch("/health?service="+Date.now(),{cache:"no-store"});
        if(response.ok&&sawDown) return true;
      }catch(_){
        sawDown=true;
        box.textContent="Waiting for broker to restart...";
        box.style.color="#596579";
      }
      await sleep(1000);
    }
    throw new Error("Timed out waiting for broker restart.");
  }
  async function waitForPlayersReady(){
    var deadline=Date.now()+30000;
    var lastText="";
    while(Date.now()<deadline){
      try{
        var response=await fetch("/api/system/players-status?ts="+Date.now(),{cache:"no-store"});
        var data=await response.json();
        if(data.ok){
          lastText=(data.running||0)+" of "+(data.configured||0)+" configured players running";
          box.textContent="Waiting for local players... "+lastText;
          box.style.color="#596579";
          if(data.ready) return data;
        }
      }catch(_){}
      await sleep(1000);
    }
    throw new Error("Timed out waiting for local players to restart. "+lastText);
  }
  Array.from(document.querySelectorAll(".light-action")).forEach(function(button){
    button.addEventListener("click",async function(){
      var action=button.getAttribute("data-action");
      if(!window.confirm("Run "+button.textContent+" now?"))return;
      setLightButtonsDisabled(true);box.textContent=button.textContent+" requested...";
      try{
        var response=await fetch("/api/system/action",{
          method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({action:action})
        });
        var data=await response.json();if(!data.ok)throw new Error(data.error||"Action failed");
        box.textContent=data.message||"Action requested.";
        if(action==="restart_players"){
          var playerStatus=await waitForPlayersReady();
          box.textContent="Local players ready: "+playerStatus.running+" of "+playerStatus.configured+" running.";
          window.setTimeout(function(){window.location.reload();},800);
        }
        else if(action==="restart_broker"){
          await waitForBrokerReady();
          window.location.reload();
        }
      }catch(error){
        box.textContent=error.message;box.style.color="#b42318";setLightButtonsDisabled(false);
      }
    });
  });
}());
</script></body></html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Broker Light"))
        .replace("__BROKER_MODE_PANEL__", _broker_mode_panel())
        .replace("__HOSTNAME__", _html_escape(status["hostname"]))
        .replace("__VERSION__", _html_escape(APP_VERSION))
        .replace("__UPTIME__", str(status["uptime"] // 60))
        .replace("__TEMPERATURE__", _html_escape(temp_text))
        .replace("__CPU_LOAD__", _html_escape(load_text))
        .replace("__MEMORY__", _html_escape(memory_text))
        .replace("__LMS_BASE__", _html_escape(_lms_target_display() or "Not set"))
        .replace("__PLAYER_ROWS__", player_rows)
    )
    return web.Response(text=html, content_type="text/html")


async def setup_page(_req: web.Request) -> web.Response:
    _load_setup_config()
    if _broker_light_mode():
        return await setup_light_page(_req)
    _ensure_license_trial_started()
    effective = LMS_BASE
    saved = _safe_str(_setup_cache.get("lms_base"))
    iheart_region = _iheart_region_setting()
    iheart_skip_checked = " checked" if _iheart_skip_intro_when_filtered() else ""
    license_info = _license_status()
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    legal_checked = " checked" if _legal_terms_accepted() else ""
    if license_info["state"] == "licensed":
        license_summary = "Licensed"
        license_color = "#18794e"
    elif license_info["state"] == "trial":
        seconds = _safe_int(license_info.get("trial_seconds_remaining"), 0)
        license_summary = "Trial active - {:.1f} days remaining".format(seconds / 86400.0)
        license_color = "#8a5a00"
    else:
        license_summary = "Trial expired - enter a license key to enable RTI"
        license_color = "#b42318"
    iheart_region_options = []
    for value, label in (
        ("", "All regions"),
        ("US", "United States (US)"),
        ("NZ", "New Zealand (NZ)"),
        ("AU", "Australia (AU)"),
        ("CA", "Canada (CA)"),
        ("MX", "Mexico (MX)"),
    ):
        selected = " selected" if value == iheart_region else ""
        iheart_region_options.append(
            '<option value="{}"{}>{}</option>'.format(
                _html_escape(value), selected, _html_escape(label)
            )
        )

    pid = await _pick_setup_playerid(_req)
    iheart_installed = False
    iheart_candidates: List[Dict[str, Any]] = []
    try:
        iheart_candidates.extend(await _discover_radio_menu_rows(pid))
    except Exception:
        pass
    try:
        iheart_candidates.extend(_extract_menu_items(await _myapps_raw(pid)))
    except Exception:
        pass
    iheart_row = next((
        row for row in iheart_candidates
        if "iheart" in _norm_key(
            row.get("source_label") or _pick_label(row) or row.get("key") or row.get("id")
        )
    ), None)
    iheart_installed = iheart_row is not None
    iheart_icon_url = ""
    if iheart_installed:
        iheart_icon_url = _normalize_icon_url(
            _pick_art(iheart_row) or "/plugins/iHeartRadio/html/images/iheartradio.png"
        )
    player_inventory_warnings: List[str] = []
    try:
        all_lms_players = await lms.get_players()
        player_inventory_warnings = _player_inventory_warnings(all_lms_players)
        live_players = _rti_connected_players(all_lms_players)
    except Exception:
        live_players = []
        player_inventory_warnings = ["Could not read LMS players for RTI mapping."]
    player_rows = []
    for i, p in enumerate(live_players):
        name = _html_escape(_safe_str(p.get("name")))
        mac = _html_escape(_safe_str(p.get("playerid")))
        connected = "Yes" if _safe_int(p.get("connected"), 0) else "No"
        power = "On" if _safe_int(p.get("power"), 0) else "Off"
        player_rows.append("""
        <tr>
          <td style="padding:6px 8px;border-top:1px solid #eee;">Player {num}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>Player{idx}_Name</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{name}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>Player{idx}_MAC</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>{mac}</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{connected}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{power}</td>
        </tr>
        """.format(num=i + 1, idx=i, name=name, mac=mac, connected=connected, power=power))
    if not player_rows:
        player_rows.append('<tr><td colspan="7" style="padding:8px;color:#666;">No LMS players found yet.</td></tr>')

    home_rows_live = await _merge_home_menu_with_live_apps(pid)
    radio_home_enabled = any(
        _safe_str(row.get("key")).strip().lower() == "radio"
        and bool(row.get("enabled", True))
        for row in home_rows_live
    )
    mymusic_home_enabled = any(
        _safe_str(row.get("key")).strip().lower() == "mymusic"
        and bool(row.get("enabled", True))
        for row in home_rows_live
    )
    rows = []
    for row in home_rows_live:
        key = _html_escape(_safe_str(row.get("key")))
        label = _html_escape(_safe_str(row.get("label")))
        enabled = "checked" if row.get("enabled") else ""
        order = _safe_int(row.get("order"), 100)
        kind = _html_escape(_safe_str(row.get("type") or "core"))
        src = _html_escape(_safe_str(row.get("source_label") or row.get("label") or row.get("key") or ""))
        icon = _safe_str(row.get("icon") or "")
        icon_html = ('<img src="%s" style="width:22px;height:22px;object-fit:contain;">' % _html_escape(icon)) if icon else ''
        rows.append("""
        <tr data-key="{key}" data-type="{kind}" data-source="{src}" data-icon="{icon}">
          <td style="padding:6px 8px;"><input class="hm-enabled" type="checkbox" {enabled}></td>
          <td style="padding:6px 8px;">{icon_html}</td>
          <td style="padding:6px 8px;"><code>{key}</code></td>
          <td style="padding:6px 8px;">{kind}</td>
          <td style="padding:6px 8px;">{src}</td>
          <td style="padding:6px 8px;"><input class="hm-label" type="text" value="{label}" style="width:220px;"></td>
          <td style="padding:6px 8px;"><input class="hm-order" type="number" value="{order}" style="width:80px;"></td>
        </tr>
        """.format(key=key, kind=kind, src=src, icon=_html_escape(icon), icon_html=icon_html, enabled=enabled, label=label, order=order))

    plugin_rows = _curated_lms_plugin_rows(await _curated_lms_plugins())
    warn = "".join(
        '<div style="margin:10px 0;padding:10px;border:1px solid #f59e0b;background:#fff7ed;color:#9a3412;">{}</div>'.format(
            _html_escape(message)
        )
        for message in player_inventory_warnings
    )

    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Broker Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
  <h2>Lyrion Broker Setup</h2>
  <div class="page-nav"><b>Setup</b><a href="/setup/players">Local Players</a><a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>
  __BROKER_MODE_PANEL__
  __WARN__

  <h3>Lyrion Server</h3>
  <form method="post" action="/api/setup" style="margin-bottom:18px;" id="setupForm">
    <h3>License</h3>
    <div><b>Device MAC:</b> <code>__LICENSE_MAC__</code></div>
    <div style="margin-top:6px;color:__LICENSE_COLOR__;"><b>__LICENSE_SUMMARY__</b></div>
    <label style="display:block;margin-top:10px;">License key:</label>
    <textarea name="license_key" rows="3" placeholder="LYR1..." style="width:100%;max-width:900px;padding:6px;box-sizing:border-box;">__LICENSE_KEY__</textarea>

    <h3 style="margin-top:22px;">Required Risk Acceptance</h3>
    <div style="border:2px solid #8b1e1e;background:#fff7f7;padding:12px;max-width:900px;">
      <div style="font-weight:bold;">AS-IS SOFTWARE, ASSUMPTION OF RISK, RELEASE, AND INDEMNITY</div>
      <div style="margin-top:8px;font-size:13px;line-height:1.45;max-height:190px;overflow:auto;">
        This software and related components are experimental and provided "AS IS" and "WITH ALL FAULTS,"
        without warranties of any kind, express or implied, including merchantability, fitness for a
        particular purpose, title, non-infringement, availability, accuracy, security, or uninterrupted
        operation. You assume all risks arising from installation, configuration, operation, malfunction,
        data loss, service interruption, equipment damage, network activity, third-party services, and use
        or misuse of the software. To the fullest extent permitted by law, you release and hold harmless
        Skunk Works and every past, present, and future developer, contributor, maintainer, distributor,
        tester, agent, affiliate, and tool or service provider involved with this software from all claims,
        liabilities, losses, damages, costs, and expenses, whether direct, indirect, incidental, special,
        consequential, exemplary, or otherwise. You agree to defend and indemnify those parties against
        third-party claims arising from your installation, configuration, distribution, or use of the
        software. You are solely responsible for backups, security, legal compliance, third-party account
        terms, and determining whether the software is suitable for your system. These terms apply only to
        the fullest extent allowed by applicable law; rights that cannot legally be waived are not waived.
      </div>
      <label style="display:block;margin-top:12px;font-weight:bold;">
        <input type="checkbox" name="legal_accept" value="1" required__LEGAL_CHECKED__>
        I have read, understand, and accept these terms (version __LEGAL_VERSION__).
      </label>
      <div style="margin-top:6px;font-size:12px;color:#8b1e1e;">
        RTI WebSocket access remains disabled until these terms are accepted and saved.
      </div>
    </div>

    <input type="hidden" name="lms_base" value="__SAVED__">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Set broker role and LMS target in the Broker Role panel above.
    </div>

    <h3 style="margin-top:22px;">Curated LMS Plugins</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Install, enable, disable, and open settings for integrations tested with Lyrion Gadget. Plugin changes can require an LMS restart.</div>
    <table><thead><tr><th>Plugin</th><th>Version</th><th>State</th><th>Action</th><th>Settings</th></tr></thead>
    <tbody>__PLUGIN_ROWS__</tbody></table>
    <div id="pluginActionStatus" style="margin-top:10px;color:#596579;"></div>

    <h3 style="margin-top:18px;">RTI Player Mapping</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Use these exact values in Apex. The RTI driver ignores player status unless the configured MAC matches the LMS playerid.</div>
    <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 820px;">
      <thead>
        <tr style="background:#f7f7f7;">
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">RTI Player</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Name Setting</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Value</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">MAC Setting</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Value</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Connected</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Power</th>
        </tr>
      </thead>
      <tbody>
        __PLAYER_ROWS__
      </tbody>
    </table>

    <h3 style="margin-top:18px;">Home Menu (what RTI will show at top level)</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Enable items and set order (lower comes first). Labels are what RTI displays.</div>
    <table style="border-collapse:collapse;border:1px solid #ddd;">
      <thead>
        <tr style="background:#f7f7f7;">
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Icon</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Type</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Label</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Order</th>
        </tr>
      </thead>
      <tbody id="homeRows">
        __HOME_ROWS__
      </tbody>
    </table>
    <input type="hidden" name="home_menu_json" id="homeMenuJson" value="[]">

    <div id="myMusicMenuSection" style="display:__MYMUSIC_MENU_DISPLAY__;">
    <h3 style="margin-top:18px;">My Music Menu</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Loads the live My Music tree from LMS, then lets you pick what to show, rename it, and sort it. Original drill/play behavior is preserved.</div>
    <div style="margin-bottom:8px;">
      <button type="button" id="btnLoadMyMusic" style="padding:6px 12px;">Load My Music Tree</button>
      <span id="mymusicStatus" style="margin-left:10px;color:#666;"></span>
    </div>
    <div id="mymusicWrap" style="display:none;">
      <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 760px;">
        <thead>
          <tr style="background:#f7f7f7;">
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Custom Name</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Sort</th>
          </tr>
        </thead>
        <tbody id="mymusicRows"></tbody>
      </table>
    </div>
    <input type="hidden" name="mymusic_menu_json" id="mymusicMenuJson" value="[]">
    </div>

    <div id="radioMenuSection" style="display:__RADIO_MENU_DISPLAY__;">
      <h3 style="margin-top:18px;">Radio Menu</h3>
      <div style="font-size:12px;color:#666;margin-bottom:8px;">Loads the live Radio tree from LMS. Choose what RTI shows, rename entries, and set their order without changing drill or playback behavior.</div>
      <div style="margin-bottom:8px;">
        <button type="button" id="btnLoadRadio" style="padding:6px 12px;">Load Radio Tree</button>
        <span id="radioStatus" style="margin-left:10px;color:#666;"></span>
      </div>
      <div id="radioWrap" style="display:none;">
        <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 760px;">
          <thead>
            <tr style="background:#f7f7f7;">
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Custom Name</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Sort</th>
            </tr>
          </thead>
          <tbody id="radioRows"></tbody>
        </table>
      </div>
    </div>
    <input type="hidden" name="radio_menu_json" id="radioMenuJson" value="[]">

    __IHEART_REGION_SECTION__

    <div class="save-dock" style="z-index:10;">
      <b id="saveStatus" style="margin-right:14px;color:#555;">Changes are not saved automatically.</b>
      <button type="submit" style="font-size:16px;">Save Setup</button>
    </div>
  </form>

  <section class="quick-links">
  <h3>Quick Links</h3>
  <ul>
    <li><a href="/health">/health</a></li>
    <li><a href="/api/setup">/api/setup</a></li>
    <li><a href="/api/players">/api/players</a> (RTI player MAC/name mapping)</li>
    <li><a href="/api/lms_root">/api/lms_root</a> (preview LMS root menu)</li>
    <li><a href="/api/mymusic_menu">/api/mymusic_menu</a> (preview live My Music tree)</li>
    <li><a href="/api/radio_menu">/api/radio_menu</a> (preview live Radio tree)</li>
  </ul>
  </section>
  </main>
<script>
(function(){{
  function esc(s){{ return String(s == null ? '' : s); }}
  function setStatus(msg){{ document.getElementById('mymusicStatus').textContent = msg || ''; }}
  function renderRows(items){{
    var wrap = document.getElementById('mymusicWrap');
    var body = document.getElementById('mymusicRows');
    body.innerHTML = '';
    for (var i = 0; i < items.length; i++) {{
      var it = items[i] || {{}};
      var tr = document.createElement('tr');
      tr.setAttribute('data-key', esc(it.key || ''));
      tr.innerHTML = '' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-enabled" type="checkbox" ' + (it.enabled ? 'checked' : '') + '></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><code>' + esc(it.key || '') + '</code></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;">' + esc(it.source_label || '') + '</td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-alias" type="text" value="' + esc(it.alias || it.source_label || '') + '" style="width:220px;"></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-order" type="number" value="' + esc(it.order || 100) + '" style="width:80px;"></td>';
      body.appendChild(tr);
    }}
    wrap.style.display = items.length ? '' : 'none';
    syncHidden();
  }}
  function collectRows(){{
    var out = [];
    var rows = document.querySelectorAll('#mymusicRows tr');
    for (var i = 0; i < rows.length; i++) {{
      var tr = rows[i];
      out.push({{
        key: tr.getAttribute('data-key') || '',
        source_label: tr.children[2] ? tr.children[2].textContent : '',
        alias: tr.querySelector('.mm-alias') ? tr.querySelector('.mm-alias').value : '',
        enabled: !!(tr.querySelector('.mm-enabled') && tr.querySelector('.mm-enabled').checked),
        order: parseInt((tr.querySelector('.mm-order') && tr.querySelector('.mm-order').value) || '100', 10) || 100
      }});
    }}
    return out;
  }}
  function collectHomeRows(){
    var out = [];
    var rows = document.querySelectorAll('#homeRows tr[data-key]');
    for (var i = 0; i < rows.length; i++) {
      var tr = rows[i];
      out.push({
        key: tr.getAttribute('data-key') || '',
        type: tr.getAttribute('data-type') || 'core',
        source_label: tr.getAttribute('data-source') || '',
        icon: tr.getAttribute('data-icon') || '',
        label: tr.querySelector('.hm-label') ? tr.querySelector('.hm-label').value : '',
        enabled: !!(tr.querySelector('.hm-enabled') && tr.querySelector('.hm-enabled').checked),
        order: parseInt((tr.querySelector('.hm-order') && tr.querySelector('.hm-order').value) || '100', 10) || 100
      });
    }
    return out;
  }
  function setRadioStatus(msg){{ document.getElementById('radioStatus').textContent = msg || ''; }}
  function renderRadioRows(items){{
    var wrap = document.getElementById('radioWrap');
    var body = document.getElementById('radioRows');
    body.innerHTML = '';
    for (var i = 0; i < items.length; i++) {{
      var it = items[i] || {{}};
      var tr = document.createElement('tr');
      tr.setAttribute('data-key', esc(it.key || ''));
      tr.innerHTML = '' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-enabled" type="checkbox" ' + (it.enabled ? 'checked' : '') + '></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><code>' + esc(it.key || '') + '</code></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;">' + esc(it.source_label || '') + '</td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-alias" type="text" value="' + esc(it.alias || it.source_label || '') + '" style="width:220px;"></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-order" type="number" value="' + esc(it.order || 100) + '" style="width:80px;"></td>';
      body.appendChild(tr);
    }}
    wrap.style.display = items.length ? '' : 'none';
    syncHidden();
  }}
  function collectRadioRows(){{
    var out = [];
    var rows = document.querySelectorAll('#radioRows tr');
    for (var i = 0; i < rows.length; i++) {{
      var tr = rows[i];
      out.push({{
        key: tr.getAttribute('data-key') || '',
        source_label: tr.children[2] ? tr.children[2].textContent : '',
        alias: tr.querySelector('.rm-alias') ? tr.querySelector('.rm-alias').value : '',
        enabled: !!(tr.querySelector('.rm-enabled') && tr.querySelector('.rm-enabled').checked),
        order: parseInt((tr.querySelector('.rm-order') && tr.querySelector('.rm-order').value) || '100', 10) || 100
      }});
    }}
    return out;
  }}
  function syncHidden(){
    document.getElementById('homeMenuJson').value = JSON.stringify(collectHomeRows());
    document.getElementById('mymusicMenuJson').value = JSON.stringify(collectRows());
    document.getElementById('radioMenuJson').value = JSON.stringify(collectRadioRows());
  }
  function homeEnabled(key){{
    var row = document.querySelector('#homeRows tr[data-key="' + key + '"]');
    var box = row && row.querySelector('.hm-enabled');
    return !!(box && box.checked);
  }}
  function updateSectionVisibility(){{
    var mm = document.getElementById('myMusicMenuSection');
    var radio = document.getElementById('radioMenuSection');
    if (mm) mm.style.display = homeEnabled('mymusic') ? '' : 'none';
    if (radio) radio.style.display = homeEnabled('radio') ? '' : 'none';
  }}
  function markUnsaved(){{
    var status = document.getElementById('saveStatus');
    if (status) {{
      status.textContent = 'Unsaved changes - click Save Setup';
      status.style.color = '#9a3412';
    }}
  }}
  async function postSystemAction(action, extra) {{
    var response = await fetch('/api/system/action', {{
      method: 'POST',
      credentials: 'same-origin',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify(Object.assign({{action: action}}, extra || {{}}))
    }});
    var data = await response.json();
    if (!data.ok) throw new Error(data.error || 'Action failed');
    return data;
  }}
  function sleepMs(ms) {{
    return new Promise(function(resolve){{ window.setTimeout(resolve, ms); }});
  }}
  function isNetworkDrop(error) {{
    var message = String((error && error.message) || error || '').toLowerCase();
    return message.indexOf('network') >= 0 || message.indexOf('failed to fetch') >= 0 || message.indexOf('load failed') >= 0;
  }}
  async function waitForLmsReconnect(box) {{
    var sawDown = false;
    var started = Date.now();
    for (var i = 0; i < 90; i++) {{
      try {{
        var response = await fetch('/health?setup_lms_restart=' + Date.now(), {{cache: 'no-store'}});
        if (response.ok) {{
          var data = await response.json();
          var connected = !!(data.cometd && data.cometd.connected);
          if (!connected) sawDown = true;
          if (connected && (sawDown || Date.now() - started > 10000)) {{
            box.textContent = 'LMS is responding again. Refreshing setup...';
            window.dispatchEvent(new CustomEvent('lyrion-force-lms-state', {{detail: {{connected: true, clear: true}}}}));
            window.setTimeout(function(){{ window.location.reload(); }}, 700);
            return true;
          }}
        }}
      }} catch (error) {{
        sawDown = true;
      }}
      await sleepMs(1000);
    }}
    return false;
  }}
  function showRestartLmsPrompt(message, box) {{
    box.innerHTML = '';
    var text = document.createElement('span');
    text.textContent = message + ' ';
    var restart = document.createElement('button');
    restart.type = 'button';
    restart.textContent = 'Restart LMS Now';
    restart.style.fontWeight = 'bold';
    var later = document.createElement('button');
    later.type = 'button';
    later.textContent = 'Later';
    restart.addEventListener('click', async function(){{
      if (!window.confirm('Restart LMS now to finish plugin changes?')) return;
      restart.disabled = true;
      later.disabled = true;
      window.dispatchEvent(new CustomEvent('lyrion-force-lms-state', {{detail: {{connected: false, untilMs: 45000}}}}));
      box.appendChild(document.createTextNode(' Restarting LMS...'));
      try {{
        var data = await postSystemAction('restart_lms');
        box.textContent = (data.message || 'LMS restart requested.') + ' Waiting for LMS to reconnect...';
        if (!(await waitForLmsReconnect(box))) {{
          box.textContent = 'LMS restart command completed. Refreshing setup...';
          window.setTimeout(function(){{ window.location.reload(); }}, 900);
        }}
      }} catch (error) {{
        if (isNetworkDrop(error)) {{
          box.textContent = 'LMS restart command sent. Waiting for broker/LMS to reconnect...';
          if (!(await waitForLmsReconnect(box))) {{
            box.textContent = 'LMS restart command completed. Refreshing setup...';
            window.setTimeout(function(){{ window.location.reload(); }}, 900);
          }}
        }} else {{
          box.textContent = error.message;
          restart.disabled = false;
          later.disabled = false;
        }}
      }}
    }});
    later.addEventListener('click', function(){{
      box.textContent = 'Plugin change saved. Restart LMS later to finish applying it.';
      window.setTimeout(function(){{ window.location.reload(); }}, 1500);
    }});
    box.appendChild(text);
    box.appendChild(restart);
    box.appendChild(document.createTextNode(' '));
    box.appendChild(later);
    box.scrollIntoView({{behavior: 'smooth', block: 'nearest'}});
  }}
  async function loadTree(){{
    setStatus('Loading...');
    try {{
      var r = await fetch('/api/mymusic_menu', {{cache:'no-store'}});
      var j = await r.json();
      if (!j.ok) {{
        setStatus('Load failed: ' + (j.error || 'unknown'));
        return;
      }}
      renderRows(j.items || []);
      setStatus('Loaded ' + ((j.items || []).length) + ' item(s)');
    }} catch (e) {{
      setStatus('Load failed: ' + e);
    }}
  }}
  async function loadRadioTree(){{
    setRadioStatus('Loading...');
    try {{
      var r = await fetch('/api/radio_menu', {{cache:'no-store'}});
      var j = await r.json();
      if (!j.ok) {{
        setRadioStatus('Load failed: ' + (j.error || 'unknown'));
        return;
      }}
      renderRadioRows(j.items || []);
      setRadioStatus('Loaded ' + ((j.items || []).length) + ' item(s)');
    }} catch (e) {{
      setRadioStatus('Load failed: ' + e);
    }}
  }}
  document.getElementById('btnLoadMyMusic').addEventListener('click', loadTree);
  document.getElementById('btnLoadRadio').addEventListener('click', loadRadioTree);
  Array.from(document.querySelectorAll('.plugin-action')).forEach(function(button){{
    button.addEventListener('click', async function(){{
      var plugin = button.getAttribute('data-plugin');
      var enable = button.getAttribute('data-enable') === '1';
      var pluginStatusBox = document.getElementById('pluginActionStatus');
      if (!window.confirm((enable ? 'Install/enable ' : 'Disable ') + plugin + '?')) return;
      button.disabled = true;
      pluginStatusBox.textContent = 'Updating ' + plugin + '...';
      try {{
        var response = await fetch('/api/system/plugin', {{
          method: 'POST',
          credentials: 'same-origin',
          headers: {{'Content-Type': 'application/json'}},
          body: JSON.stringify({{plugin: plugin, enable: enable}})
        }});
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || 'Plugin update failed');
        if (data.restart_required) {{
          showRestartLmsPrompt((data.message || 'Plugin change saved.') + ' LMS restart is required to finish.', pluginStatusBox);
        }} else {{
          pluginStatusBox.textContent = data.message;
          window.setTimeout(function(){{ window.location.reload(); }}, 1500);
        }}
      }} catch (error) {{
        pluginStatusBox.textContent = error.message;
        button.disabled = false;
      }}
    }});
  }});
  document.getElementById('mymusicRows').addEventListener('input', syncHidden);
  document.getElementById('mymusicRows').addEventListener('change', syncHidden);
  document.getElementById('radioRows').addEventListener('input', syncHidden);
  document.getElementById('radioRows').addEventListener('change', syncHidden);
  document.getElementById('setupForm').addEventListener('input', function(){{
    syncHidden();
    updateSectionVisibility();
    markUnsaved();
  }});
  document.getElementById('setupForm').addEventListener('change', function(){{
    syncHidden();
    updateSectionVisibility();
    markUnsaved();
  }});
  document.getElementById('setupForm').addEventListener('submit', syncHidden);
  updateSectionVisibility();
  if (homeEnabled('mymusic')) loadTree();
  if (homeEnabled('radio')) loadRadioTree();
}})();
</script>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(
            APP_VERSION,
            "LMS: <code>{}</code>".format(_html_escape(effective)),
        ))
        .replace("__BROKER_MODE_PANEL__", _broker_mode_panel())
        .replace("__APP_VERSION__", _html_escape(APP_VERSION))
        .replace("__EFFECTIVE__", _html_escape(effective))
        .replace("__WARN__", warn)
        .replace("__LICENSE_MAC__", _html_escape(license_info.get("device_mac")))
        .replace("__LICENSE_COLOR__", _html_escape(license_color))
        .replace("__LICENSE_SUMMARY__", _html_escape(license_summary))
        .replace("__LICENSE_KEY__", _html_escape(license_key))
        .replace("__LEGAL_CHECKED__", legal_checked)
        .replace("__LEGAL_VERSION__", _html_escape(LEGAL_TERMS_VERSION))
        .replace("__SAVED__", _html_escape(saved))
        .replace("__PLAYER_ROWS__", ''.join(player_rows))
        .replace("__HOME_ROWS__", ''.join(rows))
        .replace("__PLUGIN_ROWS__", plugin_rows)
        .replace("__MYMUSIC_MENU_DISPLAY__", ("block" if mymusic_home_enabled else "none"))
        .replace("__RADIO_MENU_DISPLAY__", ("block" if radio_home_enabled else "none"))
        .replace("__IHEART_REGION_SECTION__", (
            '<div class="service-card">'
            '<div class="service-card-heading">'
            '<img src="{}" alt="iHeartRadio">'
            '<h3>iHeartRadio Station Region Filter</h3>'
            '</div>'
            '<label for="iheartRegion"><b>Show iHeartRadio stations for:</b></label><br>'
            '<select id="iheartRegion" name="iheart_region" style="min-width:280px;padding:6px;margin-top:6px;">'
            .format(_html_escape(iheart_icon_url))
            + ''.join(iheart_region_options) +
            '</select>'
            '<label style="display:block;margin-top:10px;">'.format()
            + '<input type="checkbox" name="iheart_skip_intro_when_filtered" value="1"{}> '.format(iheart_skip_checked) +
            'When a region is selected, open iHeartRadio directly to Genres'
            '</label>'
            '<div style="font-size:12px;color:#555;margin-top:8px;">Filters region-tagged iHeartRadio choices shown under RTI Radio. '
            'Choose <b>All regions</b> to show every station returned by the plugin. The direct-to-Genres option only applies when a specific region is selected. '
            'This does not change your iHeartRadio account or make unavailable stations playable.</div>'
            '</div>'
            if iheart_installed else
            '<input type="hidden" name="iheart_region" value="{}">'.format(_html_escape(iheart_region))
        ))
        .replace("{{", "{")
        .replace("}}", "}")
    )
    return web.Response(text=html, content_type="text/html")


def _update_root_dir() -> str:
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    return os.path.join(app_dir, "updates")


def _update_status_path() -> str:
    return os.path.join(_update_root_dir(), "update_status.json")


def _write_update_status(state: str, message: str, **extra: Any) -> None:
    try:
        os.makedirs(_update_root_dir(), exist_ok=True)
        payload = {
            "state": state,
            "message": message,
            "current_version": APP_VERSION,
            "updated_at": int(time.time()),
        }
        payload.update(extra)
        path = _update_status_path()
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        os.replace(tmp, path)
    except Exception:
        pass


def _read_update_status() -> Dict[str, Any]:
    try:
        with open(_update_status_path(), "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _version_tuple(value: Any) -> Tuple[int, ...]:
    parts = _re.findall(r"\d+", _safe_str(value))
    return tuple(int(part) for part in parts[:4]) if parts else (0,)


def _validated_https_url(value: Any, field: str) -> str:
    url = _safe_str(value).strip()
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError(f"{field} must be an HTTPS URL")
    return url


def _dropbox_direct_url(value: str) -> str:
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or "").lower()
    if host not in ("dropbox.com", "www.dropbox.com"):
        return value
    query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    query["dl"] = ["1"]
    return urllib.parse.urlunsplit((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        urllib.parse.urlencode(query, doseq=True),
        parsed.fragment,
    ))


async def _download_bytes(url: str, maximum: int) -> bytes:
    timeout = ClientTimeout(total=90, connect=15, sock_read=45)
    body = bytearray()
    async with ClientSession(timeout=timeout) as session:
        async with session.get(url, allow_redirects=True) as response:
            if response.status != 200:
                raise RuntimeError(f"download returned HTTP {response.status}")
            length = _safe_int(response.headers.get("Content-Length"), 0)
            if length > maximum:
                raise RuntimeError("download is larger than the allowed package size")
            async for chunk in response.content.iter_chunked(65536):
                body.extend(chunk)
                if len(body) > maximum:
                    raise RuntimeError("download is larger than the allowed package size")
    return bytes(body)


async def _fetch_update_manifest() -> Dict[str, Any]:
    _load_setup_config()
    manifest_url = _validated_https_url(
        _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL,
        "Manifest URL",
    )
    raw = await _download_bytes(_dropbox_direct_url(manifest_url), 256 * 1024)
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as error:
        raise RuntimeError(f"manifest is not valid JSON: {error}")
    if not isinstance(manifest, dict):
        raise RuntimeError("manifest must contain a JSON object")

    version = _safe_str(manifest.get("version")).strip()
    package_url = _validated_https_url(manifest.get("package_url"), "Package URL")
    sha256 = _safe_str(manifest.get("sha256")).strip().lower()
    if not version:
        raise RuntimeError("manifest is missing version")
    if not _re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise RuntimeError("manifest SHA-256 must contain 64 hexadecimal characters")
    return {
        "version": version,
        "package_url": _dropbox_direct_url(package_url),
        "sha256": sha256,
        "notes": _safe_str(manifest.get("notes")).strip(),
        "available": _version_tuple(version) > _version_tuple(APP_VERSION),
        "manifest_url": manifest_url,
    }


def _safe_archive_members(archive: tarfile.TarFile) -> List[tarfile.TarInfo]:
    members = archive.getmembers()
    names: Set[str] = set()
    for member in members:
        name = member.name.replace("\\", "/").lstrip("./")
        if (
            not name
            or name.startswith("/")
            or name == ".."
            or name.startswith("../")
            or "/../" in name
            or member.issym()
            or member.islnk()
            or not (member.isdir() or member.isfile())
        ):
            raise RuntimeError(f"unsafe archive entry: {member.name}")
        member.name = name
        names.add(name)
    missing = sorted(UPDATE_REQUIRED_FILES - names)
    if missing:
        raise RuntimeError("package is missing: " + ", ".join(missing))
    return members


def _extract_update_package(package_path: str, stage_dir: str) -> None:
    os.makedirs(stage_dir, exist_ok=False)
    with tarfile.open(package_path, "r:gz") as archive:
        members = _safe_archive_members(archive)
        for member in members:
            target = os.path.abspath(os.path.join(stage_dir, member.name))
            if os.path.commonpath((os.path.abspath(stage_dir), target)) != os.path.abspath(stage_dir):
                raise RuntimeError(f"unsafe archive path: {member.name}")
            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"could not read archive entry: {member.name}")
            with source, open(target, "wb") as output:
                while True:
                    chunk = source.read(65536)
                    if not chunk:
                        break
                    output.write(chunk)
            os.chmod(target, member.mode & 0o777)
    for script in ("repair-picoreplayer.sh", "start-lyrion-broker-pcp.sh", "install-picoreplayer.sh"):
        path = os.path.join(stage_dir, script)
        if os.path.isfile(path):
            os.chmod(path, 0o755)


def _backup_current_install() -> str:
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    backup_dir = os.path.join(_update_root_dir(), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    path = os.path.join(backup_dir, f"broker-{APP_VERSION}-{int(time.time())}.tgz")
    include = (
        "lyrion_broker.py",
        "pandora_backend.py",
        "requirements.txt",
        "start-lyrion-broker-pcp.sh",
        "pandora_plugins",
        "web_assets",
    )
    with tarfile.open(path, "w:gz") as archive:
        for name in include:
            source = os.path.join(app_dir, name)
            if os.path.exists(source):
                archive.add(source, arcname=name, recursive=True)
    return path


async def api_update_check(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    try:
        manifest = await _fetch_update_manifest()
        return web.json_response({"ok": True, "current_version": APP_VERSION, **manifest})
    except Exception as error:
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_update_status(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    return web.json_response({"ok": True, **_read_update_status()})


async def api_update_install(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    package_path = ""
    stage_dir = ""
    try:
        manifest = await _fetch_update_manifest()
        if not manifest["available"]:
            return web.json_response({
                "ok": False,
                "error": f"version {manifest['version']} is not newer than {APP_VERSION}",
            }, status=409)

        _write_update_status("downloading", f"Downloading broker {manifest['version']}")
        package = await _download_bytes(manifest["package_url"], UPDATE_MAX_PACKAGE_BYTES)
        digest = hashlib.sha256(package).hexdigest()
        if not hmac.compare_digest(digest, manifest["sha256"]):
            raise RuntimeError("downloaded package SHA-256 does not match the manifest")

        root = _update_root_dir()
        os.makedirs(root, exist_ok=True)
        package_path = os.path.join(root, f"broker-{manifest['version']}.tgz")
        with open(package_path + ".tmp", "wb") as handle:
            handle.write(package)
        os.replace(package_path + ".tmp", package_path)

        stage_dir = tempfile.mkdtemp(prefix="stage-", dir=root)
        os.rmdir(stage_dir)
        _extract_update_package(package_path, stage_dir)
        backup_path = _backup_current_install()
        repair = os.path.join(stage_dir, "repair-picoreplayer.sh")
        log_path = os.path.join(root, "update-install.log")
        _write_update_status(
            "installing",
            f"Installing broker {manifest['version']}",
            target_version=manifest["version"],
            backup_path=backup_path,
        )

        command = f"sleep 2; /bin/sh {repair!r} >> {log_path!r} 2>&1"
        subprocess.Popen(
            ["/bin/sh", "-c", command],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return web.json_response({
            "ok": True,
            "state": "installing",
            "current_version": APP_VERSION,
            "target_version": manifest["version"],
            "message": "Update verified. The broker will restart now.",
        })
    except Exception as error:
        _write_update_status("failed", _safe_str(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _read_first_line(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.readline().strip()
    except Exception:
        return ""


def _broker_rollback_archives() -> List[Dict[str, Any]]:
    backup_dir = os.path.join(_update_root_dir(), "backups")
    rows: List[Dict[str, Any]] = []
    try:
        for name in os.listdir(backup_dir):
            if not re.fullmatch(r"broker-[A-Za-z0-9_.-]+\.tgz", name):
                continue
            path = os.path.join(backup_dir, name)
            if not os.path.isfile(path):
                continue
            stat = os.stat(path)
            rows.append({
                "name": name,
                "size": stat.st_size,
                "modified": int(stat.st_mtime),
            })
    except Exception:
        pass
    rows.sort(key=lambda row: row["modified"], reverse=True)
    return rows[:12]


CURATED_LMS_PLUGINS: Tuple[Tuple[str, str], ...] = (
    ("FR_Pandora_0", "Pandora A"),
    ("FR_Pandora_1", "Pandora B"),
    ("FR_Pandora_2", "Pandora C"),
    ("FR_Pandora_3", "Pandora D"),
    ("Pyrrha", "Pyrrha"),
    ("Spotty", "Spotify / Spotty"),
    ("iHeartRadio", "iHeartRadio"),
    ("Podcast", "Podcasts"),
    ("ShairTunes2W", "AirPlay / ShairTunes"),
    ("BBCSounds", "BBC Sounds"),
    ("Qobuz", "Qobuz"),
)


async def _lms_plugin_manager_html() -> str:
    await lms.start()
    assert lms._session is not None
    url = LMS_BASE.rstrip("/") + "/Default/settings/server/plugins.html"
    async with lms._session.get(url) as response:
        text = await response.text()
        if response.status != 200:
            raise RuntimeError("LMS plugin manager returned HTTP {}".format(response.status))
    return text


def _parse_lms_plugin_catalog(text: str) -> Dict[str, Dict[str, Any]]:
    active_at = text.find('id="activePlugins"')
    inactive_at = text.find('id="inactivePlugins"')
    catalog: Dict[str, Dict[str, Any]] = {}
    for item in re.finditer(
        r'"([A-Za-z0-9_]+)"\s*:\s*\{[^{}]*"category"\s*:\s*"[^"]*"[^{}]*\}',
        text,
        flags=re.I | re.S,
    ):
        plugin_id = html_lib.unescape(item.group(1)).strip()
        if not plugin_id:
            continue
        catalog.setdefault(plugin_id, {
            "id": plugin_id,
            "name": plugin_id,
            "version": "",
            "state": "available",
            "action_type": "install",
            "settings_url": "",
        })
    for item in re.finditer(
        r'<li[^>]+id="plugin-([^"]+)"[^>]*>(.*?)</li>',
        text,
        flags=re.I | re.S,
    ):
        plugin_id = html_lib.unescape(item.group(1)).strip()
        block = item.group(2)
        state = "available"
        if active_at >= 0 and item.start() > active_at and (inactive_at < 0 or item.start() < inactive_at):
            state = "active"
        elif inactive_at >= 0 and item.start() > inactive_at:
            state = "inactive"
        id_pattern = re.escape(plugin_id)
        input_match = re.search(
            r'<input(?=[^>]+\bid="' + id_pattern + r'")[^>]*>',
            block,
            flags=re.I | re.S,
        )
        value_match = re.search(r'\bvalue="([^"]*)"', input_match.group(0), flags=re.I | re.S) if input_match else None
        name = html_lib.unescape(value_match.group(1)).strip() if value_match else plugin_id
        if input_match and re.search(r"\bchecked\b", input_match.group(0), flags=re.I):
            state = "active"
        version_match = re.search(r'\(v([^)]+)\)', block, flags=re.I)
        version = ""
        if version_match:
            version_text = html_lib.unescape(version_match.group(1)).strip()
            version_text = re.sub(r"<[^>]+>", " ", version_text)
            clean_version = re.search(r"\d+(?:[._-][0-9A-Za-z]+)*", version_text)
            version = clean_version.group(0) if clean_version else version_text.strip()
        action_match = re.search(r'name="(manual|install):' + id_pattern + r'"', block, flags=re.I)
        settings_match = re.search(
            r'<a\b[^>]+\bhref="([^"]+)"[^>]*>\s*Settings\s*</a>',
            block,
            flags=re.I | re.S,
        )
        catalog[plugin_id] = {
            "id": plugin_id,
            "name": name or plugin_id,
            "version": version,
            "state": state,
            "action_type": action_match.group(1).lower() if action_match else "",
            "settings_url": html_lib.unescape(settings_match.group(1)).strip() if settings_match else "",
        }
    return catalog


def _broker_owned_plugin_catalog_entry(plugin_id: str, label: str) -> Dict[str, Any]:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    if match:
        letter = chr(ord("A") + int(match.group(1)))
        if _pandora_plugin_zip(letter):
            return {
                "id": plugin_id,
                "name": label,
                "version": "1.1.10",
                "state": "available",
                "action_type": "install",
                "settings_url": "",
            }
    return {}


def _public_lms_page_url(path_or_url: Any) -> str:
    value = _safe_str(path_or_url).strip()
    if not value:
        return ""
    parts = urllib.parse.urlsplit(value)
    if parts.scheme and parts.netloc:
        return value
    base = _public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")
    if value.startswith("/"):
        return base + value
    return base + "/" + value.lstrip("/")


def _lms_settings_wrapper_url(path_or_url: Any) -> str:
    value = _safe_str(path_or_url).strip()
    if not value:
        return ""
    parts = urllib.parse.urlsplit(value)
    path = parts.path if parts.scheme and parts.netloc else value
    if not re.search(r"^/Default/plugins/[^/]+/settings/[^?#]+\.html$", path, flags=re.I):
        return ""
    return "/setup/lms-plugin-settings?path=" + urllib.parse.quote(path, safe="")


def _pandora_account_settings_url(plugin_id: str) -> str:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    if not match:
        return ""
    return "/setup/pandora-account?index=" + match.group(1)


def _pandora_account_index(plugin_id: str) -> int:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    return int(match.group(1)) if match else -1


async def _curated_lms_plugins() -> List[Dict[str, Any]]:
    catalog = _parse_lms_plugin_catalog(await _lms_plugin_manager_html())
    rows: List[Dict[str, Any]] = []
    for plugin_id, label in CURATED_LMS_PLUGINS:
        row = dict(catalog.get(plugin_id) or _broker_owned_plugin_catalog_entry(plugin_id, label))
        pandora_index = _pandora_account_index(plugin_id)
        pandora_account_ready = True
        if pandora_index >= 0:
            account = _pandora_accounts_cache()[pandora_index]
            pandora_account_ready = bool(_safe_str(account.get("username")).strip() and _safe_str(account.get("password")))
        row.update({
            "id": plugin_id,
            "label": label,
            "name": _safe_str(row.get("name") or label),
            "version": _safe_str(row.get("version")),
            "state": _safe_str(row.get("state") or "unavailable"),
            "action_type": _safe_str(row.get("action_type")),
            "settings_url": _pandora_account_settings_url(plugin_id) or _lms_settings_wrapper_url(row.get("settings_url")),
            "pandora_account": pandora_index >= 0,
            "pandora_account_ready": pandora_account_ready,
        })
        rows.append(row)
    return rows


def _curated_lms_plugin_rows(plugin_rows: List[Dict[str, Any]]) -> str:
    rows: List[str] = []
    for row in plugin_rows:
        state = _safe_str(row.get("state")).lower()
        state_color = "#18794e" if state == "active" else ("#b42318" if state == "inactive" else "#7a8694")
        state_label = '<span style="color:{};font-weight:bold;">{}</span>'.format(
            state_color,
            _html_escape(state.title() or "Unknown"),
        )
        if state == "active":
            action = '<button class="plugin-action" type="button" data-plugin="{id}" data-enable="0">Disable</button>'.format(
                id=_html_escape(row.get("id"))
            )
        elif state in ("inactive", "available"):
            label = "Install" if state == "available" else "Enable"
            action = '<button class="plugin-action" type="button" data-plugin="{id}" data-enable="1">{label}</button>'.format(
                id=_html_escape(row.get("id")),
                label=label,
            )
        else:
            action = "Not available from configured LMS repositories"

        if row.get("settings_url"):
            needs_account = bool(row.get("pandora_account") and not row.get("pandora_account_ready"))
            settings = '<a href="{url}" target="_blank" rel="{rel}"><button type="button" class="{cls}">{label}</button></a>'.format(
                url=_html_escape(row.get("settings_url")),
                rel="opener" if row.get("pandora_account") else "noopener",
                cls="needs-account" if needs_account else "",
                label="Needs Account" if needs_account else "Open Settings",
            )
        else:
            settings = '<span style="color:#7a8694;">No settings link</span>'

        rows.append(
            "<tr><td>{label}</td><td>{version}</td><td>{state}</td><td>{action}</td><td>{settings}</td></tr>".format(
                label=_html_escape(row.get("label")),
                version=_html_escape(row.get("version")),
                state=state_label,
                action=action,
                settings=settings,
            )
        )
    return "".join(rows) or '<tr><td colspan="5">No curated LMS plugin data returned.</td></tr>'


def _same_host_http_base(req: web.Request, port: int) -> str:
    host = _safe_str(req.host).strip()
    if host.startswith("["):
        parsed_host = host.split("]", 1)[0] + "]"
    else:
        parsed_host = host.split(":", 1)[0]
    parsed_host = parsed_host or "127.0.0.1"
    return "http://{}:{}".format(parsed_host, port)


async def _system_status_snapshot() -> Dict[str, Any]:
    uptime = 0
    try:
        uptime = int(float(_read_first_line("/proc/uptime").split()[0]))
    except Exception:
        pass
    temperature = None
    try:
        temperature = round(float(_read_first_line("/sys/class/thermal/thermal_zone0/temp")) / 1000.0, 1)
    except Exception:
        pass
    loadavg = {"one": None, "five": None, "fifteen": None}
    try:
        parts = _read_first_line("/proc/loadavg").split()
        loadavg = {
            "one": float(parts[0]),
            "five": float(parts[1]),
            "fifteen": float(parts[2]),
        }
    except Exception:
        pass
    memory = {"total": 0, "available": 0}
    try:
        meminfo: Dict[str, int] = {}
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                key, _, rest = line.partition(":")
                value = rest.strip().split()[0] if rest.strip() else "0"
                meminfo[key] = int(value) * 1024
        memory = {
            "total": meminfo.get("MemTotal", 0),
            "available": meminfo.get("MemAvailable", meminfo.get("MemFree", 0)),
        }
    except Exception:
        pass
    disk = {"total": 0, "free": 0}
    try:
        stat = os.statvfs(os.path.dirname(SETUP_JSON_PATH))
        disk = {"total": stat.f_blocks * stat.f_frsize, "free": stat.f_bavail * stat.f_frsize}
    except Exception:
        pass

    sessions = _pcp_player_sessions()
    running = {
        _safe_str(row.get("mac")).lower(): bool(
            _managed_squeezelite_processes({_safe_str(row.get("mac")).lower()})
        )
        for row in sessions
    }
    lms_ok = False
    lms_version = ""
    library_name = ""
    plugin_rows: List[Dict[str, Any]] = []
    if not _broker_light_mode():
        try:
            status = await lms.rpc("", ["serverstatus", 0, 1])
            result = status.get("result") or {}
            lms_version = _safe_str(result.get("version"))
            lms_ok = True
            library_response = await lms.rpc("", ["pref", "libraryname", "?"])
            library_name = _safe_str((library_response.get("result") or {}).get("_p2")).strip()
            plugin_rows = await _curated_lms_plugins()
        except Exception:
            pass

    checks: List[Dict[str, str]] = []
    if _broker_light_mode():
        checks.append({"level": "ok", "text": "Broker Light mode is active"})
    else:
        checks.append({"level": "ok" if lms_ok else "error", "text": "LMS is responding" if lms_ok else "LMS is not responding"})
        checks.append({
            "level": "ok" if _cometd_client_id else "error",
            "text": "CometD is connected" if _cometd_client_id else "CometD is disconnected",
        })
    macs = [_safe_str(row.get("mac")).lower() for row in sessions]
    checks.append({
        "level": "ok" if len(macs) == len(set(macs)) else "error",
        "text": "Player MAC addresses are unique" if len(macs) == len(set(macs)) else "Duplicate player MAC addresses detected",
    })
    available = {row["output"] for row in _available_alsa_outputs()}
    missing_outputs = [
        _safe_str(row.get("output")) for row in sessions
        if _safe_str(row.get("output")) not in available
    ]
    checks.append({
        "level": "ok" if not missing_outputs else "error",
        "text": "All configured audio outputs are present" if not missing_outputs
        else "Missing audio outputs: " + ", ".join(missing_outputs),
    })
    stopped = [
        _safe_str(row.get("name")) for row in sessions
        if not running.get(_safe_str(row.get("mac")).lower(), False)
    ]
    checks.append({
        "level": "ok" if not stopped else "error",
        "text": "All configured players are running" if not stopped
        else "Stopped players: " + ", ".join(stopped),
    })
    if not _broker_light_mode():
        checks.append({
            "level": "ok" if _legal_terms_accepted() else "error",
            "text": "Required risk acceptance is saved" if _legal_terms_accepted() else "Required risk acceptance is missing",
        })
    license_info = _license_status()
    license_state = _safe_str(license_info.get("state")).strip().lower()
    if license_state == "licensed":
        license_text = "License state: licensed"
    elif license_state == "trial":
        license_text = "License state: trial ({:.1f} days remaining)".format(
            _safe_int(license_info.get("trial_seconds_remaining"), 0) / 86400.0
        )
    else:
        license_text = "License state: expired"
    checks.append({
        "level": "error" if license_state == "expired" else "ok",
        "text": license_text,
    })

    return {
        "hostname": _pcp_config_hostname(),
        "uptime": uptime,
        "temperature": temperature,
        "loadavg": loadavg,
        "memory": memory,
        "disk": disk,
        "lms_ok": lms_ok,
        "lms_version": lms_version,
        "library_name": library_name,
        "cometd": bool(_cometd_client_id),
        "rti_connections": len(_ws_clients),
        "players": [
            {
                "slot": row.get("slot"),
                "name": row.get("name"),
                "mac": row.get("mac"),
                "output": row.get("output"),
                "running": running.get(_safe_str(row.get("mac")).lower(), False),
            }
            for row in sessions
        ],
        "checks": checks,
        "plugins": plugin_rows,
        "rollbacks": _broker_rollback_archives(),
    }


async def setup_system_page(req: web.Request) -> web.Response:
    status = await _system_status_snapshot()
    identity_hostname = _default_unit_hostname() if _is_generic_hostname(status["hostname"]) else _safe_str(status["hostname"])
    player_rows = "".join(
        "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td><td><code>{output}</code></td>"
        "<td style=\"color:{color};font-weight:bold;\">{state}</td></tr>".format(
            slot=_html_escape(row.get("slot")),
            name=_html_escape(row.get("name")),
            mac=_html_escape(row.get("mac")),
            output=_html_escape(row.get("output")),
            color="#18794e" if row.get("running") else "#b42318",
            state="Running" if row.get("running") else "Stopped",
        )
        for row in status["players"]
    ) or '<tr><td colspan="5">No configured players found.</td></tr>'
    check_rows = "".join(
        '<li style="margin:7px 0;color:{color};"><b>{mark}</b> {text}</li>'.format(
            color="#18794e" if row["level"] == "ok" else "#b42318",
            mark="PASS" if row["level"] == "ok" else "FAIL",
            text=_html_escape(row["text"]),
        )
        for row in status["checks"]
    )
    temp_text = "{} C".format(status["temperature"]) if status["temperature"] is not None else "Unavailable"
    disk_total = max(_safe_int(status["disk"].get("total"), 0), 1)
    disk_free = _safe_int(status["disk"].get("free"), 0)
    disk_text = "{:.1f} GB free of {:.1f} GB".format(disk_free / 1073741824.0, disk_total / 1073741824.0)
    loadavg = status["loadavg"]
    if loadavg.get("one") is None:
        load_text = "Unavailable"
    else:
        load_text = "{:.2f} / {:.2f} / {:.2f}".format(
            loadavg.get("one") or 0.0,
            loadavg.get("five") or 0.0,
            loadavg.get("fifteen") or 0.0,
        )
    mem_total = max(_safe_int(status["memory"].get("total"), 0), 1)
    mem_avail = _safe_int(status["memory"].get("available"), 0)
    mem_used = max(mem_total - mem_avail, 0)
    memory_text = "{:.0f}% used ({:.0f} MB free)".format(
        (mem_used / mem_total) * 100.0,
        mem_avail / 1048576.0,
    )
    if _broker_light_mode():
        mode_status_rows = """
<tr><th>Hostname</th><td>__HOSTNAME__</td><th>Broker</th><td>v__VERSION__</td></tr>
<tr><th>Mode</th><td>Broker Light</td><th>CPU Temperature</th><td>__TEMPERATURE__</td></tr>
<tr><th>CPU Load</th><td>__CPU_LOAD__</td><th>Memory</th><td>__MEMORY__</td></tr>
<tr><th>Uptime</th><td>__UPTIME__ minutes</td><th>Storage</th><td>__DISK__</td></tr>
"""
        identity_extra = ""
        storage_section = ""
    else:
        mode_status_rows = """
<tr><th>Hostname</th><td>__HOSTNAME__</td><th>Broker</th><td>v__VERSION__</td></tr>
<tr><th>LMS</th><td>__LMS_STATE__ __LMS_VERSION__</td><th>CometD</th><td>__COMETD__</td></tr>
<tr><th>RTI Connections</th><td>__RTI_CONNECTIONS__</td><th>CPU Temperature</th><td>__TEMPERATURE__</td></tr>
<tr><th>CPU Load</th><td>__CPU_LOAD__</td><th>Memory</th><td>__MEMORY__</td></tr>
<tr><th>Uptime</th><td>__UPTIME__ minutes</td><th>Storage</th><td>__DISK__</td></tr>
"""
        identity_extra = """
<label>LMS Library Name
<input id="lmsLibraryName" type="text" maxlength="80" value="__LIBRARY_NAME__" placeholder="Uses hostname when blank">
</label>
"""
        storage_section = """
<h3>Storage / Drives</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
<a href="__PCP_BASE__/cgi-bin/drives.cgi" target="_blank" rel="noopener"><button type="button">Open pCP Storage / Mounts</button></a>
<a href="__LMS_BASE__/Default/settings/index.html?activePage=BASIC_SETTINGS" target="_blank" rel="noopener"><button type="button">Open LMS Music Folder</button></a>
<a href="__LMS_BASE__/Default/settings/index.html" target="_blank" rel="noopener"><button type="button">Open LMS Rescan / Library Settings</button></a>
</div>
<div style="font-size:12px;color:#596579;margin-top:8px;max-width:900px;line-height:1.45;">
Use pCP/LMS for USB drives and network shares. For NAS music libraries, configure the SMB/CIFS mount in pCP,
then point LMS at the mounted folder and rescan. Samba server sharing is separate; it exposes this unit's files
to Windows/macOS clients and is not required just to play music from a NAS.
</div>
"""
    restart_lms_button = '' if _broker_light_mode() else '<button class="system-action" data-action="restart_lms">Restart LMS</button>'
    pcp_base = _same_host_http_base(req, 80)
    lms_ui_base = _safe_str(_public_lms_base()).rstrip("/") or _same_host_http_base(req, 9000)
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Lyrion Gadget System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell">
<h2>System Commissioning</h2>
<div class="page-nav"><a href="/setup">Setup</a><a href="/setup/players">Local Players</a><b>System</b><a href="/setup/advanced">Advanced</a></div>

<section class="quick-links">
<h3>Status</h3>
<table><tbody>
__STATUS_ROWS__
</tbody></table>

<h3>System Identity</h3>
<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:end;">
<label>Hostname
<input id="systemHostname" type="text" maxlength="26" pattern="[A-Za-z0-9-]+" value="__IDENTITY_HOSTNAME__">
</label>
__IDENTITY_EXTRA__
<button id="applyIdentity" type="button">Save Identity</button>
</div>
<div id="identityStatus" style="margin-top:10px;color:#596579;">Hostname changes may take a moment to appear in network discovery.</div>

<h3>System Check</h3><ul style="list-style:none;padding:0;">__CHECK_ROWS__</ul>

<h3>Players</h3>
<table><thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>Status</th></tr></thead>
<tbody>__PLAYER_ROWS__</tbody></table>

<h3>Service Controls</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;">
<button class="system-action" data-action="restart_broker">Restart Broker</button>
<button class="system-action" data-action="restart_players">Restart Players</button>
__RESTART_LMS_BUTTON__
<button class="system-action" data-action="reboot">Reboot Device</button>
</div>
<div id="systemActionStatus" style="margin-top:10px;color:#596579;"></div>

__STORAGE_SECTION__

<h3>Configuration Backup</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
<a href="/api/system/backup"><button type="button">Save Config Backup</button></a>
<form id="restoreForm" style="padding:0;border:0;box-shadow:none;margin:0;" enctype="multipart/form-data">
<input id="restoreFile" type="file" accept=".tgz,.gz" required>
<button type="submit">Restore Configuration</button>
</form>
</div>
<div style="font-size:12px;color:#8a5a00;margin-top:8px;">Backups contain local credentials and license information. Store them securely.</div>
</section>
</main>
<script>
(function(){
  var statusBox=document.getElementById("systemActionStatus");
  var statusClearTimer=null;
  var pendingActionButton=null;
  var pendingActionName="";
  var pendingActionStartedAt=0;
  var waitingForReconnect=false;
  var sawBrokerDisconnect=false;
  var sawLmsDisconnect=false;
  var identityButton=document.getElementById("applyIdentity");
  var identityStatus=document.getElementById("identityStatus");
  function flashStatus(message,isError){
    if(statusClearTimer) window.clearTimeout(statusClearTimer);
    statusBox.textContent=message||"";
    statusBox.style.color=isError?"#b42318":"#596579";
    if(!isError&&message){
      statusClearTimer=window.setTimeout(function(){
        if(statusBox.textContent===message) statusBox.textContent="";
      },12000);
    }
  }
  function isNetworkDrop(error){
    var message=(error&&error.message?error.message:String(error||"")).toLowerCase();
    return message.indexOf("failed to fetch")>=0||
      message.indexOf("networkerror")>=0||
      message.indexOf("network error")>=0||
      message.indexOf("load failed")>=0;
  }
  function setWaitingForReconnect(message){
    if(statusClearTimer) window.clearTimeout(statusClearTimer);
    waitingForReconnect=true;
    statusBox.textContent=message||"Command sent. Waiting for broker to reconnect...";
    statusBox.style.color="#596579";
  }
  function setServiceButtonsDisabled(disabled){
    Array.from(document.querySelectorAll(".system-action")).forEach(function(button){
      button.disabled=!!disabled;
    });
  }
  function clearPendingActions(detail){
    detail=detail||{};
    if((pendingActionName==="reboot"||pendingActionName==="restart_broker")&&!sawBrokerDisconnect) return;
    if(pendingActionName==="restart_lms"){
      if(!sawLmsDisconnect&&Date.now()-pendingActionStartedAt<10000) return;
      if(sawLmsDisconnect&&!detail.lmsConnected) return;
    }
    setServiceButtonsDisabled(false);
    var completedAction=pendingActionName;
    pendingActionButton=null;
    pendingActionName="";
    sawBrokerDisconnect=false;
    sawLmsDisconnect=false;
    if(waitingForReconnect){
      waitingForReconnect=false;
      window.dispatchEvent(new CustomEvent("lyrion-force-lms-state",{detail:{clear:true}}));
      flashStatus(completedAction==="restart_lms"?"LMS is responding again.":"Broker is responding again.",false);
    }
  }
  window.addEventListener("lyrion-health",function(event){
    var detail=event.detail||{};
    if(detail.brokerReachable&&pendingActionName==="restart_lms"&&!detail.lmsConnected) sawLmsDisconnect=true;
    if(detail.brokerReachable) clearPendingActions(detail);
    else if(pendingActionName==="reboot"||pendingActionName==="restart_broker") sawBrokerDisconnect=true;
  });
  identityButton.addEventListener("click",async function(){
    identityButton.disabled=true;identityStatus.textContent="Saving system identity...";
    try{
      var response=await fetch("/api/setup/system-identity",{
        method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          hostname:document.getElementById("systemHostname").value,
          library_name:(document.getElementById("lmsLibraryName")||{}).value||""
        })
      });
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Identity update failed");
      identityStatus.innerHTML="";
      identityStatus.style.color="#18794e";identityStatus.style.fontWeight="bold";
      if(data.reboot_required){
        var text=document.createElement("span");
        text.textContent="Hostname saved. Reboot is required for pCP/network discovery to fully use it. ";
        var reboot=document.createElement("button");
        reboot.type="button";
        reboot.textContent="Reboot Now";
        window.addEventListener("lyrion-health",function(event){
          if(event.detail&&event.detail.brokerReachable) reboot.disabled=false;
        });
        reboot.addEventListener("click",async function(){
          if(!window.confirm("Reboot device now to finish hostname change?"))return;
          reboot.disabled=true;
          identityStatus.appendChild(document.createTextNode(" Reboot requested..."));
          try{
            await postAction("reboot");
            window.setTimeout(function(){
              var attempts=0;
              var timer=window.setInterval(async function(){
                attempts+=1;
                try{
                  var response=await fetch("/health?reboot="+Date.now(),{cache:"no-store"});
                  if(response.ok){
                    window.clearInterval(timer);
                    window.location.replace("/setup/system?rebooted="+Date.now());
                  }
                }catch(_){}
                if(attempts>120)window.clearInterval(timer);
              },2000);
            },8000);
          }
          catch(error){
            if(isNetworkDrop(error)){
              identityStatus.textContent="Reboot command sent. Waiting for broker to reconnect...";
              identityStatus.style.color="#596579";
            }else{
              identityStatus.textContent=error.message;identityStatus.style.color="#b42318";
            }
          }
        });
        identityStatus.appendChild(text);
        identityStatus.appendChild(reboot);
      }else{
        identityStatus.textContent="Hostname and LMS library name saved.";
      }
    }catch(error){
      identityStatus.textContent=error.message;identityStatus.style.color="#b42318";
      identityStatus.style.fontWeight="bold";
    }finally{identityButton.disabled=false;}
  });
  async function postAction(action, extra) {
    var response=await fetch("/api/system/action",{
      method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
      body:JSON.stringify(Object.assign({action:action},extra||{}))
    });
    var data=await response.json();
    if(!data.ok) throw new Error(data.error||"Action failed");
    return data;
  }
  async function waitForPlayersReady(){
    var deadline=Date.now()+30000;
    var lastText="";
    while(Date.now()<deadline){
      try{
        var response=await fetch("/api/system/players-status?ts="+Date.now(),{cache:"no-store"});
        var data=await response.json();
        if(data.ok){
          lastText=(data.running||0)+" of "+(data.configured||0)+" configured players running";
          flashStatus("Waiting for local players... "+lastText,false);
          if(data.ready) return data;
        }
      }catch(_){}
      await new Promise(function(resolve){window.setTimeout(resolve,1000);});
    }
    throw new Error("Timed out waiting for local players to restart. "+lastText);
  }
  Array.from(document.querySelectorAll(".system-action")).forEach(function(button){
    button.addEventListener("click",async function(){
      var action=button.getAttribute("data-action");
      if(!window.confirm("Run "+button.textContent+" now?")) return;
      setServiceButtonsDisabled(true); pendingActionButton=button; pendingActionName=action; pendingActionStartedAt=Date.now();
      flashStatus(button.textContent+" requested...",false);
      try{
        var data=await postAction(action);
        if(action==="reboot") setWaitingForReconnect(data.message||"Reboot command sent. Waiting for broker to disconnect...");
        else if(action==="restart_lms") setWaitingForReconnect(data.message||"LMS restart command sent. Waiting for LMS to reconnect...");
        else if(action==="restart_broker"){
          window.dispatchEvent(new CustomEvent("lyrion-force-lms-state",{detail:{connected:false,untilMs:45000}}));
          setWaitingForReconnect(data.message||"Broker restart command sent. Waiting for broker to disconnect...");
        }
        else if(action==="restart_players"){
          flashStatus((data.message||"Local players restarted.")+" Waiting for players to report running...",false);
          var playerStatus=await waitForPlayersReady();
          flashStatus("Local players ready: "+playerStatus.running+" of "+playerStatus.configured+" running.",false);
        }
        else flashStatus(data.message||"Action requested.",false);
      }
      catch(error){
        if(action==="reboot"||isNetworkDrop(error)) setWaitingForReconnect("Command sent. Waiting for broker to reconnect...");
        else flashStatus(error.message,true);
      }
      finally{
        if(action!=="reboot"&&!waitingForReconnect){
          setServiceButtonsDisabled(false); pendingActionButton=null; pendingActionName="";
        }
      }
    });
  });
  document.getElementById("restoreForm").addEventListener("submit",async function(event){
    event.preventDefault();
    if(!window.confirm("Restore this configuration and restart local players?")) return;
    var restoreForm=event.target;
    var restoreButton=restoreForm.querySelector("button[type=submit]");
    var restoreFile=document.getElementById("restoreFile");
    var form=new FormData();form.append("backup",restoreFile.files[0]);
    restoreButton.disabled=true;
    flashStatus("Restoring configuration...",false);
    try{
      var response=await fetch("/api/system/restore",{method:"POST",credentials:"same-origin",body:form});
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Restore failed");
      flashStatus(data.message,false);
      restoreForm.reset();
      window.setTimeout(function(){window.location.reload();},2500);
    }catch(error){flashStatus(error.message,true);}
    finally{restoreButton.disabled=false;}
  });
}());
</script></body></html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "System commissioning"))
        .replace("__STATUS_ROWS__", mode_status_rows)
        .replace("__IDENTITY_EXTRA__", identity_extra)
        .replace("__STORAGE_SECTION__", storage_section)
        .replace("__HOSTNAME__", _html_escape(status["hostname"]))
        .replace("__IDENTITY_HOSTNAME__", _html_escape(identity_hostname))
        .replace("__LIBRARY_NAME__", _html_escape(status["library_name"]))
        .replace("__VERSION__", _html_escape(APP_VERSION))
        .replace("__LMS_STATE__", "Connected" if status["lms_ok"] else "Disconnected")
        .replace("__LMS_VERSION__", _html_escape(status["lms_version"]))
        .replace("__COMETD__", "Connected" if status["cometd"] else "Disconnected")
        .replace("__RTI_CONNECTIONS__", str(status["rti_connections"]))
        .replace("__TEMPERATURE__", temp_text)
        .replace("__CPU_LOAD__", _html_escape(load_text))
        .replace("__MEMORY__", _html_escape(memory_text))
        .replace("__UPTIME__", str(status["uptime"] // 60))
        .replace("__DISK__", disk_text)
        .replace("__PCP_BASE__", _html_escape(pcp_base))
        .replace("__LMS_BASE__", _html_escape(lms_ui_base))
        .replace("__RESTART_LMS_BUTTON__", restart_lms_button)
        .replace("__CHECK_ROWS__", check_rows)
        .replace("__PLAYER_ROWS__", player_rows)
    )
    return web.Response(text=html, content_type="text/html")


async def setup_lms_plugin_settings_page(req: web.Request) -> web.Response:
    path = _safe_str(req.query.get("path")).strip()
    if not re.search(r"^/Default/plugins/[^/]+/settings/[^?#]+\.html$", path, flags=re.I):
        raise web.HTTPBadRequest(text="Invalid LMS plugin settings path")

    await lms.start()
    assert lms._session is not None
    fetch_url = LMS_BASE.rstrip("/") + path
    async with lms._session.get(fetch_url) as response:
        body = await response.text()
        if response.status != 200:
            raise web.HTTPBadGateway(text="LMS settings page returned HTTP {}".format(response.status))

    public_lms = _public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")

    def _absolute_action(match: re.Match[str]) -> str:
        action = html_lib.unescape(match.group(2)).strip()
        parts = urllib.parse.urlsplit(action)
        if parts.scheme and parts.netloc:
            absolute = action
        elif action.startswith("/"):
            absolute = public_lms + action
        else:
            absolute = public_lms + "/" + action.lstrip("/")
        return match.group(1) + _html_escape(absolute) + match.group(3)

    body = re.sub(r'(<form\b[^>]*\baction=")([^"]*)(")', _absolute_action, body, count=1, flags=re.I | re.S)
    body = re.sub(
        r"(<head\b[^>]*>)",
        r'\1<base href="{}">'.format(_html_escape(public_lms.rstrip("/") + "/Default/")),
        body,
        count=1,
        flags=re.I,
    )
    controls = """
<div style="position:sticky;bottom:0;z-index:9999;background:#f6f8fb;border-top:1px solid #ccd4dc;padding:10px;display:flex;gap:8px;align-items:center;box-shadow:0 -2px 8px rgba(0,0,0,.08);">
  <button type="submit" form="settingsForm" style="font-weight:bold;">Save Settings</button>
  <button type="button" onclick="window.close()">Close</button>
  <span style="color:#596579;font-size:12px;">Saved by the native LMS plugin form.</span>
</div>
"""
    if re.search(r"</form>", body, flags=re.I):
        body = re.sub(r"</form>", controls + "</form>", body, count=1, flags=re.I)
    else:
        body += controls
    return web.Response(text=body, content_type="text/html")


async def setup_pandora_account_page(req: web.Request) -> web.Response:
    index = _safe_int(req.query.get("index"), -1)
    if index < 0 or index > 3:
        raise web.HTTPBadRequest(text="Invalid Pandora account index")
    account = _pandora_accounts_cache()[index]
    letter = chr(65 + index)
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Pandora {letter} Settings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell" style="max-width:720px;">
<h2>Pandora {letter}</h2>
<form id="pandoraAccountForm">
  <label>Name
    <input id="name" type="text" maxlength="80" value="{name}" placeholder="Pandora {letter}">
  </label>
  <label>Pandora username/email
    <input id="username" type="text" autocomplete="username" value="{username}">
  </label>
  <label>Pandora password
    <input id="password" type="password" autocomplete="current-password" value="{password}">
  </label>
  <div style="display:flex;gap:8px;align-items:center;margin-top:14px;">
    <button id="saveButton" type="submit" style="font-weight:bold;">Save Pandora {letter}</button>
    <button type="button" onclick="window.close()">Close</button>
  </div>
  <div id="saveStatus" style="margin-top:10px;color:#596579;"></div>
</form>
<div style="font-size:12px;color:#596579;margin-top:16px;">These credentials are stored locally in the broker setup file and used by the broker-backed Pandora {letter} LMS plugin.</div>
</main>
<script>
(function(){{
  var form=document.getElementById("pandoraAccountForm");
  var status=document.getElementById("saveStatus");
  var button=document.getElementById("saveButton");
  form.addEventListener("submit",async function(event){{
    event.preventDefault();
    button.disabled=true;status.textContent="Saving Pandora {letter}...";
    try{{
      var response=await fetch("/api/pandora/account", {{
        method:"POST",credentials:"same-origin",headers:{{"Content-Type":"application/json"}},
        body:JSON.stringify({{
          index:{index},
          name:document.getElementById("name").value,
          username:document.getElementById("username").value,
          password:document.getElementById("password").value
        }})
      }});
      var data=await response.json();
      if(!data.ok)throw new Error(data.error||"Save failed");
      status.textContent="Saved. You can close this window.";
      status.style.color="#18794e";status.style.fontWeight="bold";
      if(window.opener && !window.opener.closed) {{
        window.opener.location.reload();
      }}
    }}catch(error){{
      status.textContent=error.message;status.style.color="#b42318";status.style.fontWeight="bold";
      button.disabled=false;
    }}
  }});
}})();
</script></body></html>""".format(
        letter=letter,
        index=index,
        name=_html_escape(account.get("name") or "Pandora {}".format(letter)),
        username=_html_escape(account.get("username")),
        password=_html_escape(account.get("password")),
    )
    html = html.replace("__SETUP_STYLE__", _SETUP_STYLE).replace(
        "__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Pandora account settings")
    )
    return web.Response(text=html, content_type="text/html")


async def api_pandora_account(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        index = _safe_int(body.get("index"), -1)
        if index < 0 or index > 3:
            raise ValueError("Invalid Pandora account index")
        accounts = _pandora_accounts_cache()
        accounts[index] = {
            "enabled": True,
            "name": _safe_str(body.get("name") or accounts[index].get("name") or "Pandora {}".format(chr(65 + index))).strip(),
            "username": _safe_str(body.get("username")).strip(),
            "password": _safe_str(body.get("password")),
        }
        _setup_cache["pandora_accounts"] = accounts
        pandora_backend.invalidate()
        _save_setup_config()
        return web.json_response({"ok": True, "account": index})
    except Exception as error:
        dbg("Pandora account save failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _restart_all_local_players() -> None:
    rows = _pcp_player_sessions()
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _stop_managed_squeezelite(macs)
    _restart_pcp_main()
    _launch_extra_sessions(rows)
    if len(_wait_for_squeezelite_macs(macs, len(rows), timeout=15)) != len(rows):
        raise RuntimeError("Not all configured players restarted")


def _start_all_local_players() -> Dict[str, Any]:
    rows = _pcp_player_sessions()
    if not rows:
        raise RuntimeError("No configured local players found")
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _restart_pcp_main()
    _launch_extra_sessions(rows)
    running = _wait_for_squeezelite_macs(macs, len(rows), timeout=15)
    if len(running) != len(rows):
        raise RuntimeError("Only {} of {} configured players started".format(len(running), len(rows)))
    return {"players": len(rows)}


def _stop_all_local_players() -> Dict[str, Any]:
    rows = _pcp_player_sessions()
    if not rows:
        raise RuntimeError("No configured local players found")
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _stop_managed_squeezelite(macs)
    remaining = _managed_squeezelite_processes(macs)
    if remaining:
        raise RuntimeError("{} configured player process(es) are still running".format(len(remaining)))
    return {"players": len(rows)}


def _schedule_broker_restart() -> None:
    start_script = os.path.join(os.path.dirname(SETUP_JSON_PATH), "start-lyrion-broker-pcp.sh")
    app_dir = os.path.dirname(SETUP_JSON_PATH)
    pid_file = os.path.join(app_dir, "logs", "lyrion-broker.pid")
    log_file = os.path.join(app_dir, "logs", "lyrion-broker-restart.log")
    command = (
        "pid={pid}; start={start}; pidfile={pidfile}; log={log}; "
        "sleep 1; "
        "kill -TERM $pid >/dev/null 2>&1 || true; "
        "for i in 1 2 3 4 5; do kill -0 $pid >/dev/null 2>&1 || break; sleep 1; done; "
        "kill -KILL $pid >/dev/null 2>&1 || true; "
        "rm -f $pidfile; "
        "sleep 1; "
        "$start >> $log 2>&1"
    ).format(
        pid=os.getpid(),
        start=shlex.quote(start_script),
        pidfile=shlex.quote(pid_file),
        log=shlex.quote(log_file),
    )
    subprocess.Popen(
        ["/bin/sh", "-c", command],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _restart_lms_service() -> str:
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors: List[str] = []
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        stop = subprocess.run(
            [script, "stop"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        if stop.returncode != 0:
            errors.append("{} stop: {}".format(script, _safe_str(stop.stdout).strip()[-300:] or "exit {}".format(stop.returncode)))
            continue
        stopped = _wait_lms_http_state(False, timeout=35)
        time.sleep(2.0)
        try:
            start = subprocess.run(
                [script, "start"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=45,
                check=False,
            )
        except subprocess.TimeoutExpired:
            if _wait_lms_http_state(True, timeout=15):
                return "LMS stop/start completed and LMS is responding"
            errors.append("{} start timed out and LMS did not come back".format(script))
            continue
        if start.returncode != 0:
            errors.append("{} start: {}".format(script, _safe_str(start.stdout).strip()[-300:] or "exit {}".format(start.returncode)))
            continue
        started = _wait_lms_http_state(True, timeout=70)
        if stopped and started:
            return "LMS stop/start completed and LMS is responding"
        if not stopped:
            errors.append("{} stop command ran, but LMS did not stop responding".format(script))
        if not started:
            errors.append("{} start command ran, but LMS did not come back".format(script))

    command_sets = (
        ("/bin/systemctl", "restart", "logitechmediaserver"),
        ("/usr/bin/systemctl", "restart", "logitechmediaserver"),
        ("/bin/systemctl", "restart", "lyrionmusicserver"),
        ("/usr/bin/systemctl", "restart", "lyrionmusicserver"),
    )
    for args in command_sets:
        if not os.path.exists(args[0]):
            continue
        result = subprocess.run(
            list(args),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        output = _safe_str(result.stdout).strip()
        if result.returncode == 0:
            return output or "service command completed"
        errors.append("{}: {}".format(" ".join(args), output[-300:] or "exit {}".format(result.returncode)))
    if errors:
        raise RuntimeError("LMS restart failed: " + " | ".join(errors[-3:]))
    raise RuntimeError("No local LMS restart command was found")


def _http_endpoint_up(url: str, timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            response.read(256)
            return response.status < 500
    except Exception:
        return False


def _wait_lms_http_state(want_up: bool, timeout: float, url: str = "") -> bool:
    target_url = url or LMS_BASE
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _http_endpoint_up(target_url, timeout=1.5) == want_up:
            return True
        time.sleep(1.0)
    return False


def _start_local_lms() -> str:
    try:
        _pcp_lms_action("Start")
        if _wait_lms_http_state(True, timeout=70, url=LOCAL_LMS_BASE):
            return "pCP LMS start completed and LMS is responding"
    except Exception as error:
        pcp_error = error
    else:
        pcp_error = RuntimeError("pCP Start was requested, but local LMS did not respond")
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors = [_safe_str(pcp_error)]
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        result = subprocess.run(
            [script, "start"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=45,
            check=False,
        )
        if result.returncode == 0 and _wait_lms_http_state(True, timeout=70, url=LOCAL_LMS_BASE):
            return "LMS start completed and LMS is responding"
        errors.append("{} start: {}".format(script, _safe_str(result.stdout).strip()[-300:] or "exit {}".format(result.returncode)))
    raise RuntimeError("LMS start failed: " + " | ".join(errors[-3:]))


def _stop_local_lms() -> str:
    try:
        _pcp_lms_action("Stop")
        if _wait_lms_http_state(False, timeout=35, url=LOCAL_LMS_BASE):
            return "pCP LMS stop completed"
    except Exception as error:
        pcp_error = error
    else:
        pcp_error = RuntimeError("pCP Stop was requested, but local LMS still responded")
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors = [_safe_str(pcp_error)]
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        result = subprocess.run(
            [script, "stop"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        if result.returncode == 0 and _wait_lms_http_state(False, timeout=35, url=LOCAL_LMS_BASE):
            return "LMS stop completed"
        errors.append("{} stop: {}".format(script, _safe_str(result.stdout).strip()[-300:] or "exit {}".format(result.returncode)))
    raise RuntimeError("LMS stop failed: " + " | ".join(errors[-3:]))


def _pcp_lms_action(action: str) -> str:
    url = "http://127.0.0.1/cgi-bin/lms.cgi?ACTION={}".format(
        urllib.parse.quote(action)
    )
    with urllib.request.urlopen(url, timeout=15) as response:
        body = response.read(4096)
        if response.status >= 400:
            raise RuntimeError("pCP LMS {} returned HTTP {}".format(action, response.status))
        return body.decode("utf-8", errors="replace")


def _restart_lms_via_pcp_stop_start() -> str:
    _pcp_lms_action("Stop")
    stopped = _wait_lms_http_state(False, timeout=35)
    if not stopped:
        raise RuntimeError("pCP Stop was requested, but LMS did not stop responding on {}".format(LMS_BASE))
    time.sleep(2.0)
    _pcp_lms_action("Start")
    started = _wait_lms_http_state(True, timeout=70)
    if not started:
        raise RuntimeError("pCP Start was requested, but LMS did not come back on {}".format(LMS_BASE))
    return "pCP Stop/Start completed and LMS is responding"


def _restore_broker_archive(name: str) -> None:
    backup_dir = os.path.join(_update_root_dir(), "backups")
    if not re.fullmatch(r"broker-[A-Za-z0-9_.-]+\.tgz", name):
        raise ValueError("Invalid rollback archive")
    path = os.path.abspath(os.path.join(backup_dir, name))
    if os.path.dirname(path) != os.path.abspath(backup_dir) or not os.path.isfile(path):
        raise ValueError("Rollback archive was not found")
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    allowed_roots = {
        "lyrion_broker.py", "pandora_backend.py", "requirements.txt",
        "start-lyrion-broker-pcp.sh", "pandora_plugins", "web_assets",
    }
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            clean = member.name.replace("\\", "/").lstrip("./")
            root = clean.split("/", 1)[0]
            if (
                not clean or root not in allowed_roots or ".." in clean.split("/")
                or member.issym() or member.islnk()
                or not (member.isfile() or member.isdir())
            ):
                raise RuntimeError("Unsafe rollback archive entry: {}".format(member.name))
        for member in members:
            clean = member.name.replace("\\", "/").lstrip("./")
            target = os.path.abspath(os.path.join(app_dir, clean))
            if os.path.commonpath((app_dir, target)) != app_dir:
                raise RuntimeError("Unsafe rollback path")
            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError("Could not read rollback entry")
            with source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
            os.chmod(target, member.mode & 0o777)


async def api_system_action(req: web.Request) -> web.Response:
    global _cometd_client_id, _cometd_connected, _cometd_response_channel
    try:
        body = await req.json()
        action = _safe_str(body.get("action")).strip().lower()
        if action == "restart_players":
            await asyncio.to_thread(_restart_all_local_players)
            return web.json_response({"ok": True, "message": "Local players restarted."})
        if action == "restart_lms":
            _cometd_client_id = ""
            _cometd_connected = False
            _cometd_response_channel = ""
            try:
                output = await asyncio.to_thread(_restart_lms_service)
                return web.json_response({
                    "ok": True,
                    "message": "LMS restart command completed. Broker will reconnect shortly. {}".format(output[-180:]),
                })
            except Exception as service_error:
                output = await asyncio.to_thread(_restart_lms_via_pcp_stop_start)
                return web.json_response({
                    "ok": True,
                    "message": "LMS service restart was unavailable ({}). {}. Broker will reconnect shortly.".format(
                        _safe_str(service_error),
                        output,
                    ),
                })
        if action == "restart_broker":
            _schedule_broker_restart()
            return web.json_response({"ok": True, "message": "Broker restart requested."})
        if action == "reboot":
            subprocess.Popen(
                ["/bin/sh", "-c", "sleep 2; /sbin/reboot"],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, start_new_session=True,
            )
            return web.json_response({"ok": True, "message": "Device reboot requested."})
        if action == "rollback_broker":
            archive = _safe_str(body.get("archive")).strip()
            await asyncio.to_thread(_backup_current_install)
            await asyncio.to_thread(_restore_broker_archive, archive)
            _schedule_broker_restart()
            return web.json_response({"ok": True, "message": "Rollback installed; broker is restarting."})
        raise ValueError("Unknown system action")
    except Exception as error:
        dbg("System action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _html_input_value(tag: str, name: str) -> str:
    match = re.search(
        r'\b' + re.escape(name) + r'\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))',
        tag,
        flags=re.I,
    )
    if not match:
        return ""
    return html_lib.unescape(next((group for group in match.groups() if group is not None), ""))


def _lms_plugin_checkbox_fields(page: str, target_plugin_id: str, enable_target: bool) -> List[Tuple[str, str]]:
    fields: List[Tuple[str, str]] = []
    seen: set[str] = set()
    target = _safe_str(target_plugin_id).strip()
    for tag in re.findall(r'<input\b[^>]*>', page, flags=re.I | re.S):
        input_type = _html_input_value(tag, "type").lower()
        name = _html_input_value(tag, "name").strip()
        input_id = _html_input_value(tag, "id").strip()
        if input_type != "checkbox" or not name or name != input_id:
            continue
        checked = bool(re.search(r"\bchecked\b", tag, flags=re.I))
        if name == target:
            checked = enable_target
        if not checked or name in seen:
            continue
        value = _html_input_value(tag, "value").strip() or name
        fields.append((name, value))
        seen.add(name)
    if enable_target and target and target not in seen:
        fields.append((target, target))
    return fields


async def api_system_plugin(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        plugin_id = _safe_str(body.get("plugin")).strip()
        enable = bool(body.get("enable"))
        curated_ids = {item[0] for item in CURATED_LMS_PLUGINS}
        if plugin_id not in curated_ids:
            raise ValueError("Plugin is not in the curated Lyrion Gadget list")

        page = await _lms_plugin_manager_html()
        catalog = _parse_lms_plugin_catalog(page)
        label = next((name for cur_id, name in CURATED_LMS_PLUGINS if cur_id == plugin_id), plugin_id)
        plugin = catalog.get(plugin_id) or _broker_owned_plugin_catalog_entry(plugin_id, label)
        if not isinstance(plugin, dict):
            raise ValueError("Plugin is not available from the configured LMS repositories")
        action_type = _safe_str(plugin.get("action_type")).lower()
        if action_type not in ("manual", "install"):
            raise RuntimeError("LMS did not expose a safe management action for this plugin")
        current_state = _safe_str(plugin.get("state")).lower()
        if enable and current_state == "active":
            return web.json_response({"ok": True, "message": "{} is already active.".format(plugin_id)})
        if not enable and current_state != "active":
            return web.json_response({"ok": True, "message": "{} is already inactive.".format(plugin_id)})

        rand_match = re.search(r'<input[^>]+name="rand"[^>]+value="([^"]+)"', page, flags=re.I)
        if rand_match is None:
            rand_match = re.search(r'<input[^>]+value="([^"]+)"[^>]+name="rand"', page, flags=re.I)
        if rand_match is None:
            raise RuntimeError("LMS plugin security token was not found")

        fields: List[Tuple[str, str]] = [
            ("saveSettings", "1"),
            ("rand", html_lib.unescape(rand_match.group(1))),
        ]
        repo_values: List[str] = []
        for tag in re.findall(r'<input\b[^>]*>', page, flags=re.I | re.S):
            if _html_input_value(tag, "name") == "repos":
                value = _html_input_value(tag, "value").strip()
                if value:
                    repo_values.append(value)
        for value in re.findall(r'<textarea[^>]+name="repos"[^>]*>(.*?)</textarea>', page, flags=re.I | re.S):
            clean = html_lib.unescape(re.sub(r"<[^>]+>", "", value)).strip()
            if clean:
                repo_values.append(clean)
        if not repo_values:
            raise RuntimeError("LMS repository list was not found; plugin settings were not changed")
        fields.extend(("repos", value) for value in repo_values)

        auto_match = re.search(
            r'<select[^>]+name="auto"[^>]*>.*?<option[^>]+value="([^"]+)"[^>]*selected',
            page,
            flags=re.I | re.S,
        )
        if auto_match is None:
            auto_match = re.search(
                r'<select[^>]+name="auto"[^>]*>.*?<option[^>]+selected[^>]+value="([^"]+)"',
                page,
                flags=re.I | re.S,
            )
        fields.append(("auto", auto_match.group(1) if auto_match else "0"))
        unsupported = re.search(
            r'<input(?=[^>]+name="useUnsupported")[^>]*checked',
            page,
            flags=re.I | re.S,
        )
        if unsupported:
            fields.append(("useUnsupported", "1"))
        fields.append(("{}:{}".format(action_type, plugin_id), ""))
        fields.extend(_lms_plugin_checkbox_fields(page, plugin_id, enable))

        await lms.start()
        assert lms._session is not None
        encoded = urllib.parse.urlencode(fields, doseq=True)
        url = LMS_BASE.rstrip("/") + "/Default/settings/server/plugins.html"
        async with lms._session.post(
            url,
            data=encoded,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as response:
            await response.read()
            if response.status != 200:
                raise RuntimeError("LMS plugin manager returned HTTP {}".format(response.status))
        return web.json_response({
            "ok": True,
            "message": "{} requested for {}. Restart LMS if the new state does not appear immediately.".format(
                "Install/enable" if enable else "Disable", plugin_id
            ),
            "restart_required": True,
        })
    except Exception as error:
        dbg("Curated plugin action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_system_backup(req: web.Request) -> web.Response:
    output = io.BytesIO()
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for source, arcname in (
            (SETUP_JSON_PATH, "broker_setup.json"),
            (PCP_CONFIG_PATH, "pcp.cfg"),
        ):
            if os.path.isfile(source):
                archive.add(source, arcname=arcname, recursive=False)
        for path in (
            "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
            "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
        ):
            if os.path.isfile(path):
                archive.add(path, arcname="SlimDiscovery.lua", recursive=False)
                break
    filename = "lyrion-gadget-config-{}-{}.tgz".format(
        _safe_str(_read_pcp_config().get("HOST") or "pcp"),
        int(time.time()),
    )
    return web.Response(
        body=output.getvalue(),
        content_type="application/gzip",
        headers={"Content-Disposition": 'attachment; filename="{}"'.format(filename)},
    )


def _restore_configuration_archive(data: bytes) -> None:
    current_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    backup_dir = os.path.join(current_dir, "backups")
    os.makedirs(backup_dir, exist_ok=True)
    stamp = int(time.time())
    if os.path.isfile(SETUP_JSON_PATH):
        shutil.copyfile(SETUP_JSON_PATH, os.path.join(backup_dir, "broker_setup.json.{}".format(stamp)))
    if os.path.isfile(PCP_CONFIG_PATH):
        shutil.copyfile(PCP_CONFIG_PATH, os.path.join(backup_dir, "pcp.cfg.{}".format(stamp)))

    files: Dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive.getmembers():
            clean = member.name.replace("\\", "/").lstrip("./")
            if clean not in ("broker_setup.json", "pcp.cfg", "SlimDiscovery.lua") or not member.isfile():
                raise RuntimeError("Unsupported configuration backup entry: {}".format(member.name))
            source = archive.extractfile(member)
            if source is not None:
                files[clean] = source.read()
    if "broker_setup.json" not in files or "pcp.cfg" not in files:
        raise RuntimeError("Backup must contain broker_setup.json and pcp.cfg")
    json.loads(files["broker_setup.json"].decode("utf-8"))
    files["pcp.cfg"].decode("utf-8")

    with open(SETUP_JSON_PATH + ".restore", "wb") as handle:
        handle.write(files["broker_setup.json"])
    os.replace(SETUP_JSON_PATH + ".restore", SETUP_JSON_PATH)
    with open(PCP_CONFIG_PATH + ".restore", "wb") as handle:
        handle.write(files["pcp.cfg"])
    os.replace(PCP_CONFIG_PATH + ".restore", PCP_CONFIG_PATH)
    if "SlimDiscovery.lua" in files:
        for path in (
            "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
            "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
        ):
            if os.path.isfile(path):
                with open(path, "wb") as handle:
                    handle.write(files["SlimDiscovery.lua"])
                break
    subprocess.run(["/usr/bin/filetool.sh", "-b"], timeout=60, check=True)


async def api_system_restore(req: web.Request) -> web.Response:
    try:
        reader = await req.multipart()
        part = await reader.next()
        if part is None or part.name != "backup":
            raise ValueError("Configuration backup file is required")
        data = bytearray()
        while True:
            chunk = await part.read_chunk(65536)
            if not chunk:
                break
            data.extend(chunk)
            if len(data) > 5 * 1024 * 1024:
                raise ValueError("Configuration backup exceeds 5 MB")
        await asyncio.to_thread(_restore_configuration_archive, bytes(data))
        _load_setup_config()
        await asyncio.to_thread(_restart_all_local_players)
        return web.json_response({"ok": True, "message": "Configuration restored and local players restarted."})
    except Exception as error:
        dbg("Configuration restore failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def setup_advanced_page(_req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(_req):
        raise web.HTTPFound("/setup/advanced/login")
    _load_setup_config()
    saved_public = _safe_str(_setup_cache.get("public_lms_base"))
    update_manifest_url = _safe_str(
        _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL
    )
    rollback_options = "".join(
        '<option value="{name}">{name}</option>'.format(name=_html_escape(row["name"]))
        for row in _broker_rollback_archives()
    )
    track_checked = " checked" if bool(_setup_cache.get("track_drilldown", False)) else ""
    hide_spotty_transfer_checked = " checked" if bool(_setup_cache.get("hide_spotty_transfer_playback", True)) else ""
    if _broker_light_mode():
        advanced_settings_form = """
  <section class="quick-links">
    <h3>Broker Light Advanced</h3>
    <div style="font-size:13px;color:#596579;">
      Broker Light keeps advanced settings focused on updates and rollback. Player setup, hostname, reboot,
      and service controls are on Setup/System.
    </div>
  </section>
"""
    else:
        advanced_settings_form = """
  <form method="post" action="/api/setup/advanced">
    <h3>Playable Track Behavior</h3>
    <label><input type="checkbox" name="track_drilldown"__TRACK_CHECKED__> Drill down when selecting playable tracks</label>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      When off, selecting a playable track makes it the target so the RTI driver's Select Action can apply.
    </div>

    <h3 style="margin-top:22px;">Spotty Menu</h3>
    <label><input type="checkbox" name="hide_spotty_transfer_playback"__HIDE_SPOTTY_TRANSFER_CHECKED__> Hide Transfer Playback row</label>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Hides Spotty's Transfer Playback menu item from RTI. Leave enabled unless you need Spotify Connect transfer controls in this project.
    </div>

    <h3 style="margin-top:22px;">Public LMS Base for Art/Icons</h3>
    <input type="text" name="public_lms_base" value="__SAVED_PUBLIC__" placeholder="http://lyriongadget.local:9000" style="width:420px;max-width:100%;padding:6px;box-sizing:border-box;">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Optional. Use this when LMS_BASE is loopback or not reachable by RTI panels. Relative art and icon paths are rewritten against this base.
    </div>

    <div style="margin-top:18px;">
      <button type="submit" style="padding:8px 14px;">Save Advanced Settings</button>
    </div>
  </form>
"""
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Broker Advanced Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
  <h2>Lyrion Broker Advanced Setup</h2>
  <div class="page-nav"><a href="/setup">Setup</a><a href="/setup/players">Local Players</a><a href="/setup/system">System</a><b>Advanced</b><a href="/setup/advanced/logout">Logout</a></div>

  __ADVANCED_SETTINGS_FORM__

  <section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:20px;">
    <h3>Broker Update</h3>
    <label for="updateManifestUrl">Update manifest URL</label>
    <input id="updateManifestUrl" type="url" value="__UPDATE_MANIFEST_URL__" placeholder="https://raw.githubusercontent.com/.../update.json"
           style="display:block;width:620px;max-width:100%;padding:7px;box-sizing:border-box;margin-top:6px;">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      The default points to the public Lyrion Gadget GitHub release feed. Packages install only after their SHA-256 matches the manifest.
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">
      <button id="checkUpdate" type="button" style="padding:8px 14px;">Check for Updates</button>
      <button id="installUpdate" type="button" style="padding:8px 14px;" disabled>Download and Install</button>
    </div>
    <pre id="updateStatus" style="white-space:pre-wrap;background:#eef2f5;border:1px solid #ccd4dc;border-radius:6px;padding:10px;margin-top:12px;">Current broker version: __APP_VERSION__</pre>
  </section>

  <section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:20px;">
    <h3>Broker Rollback</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">
      Restore a broker package backup created before an update. Configuration backups stay on the System page.
    </div>
    <select id="rollbackArchive"><option value="">Select a previous broker backup</option>__ROLLBACK_OPTIONS__</select>
    <button id="rollbackButton" type="button" style="padding:8px 14px;">Roll Back Broker</button>
    <div id="rollbackStatus" style="margin-top:10px;color:#596579;"></div>
  </section>
  </main>
  <script>
  (function () {
    var checkButton = document.getElementById("checkUpdate");
    var installButton = document.getElementById("installUpdate");
    var statusBox = document.getElementById("updateStatus");
    var manifestInput = document.getElementById("updateManifestUrl");
    var rollbackButton = document.getElementById("rollbackButton");
    var rollbackStatus = document.getElementById("rollbackStatus");

    async function saveManifestUrl() {
      var body = {
        update_manifest_url: manifestInput.value.trim()
      };
      var response = await fetch("/api/setup/advanced", {
        method: "POST",
        credentials: "same-origin",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(body)
      });
      if (!response.ok) throw new Error("Could not save update URL");
    }

    checkButton.addEventListener("click", async function () {
      installButton.disabled = true;
      statusBox.textContent = "Checking for updates...";
      try {
        await saveManifestUrl();
        var response = await fetch("/api/update/check", {credentials: "same-origin"});
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Update check failed");
        statusBox.textContent =
          "Installed: " + data.current_version + "\\n" +
          "Available: " + data.version + "\\n" +
          (data.notes ? "\\n" + data.notes : "") +
          (data.available ? "\\n\\nUpdate is ready to install." : "\\n\\nNo newer update is available.");
        installButton.disabled = !data.available;
      } catch (error) {
        statusBox.textContent = "Update check failed: " + error.message;
      }
    });

    installButton.addEventListener("click", async function () {
      if (!window.confirm("Install this broker update now? Playback control will briefly disconnect.")) return;
      checkButton.disabled = true;
      installButton.disabled = true;
      statusBox.textContent = "Downloading and verifying update...";
      try {
        var response = await fetch("/api/update/install", {
          method: "POST",
          credentials: "same-origin"
        });
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Install failed");
        statusBox.textContent = data.message + "\\nWaiting for broker " + data.target_version + "...";
        var attempts = 0;
        var timer = window.setInterval(async function () {
          attempts += 1;
          try {
            var health = await fetch("/health?update=" + Date.now(), {cache: "no-store"});
            var result = await health.json();
            if (result.ver === data.target_version) {
              window.clearInterval(timer);
              statusBox.textContent = "Update complete. Broker version " + result.ver + " is running.";
              window.setTimeout(function () {
                window.location.replace("/setup/advanced?updated=" + Date.now());
              }, 500);
            }
          } catch (_) {}
          if (attempts > 90) {
            window.clearInterval(timer);
            statusBox.textContent += "\\nRestart is taking longer than expected. Refresh this page in a minute.";
          }
        }, 2000);
      } catch (error) {
        statusBox.textContent = "Install failed: " + error.message;
        checkButton.disabled = false;
      }
    });

    rollbackButton.addEventListener("click", async function () {
      var archive = document.getElementById("rollbackArchive").value;
      if (!archive) {
        rollbackStatus.textContent = "Select a rollback archive.";
        return;
      }
      if (!window.confirm("Replace the running broker with " + archive + "?")) return;
      rollbackButton.disabled = true;
      rollbackStatus.textContent = "Installing rollback...";
      try {
        var response = await fetch("/api/system/action", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({action: "rollback_broker", archive: archive})
        });
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Rollback failed");
        rollbackStatus.textContent = data.message || "Rollback installed; broker is restarting.";
      } catch (error) {
        rollbackStatus.textContent = error.message;
        rollbackButton.disabled = false;
      }
    });
  }());
  </script>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION))
        .replace("__ADVANCED_SETTINGS_FORM__", advanced_settings_form)
        .replace("__APP_VERSION__", _html_escape(APP_VERSION))
        .replace("__TRACK_CHECKED__", track_checked)
        .replace("__HIDE_SPOTTY_TRANSFER_CHECKED__", hide_spotty_transfer_checked)
        .replace("__SAVED_PUBLIC__", _html_escape(saved_public))
        .replace("__UPDATE_MANIFEST_URL__", _html_escape(update_manifest_url))
        .replace("__ROLLBACK_OPTIONS__", rollback_options)
    )
    return web.Response(text=html, content_type="text/html")


def _advanced_auth_token() -> str:
    return hashlib.sha256(
        ("lyrion-advanced-setup:" + ADVANCED_SETUP_PASSWORD).encode("utf-8")
    ).hexdigest()


def _advanced_setup_authorized(req: web.Request) -> bool:
    supplied = _safe_str(req.cookies.get(ADVANCED_AUTH_COOKIE))
    return bool(supplied) and hmac.compare_digest(supplied, _advanced_auth_token())


async def setup_advanced_login_page(req: web.Request) -> web.Response:
    if _advanced_setup_authorized(req):
        raise web.HTTPFound("/setup/advanced")
    error = "Incorrect password." if _safe_str(req.query.get("error")) else ""
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Advanced Setup Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell" style="max-width:560px;">
  <h2>Advanced Setup</h2>
  <div class="page-nav"><a href="/setup">Back to Setup</a></div>
  <form method="post" action="/setup/advanced/login">
    <label for="password" style="display:block;margin-bottom:6px;">Password</label>
    <input id="password" name="password" type="password" autofocus required
           style="width:100%;max-width:360px;padding:8px;box-sizing:border-box;">
    <div style="color:#b42318;margin-top:8px;">__ERROR__</div>
    <div style="margin-top:14px;">
      <button type="submit" style="padding:8px 14px;">Open Advanced Setup</button>
    </div>
  </form>
  </main>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION))
        .replace("__ERROR__", _html_escape(error))
    )
    return web.Response(text=html, content_type="text/html")


async def setup_advanced_login_post(req: web.Request) -> web.Response:
    form = await req.post()
    supplied = _safe_str(form.get("password"))
    if not hmac.compare_digest(supplied, ADVANCED_SETUP_PASSWORD):
        raise web.HTTPFound("/setup/advanced/login?error=1")
    response = web.HTTPFound("/setup/advanced")
    response.set_cookie(
        ADVANCED_AUTH_COOKIE,
        _advanced_auth_token(),
        max_age=ADVANCED_AUTH_MAX_AGE,
        httponly=True,
        samesite="Strict",
        path="/",
    )
    raise response


async def setup_advanced_logout(_req: web.Request) -> web.Response:
    response = web.HTTPFound("/setup")
    response.del_cookie(ADVANCED_AUTH_COOKIE, path="/")
    raise response


async def api_setup_advanced_post(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        if "application/json" in _safe_str(req.headers.get("content-type")).lower():
            return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
        raise web.HTTPFound("/setup/advanced/login")
    _load_setup_config()
    ctype = _safe_str(req.headers.get("content-type")).lower()
    if "application/json" in ctype:
        try:
            body = await req.json()
        except Exception:
            body = {}
        if isinstance(body, dict):
            if "track_drilldown" in body:
                _setup_cache["track_drilldown"] = bool(body.get("track_drilldown"))
            if "broker_mode" in body:
                broker_mode = _safe_str(body.get("broker_mode")).strip().lower()
                if broker_mode in ("full", "light"):
                    _setup_cache["broker_mode"] = broker_mode
            if "hide_spotty_transfer_playback" in body:
                _setup_cache["hide_spotty_transfer_playback"] = bool(body.get("hide_spotty_transfer_playback"))
            if "public_lms_base" in body:
                _setup_cache["public_lms_base"] = _safe_str(body.get("public_lms_base")).strip()
            if "update_manifest_url" in body:
                _setup_cache["update_manifest_url"] = _safe_str(body.get("update_manifest_url")).strip()
    else:
        form = await req.post()
        broker_mode = _safe_str(form.get("broker_mode")).strip().lower()
        if broker_mode in ("full", "light"):
            _setup_cache["broker_mode"] = broker_mode
        _setup_cache["track_drilldown"] = form.get("track_drilldown") is not None
        _setup_cache["hide_spotty_transfer_playback"] = form.get("hide_spotty_transfer_playback") is not None
        _setup_cache["public_lms_base"] = _safe_str(form.get("public_lms_base")).strip()
        if "update_manifest_url" in form:
            _setup_cache["update_manifest_url"] = _safe_str(form.get("update_manifest_url")).strip()
    _save_setup_config()
    _load_setup_config()
    if "application/json" not in ctype:
        raise web.HTTPFound("/setup/advanced")
    return await api_setup_get(req)


async def api_setup_get(_req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(_req)
    sources_in_use = await _sources_in_use(pid)
    return web.json_response({
        "ok": True,
        "ver": APP_VERSION,
        "effective_lms_base": LMS_BASE,
        "setup_json_path": SETUP_JSON_PATH,
        "saved_lms_base": _safe_str(_setup_cache.get("lms_base")),
        "broker_mode": _broker_mode(),
        "saved_public_lms_base": _safe_str(_setup_cache.get("public_lms_base")),
        "update_manifest_url": _safe_str(
            _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL
        ),
        "effective_public_lms_base": _public_lms_base(),
        "home_menu": _home_menu_cache,
        "sources_in_use": sources_in_use,
        "track_drilldown": bool(_setup_cache.get("track_drilldown", False)),
        "hide_spotty_transfer_playback": bool(_setup_cache.get("hide_spotty_transfer_playback", True)),
        "mymusic_menu": _mymusic_menu_cache(),
        "radio_menu": _radio_menu_cache(),
        "iheart_region": _iheart_region_setting(),
        "iheart_skip_intro_when_filtered": _iheart_skip_intro_when_filtered(),
        "license": _license_status(),
        "legal": {
            "accepted": _legal_terms_accepted(),
            "terms_version": LEGAL_TERMS_VERSION,
            "accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        },
        "pandora_accounts": [
            {
                "enabled": row["enabled"],
                "name": row["name"],
                "username": row["username"],
                "password_configured": bool(row["password"]),
            }
            for row in _pandora_accounts_cache()
        ],
    })


async def api_mymusic_menu(req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(req)
    try:
        items = await _discover_mymusic_menu_merged(pid)
        return web.json_response({"ok": True, "playerid": pid, "items": items})
    except Exception as e:
        return web.json_response({"ok": False, "playerid": pid, "error": _safe_str(e)}, status=500)


async def api_radio_menu(req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(req)
    try:
        items = await _discover_radio_menu_merged(pid)
        return web.json_response({"ok": True, "playerid": pid, "items": items})
    except Exception as e:
        return web.json_response({"ok": False, "playerid": pid, "error": _safe_str(e)}, status=500)


async def api_setup_post(req: web.Request) -> web.Response:
    _load_setup_config()

    # accept either HTML form or JSON
    lms_base = ""
    public_lms_base = _safe_str(_setup_cache.get("public_lms_base"))
    home_menu = None
    mymusic_menu = None
    radio_menu = None
    iheart_region = ""
    iheart_skip_intro_when_filtered = _iheart_skip_intro_when_filtered()
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    legal_accept = _legal_terms_accepted()
    pandora_accounts = None

    ctype = _safe_str(req.headers.get("content-type")).lower()
    if "application/json" in ctype:
        try:
            body = await req.json()
        except Exception:
            body = {}
        if isinstance(body, dict):
            lms_base = _safe_str(body.get("lms_base"))
            if "public_lms_base" in body:
                public_lms_base = _safe_str(body.get("public_lms_base"))
            home_menu = body.get("home_menu")
            mymusic_menu = body.get("mymusic_menu")
            radio_menu = body.get("radio_menu")
            iheart_region = _safe_str(body.get("iheart_region"))
            if "iheart_skip_intro_when_filtered" in body:
                iheart_skip_intro_when_filtered = bool(body.get("iheart_skip_intro_when_filtered"))
            if "license_key" in body:
                license_key = _safe_str(body.get("license_key")).strip()
            if "legal_accept" in body:
                legal_accept = bool(body.get("legal_accept"))
            pandora_accounts = body.get("pandora_accounts")
            if "track_drilldown" in body:
                _setup_cache["track_drilldown"] = bool(body.get("track_drilldown"))
    else:
        form = await req.post()
        lms_base = _safe_str(form.get("lms_base"))
        if form.get("public_lms_base") is not None:
            public_lms_base = _safe_str(form.get("public_lms_base"))
        iheart_region = _safe_str(form.get("iheart_region"))
        iheart_skip_intro_when_filtered = form.get("iheart_skip_intro_when_filtered") is not None
        license_key = _safe_str(form.get("license_key")).strip()
        legal_accept = form.get("legal_accept") is not None
        if any(form.get(f"pandora_name_{index}") is not None for index in range(4)):
            pandora_accounts = [
                {
                    "enabled": form.get(f"pandora_enabled_{index}") is not None,
                    "name": _safe_str(form.get(f"pandora_name_{index}")),
                    "username": _safe_str(form.get(f"pandora_username_{index}")),
                    "password": _safe_str(form.get(f"pandora_password_{index}")),
                }
                for index in range(4)
            ]

        hm_raw = _safe_str(form.get("home_menu_json")).strip()
        if hm_raw:
            try:
                home_menu = json.loads(hm_raw)
            except Exception:
                home_menu = None
        mm_raw = _safe_str(form.get("mymusic_menu_json")).strip()
        if mm_raw:
            try:
                mymusic_menu = json.loads(mm_raw)
            except Exception:
                mymusic_menu = None
        rm_raw = _safe_str(form.get("radio_menu_json")).strip()
        if rm_raw:
            try:
                radio_menu = json.loads(rm_raw)
            except Exception:
                radio_menu = None

    if isinstance(home_menu, list) and home_menu:
        clean_hm: List[Dict[str, Any]] = []
        seen_hm: Set[str] = set()
        for row in home_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key")).strip()
            if not key or key in seen_hm:
                continue
            seen_hm.add(key)
            clean_hm.append({
                "key": key,
                "label": _safe_str(row.get("label") or row.get("source_label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
                "type": _safe_str(row.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core",
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "icon": _safe_str(row.get("icon") or _core_home_icon(key)),
            })
        _setup_cache["home_menu"] = clean_hm
    if isinstance(mymusic_menu, list):
        clean_mm: List[Dict[str, Any]] = []
        seen_mm: Set[str] = set()
        for row in mymusic_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key") or row.get("id")).strip()
            if not key or key in seen_mm:
                continue
            seen_mm.add(key)
            clean_mm.append({
                "key": key,
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "alias": _safe_str(row.get("alias") or row.get("source_label") or row.get("label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
            })
        _setup_cache["mymusic_menu"] = clean_mm
    if isinstance(radio_menu, list):
        clean_rm: List[Dict[str, Any]] = []
        seen_rm: Set[str] = set()
        for row in radio_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key") or row.get("id")).strip()
            if not key or key in seen_rm:
                continue
            seen_rm.add(key)
            clean_rm.append({
                "key": key,
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "alias": _safe_str(row.get("alias") or row.get("source_label") or row.get("label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
            })
        _setup_cache["radio_menu"] = clean_rm

    # Persist values from the web UI. Saved values override env hints.
    _setup_cache["lms_base"] = lms_base.strip()
    _setup_cache["public_lms_base"] = public_lms_base.strip()
    _setup_cache["iheart_region"] = _iheart_region_setting(iheart_region)
    _setup_cache["iheart_skip_intro_when_filtered"] = bool(iheart_skip_intro_when_filtered)
    _setup_cache["license_key"] = license_key
    if legal_accept:
        if not _legal_terms_accepted():
            _setup_cache["legal_accepted_at"] = int(time.time())
        _setup_cache["legal_accepted"] = True
        _setup_cache["legal_terms_version"] = LEGAL_TERMS_VERSION
    else:
        _setup_cache["legal_accepted"] = False
        _setup_cache["legal_accepted_at"] = 0
        _setup_cache["legal_terms_version"] = ""
    if isinstance(pandora_accounts, list):
        clean_pandora_accounts: List[Dict[str, Any]] = []
        current_accounts = _pandora_accounts_cache()
        for index in range(4):
            row = pandora_accounts[index] if index < len(pandora_accounts) and isinstance(pandora_accounts[index], dict) else {}
            current = current_accounts[index]
            clean_pandora_accounts.append({
                "enabled": bool(row.get("enabled", False)),
                "name": _safe_str(row.get("name") or current.get("name") or f"Pandora {chr(65 + index)}").strip(),
                "username": _safe_str(row.get("username") if "username" in row else current.get("username")).strip(),
                "password": _safe_str(row.get("password") if "password" in row else current.get("password")),
            })
        if clean_pandora_accounts != current_accounts:
            pandora_backend.invalidate()
        _setup_cache["pandora_accounts"] = clean_pandora_accounts

    _save_setup_config()
    _load_setup_config()

    # Apply new LMS base live immediately
    new_live_base = _safe_str(_setup_cache.get("lms_base")).strip()
    if not new_live_base:
        new_live_base = LOCAL_LMS_BASE
    await _apply_lms_base(new_live_base)

    # If browser, redirect back to /setup
    if "text/html" in ctype or "application/x-www-form-urlencoded" in ctype:
        raise web.HTTPFound("/setup")

    return await api_setup_get(req)


async def api_lms_root(req: web.Request) -> web.Response:
    """Preview LMS root menu. Uses a player context if provided."""
    pid = _safe_str(await _pick_setup_playerid(req)).strip().lower()
    try:
        if not pid:
            raise RuntimeError("No connected LMS player is available for menu preview")
        r = await lms.rpc(pid, ["menu", 0, 200, "direct:1"])
        return web.json_response({"ok": True, "playerid": pid, "result": r.get("result") or {}})
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e), "playerid": pid}, status=500)




# ---------------- Menu/Browse engine (action-driven from real Lyrion top menu) ----------------

_ws_nav: Dict[int, List[Dict[str, Any]]] = {}

_APP_KEY_ALIASES = {
    "spotty": ["spotty", "spotify"],
    "pyrrha": ["pyrrha", "pandora"],
    "bbcsounds": ["bbcsounds", "bbc sounds", "bbc"],
    "sounds": ["sounds", "sounds & effects"],
    "iheart": ["iheart", "iheartradio", "iheart radio"],
}

_GROUP_TITLE = {
    "myMusic": "My Music",
    "radios": "Radio",
    "randomplay": "Random Mix",
}


def _norm_key(s: Any) -> str:
    s = _safe_str(s).lower()
    return "".join(ch for ch in s if ch.isalnum())


def _b64u_enc(obj: Dict[str, Any]) -> str:
    raw = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_dec(s: str) -> Dict[str, Any]:
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return json.loads(base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8"))


def _extract_menu_items(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(result, dict):
        return []
    for k in ("item_loop", "loop_loop", "items"):
        v = result.get(k)
        if isinstance(v, list):
            items = [i for i in v if isinstance(i, dict)]
            _learn_pandora_station_urls(items)
            return items
    return []


def _pandora_url_key(value: Any) -> str:
    url = _clean_text(value)
    if not url:
        return ""
    if not url.lower().startswith(("frpandora", "pyr", "pyrrha")):
        return ""
    return url.split("?", 1)[0].strip().lower()


def _learn_pandora_station_urls(items: List[Dict[str, Any]]) -> None:
    try:
        for it in items:
            if not isinstance(it, dict):
                continue
            bags = [it]
            for bag_name in ("presetParams", "params", "playControlParams"):
                bag = it.get(bag_name)
                if isinstance(bag, dict):
                    bags.append(bag)
            for bag in bags:
                url = _pandora_url_key(
                    bag.get("favorites_url")
                    or bag.get("url")
                    or bag.get("touchToPlay")
                )
                if not url:
                    continue
                station = _valid_station_label(
                    bag.get("favorites_title")
                    or it.get("text")
                    or it.get("title")
                    or it.get("name")
                )
                if station:
                    _pandora_station_by_url[url] = station
    except Exception:
        pass


def _pick_label(it: Dict[str, Any]) -> str:
    return _safe_str(it.get("text") or it.get("title") or it.get("name") or it.get("label") or it.get("id") or "")




def _dbg_row_art(label: str, item_id: str, art: str, it: Dict[str, Any]) -> None:
    try:
        win = it.get("window") or {}
        dbg("ROW ART label=%s id=%s art=%s raw_icon=%s raw_icon_id=%s raw_preset_icon=%s raw_artwork=%s raw_win_icon_id=%s raw_coverid=%s raw_artwork_track_id=%s" % (
            _safe_str(label),
            _safe_str(item_id),
            _safe_str(art),
            _safe_str(it.get("icon")),
            _safe_str(it.get("icon-id")),
            _safe_str((it.get("presetParams") or {}).get("icon")) if isinstance(it.get("presetParams"), dict) else "",
            _safe_str(it.get("artwork_url")),
            _safe_str(win.get("icon-id")) if isinstance(win, dict) else "",
            _safe_str(it.get("coverid") or it.get("cover_id") or it.get("coverart") or it.get("artwork_track_id")),
            _safe_str(it.get("artwork_track_id"))
        ))
    except Exception:
        pass


def _track_album_art_url(it: Dict[str, Any]) -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    if not isinstance(it, dict):
        return ""

    def _clean_music_id(v: Any) -> str:
        s = _safe_str(v).strip()
        if not s:
            return ""
        if ":" in s or "/" in s or "?" in s or "&" in s:
            return ""
        return s

    def _walk(obj: Any, depth: int = 0) -> str:
        if depth > 5:
            return ""
        if isinstance(obj, dict):
            # Explicit art first.
            for k in ("artwork_url", "art", "icon", "icon-id", "image", "icon_url"):
                v = _safe_str(obj.get(k)).strip()
                if not v:
                    continue
                art = _normalize_art_url(v) if ("art" in k or k == "artwork_url") else _normalize_icon_url(v)
                cid = _extract_cover_id_from_pathish(art)
                if cid:
                    return f"{base}/music/{cid}/cover_200x200_o"
                if art.startswith((_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"), "/music/")) or "/music/" in art:
                    return art if art.startswith("http") else ((_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")) + art)
            # Then ID-style fields.
            for k in ("coverid", "cover_id", "artwork_track_id", "album_id", "track_id", "id"):
                v = _clean_music_id(obj.get(k))
                if v:
                    return f"{base}/music/{v}/cover_200x200_o"
            # Some rows only expose coverart=1 with an id in the same bag.
            coverart = _safe_str(obj.get("coverart")).strip().lower()
            if coverart in ("1", "true"):
                for k in ("album_id", "id", "track_id"):
                    v = _clean_music_id(obj.get(k))
                    if v:
                        return f"{base}/music/{v}/cover_200x200_o"
            # Recurse through common nested bags first, then any remaining dict/list values.
            for k in ("window", "params", "commonParams", "playControlParams", "presetParams", "itemParams"):
                if k in obj:
                    got = _walk(obj.get(k), depth + 1)
                    if got:
                        return got
            for _, val in obj.items():
                if isinstance(val, (dict, list)):
                    got = _walk(val, depth + 1)
                    if got:
                        return got
        elif isinstance(obj, list):
            for val in obj:
                got = _walk(val, depth + 1)
                if got:
                    return got
        return ""

    return _walk(it)


def _local_cover_art_url(it: Dict[str, Any]) -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    coverid = _safe_str(it.get("coverid") or it.get("cover_id") or "").strip()
    if coverid:
        return f"{base}/music/{coverid}/cover_200x200_o"
    atid = _safe_str(it.get("artwork_track_id") or "").strip()
    if atid:
        return f"{base}/music/{atid}/cover_200x200_o"
    albumid = _safe_str(it.get("album_id") or "").strip()
    if albumid:
        return f"{base}/music/{albumid}/cover_200x200_o"
    # Some local-library title/album rows only expose coverart=1 plus a numeric id.
    # In that case LMS can still serve cover art from /music/<id>/cover_200x200_o.
    if _safe_str(it.get("coverart")).strip() in ("1", "true", "True"):
        tid = _safe_str(it.get("id") or "").strip()
        if tid:
            return f"{base}/music/{tid}/cover_200x200_o"
    return ""

def _pick_art(it: Dict[str, Any]) -> str:
    win = it.get("window") or {}
    if isinstance(win, dict):
        # Prefer a real icon path over icon-id tokens. LMS browse rows often expose
        # usable local art as music/<id>/cover in icon/icon-id fields.
        v = _safe_str(win.get("icon"))
        if v:
            return _normalize_icon_url(v)
        v = _safe_str(win.get("icon-id"))
        if v:
            return _normalize_icon_url(v)

    # Prefer artwork first for stream/web items
    for k in ("artwork_url", "art"):
        v = _safe_str(it.get(k))
        if v:
            return _normalize_art_url(v)

    # For browse rows, prefer icon before icon-id. icon-id is often just a token,
    # while icon can be a usable LMS-local path like music/<id>/cover.
    for k in ("image", "icon", "icon_url", "icon-id"):
        v = _safe_str(it.get(k))
        if v:
            return _normalize_icon_url(v)

    # Last resort for local library rows that only expose cover identifiers
    v = _local_cover_art_url(it)
    if v:
        return v
    return ""


def _action_fallback_art(label: str, row_type: str = "node") -> str:
    lab = _norm_key(label)
    if not lab:
        return ""
    if "addtoend" in lab or ("add" in lab and "end" in lab):
        return _normalize_icon_url("/html/images/playlists.png")
    if "playnext" in lab or ("play" in lab and "next" in lab):
        return _normalize_icon_url("/html/images/newmusic.png")
    if "playallsongs" in lab or ("play" in lab and "all" in lab and "song" in lab):
        return _normalize_icon_url("/html/images/albums.png")
    if "playthissong" in lab or "playthisstation" in lab or (lab.startswith("play") and "song" in lab):
        return _normalize_icon_url("/html/images/browselibrary.png")
    return ""

def _mymusic_fallback_art(it: Dict[str, Any], label: str) -> str:
    iid = _safe_str(it.get("id"))
    node = _safe_str(it.get("node"))
    lab = _norm_key(label)
    iidn = _norm_key(iid)
    if node != "myMusic" and iid not in ("randomplay",):
        return ""
    # Use known-good LMS-local icons where possible.
    if iid == "randomplay" or "randommix" in lab:
        return _normalize_icon_url("/html/images/browselibrary.png")
    if iid == "myMusicNewMusic" or "newmusic" in iidn or ("newmusic" in lab):
        return _normalize_icon_url("/html/images/newmusic.png")
    if iid == "myMusicMusicFolder" or "musicfolder" in iidn or ("musicfolder" in lab):
        return _normalize_icon_url("/html/images/musicfolder.png")
    if iid == "myMusicAlbums" or "album" in lab:
        return _normalize_icon_url("/html/images/albums.png")
    if iid == "myMusicPlaylists" or "playlist" in lab:
        return _normalize_icon_url("/html/images/playlists.png")
    if iid == "myMusicGenres" or "genre" in lab:
        return _normalize_icon_url("/html/images/genres.png")
    if iid == "myMusicYears" or "year" in lab:
        return _normalize_icon_url("/html/images/browselibrary.png")
    if iid == "myMusicSearch" or lab == "search":
        return _normalize_icon_url("/html/images/search.png")
    return ""

def _track_drilldown_enabled() -> bool:
    try:
        return bool(_setup_cache.get("track_drilldown", False))
    except Exception:
        return False


async def _top_menu_raw(pid: str) -> Dict[str, Any]:
    r = await lms.rpc(pid, ["menu", 0, 100, "direct:1"])
    return (r.get("result") or {})


def _home_enabled_lookup() -> Dict[str, Dict[str, Any]]:
    _load_setup_config()
    out: Dict[str, Dict[str, Any]] = {}
    for row in _home_menu_cache:
        if not row.get("enabled"):
            continue
        key = _norm_key(row.get("key"))
        if key:
            out[key] = row
        lbl = _norm_key(row.get("label"))
        if lbl:
            out[lbl] = row
    return out


def _top_find_home_item(top_items: List[Dict[str, Any]], text: str) -> Optional[Dict[str, Any]]:
    want = _norm_key(text)
    for it in top_items:
        if _norm_key(_pick_label(it)) == want:
            return it
    return None




def _top_find_item_by_alias(top_items: List[Dict[str, Any]], aliases: List[str], node: str = "") -> Optional[Dict[str, Any]]:
    wants = [_norm_key(a) for a in aliases if _norm_key(a)]
    for it in top_items:
        if node and _safe_str(it.get("node")) != node:
            continue
        lab = _norm_key(_pick_label(it))
        iid = _norm_key(it.get("id"))
        if lab in wants or iid in wants:
            return it
    return None

def _mymusic_menu_lookup() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in _mymusic_menu_cache():
        key = _safe_str(row.get("key")).strip()
        if key:
            out[key] = row
    return out


def _apply_mymusic_menu_config(raw_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cfg = _mymusic_menu_lookup()
    if not cfg:
        return raw_items
    out: List[Tuple[int, str, Dict[str, Any]]] = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        key = _safe_str(it.get("id")).strip()
        if not key:
            continue
        rowcfg = cfg.get(key)
        if not rowcfg:
            continue
        if not bool(rowcfg.get("enabled", True)):
            continue
        row = dict(it)
        alias = _safe_str(rowcfg.get("alias")).strip()
        if alias:
            row["text"] = alias
        order = _safe_int(rowcfg.get("order"), _safe_int(it.get("weight"), 100))
        out.append((order, _safe_str(row.get("text") or row.get("id")), row))
    out.sort(key=lambda t: (t[0], t[1]))
    return [t[2] for t in out]


def _apply_radio_menu_config(raw_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cfg = {
        _safe_str(row.get("key")).strip(): row
        for row in _radio_menu_cache()
        if _safe_str(row.get("key")).strip()
    }
    if not cfg:
        return raw_items
    out: List[Tuple[int, str, Dict[str, Any]]] = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        key = _safe_str(it.get("id")).strip()
        rowcfg = cfg.get(key)
        if not key or not rowcfg or not bool(rowcfg.get("enabled", True)):
            continue
        row = dict(it)
        alias = _safe_str(rowcfg.get("alias")).strip()
        if alias:
            row["text"] = alias
        order = _safe_int(rowcfg.get("order"), _safe_int(it.get("weight"), 100))
        out.append((order, _safe_str(row.get("text") or row.get("id")), row))
    out.sort(key=lambda t: (t[0], t[1]))
    return [t[2] for t in out]


def _app_key_from_item(it: Dict[str, Any]) -> str:
    n = _norm_key(_pick_label(it))
    for key, aliases in _APP_KEY_ALIASES.items():
        if n == key:
            return key
        for a in aliases:
            if n == _norm_key(a):
                return key
    return n


def _canon_app_key(s: Any) -> str:
    n = _norm_key(s)
    for key, aliases in _APP_KEY_ALIASES.items():
        if n == key:
            return key
        for a in aliases:
            if n == _norm_key(a):
                return key
    return n



def _pandora_menu_name(value: Any) -> str:
    name = _safe_str(value).strip().lower()
    prefix = "fr_pandora_"
    suffix = name[len(prefix):] if name.startswith(prefix) else ""
    return name if suffix.isdigit() else ""


def _pandora_station_action(actions: Any) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(actions, dict):
            return None
        for key in ("play", "go", "add", "add-hold", "do"):
            act = actions.get(key)
            if not isinstance(act, dict):
                continue
            cmd = act.get("cmd")
            if not isinstance(cmd, list) or len(cmd) < 3:
                continue
            lower = [_safe_str(x).strip().lower() for x in cmd]
            if not lower[0].startswith("fr_pandora_"):
                continue
            if lower[1] != "playlist" or lower[2] != "play":
                continue
            params = act.get("params") if isinstance(act.get("params"), dict) else {}
            menu_name = _pandora_menu_name(params.get("menu"))
            if not menu_name or menu_name != lower[0]:
                continue
            if not _safe_str(params.get("item_id")).strip():
                continue
            return act
        return None
    except Exception:
        return None

def _is_pandora_station_context_row(label: Any, actions: Any) -> bool:
    if _norm_key(label) == "playthisstation":
        return False
    return _pandora_station_action(actions) is not None


def _is_pandora_station_actions(actions: Any) -> bool:
    return _pandora_station_action(actions) is not None


def _is_pyrrha_station_actions(actions: Any) -> bool:
    try:
        if not isinstance(actions, dict):
            return False
        play = actions.get("play")
        if not isinstance(play, dict):
            return False
        cmd = play.get("cmd")
        if not isinstance(cmd, list) or len(cmd) < 3:
            return False
        lower = [_safe_str(x).strip().lower() for x in cmd]
        if lower[0] != "pyrrha":
            return False
        if lower[1] != "playlist" or lower[2] != "play":
            return False
        params = play.get("params") if isinstance(play.get("params"), dict) else {}
        if _safe_str(params.get("menu")).strip().lower() != "pyrrha":
            return False
        return _safe_str(params.get("touchToPlaySingle")).strip() in ("1", "true", "True")
    except Exception:
        return False

def _valid_station_label(value: Any) -> str:
    lines = _clean_text(value).splitlines()
    station = lines[0].strip() if lines else ""
    if not station:
        return ""
    if _norm_key(station) in (
        "playthisstation", "play", "yourstations", "stations", "pandora",
        "pyrrha", "delete", "renamestation", "addmoremusic",
    ):
        return ""
    return station

def _remember_pandora_station(pid: str, station: Any) -> str:
    name = _valid_station_label(station)
    if name and pid:
        _pandora_station_by_playerid[pid] = name
        _pandora_station_by_playerid[pid.lower()] = name
        _np_station_by_playerid[pid] = name
        _np_station_by_playerid[pid.lower()] = name
    return name


def _pandora_station_payload(spec: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(spec, dict):
            return None
        acts = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
        if not _is_pandora_station_actions(acts):
            return None
        label = _safe_str(spec.get("label") or "Pandora Station").strip() or "Pandora Station"
        items: List[Dict[str, Any]] = []
        order = [
            ("play", "Play Now"),
            ("add-hold", "Play Next"),
            ("add", "Add to End"),
        ]
        for key, row_label in order:
            act = acts.get(key)
            if not isinstance(act, dict):
                continue
            row_spec = {"kind": "actions", "actions": {key: act}}
            items.append({
                "id": "act:" + _b64u_enc(row_spec),
                "label": row_label,
                "type": "action",
                "can_open": False,
                "no_icon": True,
            })
        if not items:
            return None
        return {
            "node": "act",
            "title": label,
            "offset": 0,
            "limit": len(items),
            "total": len(items),
            "items": items,
            "nav": {"can_back": True, "can_home": True},
        }
    except Exception:
        return None


def _row_action_params(it: Dict[str, Any], key: str) -> Dict[str, Any]:
    acts = it.get("actions") or {}
    act = acts.get(key) if isinstance(acts, dict) else None
    return act.get("params") if isinstance(act, dict) and isinstance(act.get("params"), dict) else {}


def _row_track_id_from_item(it: Dict[str, Any]) -> str:
    for k in ("track_id", "artwork_track_id"):
        v = _safe_str(it.get(k)).strip()
        if v:
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        for k in ("track_id", "artwork_track_id"):
            v = _safe_str(bag.get(k)).strip()
            if v:
                return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        for k in ("track_id", "artwork_track_id"):
            v = _safe_str(params.get(k)).strip()
            if v:
                return v
    return ""


def _row_album_id_from_item(it: Dict[str, Any]) -> str:
    for k in ("album_id",):
        v = _safe_str(it.get(k)).strip()
        if v:
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        v = _safe_str(bag.get("album_id")).strip()
        if v:
            return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        v = _safe_str(params.get("album_id")).strip()
        if v:
            return v
    return ""


def _row_menu_id_from_item(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return ""
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        v = _safe_str(bag.get("menu")).strip()
        if v:
            return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        v = _safe_str(params.get("menu")).strip()
        if v:
            return v
    return ""


def _row_can_add_favorite(it: Dict[str, Any], row_type: str, track_id: str, album_id: str) -> bool:
    if not isinstance(it, dict):
        return False

    # Some plugins expose an explicit favorites URL or favorites action; trust that.
    try:
        fav_url = _safe_str(((it.get("presetParams") or {}).get("favorites_url"))).strip() if isinstance(it.get("presetParams"), dict) else ""
    except Exception:
        fav_url = ""
    if fav_url:
        return True

    acts = it.get("actions") if isinstance(it.get("actions"), dict) else {}
    if isinstance(acts, dict):
        for k in acts.keys():
            lk = _safe_str(k).strip().lower()
            if lk in ("favorite", "favorites", "addfavorite", "add_favorite", "savefavorite", "save_favorite"):
                return True

    # Broker should do the heavy lifting here: real LMS track/album ids are favorite-capable.
    # This covers My Music album rows even when the raw item/node shape is thin or menu context
    # is not obvious by the time RTI selects the target.
    if track_id or album_id:
        return True

    return False


def _track_row_needs_meta(row: Dict[str, Any]) -> bool:
    return (
        row.get("type") == "track" and (
            not _safe_str(row.get("artist")).strip() or
            not _safe_str(row.get("album")).strip() or
            not _safe_str(row.get("genre")).strip() or
            row.get("duration") in (None, "", 0, "0")
        )
    )


async def _enrich_track_rows(raw_items: List[Dict[str, Any]], rows: List[Dict[str, Any]]) -> None:
    if not raw_items or not rows:
        return
    count = min(len(raw_items), len(rows))
    for idx in range(count):
        row = rows[idx]
        if not isinstance(row, dict) or not _track_row_needs_meta(row):
            continue
        raw = raw_items[idx] if isinstance(raw_items[idx], dict) else {}
        track_id = _row_track_id_from_item(raw) or _safe_str(row.get("track_id")).strip()
        album_id = _row_album_id_from_item(raw) or _safe_str(row.get("album_id")).strip()
        if track_id:
            row["track_id"] = track_id
        if album_id:
            row["album_id"] = album_id
        if not track_id:
            continue
        try:
            meta = await lms.track_metadata(track_id)
        except Exception as e:
            dbg("TRACK META fetch failed track_id=%s err=%s" % (track_id, _safe_str(e)))
            continue
        if not isinstance(meta, dict) or not meta:
            continue
        if not _safe_str(row.get("artist")) and _safe_str(meta.get("artist")):
            row["artist"] = _safe_str(meta.get("artist"))
        if not _safe_str(row.get("album")) and _safe_str(meta.get("album")):
            row["album"] = _safe_str(meta.get("album"))
        if not _safe_str(row.get("genre")) and _safe_str(meta.get("genre")):
            row["genre"] = _safe_str(meta.get("genre"))
        if row.get("duration") in (None, "", 0, "0") and meta.get("duration") not in (None, ""):
            row["duration"] = meta.get("duration")
        if not _safe_str(row.get("label")) and _safe_str(meta.get("title")):
            row["label"] = _safe_str(meta.get("title"))
        if not _safe_str(row.get("art")) and _safe_str(meta.get("art")):
            row["art"] = _safe_str(meta.get("art"))
        dbg("TRACK META merge idx=%s track_id=%s artist=%s album=%s genre=%s duration=%s" % (idx, track_id, _safe_str(row.get("artist")), _safe_str(row.get("album")), _safe_str(row.get("genre")), _safe_str(row.get("duration"))))


def _dbg_broker_menu_rows(title: str, offset: int, raw_items: List[Dict[str, Any]], rows: List[Dict[str, Any]]) -> None:
    try:
        dbg("BROKER_PAGE title=%s offset=%s raw_items=%s rows=%s" % (
            _safe_str(title), _safe_int(offset), len(raw_items or []), len(rows or [])
        ))
        count = min(3, len(raw_items or []), len(rows or []))
        for idx in range(count):
            raw = raw_items[idx] if isinstance(raw_items[idx], dict) else {}
            row = rows[idx] if isinstance(rows[idx], dict) else {}
            dbg("BROKER_RAW idx=%s name=%s type=%s node=%s id=%s track_id=%s album_id=%s artist=%s album=%s genre=%s duration=%s art=%s" % (
                idx,
                _safe_str(raw.get("text") or raw.get("title") or raw.get("name") or raw.get("label")),
                _safe_str(raw.get("type")),
                _safe_str(raw.get("node")),
                _safe_str(raw.get("id")),
                _row_track_id_from_item(raw),
                _row_album_id_from_item(raw),
                _safe_str(raw.get("artist")),
                _safe_str(raw.get("album")),
                _safe_str(raw.get("genre")),
                _safe_str(raw.get("duration")),
                _safe_str(raw.get("artwork_url") or raw.get("icon") or raw.get("icon-id"))
            ))
            dbg("BROKER_ROW idx=%s label=%s type=%s id=%s track_id=%s album_id=%s artist=%s album=%s genre=%s duration=%s art=%s can_open=%s" % (
                idx,
                _safe_str(row.get("label")),
                _safe_str(row.get("type")),
                _safe_str(row.get("id")),
                _safe_str(row.get("track_id")),
                _safe_str(row.get("album_id")),
                _safe_str(row.get("artist")),
                _safe_str(row.get("album")),
                _safe_str(row.get("genre")),
                _safe_str(row.get("duration")),
                _safe_str(row.get("art")),
                _safe_str(row.get("can_open"))
            ))
    except Exception as e:
        dbg("BROKER_LOG_ERR %s" % _safe_str(e))


def _row_from_action_item(it: Dict[str, Any], default_type: str = "node") -> Dict[str, Any]:
    label = _pick_label(it)
    row_type = default_type
    actions = it.get("actions") or {}

    item_kind = _safe_str(it.get("type")).lower()
    source_node = _safe_str(it.get("node")).lower()
    row_item_id = _safe_str((it.get("params") or {}).get("item_id")).strip() if isinstance(it.get("params"), dict) else ""
    row_ctx = _safe_str((it.get("params") or {}).get("isContextMenu")).strip() if isinstance(it.get("params"), dict) else ""
    row_pc = _safe_str((it.get("playControlParams") or {}).get("xmlbrowserPlayControl")).strip() if isinstance(it.get("playControlParams"), dict) else ""
    row_touch = _safe_str((it.get("params") or {}).get("touchToPlay")).strip() if isinstance(it.get("params"), dict) else ""
    row_style = _safe_str(it.get("style")).lower()
    row_fav_url = _safe_str(((it.get("presetParams") or {}).get("favorites_url"))).strip() if isinstance(it.get("presetParams"), dict) else ""
    label_key = _norm_key(label)
    can_search = _safe_str(it.get("can_search") or it.get("canSearch")).strip().lower() in ("1", "true", "yes")
    action_menus: Set[str] = set()
    for action in actions.values() if isinstance(actions, dict) else []:
        params = action.get("params") if isinstance(action, dict) and isinstance(action.get("params"), dict) else {}
        menu_name = _safe_str(params.get("menu")).strip().lower()
        if menu_name:
            action_menus.add(menu_name)
    is_spotty_search_container = (
        label_key == "search" and
        any("spotty" in menu_name or "spotify" in menu_name for menu_name in action_menus)
    )
    if label_key in (
        "createanewstation", "createnewstation", "createstation", "newstation", "addstation",
        "renamestation",
        "addmoremusictothisstation", "addmoremusic"
    ):
        can_search = True
    elif label_key == "search" and not is_spotty_search_container:
        can_search = True
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        mode = _safe_str(bag.get("mode")).strip().lower()
        tagged = _safe_str(
            bag.get("search") or bag.get("query") or bag.get("term") or
            bag.get("station") or bag.get("station_name") or bag.get("stationname")
        ).strip().upper()
        if tagged == "__TAGGEDINPUT__":
            can_search = True
            break
    if not can_search and isinstance(actions, dict):
        for act in actions.values():
            params = act.get("params") if isinstance(act, dict) and isinstance(act.get("params"), dict) else {}
            mode = _safe_str(params.get("mode")).strip().lower()
            tagged = _safe_str(
                params.get("search") or params.get("query") or params.get("term") or
                params.get("station") or params.get("station_name") or params.get("stationname")
            ).strip().upper()
            if tagged == "__TAGGEDINPUT__":
                can_search = True
                break
    is_spotty_touch_track = (
        row_item_id != "" and
        row_touch != "" and
        row_ctx in ("1", "true", "True") and
        row_style == "itemplay" and
        row_fav_url.startswith("spotify:track:")
    )
    is_spotty_playcontrol_track = (
        _safe_str(it.get("goAction")).lower() == "playcontrol" and
        row_item_id != "" and
        row_ctx in ("1", "true", "True") and
        row_pc != "" and
        row_fav_url.startswith("spotify:track:")
    )

    go_action_play = (_safe_str(it.get("goAction")).lower() == "play" and
                      item_kind in ("audio", "track", "song", "playlist"))
    # Spotty track rows should target/select only on tap; UI Play handles playback.
    # Keep Pandora, Pyrrha, randomplay and all other sources on their existing behavior.
    if is_spotty_touch_track or is_spotty_playcontrol_track:
        go_action_play = False
    has_playable_actions = isinstance(actions, dict) and (
        isinstance(actions.get("play"), dict) or
        isinstance(actions.get("add"), dict) or
        isinstance(actions.get("add-hold"), dict)
    )
    is_podcast_episode = bool(it.get("_broker_podcast_episode")) or _is_podcast_episode_actions(actions)
    if is_podcast_episode:
        has_playable_actions = True
    podcast_go = actions.get("go") if isinstance(actions.get("go"), dict) else {}
    podcast_go_cmd = podcast_go.get("cmd") if isinstance(podcast_go.get("cmd"), list) else []
    is_podcast_browse_node = (
        not is_podcast_episode
        and len(podcast_go_cmd) >= 2
        and _safe_str(podcast_go_cmd[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(podcast_go_cmd[1]).strip().lower() == "items"
    )
    # Treat only true track/song/audio rows as playable-first when track drilldown is off.
    # Albums often expose play/add actions too, but should still drill to the track list.
    looks_like_track = (
        item_kind in ("audio", "track", "song") or
        (it.get("duration") is not None) or
        bool(_safe_str(it.get("track"))) or
        is_spotty_touch_track or
        is_spotty_playcontrol_track or
        is_podcast_episode
    )
    track_drill = _track_drilldown_enabled()

    if is_spotty_touch_track or is_spotty_playcontrol_track:
        row_type = "track"
    elif go_action_play or (has_playable_actions and looks_like_track):
        row_type = "track"
    elif it.get("isANode"):
        row_type = "node"

    art = _pick_art(it)
    if not art and row_type == "track":
        art = _track_album_art_url(it)
    if not art and isinstance(it.get("presetParams"), dict):
        art = _normalize_icon_url(_safe_str((it.get("presetParams") or {}).get("icon")))
    if not art:
        art = _mymusic_fallback_art(it, label)
    if not art and row_type != "track":
        art = _action_fallback_art(label, row_type)
    if not art and row_type != "track":
        art = _broker_list_art_url("0")
    if it.get("no_icon"):
        art = ""

    item_id = ""
    node_name = _safe_str(it.get("id"))
    can_open = False

    if is_spotty_touch_track or is_spotty_playcontrol_track:
        item_id = "sptrack:" + row_item_id
        row_type = "track"
        can_open = False
    elif it.get("isANode") and node_name and not (row_type == "track" and not track_drill):
        item_id = "group:" + node_name
        row_type = "node"
        can_open = True
    elif isinstance(actions, dict) and actions:
        is_pandora_station = _is_pandora_station_context_row(label, actions)
        if is_pandora_station:
            item_id = "act:" + _b64u_enc({"kind": "pandora_station", "label": label, "actions": actions})
            row_type = "node"
            can_open = True
            dbg("PANDORA STATION ROW label=%s can_open=1" % _safe_str(label))
        else:
            action_spec: Dict[str, Any] = {"kind": "actions", "label": label, "actions": actions}
            if "checkbox" in it:
                action_spec["checkbox"] = _safe_int(it.get("checkbox"), 0)
            if it.get("nextWindow") is not None:
                action_spec["nextWindow"] = _safe_str(it.get("nextWindow"))
            item_id = "act:" + _b64u_enc(action_spec)
        if is_spotty_touch_track or is_spotty_playcontrol_track:
            item_id = "sptrack:" + row_item_id
            row_type = "track"
            can_open = False
        elif is_pandora_station:
            row_type = "node"
            can_open = True
        elif is_podcast_browse_node:
            row_type = "node"
            can_open = True
        elif has_playable_actions and looks_like_track and not track_drill:
            row_type = "track"
            can_open = False
        elif isinstance(actions.get("go"), dict):
            row_type = "node"
            can_open = True
        elif isinstance(actions.get("on"), dict) or isinstance(actions.get("off"), dict):
            row_type = "node"
            can_open = True
        elif has_playable_actions and (looks_like_track or not isinstance(actions.get("go"), dict)):
            row_type = "track"
        elif isinstance(actions.get("do"), dict):
            row_type = "action"
    elif go_action_play:
        dbg("NOOP RAW ITEM " + json.dumps(it, ensure_ascii=False))
        item_id = "noop:" + _norm_key(label)
    else:
        dbg("NOOP RAW ITEM " + json.dumps(it, ensure_ascii=False))
        item_id = "noop:" + _norm_key(label)

    display_label = label
    if "checkbox" in it:
        display_label = ("[x] " if _safe_int(it.get("checkbox"), 0) else "[ ] ") + label
    row = {"id": item_id, "label": display_label, "type": row_type, "can_open": can_open}
    if "checkbox" in it:
        row["checkbox"] = _safe_int(it.get("checkbox"), 0)
    if can_search:
        row["can_search"] = True
        row["can_open"] = True
        row["type"] = "node"
    if art:
        row["art"] = art
    _dbg_row_art(label, item_id, art, it)
    if _safe_str(it.get("artist")):
        row["artist"] = _safe_str(it.get("artist"))
    if _safe_str(it.get("album")):
        row["album"] = _safe_str(it.get("album"))
    if _safe_str(it.get("genre")):
        row["genre"] = _safe_str(it.get("genre"))
    if it.get("duration") is not None:
        row["duration"] = it.get("duration")
    track_id = _row_track_id_from_item(it)
    if track_id:
        row["track_id"] = track_id
    album_id = _row_album_id_from_item(it)
    if album_id:
        row["album_id"] = album_id
    if _row_can_add_favorite(it, row_type, track_id, album_id):
        row["canAddFavorite"] = True
    try:
        dbg("ALBUM ROW DEBUG label=%s type=%s album_id=%s track_id=%s canAddFavorite=%s node=%s raw_id=%s raw_keys=%s" % (
            _safe_str(row.get("label")),
            _safe_str(row.get("type")),
            _safe_str(row.get("album_id")),
            _safe_str(row.get("track_id")),
            _safe_str(row.get("canAddFavorite")),
            _safe_str(it.get("node")),
            _safe_str(it.get("id")),
            ",".join(sorted(list(it.keys()))) if isinstance(it, dict) else ""
        ))
    except Exception:
        pass
    return row

def _payload(node: str, title: str, items: List[Dict[str, Any]], can_back: bool, source: str = "", page_kind: str = "", context_name: str = "", context_source: str = "") -> Dict[str, Any]:
    return {
        "node": node,
        "title": title,
        "source": source,
        "page_kind": page_kind,
        "context_name": context_name,
        "context_source": context_source,
        "offset": 0,
        "limit": len(items),
        "total": len(items),
        "items": items,
        "nav": {"can_back": can_back, "can_home": node != "home"},
    }




def _infer_page_kind(rows: List[Dict[str, Any]]) -> str:
    if not isinstance(rows, list) or not rows:
        return "container"
    has_trackish = False
    actionish = 0
    for r in rows:
        if not isinstance(r, dict):
            continue
        if _safe_str(r.get("type")).lower() == "track" or _safe_str(r.get("track_id")).strip() or _safe_str(r.get("album_id")).strip() or _safe_int(r.get("duration"), 0) > 0:
            has_trackish = True
        if r.get("can_open"):
            return "container"
        if _safe_str(r.get("id")).startswith("act:") or r.get("canPlayLoad") or r.get("canPlayAdd") or r.get("canPlayInsert"):
            actionish += 1
    if has_trackish:
        return "track_list"
    if actionish > 0:
        return "action_page"
    return "container"

def _home_payload_from_top(top: Dict[str, Any]) -> Dict[str, Any]:
    items = _extract_menu_items(top)
    rows: List[Dict[str, Any]] = []
    for rowcfg in sorted(_home_menu_cache, key=lambda r: (_safe_int(r.get("order"),100), _safe_str(r.get("label")))):
        if not rowcfg.get("enabled"):
            continue
        key = _safe_str(rowcfg.get("key")).strip().lower()
        label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or key)
        kind = _safe_str(rowcfg.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core"
        if kind == "core":
            if key == "mymusic":
                it = _top_find_home_item(items, "My Music") or {}
                row = {"id": "root:mymusic", "label": label or "My Music", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/html/images/musicfolder.png")
                if art: row["art"] = art
                rows.append(row)
            elif key == "radio":
                it = _top_find_home_item(items, "Radio") or {}
                row = {"id": "root:radio", "label": label or "Radio", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/plugins/TuneIn/html/images/radio.png")
                if art: row["art"] = art
                rows.append(row)
            elif key == "favorites":
                it = _top_find_home_item(items, "Favorites") or {}
                row = {"id": "root:favorites", "label": label or "Favorites", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/html/images/favorites.png")
                if art: row["art"] = art
                rows.append(row)
            continue
        want = _norm_key(rowcfg.get("source_label") or rowcfg.get("label") or "")
        picked = None
        for it in items:
            if _safe_int(it.get("isApp"), 0) != 1:
                continue
            if _norm_key(_pick_label(it)) == want:
                picked = it
                break
        if picked is None:
            continue
        root_id = "rootapp:" + _safe_str(rowcfg.get("key"))
        r = {"id": root_id, "label": label or _pick_label(picked), "type": "node", "can_open": True}
        art = _pick_art(picked) or _safe_str(rowcfg.get("icon") or "")
        if art:
            r["art"] = art
        rows.append(r)
    return _payload("home", _safe_str(_setup_cache.get("home_title") or "Home"), rows, False, "", "home", "", "")


def _group_payload_from_top(top: Dict[str, Any], node_name: str, title: str, source: str = "") -> Dict[str, Any]:
    raw_group: List[Dict[str, Any]] = []
    for it in _extract_menu_items(top):
        if _safe_str(it.get("node")) == node_name:
            raw_group.append(it)
    if node_name == "randomplay":
        raw_group = [
            it for it in raw_group
            if _safe_str(it.get("id")).strip().lower() != "randomchooselibrary"
            and _norm_key(_pick_label(it)) != "uselibraryview"
        ]
    if node_name == "myMusic":
        raw_group = _apply_mymusic_menu_config(raw_group)
    elif node_name == "radios":
        raw_group = _apply_radio_menu_config(raw_group)
    items = [_row_from_action_item(it) for it in raw_group]
    source = _clean_text(source or title)
    return _payload(f"group:{node_name}", title, items, True, source, "section", title, source)


def _action_to_rpc_args(action: Dict[str, Any], offset: int = 0, limit: int = 60, search: str = "") -> List[Any]:
    cmd = action.get("cmd") or []
    if not isinstance(cmd, list):
        cmd = [cmd]
    args: List[Any] = list(cmd)
    lower = [_safe_str(x).lower() for x in args]
    if any(x == "items" for x in lower):
        args.extend([str(offset), str(limit)])
    elif lower and lower[0] == "randomplaygenrelist" and len(args) == 1:
        # Without a range LMS returns only the count, not the genre rows.
        args.extend(["0", "200"])
    params = action.get("params") or {}
    if (
        isinstance(params, dict)
        and len(lower) >= 3
        and _safe_str(args[0]).strip().lower().startswith("fr_pandora_")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() in ("play", "add")
    ):
        parent_id = _pandora_station_parent_item_id(params.get("item_id"))
        current_id = _safe_str(params.get("item_id")).strip()
        if parent_id and parent_id != current_id:
            params = dict(params)
            params["item_id"] = parent_id
            if _safe_str(params.get("touchToPlay")).strip():
                params["touchToPlay"] = parent_id
            dbg("PANDORA ACTION parent item_id=%s from=%s" % (parent_id, current_id))
        if isinstance(params, dict):
            params = dict(params)
            for k in ("isContextMenu", "useContextMenu", "touchToPlaySingle", "nextWindow"):
                params.pop(k, None)
    search = _safe_str(search).strip()
    search_added = False
    station_added = False
    if isinstance(params, dict):
        for k, v in params.items():
            lk = _safe_str(k).lower()
            if lk in ("player", "playerid", "player_id"):
                continue
            if search and lk in ("search", "searchterm", "query", "q", "term", "station", "stationname", "station_name"):
                args.append(f"{k}:{search}")
                search_added = True
                if lk in ("station", "stationname", "station_name"):
                    station_added = True
                continue
            if v is None or v == "":
                continue
            args.append(f"{k}:{v}")
    if search and not search_added:
        args.append(f"search:{search}")
    if search and args and _safe_str(args[0]).lower().startswith("fr_pandora") and not station_added:
        args.append(f"station:{search}")
    return args


def _menu_action_track_override_args(acts: Dict[str, Any], pcmd: str) -> Optional[List[Any]]:
    if not isinstance(acts, dict):
        return None

    add_hold = acts.get("add-hold") if isinstance(acts.get("add-hold"), dict) else None
    ah_params = add_hold.get("params") if isinstance(add_hold, dict) and isinstance(add_hold.get("params"), dict) else {}
    track_id = _safe_str(ah_params.get("track_id")).strip()
    if not track_id:
        return None

    play = acts.get("play") if isinstance(acts.get("play"), dict) else None
    play_params = play.get("params") if isinstance(play, dict) and isinstance(play.get("params"), dict) else {}
    add = acts.get("add") if isinstance(acts.get("add"), dict) else None
    add_params = add.get("params") if isinstance(add, dict) and isinstance(add.get("params"), dict) else {}

    # Track rows coming from LMS album drilldown often expose:
    #   play      -> album-level playlistcontrol load
    #   add       -> album-level playlistcontrol add
    #   add-hold  -> track-level playlistcontrol insert
    # For RTI target mode we want the selected track, not the whole album.
    # When add-hold gives us a concrete track_id, prefer that for load/add too.
    args: List[Any] = ["playlistcontrol", pcmd, f"track_id:{track_id}"]

    src_params = ah_params
    if pcmd == "cmd:load" and play_params:
        src_params = play_params
    elif pcmd == "cmd:add" and add_params:
        src_params = add_params

    for key in ("menu", "sort"):
        val = src_params.get(key)
        if val is None or val == "":
            val = ah_params.get(key)
        if val is not None and val != "":
            args.append(f"{key}:{val}")
    return args


def _pandora_contextmenu_action_from_spec(spec: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(spec, dict):
            return None
        if _norm_key(spec.get("label")) == "playthisstation":
            return None
        acts = spec.get("actions") or {}
        if not isinstance(acts, dict) or not acts:
            return None
        sample = _pandora_station_action(acts)
        if not isinstance(sample, dict):
            return None
        cmd = sample.get("cmd") or []
        if not isinstance(cmd, list):
            cmd = [cmd]
        lower = [_safe_str(x).lower() for x in cmd]
        if len(lower) < 3:
            return None
        menu_name = _pandora_menu_name(lower[0])
        if not menu_name:
            return None
        if lower[1] != "playlist" or lower[2] != "play":
            return None
        params = sample.get("params") or {}
        if not isinstance(params, dict):
            return None
        if _pandora_menu_name(params.get("menu")) != menu_name:
            return None
        if not _safe_str(params.get("item_id")):
            return None
        ctx_params = dict(params)
        for k in ("touchToPlay", "touchToPlaySingle", "nextWindow", "player", "playerid", "player_id"):
            ctx_params.pop(k, None)
        ctx_params["isContextMenu"] = 1
        if "useContextMenu" not in ctx_params:
            ctx_params["useContextMenu"] = 1
        dbg("PANDORA CONTEXT OPEN item_id=" + _safe_str(ctx_params.get("item_id")))
        # Pandora's station "play" action starts playback even with
        # isContextMenu set. Ask the plugin's XML-browser endpoint for the
        # context menu instead, using the same station item_id.
        return {"cmd": [cmd[0], "items"], "params": ctx_params}
    except Exception as e:
        dbg("PANDORA CONTEXT helper error: " + _safe_str(e))
        return None

def _pandora_station_parent_item_id(item_id: Any) -> str:
    s = _safe_str(item_id).strip()
    if not s:
        return ""
    parts = [p for p in s.split(".") if p != ""]
    if len(parts) >= 3:
        return ".".join(parts[:2])
    return s

def _spec_label_for_favorite(spec: Dict[str, Any]) -> str:
    if not isinstance(spec, dict):
        return ""
    v = _safe_str(spec.get("label") or spec.get("title") or spec.get("name")).strip()
    if "\n" in v:
        v = v.split("\n", 1)[0].strip()
    return v

def _favorite_args_from_ids(title: str, track_id: str = "", album_id: str = "", artist_id: str = "", playlist_id: str = "") -> Optional[List[Any]]:
    title = _safe_str(title).strip()
    if track_id:
        return ["favorites", "add", f"url:db:track.id={track_id}", f"title:{title or track_id}"]
    if album_id:
        return ["favorites", "add", f"url:db:album.id={album_id}", f"title:{title or album_id}"]
    if artist_id:
        return ["favorites", "add", f"url:db:contributor.id={artist_id}", f"title:{title or artist_id}"]
    if playlist_id:
        return ["favorites", "add", f"url:db:playlist.id={playlist_id}", f"title:{title or playlist_id}"]
    return None

def _spec_favorite_args(spec: Dict[str, Any]) -> Optional[List[Any]]:
    if not isinstance(spec, dict):
        return None

    title = _spec_label_for_favorite(spec)

    # Exact favorite action from LMS/plugin, if present.
    acts = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
    for k in ("favorite", "favorites", "addfavorite", "add_favorite"):
        act = acts.get(k)
        if isinstance(act, dict):
            args = _action_to_rpc_args(act, 0, 60)
            if isinstance(args, list) and args:
                return args

    # Explicit favorite URL from plugin rows.
    for bucket in (spec.get("presetParams"), spec.get("commonParams")):
        if isinstance(bucket, dict):
            fav_url = _safe_str(bucket.get("favorites_url")).strip()
            if fav_url:
                return ["favorites", "add", f"url:{fav_url}", f"title:{title or fav_url}"]

    # Fall back to ids found in any common action params.
    track_id = album_id = artist_id = playlist_id = ""
    for k in ("add-hold", "play", "add", "go", "do"):
        act = acts.get(k)
        if not isinstance(act, dict):
            continue
        params = act.get("params") if isinstance(act.get("params"), dict) else {}
        track_id = track_id or _safe_str(params.get("track_id")).strip()
        album_id = album_id or _safe_str(params.get("album_id")).strip()
        artist_id = artist_id or _safe_str(params.get("artist_id")).strip()
        playlist_id = playlist_id or _safe_str(params.get("playlist_id")).strip()

    return _favorite_args_from_ids(title, track_id, album_id, artist_id, playlist_id)



def _find_top_action_item(top_items: List[Dict[str, Any]], menu: str = "", mode: str = "", node: str = "", item_id: str = "") -> Optional[Dict[str, Any]]:
    want_menu = _safe_str(menu)
    want_mode = _safe_str(mode)
    want_node = _safe_str(node)
    want_id = _safe_str(item_id)
    for it in top_items:
        if want_node and _safe_str(it.get("node")) != want_node:
            continue
        if want_id and _safe_str(it.get("id")) == want_id:
            return it
        acts = it.get("actions") or {}
        go = acts.get("go") if isinstance(acts, dict) else None
        params = go.get("params") if isinstance(go, dict) else None
        if isinstance(params, dict):
            if want_menu and _safe_str(params.get("menu")) == want_menu:
                if not want_mode or _safe_str(params.get("mode")) == want_mode:
                    return it
            if want_mode and _safe_str(params.get("mode")) == want_mode and (not want_menu or _safe_str(params.get("menu")) == want_menu):
                return it
    return None




def _merge_base_actions_into_raw_items(raw_items: List[Dict[str, Any]], base_actions: Dict[str, Any]) -> None:
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        row_params = it.get("params") if isinstance(it.get("params"), dict) else {}
        if (not isinstance(it.get("actions"), dict)) and isinstance(it.get("addAction"), str):
            ak = _safe_str(it.get("addAction"))
            if isinstance(base_actions.get(ak), dict):
                it["actions"] = {ak: dict(base_actions.get(ak) or {})}
        # For many LMS plugin rows (eg Pyrrha/Pandora-style itemplay/audio), actions are not inline.
        # Instead the row advertises goAction/play and the parent result provides base.actions with
        # itemsParams:"params". Synthesize row actions from base.actions + row params so we call the
        # plugin's own command path rather than forcing playlistcontrol item_id loads.
        if not isinstance(it.get("actions"), dict):
            synth = {}
            ga = _safe_str(it.get("goAction")).strip()
            for bk in (ga, "play", "add", "add-hold", "go"):
                if not bk:
                    continue
                bv = base_actions.get(bk)
                if not isinstance(bv, dict):
                    continue
                spec = dict(bv)
                params = dict(spec.get("params") or {})
                items_params = _safe_str(spec.get("itemsParams"))
                if items_params == "params" and row_params:
                    for rk, rv in row_params.items():
                        if rv is not None and rv != "":
                            params[rk] = rv
                elif items_params == "commonParams":
                    cp = dict(it.get("commonParams") or {})
                    for rk, rv in cp.items():
                        if rv is not None and rv != "":
                            params[rk] = rv
                elif items_params == "presetParams":
                    pp = dict(it.get("presetParams") or {})
                    for rk, rv in pp.items():
                        if rv is not None and rv != "":
                            params[rk] = rv
                elif items_params == "playControlParams":
                    pcp = dict(it.get("playControlParams") or {})
                    for rk, rv in pcp.items():
                        if rv is not None and rv != "":
                            params[rk] = rv
                spec["params"] = params
                synth[bk] = spec
            if synth:
                it["actions"] = synth
        elif isinstance(it.get("actions"), dict) and isinstance(base_actions, dict):
            for bk, bv in base_actions.items():
                if bk not in it["actions"] and isinstance(bv, dict):
                    it["actions"][bk] = bv

def _fill_tagged_search_inputs(obj: Any, search: str) -> None:
    s = _safe_str(search).strip()
    if not s:
        return
    try:
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if isinstance(v, str) and v.strip().upper() == "__TAGGEDINPUT__":
                    obj[k] = s
                elif isinstance(v, (dict, list)):
                    _fill_tagged_search_inputs(v, s)
        elif isinstance(obj, list):
            for v in obj:
                if isinstance(v, (dict, list)):
                    _fill_tagged_search_inputs(v, s)
    except Exception:
        pass

def _search_bucket_from_item(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return ""
    acts = it.get("actions") if isinstance(it.get("actions"), dict) else {}
    go = acts.get("go") if isinstance(acts.get("go"), dict) else None
    params = go.get("params") if isinstance(go, dict) and isinstance(go.get("params"), dict) else {}
    bucket = _safe_str(params.get("cachesearch")).strip().upper()
    if bucket:
        return bucket
    lab = _norm_key(_pick_label(it))
    if "artist" in lab:
        return "ARTISTS"
    if "album" in lab:
        return "ALBUMS"
    if "song" in lab or "track" in lab:
        return "SONGS"
    if "work" in lab:
        return "WORKS"
    return ""

def _search_bucket_suffix(bucket: str) -> str:
    b = _safe_str(bucket).strip().upper()
    if b.startswith("ARTIST"):
        return "Artist"
    if b.startswith("ALBUM"):
        return "Album"
    if b.startswith("SONG") or b.startswith("TRACK"):
        return "Song"
    if b.startswith("WORK"):
        return "Work"
    if b.startswith("PLAYLIST"):
        return "Playlist"
    return ""

def _looks_like_search_bucket_page(items: List[Dict[str, Any]], search: str) -> bool:
    if not search or not isinstance(items, list) or not items:
        return False
    found = 0
    for it in items:
        if _search_bucket_from_item(it):
            found += 1
    return found >= max(2, min(3, len(items)))

async def _flatten_mymusic_search_results(pid: str, raw_items: List[Dict[str, Any]], search: str, limit: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    order = {"ARTISTS": 0, "ALBUMS": 1, "SONGS": 2, "TRACKS": 2, "WORKS": 3, "PLAYLISTS": 4}
    buckets = sorted(
        [it for it in raw_items if isinstance(it, dict) and _search_bucket_from_item(it)],
        key=lambda it: order.get(_search_bucket_from_item(it), 99)
    )
    per_bucket = max(3, min(12, _safe_int(limit, 20)))
    for bucket_item in buckets:
        bucket = _search_bucket_from_item(bucket_item)
        suffix = _search_bucket_suffix(bucket)
        acts = bucket_item.get("actions") if isinstance(bucket_item.get("actions"), dict) else {}
        go = acts.get("go") if isinstance(acts.get("go"), dict) else None
        if not isinstance(go, dict):
            continue
        action = copy.deepcopy(go)
        _fill_tagged_search_inputs(action, search)
        try:
            rr = await lms.rpc(pid, _action_to_rpc_args(action, 0, per_bucket, ""))
            sub_res = rr.get("result") or {}
            sub_items = _extract_menu_items(sub_res)
            base_actions = (sub_res.get("base") or {}).get("actions") or {}
            _merge_base_actions_into_raw_items(sub_items, base_actions)
        except Exception as e:
            dbg("SEARCH FLATTEN bucket=%s failed: %s" % (bucket, _safe_str(e)))
            continue
        for raw in sub_items:
            if not isinstance(raw, dict):
                continue
            row = _row_from_action_item(raw)
            label = _safe_str(row.get("label")).strip()
            if suffix and label and f"({suffix})" not in label:
                row["label"] = f"{label} ({suffix})"
            sig = _safe_str(row.get("id") or row.get("label"))
            if not sig or sig in seen:
                continue
            seen.add(sig)
            out.append(row)
            if len(out) >= _safe_int(limit, 20):
                return out
    return out


def _first_nonempty(d: Dict[str, Any], *keys: str) -> str:
    if not isinstance(d, dict):
        return ""
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            return _safe_str(v).strip()
    return ""


async def _direct_mymusic_search_results(search: str, limit: int = 60) -> List[Dict[str, Any]]:
    term = _safe_str(search).strip()
    if not term:
        return []
    max_items = max(5, min(_safe_int(limit, 20), 40))

    async def quick_rpc(args: List[Any]) -> Dict[str, Any]:
        try:
            return await asyncio.wait_for(lms.rpc("", args), timeout=2.0)
        except Exception as e:
            dbg("SEARCH DIRECT failed args=%s err=%s" % (_safe_str(args), _safe_str(e)))
            return {}

    per_group = max(6, min(16, max_items))
    artist_r, album_r, title_r = await asyncio.gather(
        quick_rpc(["artists", 0, per_group, f"search:{term}"]),
        quick_rpc(["albums", 0, per_group, f"search:{term}"]),
        quick_rpc(["titles", 0, per_group, f"search:{term}", "tags:aldt"]),
    )

    rows: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    def add_row(row: Dict[str, Any]) -> None:
        if len(rows) >= max_items:
            return
        sig = _safe_str(row.get("id") or row.get("label")).strip()
        if not sig or sig in seen:
            return
        seen.add(sig)
        rows.append(row)

    def leaf_row(row_id: str, label: str, suffix: str, raw: Dict[str, Any]) -> Dict[str, Any]:
        text = _safe_str(label).strip()
        if suffix and text and f"({suffix})" not in text:
            text = f"{text} ({suffix})"
        row: Dict[str, Any] = {
            "id": row_id,
            "label": text,
            "type": "track",
            "can_open": False,
        }
        artist = _first_nonempty(raw, "artist", "artistname", "contributor")
        album = _first_nonempty(raw, "album", "albumtitle")
        duration = _first_nonempty(raw, "duration", "secs", "seconds")
        track_id = _first_nonempty(raw, "track_id", "trackid", "id") if row_id.startswith("title:") else ""
        album_id = _first_nonempty(raw, "album_id", "albumid", "id") if row_id.startswith("album:") else _first_nonempty(raw, "album_id", "albumid")
        if artist:
            row["artist"] = artist
        if album:
            row["album"] = album
        if duration:
            row["duration"] = duration
        if track_id:
            row["track_id"] = track_id
        if album_id:
            row["album_id"] = album_id
        art = _pick_art(raw) or _track_album_art_url(raw) or _local_cover_art_url(raw)
        if art:
            row["art"] = art
        return row

    artist_res = (artist_r.get("result") or {}) if isinstance(artist_r, dict) else {}
    for raw in artist_res.get("artists_loop") or artist_res.get("contributors_loop") or []:
        if not isinstance(raw, dict):
            continue
        aid = _first_nonempty(raw, "artist_id", "contributor_id", "id")
        name = _first_nonempty(raw, "artist", "artistname", "contributor", "name")
        if aid and name:
            add_row(leaf_row(f"artist:{aid}", name, "Artist", raw))

    album_res = (album_r.get("result") or {}) if isinstance(album_r, dict) else {}
    for raw in album_res.get("albums_loop") or []:
        if not isinstance(raw, dict):
            continue
        aid = _first_nonempty(raw, "album_id", "albumid", "id")
        name = _first_nonempty(raw, "album", "albumtitle", "title", "name")
        if aid and name:
            add_row(leaf_row(f"album:{aid}", name, "Album", raw))

    title_res = (title_r.get("result") or {}) if isinstance(title_r, dict) else {}
    for raw in title_res.get("titles_loop") or title_res.get("tracks_loop") or []:
        if not isinstance(raw, dict):
            continue
        tid = _first_nonempty(raw, "track_id", "trackid", "id")
        name = _first_nonempty(raw, "title", "track", "name")
        if tid and name:
            add_row(leaf_row(f"title:{tid}", name, "Song", raw))

    dbg("SEARCH DIRECT term=%s rows=%s" % (term, len(rows)))
    return rows



def _library_title_from_action(action: Dict[str, Any], title_hint: str = "") -> str:
    t = _safe_str(title_hint).strip()
    if t and t.lower() not in ("library", "browse", "music library"):
        return t
    params = action.get("params") if isinstance(action, dict) and isinstance(action.get("params"), dict) else {}
    mode = _safe_str(params.get("mode")).strip().lower()
    if mode == "albums":
        return "Albums"
    if mode == "artists":
        return "Artists"
    if mode == "genres":
        return "Genres"
    if mode == "playlists":
        return "Playlists"
    if mode == "years":
        return "Years"
    if mode == "search":
        return "Search"
    cmd = action.get("cmd") if isinstance(action, dict) else []
    if isinstance(cmd, list) and len(cmd) >= 2 and _safe_str(cmd[0]).lower() == "browselibrary" and _safe_str(cmd[1]).lower() == "items":
        return "My Music"
    menu = _safe_str(params.get("menu")).strip()
    if menu == "1":
        return "My Music"
    return t or "Library"


async def _action_result_payload(pid: str, spec: Dict[str, Any], title_hint: str = "", offset: int = 0, limit: int = 60, source_hint: str = "", search: str = "") -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    action = spec.get("action") or {}
    if not action:
        pandora_ctx = _pandora_contextmenu_action_from_spec(spec)
        if isinstance(pandora_ctx, dict):
            action = pandora_ctx
        else:
            acts = spec.get("actions") or {}
            if isinstance(acts, dict):
                if isinstance(acts.get("go"), dict):
                    action = acts.get("go")
                elif isinstance(acts.get("do"), dict):
                    action = acts.get("do")
                elif isinstance(acts.get("play"), dict):
                    action = acts.get("play")
                elif isinstance(acts.get("on"), dict) or isinstance(acts.get("off"), dict):
                    action = acts.get("off") if _safe_int(spec.get("checkbox"), 0) else acts.get("on")
    if not isinstance(action, dict) or not action:
        return (None, {"t": "err", "ok": False, "error": "unsupported_item"})
    search = _safe_str(search).strip()
    args = _action_to_rpc_args(action, offset, limit, search)
    is_iheart_station_play = (
        len(args) >= 3
        and _safe_str(args[0]).strip().lower() in ("iheartradio", "fr_iheartradio")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() == "play"
    )
    if is_iheart_station_play:
        await lms.rpc(pid, ["playlist", "clear"])
        _np_source_by_playerid[pid] = _configured_source_label("iheart") or "iHeartRadio"
        station_name = _clean_text(spec.get("label") or title_hint).splitlines()[0].strip()
        if station_name and not _is_internal_label(station_name):
            _np_station_by_playerid[pid] = station_name
            _np_station_by_playerid[pid.lower()] = station_name
    r = await lms.rpc(pid, args)
    r = await _verify_random_mix_start(pid, args, r)
    if (
        len(args) >= 3
        and _safe_str(args[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() == "play"
    ):
        _schedule_podcast_selection_refresh(pid, _safe_str(spec.get("label") or title_hint))
    if len(args) >= 2 and _safe_str(args[0]).strip().lower() == "randomplay":
        randomplay_mode = _safe_str(args[1]).strip().lower()
        if randomplay_mode == "disable":
            await lms.rpc(pid, ["stop"])
        else:
            _random_mix_queue_players.add(pid.lower())
    if is_iheart_station_play:
        asyncio.create_task(_collapse_iheart_queue_later(pid))
    res = (r.get("result") or {})
    raw_items = _extract_menu_items(res)
    replace_current_menu = False
    spec_label_key = _norm_key(spec.get("label"))
    action_params = action.get("params") if isinstance(action.get("params"), dict) else {}
    action_cmd = action.get("cmd") if isinstance(action.get("cmd"), list) else []
    randomplay_command = _safe_str(action_cmd[0]).strip().lower() if action_cmd else ""
    if randomplay_command in ("randomplaychoosegenre", "randomplaygenreselectall"):
        refresh = await lms.rpc(pid, ["randomplaygenrelist", "0", "200"])
        refresh_res = refresh.get("result") or {}
        refresh_items = _extract_menu_items(refresh_res)
        if refresh_items:
            res = refresh_res
            raw_items = refresh_items
            replace_current_menu = True
            title_hint = "Choose Genres"
    action_menu_name = _pandora_menu_name(action_params.get("menu"))
    action_cmd_name = _pandora_menu_name(action_cmd[0]) if action_cmd else ""
    pandora_action_menu = action_menu_name if action_menu_name and action_menu_name == action_cmd_name else ""
    if (
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[0]).strip().lower() in ("iheartradio", "fr_iheartradio") and
        _safe_str(action_cmd[1]).strip().lower() == "items"
    ):
        if (
            _iheart_region_setting()
            and _iheart_skip_intro_when_filtered()
            and _norm_key(title_hint or spec.get("label")) in ("iheartradio", "iheart", "radio")
        ):
            selected_region = _iheart_region_setting()
            genre_item = _iheart_genre_follow_item(raw_items, selected_region)
            if not genre_item:
                genre_item = next((
                    item for item in raw_items
                    if isinstance(item, dict)
                    and _norm_key(_pick_label(item)) in ("genre", "genres")
                    and isinstance((item.get("actions") or {}).get("go"), dict)
                ), None)
            if genre_item:
                genre_action = (genre_item.get("actions") or {}).get("go")
                genre_args = _action_to_rpc_args(genre_action, 0, limit, "")
                genre_response = await lms.rpc(pid, genre_args)
                genre_res = genre_response.get("result") or {}
                genre_items = _extract_menu_items(genre_res)
                if genre_items:
                    follow_item = None
                    if _norm_key(_pick_label(genre_item)) in ("genre", "genres"):
                        follow_item = _iheart_genre_follow_item(genre_items, selected_region)
                    if follow_item:
                        follow_action = (follow_item.get("actions") or {}).get("go")
                        follow_args = _action_to_rpc_args(follow_action, 0, limit, "")
                        follow_response = await lms.rpc(pid, follow_args)
                        follow_res = follow_response.get("result") or {}
                        follow_items = _extract_menu_items(follow_res)
                        if follow_items:
                            genre_res = follow_res
                            genre_items = follow_items
                            genre_item = follow_item
                    res = genre_res
                    raw_items = genre_items
                    replace_current_menu = True
                    title_hint = _pick_label(genre_item) or "Genres"
                    dbg("IHEART skip intro opened Genres rows=%s" % len(raw_items))
        unfiltered_count = len(raw_items)
        raw_items = _filter_iheart_region_items(raw_items)
        if len(raw_items) != unfiltered_count:
            res["count"] = len(raw_items)
            dbg("IHEART REGION filter=%s rows=%s->%s" % (
                _iheart_region_setting(), unfiltered_count, len(raw_items)
            ))
    if action_cmd and _safe_str(action_cmd[0]).strip().lower() in ("spotty", "spotify"):
        unfiltered_count = len(raw_items)
        raw_items = _filter_spotty_menu_items(raw_items)
        if len(raw_items) != unfiltered_count:
            res["count"] = len(raw_items)
            dbg("SPOTTY filter transfer playback rows=%s->%s" % (unfiltered_count, len(raw_items)))
    if (
        search and
        "renamestation" in spec_label_key and
        bool(pandora_action_menu) and
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[1]).strip().lower() == "items"
    ):
        parent_station_id = _pandora_station_parent_item_id(action_params.get("item_id"))
        if parent_station_id:
            try:
                refresh = await lms.rpc(pid, [
                    pandora_action_menu, "items", 0, limit,
                    f"menu:{pandora_action_menu}",
                    f"item_id:{parent_station_id}",
                    "isContextMenu:1",
                    "useContextMenu:1",
                ])
                refresh_res = refresh.get("result") or {}
                refresh_items = _extract_menu_items(refresh_res)
                if refresh_items:
                    res = refresh_res
                    raw_items = refresh_items
                    replace_current_menu = True
                    dbg("PANDORA RENAME refresh station item_id=%s title=%s" % (parent_station_id, search))
            except Exception as e:
                dbg("PANDORA RENAME refresh failed item_id=%s err=%s" % (parent_station_id, _safe_str(e)))
    if (
        not raw_items and
        _safe_str(action.get("nextWindow")).strip().lower() == "parent" and
        bool(pandora_action_menu) and
        _safe_str(action_params.get("item_id")).strip() and
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[1]).strip().lower() == "items" and
        ("stationwillbedeleted" in spec_label_key or "areyousure" in spec_label_key)
    ):
        return ({
            "node": "act",
            "title": "Station deleted",
            "source": _safe_str(source_hint).strip(),
            "page_kind": "message",
            "context_name": _safe_str(title_hint or spec.get("label") or "").strip(),
            "context_source": _safe_str(source_hint).strip(),
            "offset": 0,
            "limit": 0,
            "total": 0,
            "items": [],
            "nav": {"can_back": True, "can_home": True},
        }, None)
    if raw_items:
        base_actions = (res.get("base") or {}).get("actions") or {}
        fast_page: List[Dict[str, Any]] = list(raw_items)
        podcast_page_key = _norm_key(title_hint or spec.get("label"))
        parent_actions = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
        parent_play = parent_actions.get("play") if isinstance(parent_actions.get("play"), dict) else {}
        parent_play_cmd = parent_play.get("cmd") if isinstance(parent_play.get("cmd"), list) else []
        parent_go = parent_actions.get("go") if isinstance(parent_actions.get("go"), dict) else {}
        is_podcast_feed_page = (
            not parent_go
            and len(parent_play_cmd) >= 3
            and _safe_str(parent_play_cmd[0]).strip().lower() in ("podcast", "podcasts")
            and _safe_str(parent_play_cmd[1]).strip().lower() == "playlist"
            and _safe_str(parent_play_cmd[2]).strip().lower() == "play"
        )
        if (
            podcast_page_key == "recentlyplayed"
            or podcast_page_key.startswith("newepisodes")
            or is_podcast_feed_page
        ):
            for raw in fast_page:
                if isinstance(raw, dict):
                    raw["_broker_podcast_episode"] = True
        if search:
            _fill_tagged_search_inputs(fast_page, search)
        if search and offset == 0 and _looks_like_search_bucket_page(fast_page, search):
            direct_rows = await _direct_mymusic_search_results(search, limit)
            if direct_rows:
                dbg("SEARCH DIRECT page term=%s replacing bucket menu rows=%s" % (search, len(direct_rows)))
                return ({
                    "node": "act",
                    "title": f"Search for {search}",
                    "source": _safe_str(source_hint).strip(),
                    "page_kind": "track_list",
                    "context_name": search,
                    "context_source": _safe_str(source_hint).strip(),
                    "offset": 0,
                    "limit": len(direct_rows),
                    "total": len(direct_rows),
                    "items": direct_rows,
                    "nav": {"can_back": True, "can_home": True},
                    "_replace_current_menu": replace_current_menu,
                }, None)
        pandora_station_context_page = (
            _safe_str(spec.get("kind")).lower() == "pandora_station" or
            (
                bool(pandora_action_menu) and
                _safe_str(action_params.get("isContextMenu")).strip() in ("1", "true", "True") and
                _safe_str(action_params.get("item_id")).strip()
            )
        )
        if pandora_station_context_page:
            for raw in fast_page:
                if isinstance(raw, dict):
                    raw["no_icon"] = True
        _merge_base_actions_into_raw_items(fast_page, base_actions)
        items = [_row_from_action_item(it) for it in fast_page if isinstance(it, dict)]
        await _enrich_track_rows(fast_page, items)
        raw_title = _safe_str((res.get("window") or {}).get("text") or res.get("title") or "")
        source = _safe_str(source_hint).strip()
        context_name = _safe_str(search or title_hint or spec.get("label") or "").strip()
        context_source = source
        page_kind = _infer_page_kind(items)
        force_title = bool(spec.get("force_title"))
        title = raw_title if raw_title and raw_title.lower() not in ("library", "browse", "music library") else _library_title_from_action(action, context_name)
        if search:
            title = search
        elif force_title and context_name:
            title = context_name
        elif page_kind == "track_list" and context_name:
            title = context_name
        elif raw_title.lower() in ("your stations", "stations") and context_name:
            title = context_name
        elif not title and context_name:
            title = context_name
        if not source:
            source = ""
        if title == "My Music":
            _dbg_broker_menu_rows(title, offset, fast_page, items)
        total = max(_safe_int(res.get("count"), len(items)), len(items))
        if is_podcast_feed_page:
            total = min(total, 200)
        return ({
            "node": "act",
            "title": title,
            "source": source,
            "page_kind": page_kind,
            "context_name": context_name,
            "context_source": context_source,
            "offset": offset,
            "limit": len(items),
            "total": total,
            "items": items,
            "nav": {"can_back": True, "can_home": True},
            "_replace_current_menu": replace_current_menu,
        }, None)
    return (None, {"t": "ack", "ok": True, "req": {"t": "menu_select", "spec": spec}, "result": res, "playerid": pid})


async def _fresh_podcast_play_args(
    pid: str, stack: List[Dict[str, Any]], expected_title: str
) -> Optional[List[Any]]:
    if not stack or not expected_title:
        return None
    parent_item = _safe_str(stack[-1].get("item"))
    if not parent_item.startswith("act:"):
        return None
    try:
        parent_spec = _b64u_dec(parent_item.split(":", 1)[1])
        refreshed, _ = await _action_result_payload(
            pid, parent_spec, _safe_str(parent_spec.get("label")), 0, 200, "Podcasts"
        )
        rows = refreshed.get("items") if isinstance(refreshed, dict) else None
        if not isinstance(rows, list):
            return None
        wanted = _norm_key(expected_title)
        for row in rows:
            if not isinstance(row, dict) or _norm_key(row.get("label")) != wanted:
                continue
            fresh_id = _safe_str(row.get("id"))
            if not fresh_id.startswith("act:"):
                continue
            fresh_spec = _b64u_dec(fresh_id.split(":", 1)[1])
            fresh_actions = fresh_spec.get("actions") or {}
            play = fresh_actions.get("play") if isinstance(fresh_actions.get("play"), dict) else {}
            cmd = play.get("cmd") if isinstance(play.get("cmd"), list) else []
            if (
                len(cmd) >= 3
                and _safe_str(cmd[0]).strip().lower() in ("podcast", "podcasts")
                and _safe_str(cmd[1]).strip().lower() == "playlist"
                and _safe_str(cmd[2]).strip().lower() == "play"
            ):
                dbg(f"PODCAST PLAY rebound title={expected_title}")
                return _action_to_rpc_args(play, 0, 60)
    except Exception as e:
        dbg(f"PODCAST PLAY rebind failed: {type(e).__name__}: {_safe_str(e)}")
    return None


async def ws_rti(req: web.Request) -> web.StreamResponse:
    _load_setup_config()
    if _broker_light_mode():
        return web.json_response({
            "ok": False,
            "error": "broker_light_mode",
            "message": "RTI websocket is disabled in Broker Light mode.",
            "setup_url": "/setup/advanced",
        }, status=403)
    if not _legal_terms_accepted():
        return web.json_response({
            "ok": False,
            "error": "legal_terms_not_accepted",
            "terms_version": LEGAL_TERMS_VERSION,
            "setup_url": "/setup",
        }, status=403)
    license_info = _license_status()
    # RTI XP's WebSocket support is fragile around extensions/control frames.
    # Keep this endpoint as plain as possible: no heartbeat pings, no compression.
    ws = web.WebSocketResponse(compress=False)
    await ws.prepare(req)

    peer = req.remote or "?"
    connect_ts = time.time()
    _rti_ws_diag["connects"] = _safe_int(_rti_ws_diag.get("connects"), 0) + 1
    _rti_ws_diag["active"] = len(_ws_clients) + 1
    _rti_ws_diag["last_peer"] = peer
    _rti_ws_diag["last_connect_ts"] = connect_ts
    _rti_ws_diag["last_error"] = ""
    dbg(f"WS client connected from {peer}")
    disconnect_counted = False

    def mark_disconnected() -> None:
        nonlocal disconnect_counted
        if disconnect_counted:
            return
        disconnect_counted = True
        _ws_clients.discard(ws)
        _rti_ws_diag["disconnects"] = _safe_int(_rti_ws_diag.get("disconnects"), 0) + 1
        _rti_ws_diag["active"] = len(_ws_clients)
        _rti_ws_diag["last_disconnect_ts"] = time.time()
        _rti_ws_diag["last_disconnect_after_secs"] = round(max(0.0, time.time() - connect_ts), 3)

    async def send(obj: Any) -> None:
        msg = _json_dumps(obj) + "\n"
        try:
            await ws.send_str(msg)
            _rti_ws_diag["last_send_ts"] = time.time()
            _rti_ws_diag["last_send_type"] = _safe_str(obj.get("t") if isinstance(obj, dict) else "")
            _rti_ws_diag["last_send_bytes"] = len(msg.encode("utf-8", errors="ignore"))
        except Exception as e:
            _rti_ws_diag["last_error"] = f"send:{type(e).__name__}:{_safe_str(e)}"
            raise

    if RTI_WS_FIRST_SEND_DELAY_SECS:
        await asyncio.sleep(RTI_WS_FIRST_SEND_DELAY_SECS)

    if ws.closed:
        mark_disconnected()
        return ws

    # Say hello first (does not affect push schema)
    if (not LYRION_VERSION) or (not BROKER_ID):
        await _refresh_server_meta()
    try:
        hello_license = license_info
        await send({
            "t": "hello",
            "ok": True,
            "app": "lyrion_broker",
            "ver": APP_VERSION,
            "lyrion_ver": LYRION_VERSION,
            "broker_id": BROKER_ID,
            "license_state": _safe_str(hello_license.get("state")),
            "license_trial_days_remaining": round(
                _safe_int(hello_license.get("trial_seconds_remaining"), 0) / 86400.0,
                2,
            ),
        })
    except Exception:
        mark_disconnected()
        return ws
    if not license_info.get("valid"):
        try:
            await send({"t": "err", "ok": False, "error": "license_expired", "license": license_info})
            await ws.close(code=4003, message=b"license expired")
        except Exception:
            pass
        mark_disconnected()
        return ws

    # IMPORTANT: do NOT add this WS to the broadcast set until after we send the full-batch.
    # That guarantees the client receives FULL snapshots first, with no deltas interleaved,
    # and avoids any 'syncing suppression' state that could wedge push.
    connected_players: List[Tuple[str, str, str]] = []
    try:
        # Always rebuild this map from the active LMS. A prior LMS target can leave
        # valid-looking but stale player/status caches behind.
        players = await lms.get_players()
        _playerid_to_name.clear()
        _name_to_playerid.clear()
        for p in players:
            if _safe_int(p.get("connected"), 0) != 1:
                continue
            pid0 = _safe_str(p.get("playerid")).strip().lower()
            pname0 = _safe_str(p.get("name")).strip()
            if not pid0 or not pname0:
                continue
            _playerid_to_name[pid0] = pname0
            _name_to_playerid[pname0] = pid0
            _name_to_playerid[pname0.lower()] = pid0
            connected_players.append((pname0.lower(), pid0, pname0))

        items = connected_players
        items.sort()

        for _k, pid, pname in items:
            snap: Dict[str, Any] = {}
            try:
                st = await lms.status(pid)
                if isinstance(st, dict) and st:
                    st.setdefault("sync_master", "")
                    st.setdefault("sync_slaves", "")
                    _normalize_art_fields(st)
                    _enrich_status_payload(st, pid)
                    _rewrite_status_art_for_broker(st, pid)
                    _normalize_player_display_fields(pid, st)
                    snap = st
                    _last_status_by_key[pid] = dict(st)
            except Exception as e:
                dbg(f"WS initial status failed playerid={pid}: {_safe_str(e)}")

            if isinstance(snap, dict) and snap:
                await send({
                    "t": "push",
                    "src": "cometd",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": pid,
                    "player_name": pname,
                    "full": True,
                    "complete": True,
                    "payload": _rti_status_payload(snap)
                })

            await asyncio.sleep(0.35)  # stagger to avoid CPU spikes

    except Exception as e:
        dbg(f"WS full-batch error: {_safe_str(e)}")

    # Now enable normal broadcast deltas for this client
    _ws_clients.add(ws)

    # Renew subscriptions after the snapshot. This repairs a stale subscription
    # set after changing LMS targets without introducing any periodic polling.
    if _cometd_client_id:
        for _k, pid, _pname in connected_players:
            try:
                await cometd_status_subscribe(pid)
            except Exception as e:
                dbg(f"WS connect CometD resubscribe failed for {pid}: {_safe_str(e)}")

    try:
        async for msg in ws:
            if not _license_status().get("valid"):
                await send({"t": "err", "ok": False, "error": "license_expired"})
                await ws.close(code=4003, message=b"license expired")
                break
            if msg.type != WSMsgType.TEXT:
                continue
            raw = msg.data.strip()
            if not raw:
                continue
            for line in raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    reqj = json.loads(line)
                except Exception:
                    await send({"t": "err", "ok": False, "error": "bad_json"})
                    continue

                t = _safe_str(reqj.get("t"))
                if t == "get_players":
                    players = await lms.get_players()
                    await send({"t": "players", "players": players, "default_player": pick_default_player(players)})

                elif t == "get_status":
                    pid = _safe_str(reqj.get("playerid")) or _safe_str(reqj.get("player"))
                    if not pid:
                        await send({"t": "err", "ok": False, "error": "missing_player"})
                        continue
                    st = await fresh_status_for_push(pid)
                    await send({"t": "status", "playerid": pid, "status": st})

                elif t == "cmd":
                    # Accept both the new schema (playerid/name) and legacy aliases (player/cmd/command).
                    pid = _safe_str(reqj.get("playerid") or reqj.get("playerId") or reqj.get("player_id") or reqj.get("player"))
                    name = _safe_str(reqj.get("name") or reqj.get("cmd") or reqj.get("command"))
                    args = reqj.get("args") or reqj.get("argv") or []
                    if isinstance(args, str):
                        args = [args]
                    if not isinstance(args, list):
                        args = []
                    # Optional human label for logs/UI (identity is always pid/MAC)
                    pname = _safe_str(reqj.get("player_name") or reqj.get("playerName"))
                    if not pname and pid:
                        pname = _playerid_to_name.get(pid.lower(), "")
                    dbg(f"WS CMD playerid={pid} player_name={pname} name={name} args={args}")
                    if not pid or not name:
                        await send({"t": "err", "ok": False, "error": "missing_player_or_name"})
                        continue
                    
                    if name == "queue_fetch":
                        try:
                            st = await full_queue_status_for_push(pid, 200)
                            await send({"t": "queue", "ok": True,
                                        "playerid": pid, "player_name": pname,
                                        "view": _safe_str(reqj.get("view") or reqj.get("deviceid") or ""),
                                        "payload": st})
                        except Exception as e:
                            await send({"t": "queue", "ok": False,
                                        "playerid": pid, "player_name": pname,
                                        "view": _safe_str(reqj.get("view") or reqj.get("deviceid") or ""),
                                        "error": _safe_str(e)})
                        continue

                    try:
                        res = await lms.cmd(pid, name, args)
                        cmd_result = res.get("result") or {}
                        await send({"t": "ack", "ok": True,
                                    "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args, "view": _safe_str(reqj.get("view") or reqj.get("deviceid") or "")},
                                    "result": cmd_result})

                        if name in ("sync", "unsync", "sync_toggle", "sync_all"):
                            schedule_sync_status_refresh()
                        if name in ("play", "pause", "stop", "next", "prev"):
                            schedule_transport_command_verify(pid, pname, name)

                        if name in ("repeat", "shuffle") and cmd_result:
                            mode_key = f"playlist {name}"
                            mode_val = cmd_result.get(mode_key, cmd_result.get(f"playlist_{name}", cmd_result.get(name)))
                            if mode_val is not None:
                                _last_status_by_key.setdefault(pid, {})[mode_key] = mode_val
                                _last_status_by_key[pid][f"playlist_{name}"] = mode_val
                                _last_status_by_key[pid][name] = mode_val
                                await send({
                                    "t": "push",
                                    "src": "broker",
                                    "channel": _cometd_response_channel or "/slim/_/response",
                                    "playerid": pid,
                                    "player_name": pname,
                                    "full": False,
                                    "complete": False,
                                    "payload": {mode_key: mode_val, f"playlist_{name}": mode_val, name: mode_val}
                                })

                        # Normal live updates come from CometD. This fallback is only for troubleshooting.
                        try:
                            await cometd_status_subscribe(pid)
                        except Exception as e:
                            dbg(f"WS CMD CometD resubscribe failed for {pid}: {_safe_str(e)}")

                        if FORCE_STATUS_AFTER_COMMAND or name in ("repeat", "shuffle"):
                            try:
                                await asyncio.sleep(0.35)
                                prev_status = dict(_last_status_by_key.get(pid) or {})
                                st2 = await fresh_status_for_push(pid)
                                if isinstance(st2, dict) and st2:
                                    payload = _diff(prev_status, st2) if prev_status else st2
                                    if not payload:
                                        continue
                                    await send({
                                        "t": "push",
                                        "src": "broker",
                                        "channel": _cometd_response_channel or "/slim/_/response",
                                        "playerid": pid,
                                        "player_name": pname,
                                        "full": not bool(prev_status),
                                        "complete": not bool(prev_status),
                                        "payload": payload
                                    })
                            except Exception:
                                pass
                    except Exception as e:
                        await send({"t": "err", "ok": False, "error": _safe_str(e),
                                    "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args}})

                elif t == "cometd_subscribe_status":
                    pid = _safe_str(reqj.get("playerid")) or _safe_str(reqj.get("player"))
                    if pid:
                        await cometd_status_subscribe(pid)
                        await send({"t": "ack", "ok": True, "req": {"t": t, "playerid": pid}})
                    else:
                        await send({"t": "err", "ok": False, "error": "missing_player"})

                elif t in ("favorites_list", "favorite_list"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        offset = _safe_int(reqj.get("offset"), 0)
                        limit = _safe_int(reqj.get("limit"), 100)
                        if limit <= 0:
                            limit = 100
                        top = await _top_menu_raw(pid)
                        raw_items = _extract_menu_items(top)
                        fav = _top_find_home_item(raw_items, "Favorites")
                        pl = None
                        if fav and isinstance((fav.get("actions") or {}).get("go"), dict):
                            pl, _ack = await _action_result_payload(
                                pid,
                                {"kind": "go", "action": (fav.get("actions") or {}).get("go"), "label": "Favorites"},
                                "Favorites",
                                offset,
                                limit,
                                "Favorites"
                            )
                        if pl:
                            await send({"t": "favorites", "ok": True, **pl})
                        else:
                            await send({"t": "favorites", "ok": False, "error": "favorites_unavailable", "items": [], "total": 0})
                    except Exception as e:
                        await send({"t": "favorites", "ok": False, "error": f"favorites_exception:{type(e).__name__}", "items": [], "total": 0})
                    continue

                elif t in ("menu_home", "browse_home"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        top = await _top_menu_raw(pid)
                        pl = _home_payload_from_top(top)
                        _ws_nav[id(ws)] = [{"payload": pl}]
                        await send({"t": "menu", "ok": True, **pl})
                    except Exception as e:
                        await send({"t": "err", "ok": False, "error": f"menu_home_exception:{type(e).__name__}"})
                    continue

                elif t in ("menu_nav", "browse_nav"):
                    cmd = _safe_str(reqj.get("cmd") or reqj.get("nav") or "")
                    stack = _ws_nav.get(id(ws)) or []
                    if cmd == "back" and stack:
                        cur_pl = stack[-1].get("payload") or {}
                        if _safe_str(cur_pl.get("title")).strip().lower() == "station deleted":
                            for si in range(len(stack) - 2, -1, -1):
                                frame = stack[si]
                                frame_pl = frame.get("payload") or {}
                                if _safe_str(frame_pl.get("title")).strip().lower() != "your stations":
                                    continue
                                refresh_item = _safe_str(frame.get("item"))
                                refresh_pid = _safe_str(frame.get("pid") or reqj.get("playerid") or reqj.get("player"))
                                refreshed = None
                                if refresh_item.startswith("act:"):
                                    try:
                                        refresh_spec = _b64u_dec(refresh_item.split(":", 1)[1])
                                        refreshed, _ = await _action_result_payload(
                                            refresh_pid,
                                            refresh_spec,
                                            _safe_str(frame_pl.get("title") or "Your Stations"),
                                            0,
                                            _safe_int(frame.get("limit"), 60),
                                            _safe_str(frame_pl.get("source") or "Pandora")
                                        )
                                    except Exception as e:
                                        dbg("PANDORA DELETE BACK refresh failed: " + _safe_str(e))
                                if isinstance(refreshed, dict):
                                    nav = dict(refreshed.get("nav") or {})
                                    nav["can_back"] = si > 0
                                    nav["can_home"] = True
                                    refreshed["nav"] = nav
                                    stack = stack[:si] + [{"payload": refreshed, "item": refresh_item, "pid": refresh_pid, "offset": 0, "limit": _safe_int(frame.get("limit"), 60)}]
                                else:
                                    stack = stack[:si + 1]
                                _ws_nav[id(ws)] = stack
                                pl = dict(stack[-1].get("payload") or {})
                                nav = dict(pl.get("nav") or {})
                                nav["can_back"] = len(stack) > 1
                                nav["can_home"] = pl.get("node") != "home"
                                pl["nav"] = nav
                                await send({"t": "menu", "ok": True, **pl})
                                break
                            else:
                                if len(stack) > 1:
                                    stack.pop()
                                _ws_nav[id(ws)] = stack
                                if stack:
                                    pl = dict(stack[-1].get("payload") or {})
                                    nav = dict(pl.get("nav") or {})
                                    nav["can_back"] = len(stack) > 1
                                    nav["can_home"] = pl.get("node") != "home"
                                    pl["nav"] = nav
                                    await send({"t": "menu", "ok": True, **pl})
                                else:
                                    await send({"t": "err", "ok": False, "error": "nav_empty"})
                            continue
                    if cmd == "back" and len(stack) > 1:
                        stack.pop()
                        _ws_nav[id(ws)] = stack
                    if stack:
                        pl = dict(stack[-1].get("payload") or {})
                        nav = dict(pl.get("nav") or {})
                        nav["can_back"] = len(stack) > 1
                        nav["can_home"] = pl.get("node") != "home"
                        pl["nav"] = nav
                        await send({"t": "menu", "ok": True, **pl})
                    else:
                        await send({"t": "err", "ok": False, "error": "nav_empty"})
                    continue

                elif t in ("menu_list", "browse_list"):
                    stack = _ws_nav.get(id(ws)) or []
                    if stack:
                        pl = dict(stack[-1].get("payload") or {})
                        nav = dict(pl.get("nav") or {})
                        nav["can_back"] = len(stack) > 1
                        nav["can_home"] = pl.get("node") != "home"
                        pl["nav"] = nav
                        await send({"t": "menu", "ok": True, **pl})
                    else:
                        await send({"t": "err", "ok": False, "error": "menu_empty"})
                    continue

                elif t in ("menu_select", "browse_select"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        item = _safe_str(reqj.get("item_id") or reqj.get("id") or reqj.get("item")) or ""
                        offset = _safe_int(reqj.get("offset"), 0)
                        limit = _safe_int(reqj.get("limit"), 60)
                        search = _safe_str(reqj.get("search") or reqj.get("query") or reqj.get("term")).strip()
                        stack = _ws_nav.get(id(ws)) or []
                        if not item:
                            await send({"t": "err", "ok": False, "error": "missing_item"})
                            continue
                        top = await _top_menu_raw(pid)
                        raw_items = _extract_menu_items(top)
                        pl = None
                        ack = None

                        if item == "root:mymusic":
                            label = _configured_source_label("mymusic") or "My Music"
                            pl = _group_payload_from_top(top, "myMusic", label, label)
                        elif item == "root:radio":
                            label = _configured_source_label("radio") or "Radio"
                            pl = _group_payload_from_top(top, "radios", label, label)
                        elif item == "root:favorites":
                            fav = _top_find_home_item(raw_items, "Favorites")
                            if fav and isinstance((fav.get("actions") or {}).get("go"), dict):
                                label = _configured_source_label("favorites") or "Favorites"
                                pl, ack = await _action_result_payload(pid, {"kind": "go", "action": (fav.get("actions") or {}).get("go"), "label": label}, label, offset, limit, label)
                        elif item.startswith("rootapp:"):
                            row_key = item.split(":", 1)[1]
                            app = None
                            want = ""
                            display_label = ""
                            source_label = ""
                            for rowcfg in _home_menu_cache:
                                if _safe_str(rowcfg.get("key")) == row_key:
                                    want = _norm_key(rowcfg.get("source_label") or rowcfg.get("label") or row_key)
                                    display_label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or row_key)
                                    source_label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or row_key)
                                    break
                            for it in raw_items:
                                if _safe_int(it.get("isApp"), 0) != 1:
                                    continue
                                if _norm_key(_pick_label(it)) == want:
                                    app = it
                                    break
                            if app and isinstance((app.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(
                                    pid,
                                    {"kind": "go", "label": (display_label or _pick_label(app)), "force_title": True, "action": (app.get("actions") or {}).get("go")},
                                    display_label or _pick_label(app),
                                    offset,
                                    limit,
                                    source_label or _pick_label(app)
                                )
                        elif item.startswith("root:"):
                            root_key = item.split(":", 1)[1]
                            app = None
                            for it in raw_items:
                                if _safe_int(it.get("isApp"), 0) == 1 and _app_key_from_item(it) == root_key:
                                    app = it
                                    break
                            # support iHeart as direct custom path if ever called
                            if app is None and root_key == "iheart":
                                app = _top_find_item_by_alias(raw_items, ["iHeartRadio", "iHeart", "opmliheartradio"], "radios")
                            if app and isinstance((app.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(pid, {"kind": "go", "label": (display_label or _pick_label(app)), "action": (app.get("actions") or {}).get("go")}, _pick_label(app), offset, limit)
                        elif item.startswith("group:"):
                            grp = item.split(":", 1)[1]
                            title = _GROUP_TITLE.get(grp, _pick_label({"text": grp}))
                            pl = _group_payload_from_top(top, grp, title)
                        elif item.startswith("act:"):
                            spec = _b64u_dec(item.split(":", 1)[1])
                            parent_pl = (stack[-1].get("payload") or {}) if stack else {}
                            parent_title_hint = _safe_str(spec.get("label") or parent_pl.get("title") or "Library")
                            parent_source_hint = _safe_str(parent_pl.get("source") or "")
                            if _safe_str(spec.get("kind")).lower() == "pandora_station":
                                _remember_pandora_station(pid, spec.get("label"))
                            if (
                                _norm_key(spec.get("label")) == "playthisstation"
                                and (
                                    _is_pandora_station_actions(spec.get("actions"))
                                    or _is_pyrrha_station_actions(spec.get("actions"))
                                )
                            ):
                                for station_candidate in (
                                    spec.get("context_name"),
                                    parent_pl.get("context_name"),
                                    parent_pl.get("title"),
                                ):
                                    station_name = _remember_pandora_station(pid, station_candidate)
                                    if station_name:
                                        break
                            if not parent_source_hint and _safe_str(parent_pl.get("title")) in ("My Music", "Pandora", "Spotty", "Radio", "Favorites"):
                                parent_source_hint = _safe_str(parent_pl.get("title"))
                            pl, ack = await _action_result_payload(pid, spec, parent_title_hint, offset, limit, parent_source_hint, search)
                        elif item.startswith("cmd:"):
                            cmd_name = item.split(":", 1)[1].strip().lower()
                            picked = None
                            title_hint = "Library"
                            if cmd_name == "artists":
                                picked = _find_top_action_item(raw_items, mode="artists", node="myMusic")
                                title_hint = "Artists"
                            elif cmd_name == "albums":
                                picked = _find_top_action_item(raw_items, mode="albums", node="myMusic")
                                title_hint = "Albums"
                            elif cmd_name == "genres":
                                picked = _find_top_action_item(raw_items, mode="genres", node="myMusic")
                                title_hint = "Genres"
                            elif cmd_name == "playlists":
                                picked = _find_top_action_item(raw_items, mode="playlists", node="myMusic")
                                title_hint = "Playlists"
                            elif cmd_name == "years":
                                picked = _find_top_action_item(raw_items, mode="years", node="myMusic")
                                title_hint = "Years"
                            elif cmd_name == "search":
                                picked = _find_top_action_item(raw_items, mode="search", node="myMusic")
                                title_hint = "Search"
                            elif cmd_name == "favorites":
                                picked = _find_top_action_item(raw_items, menu="favorites") or _top_find_home_item(raw_items, "Favorites")
                                title_hint = "Favorites"
                            if picked and isinstance((picked.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(pid, {"kind": "go", "label": title_hint, "action": (picked.get("actions") or {}).get("go")}, title_hint, offset, limit, "My Music")
                            else:
                                await send({"t": "err", "ok": False, "error": f"unknown_cmd:{cmd_name}"})
                                continue
                        elif item.startswith("sptrack:"):
                            ack = {"t": "ack", "ok": True, "req": {"t": "menu_select", "item_id": item}, "result": {}}
                        elif item.startswith("noop:"):
                            ack = {"t": "ack", "ok": True, "req": {"t": "menu_select", "item_id": item}, "result": {}}
                        else:
                            await send({"t": "err", "ok": False, "error": "unknown_menu_item"})
                            continue

                        if pl is not None:
                            if item.startswith("act:"):
                                try:
                                    selected_spec = _b64u_dec(item.split(":", 1)[1])
                                    if _safe_str(selected_spec.get("kind")).lower() == "pandora_station":
                                        _remember_pandora_station(
                                            pid,
                                            pl.get("context_name") or pl.get("title") or selected_spec.get("label")
                                        )
                                except Exception:
                                    pass
                            replace_current_menu = bool(pl.pop("_replace_current_menu", False))
                            nav = dict(pl.get("nav") or {})
                            nav["can_back"] = len(stack) >= 1
                            nav["can_home"] = True
                            pl["nav"] = nav
                            # Paging requests (offset > 0) must not create new navigation history entries
                            # and must not replace the canonical current payload on the nav stack.
                            # Keep stack[-1] pointing at the logical location's first page so Back returns
                            # to the parent level instead of peeling paging chunks one at a time.
                            if replace_current_menu and stack:
                                stack[-1] = {"payload": pl, "item": item, "pid": pid, "offset": offset, "limit": limit}
                            elif offset <= 0:
                                stack.append({"payload": pl, "item": item, "pid": pid, "offset": offset, "limit": limit})
                            _ws_nav[id(ws)] = stack
                            await send({"t": "menu", "ok": True, **pl})
                        elif ack is not None:
                            await send(ack)
                            if FORCE_STATUS_AFTER_COMMAND:
                                try:
                                    st2 = await lms.status(pid)
                                    if isinstance(st2, dict) and st2:
                                        _normalize_art_fields(st2)
                                        _enrich_status_payload(st2, pid)
                                        _rewrite_status_art_for_broker(st2, pid)
                                        _normalize_player_display_fields(pid, st2)
                                        await send({
                                            "t": "push",
                                            "src": "broker",
                                            "channel": _cometd_response_channel or "/slim/_/response",
                                            "playerid": pid,
                                            "player_name": _playerid_to_name.get(pid.lower(), ""),
                                            "full": False,
                                            "complete": False,
                                            "payload": st2
                                        })
                                except Exception:
                                    pass
                        else:
                            await send({"t": "err", "ok": False, "error": "menu_select_empty"})
                        continue

                    except Exception as e:
                        tb_lines = traceback.format_exc().strip().splitlines()
                        frame = ""
                        for line in reversed(tb_lines):
                            if "lyrion_broker.py" in line:
                                frame = line.strip()
                                break
                        tb = frame or (tb_lines[-1] if tb_lines else "")
                        dbg(f"menu_select exception {type(e).__name__}: {_safe_str(e)} trace={tb}")
                        await send({"t": "err", "ok": False, "error": f"menu_select_exception:{type(e).__name__}:{_safe_str(e)}:{tb}"})
                        continue

                elif t in ("menu_action", "browse_action"):

                    # Perform an action on a broker browse item (play/add) without changing transport behavior.
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        item = _safe_str(reqj.get("item_id") or reqj.get("id") or reqj.get("item")) or ""
                        action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                        replace_and_play = False
                        play_now_keep_queue = False
                        add_favorite = False
                        remove_favorite = False
                        if action in ("play", "now", "replay"):
                            # User model: Play should start now but preserve the rest of the queue.
                            # Do that as ADD + move appended rows after current, not LOAD/INSERT.
                            pcmd = "cmd:add"
                            play_now_keep_queue = True
                        elif action in ("load", "replaceandplay", "replace_and_play", "replace-play", "replaceplay", "wipeandplay", "wipe_and_play", "replace", "clearandplay", "clear_and_play"):
                            pcmd = "cmd:load"
                            replace_and_play = True
                        elif action in ("add", "enqueue", "queue"):
                            pcmd = "cmd:add"
                        elif action in ("playnext", "next", "insert"):
                            pcmd = "cmd:insert"
                        elif action == "favorites_add":
                            pcmd = ""
                            add_favorite = True
                        elif action == "favorites_remove":
                            pcmd = ""
                            remove_favorite = True
                        else:
                            await send({"t": "err", "ok": False, "error": "bad_action"})
                            continue

                        if not pid or not item:
                            await send({"t": "err", "ok": False, "error": "missing_player_or_item"})
                            continue

                        # item_id formats emitted by broker: act:<payload>, sptrack:<id>, title:<id>, album:<id>, artist:<id>, playlist:<id>
                        kind = ""
                        val = ""
                        if ":" in item:
                            kind, val = item.split(":", 1)
                            kind = kind.strip().lower()
                            val = val.strip()
                        else:
                            kind = item.strip().lower()
                            val = ""

                        before_count = -1
                        before_index = -1
                        random_mix_was_active = _random_mix_active(
                            _last_status_by_key.get(pid) or _last_status_by_key.get(pid.lower()) or {}
                        ) or pid.lower() in _random_mix_queue_players
                        if play_now_keep_queue:
                            try:
                                before = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                before_payload = (before.get("result") or {}) if isinstance(before, dict) else {}
                                if isinstance(before_payload, dict) and before_payload:
                                    _normalize_art_fields(before_payload)
                                    _enrich_status_payload(before_payload, pid)
                                    _normalize_player_display_fields(pid, before_payload)
                                    _last_status_by_key[pid] = dict(before_payload)
                                before_count = _safe_int(before_payload.get("playlist_tracks"), -1)
                                before_index = _safe_int(before_payload.get("playlist_cur_index"), -1)
                                random_mix_was_active = random_mix_was_active or _random_mix_active(before_payload)
                            except Exception:
                                before_count = -1
                                before_index = -1

                            # If the queue is empty, let LMS do a normal album load.  The add/move
                            # preserve path is only needed when there is an existing queue to keep.
                            if before_count <= 0:
                                _random_mix_queue_players.discard(pid.lower())
                                pcmd = "cmd:load"
                                play_now_keep_queue = False

                        args = None
                        if kind == "act" and val:
                            spec = _b64u_dec(val)
                            acts = spec.get("actions") or {}
                            random_genre_actions = [
                                candidate for candidate in (acts.get("on"), acts.get("off"))
                                if isinstance(candidate, dict)
                                and isinstance(candidate.get("cmd"), list)
                                and candidate.get("cmd")
                                and _safe_str(candidate.get("cmd")[0]).strip().lower() == "randomplaychoosegenre"
                            ]
                            station_play = acts.get("play") if isinstance(acts.get("play"), dict) else {}
                            station_cmd = station_play.get("cmd") if isinstance(station_play.get("cmd"), list) else []
                            is_podcast_episode = (
                                action in ("play", "now", "replay")
                                and len(station_cmd) >= 3
                                and _safe_str(station_cmd[0]).strip().lower() in ("podcast", "podcasts")
                                and _safe_str(station_cmd[1]).strip().lower() == "playlist"
                                and _safe_str(station_cmd[2]).strip().lower() == "play"
                            )
                            if is_podcast_episode:
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                            station_head = (
                                _safe_str(station_cmd[0]).strip().lower()
                                if station_cmd else ""
                            )
                            nav_stack = _ws_nav.get(id(ws)) or []
                            in_radio_context = any(
                                _norm_key((frame.get("payload") or {}).get("source")) == "radio"
                                or _norm_key((frame.get("payload") or {}).get("context_source")) == "radio"
                                or _safe_str(frame.get("item")).strip().lower() == "root:radio"
                                for frame in nav_stack
                                if isinstance(frame, dict)
                            )
                            is_radio_context_station = (
                                action in ("play", "now", "replay")
                                and in_radio_context
                                and len(station_cmd) >= 3
                                and _safe_str(station_cmd[1]).strip().lower() == "playlist"
                                and _safe_str(station_cmd[2]).strip().lower() == "play"
                                and station_head not in (
                                    "podcast", "podcasts", "spotty", "spotify",
                                    "iheartradio", "fr_iheartradio",
                                )
                                and "pandora" not in station_head
                                and "pyrrha" not in station_head
                            )
                            if is_radio_context_station:
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                                _np_source_by_playerid[pid] = "Radio"
                                station_name = _clean_text(spec.get("label")).splitlines()[0].strip()
                                if station_name:
                                    _np_station_by_playerid[pid] = station_name
                            if (
                                action in ("play", "now", "replay")
                                and (
                                    _safe_str(spec.get("kind")).lower() == "pandora_station"
                                    or _is_pandora_station_actions(acts)
                                    or _is_pyrrha_station_actions(acts)
                                )
                            ):
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                                remembered = _remember_pandora_station(pid, spec.get("label"))
                                if not remembered:
                                    for frame in reversed(_ws_nav.get(id(ws)) or []):
                                        payload = frame.get("payload") if isinstance(frame, dict) else {}
                                        if not isinstance(payload, dict):
                                            continue
                                        remembered = _remember_pandora_station(
                                            pid,
                                            payload.get("context_name") or payload.get("title")
                                        )
                                        if remembered:
                                            break
                            if add_favorite:
                                args = _spec_favorite_args(spec)
                                if args is None:
                                    await send({"t": "err", "ok": False, "error": "favorite_unsupported"})
                                    continue
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                if action in ("play", "now", "replay") and random_genre_actions:
                                    # Genre rows configure Random Mix. RTI Play Now on
                                    # one starts a Song Mix using the enabled genres.
                                    args = ["randomplay", "tracks"]
                                    play_now_keep_queue = False
                                else:
                                    args = _menu_action_track_override_args(acts, pcmd)
                                pick = None
                                if args is None:
                                    if pcmd == "cmd:load" and isinstance(acts.get("play"), dict):
                                        pick = acts.get("play")
                                    elif pcmd == "cmd:add" and isinstance(acts.get("add"), dict):
                                        pick = acts.get("add")
                                    elif pcmd == "cmd:add" and isinstance(acts.get("add-hold"), dict):
                                        pick = acts.get("add-hold")
                                    elif pcmd == "cmd:insert" and isinstance(acts.get("add-hold"), dict):
                                        pick = acts.get("add-hold")
                                    elif isinstance(acts.get("go"), dict):
                                        pick = acts.get("go")
                                    elif isinstance(acts.get("do"), dict):
                                        pick = acts.get("do")
                                    elif isinstance(spec.get("action"), dict):
                                        pick = spec.get("action")
                                    if not isinstance(pick, dict):
                                        await send({"t": "err", "ok": False, "error": "unsupported_item"})
                                        continue
                                    args = _action_to_rpc_args(pick, 0, 60)
                                if is_podcast_episode:
                                    fresh_args = await _fresh_podcast_play_args(
                                        pid, _ws_nav.get(id(ws)) or [], _safe_str(spec.get("label"))
                                    )
                                    if fresh_args:
                                        args = fresh_args
                        elif kind == "sptrack" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:spotify://track:{val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif pcmd == "cmd:load":
                                args = ["spotty", "playlist", "play", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                            elif pcmd == "cmd:add":
                                req_action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                                if req_action in ("playnext", "next", "insert"):
                                    args = ["spotty", "playlist", "insert", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                                else:
                                    args = ["spotty", "playlist", "add", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                        elif kind == "title" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:track.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"track_id:{val}"]
                        elif kind == "album" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:album.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"album_id:{val}"]
                        elif kind == "playlist" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:playlist.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"playlist_id:{val}"]
                        elif kind == "artist" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:contributor.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"artist_id:{val}"]
                        else:
                            await send({"t": "err", "ok": False, "error": "unsupported_item"})
                            continue

                        if play_now_keep_queue:
                            active_provider = _current_player_provider(pid, before_payload if isinstance(before_payload, dict) else None)
                            target_provider = _provider_from_action_args(args)
                            leaving_random_mix = (
                                random_mix_was_active
                                and target_provider in ("mymusic", "spotify")
                            )
                            if leaving_random_mix or (
                                target_provider and target_provider != active_provider and (
                                    active_provider in ("pandora", "radio") or target_provider == "pandora"
                                )
                            ):
                                dbg(f"PLAY NOW source switch: active={active_provider} target={target_provider}; using load/clear")
                                play_now_keep_queue = False
                                replace_and_play = True
                                if target_provider == "spotify" and kind == "sptrack" and val:
                                    args = ["spotty", "playlist", "play", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                                elif target_provider == "spotify" and kind == "act" and isinstance(acts.get("play"), dict):
                                    args = _action_to_rpc_args(acts.get("play"), 0, 60)
                                elif target_provider == "mymusic" and kind in ("title", "album", "playlist", "artist") and val:
                                    id_key = "track_id" if kind == "title" else f"{kind}_id"
                                    args = ["playlistcontrol", "cmd:load", f"{id_key}:{val}"]
                                elif leaving_random_mix and target_provider == "mymusic" and kind == "act" and isinstance(acts.get("play"), dict):
                                    args = _action_to_rpc_args(acts.get("play"), 0, 60)
                                elif isinstance(args, list) and args and _safe_str(args[0]).strip().lower() == "playlistcontrol":
                                    args = ["playlistcontrol"] + [("cmd:load" if _safe_str(x).strip().lower().startswith("cmd:") else x) for x in args[1:]]

                        if play_now_keep_queue:
                            if before_count < 0 or before_index < 0:
                                try:
                                    before = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                    before_payload = (before.get("result") or {}) if isinstance(before, dict) else {}
                                    before_count = _safe_int(before_payload.get("playlist_tracks"), -1)
                                    before_index = _safe_int(before_payload.get("playlist_cur_index"), -1)
                                except Exception:
                                    before_count = -1
                                    before_index = -1

                        if replace_and_play:
                            if random_mix_was_active:
                                try:
                                    await lms.rpc(pid, ["randomplay", "disable"])
                                    await asyncio.sleep(0.15)
                                except Exception:
                                    pass
                            try:
                                await lms.rpc(pid, ["playlist", "clear"])
                            except Exception:
                                pass
                        res = await lms.rpc(pid, args)
                        res = await _verify_random_mix_start(pid, args, res)
                        if (
                            isinstance(args, list)
                            and len(args) >= 3
                            and _safe_str(args[0]).strip().lower() in ("podcast", "podcasts")
                            and _safe_str(args[1]).strip().lower() == "playlist"
                            and _safe_str(args[2]).strip().lower() == "play"
                        ):
                            _schedule_podcast_selection_refresh(
                                pid, _safe_str(spec.get("label")) if kind == "act" else ""
                            )
                        if (
                            isinstance(args, list)
                            and len(args) >= 2
                            and _safe_str(args[0]).strip().lower() == "randomplay"
                        ):
                            randomplay_mode = _safe_str(args[1]).strip().lower()
                            if randomplay_mode == "disable":
                                await lms.rpc(pid, ["stop"])
                            else:
                                _random_mix_queue_players.add(pid.lower())
                        if replace_and_play:
                            _random_mix_queue_players.discard(pid.lower())
                        is_podcast_play = (
                            isinstance(args, list)
                            and len(args) >= 3
                            and _safe_str(args[0]).strip().lower() == "podcast"
                            and _safe_str(args[1]).strip().lower() == "playlist"
                            and _safe_str(args[2]).strip().lower() == "play"
                        )
                        if is_podcast_play:
                            await lms.rpc(pid, ["play"])

                        # "Play" should preserve queue but start the inserted selection immediately.
                        # Append first, then move newly appended rows directly after the current item.
                        if play_now_keep_queue:
                            try:
                                after = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                after_payload = (after.get("result") or {}) if isinstance(after, dict) else {}
                                after_count = _safe_int(after_payload.get("playlist_tracks"), -1)
                                insert_at = 0 if before_count <= 0 else before_index + 1
                                added = after_count - before_count
                                if before_count >= 0 and before_index >= 0 and added > 0:
                                    if insert_at < 0:
                                        insert_at = 0
                                    dbg(f"PLAY NOW preserve queue: before_count={before_count} before_index={before_index} added={added} insert_at={insert_at}")
                                    for n in range(added):
                                        await lms.rpc(pid, ["playlist", "move", str(before_count + n), str(insert_at + n)])
                                    await lms.rpc(pid, ["playlist", "index", str(insert_at)])
                                else:
                                    dbg(f"PLAY NOW preserve queue fallback: before_count={before_count} after_count={after_count} before_index={before_index}")
                                    await lms.rpc(pid, ["playlist", "index", "+1"])
                            except Exception as e:
                                dbg(f"PLAY NOW preserve queue failed: {type(e).__name__}: {_safe_str(e)}")

                        await send({"t": "ack", "ok": True, "req": {"t": t, "playerid": pid, "item_id": item, "action": action}, "result": (res.get("result") if isinstance(res, dict) else res) or {}})
                        if FORCE_STATUS_AFTER_COMMAND:
                            try:
                                st2 = await lms.status(pid)
                                if isinstance(st2, dict) and st2:
                                    _normalize_art_fields(st2)
                                    _enrich_status_payload(st2, pid)
                                    _rewrite_status_art_for_broker(st2, pid)
                                    await send({
                                        "t": "push",
                                        "src": "broker",
                                        "channel": _cometd_response_channel or "/slim/_/response",
                                        "playerid": pid,
                                        "player_name": _playerid_to_name.get(pid.lower(), ""),
                                        "full": False,
                                        "complete": False,
                                        "payload": st2
                                    })
                            except Exception:
                                pass
                    except Exception as e:
                        tb = traceback.format_exc().strip().splitlines()[-1]
                        dbg(f"menu_action exception {type(e).__name__}: {_safe_str(e)} trace={tb}")
                        await send({"t": "err", "ok": False, "error": f"menu_action_exception:{type(e).__name__}:{_safe_str(e)}"})
                        continue
                elif t in ("menu_nav", "browse_nav"):
                    cmdn = _safe_str(reqj.get("cmd") or reqj.get("nav") or "")
                    stack = _ws_nav.get(id(ws)) or [{"kind": "home", "title": "Home"}]
                    if cmdn == "home":
                        _ws_nav[id(ws)] = [{"kind": "home", "title": "Home"}]
                        pl = _home_list_payload()
                        await send({"t": "menu", "ok": True, **pl})
                    elif cmdn == "back":
                        if len(stack) > 1:
                            stack.pop()
                        _ws_nav[id(ws)] = stack
                        cur = stack[-1] if stack else {"kind": "home", "title": "Home"}
                        if _safe_str(cur.get("kind")) == "home":
                            pl = _home_list_payload()
                            await send({"t": "menu", "ok": True, **pl})
                        elif _safe_str(cur.get("kind")) == "mymusic":
                            await send({
                                "t": "menu", "ok": True,
                                "node": "root:mymusic",
                                "title": "My Music",
                                "offset": 0,
                                "limit": 4,
                                "total": 4,
                                "items": [
                                    {"id": "cmd:artists", "label": "Artists", "type": "node"},
                                    {"id": "cmd:albums", "label": "Albums", "type": "node"},
                                    {"id": "cmd:genres", "label": "Genres", "type": "node"},
                                    {"id": "cmd:playlists", "label": "Playlists", "type": "node"},
                                ],
                                "nav": {"can_back": len(stack) > 1, "can_home": True},
                            })
                        else:
                            # Client can call menu_list to refresh current node
                            await send({"t": "ack", "ok": True, "req": {"t": t, "cmd": cmdn}})
                    else:
                        await send({"t": "err", "ok": False, "error": "bad_nav_cmd"})


                else:
                    await send({"t": "ack", "ok": True, "req": {"t": t}})

    finally:
        mark_disconnected()
        dbg(f"WS client disconnected from {peer}")
    return ws


async def on_startup(app: web.Application) -> None:
    dbg(f"Starting Lyrion Broker v{APP_VERSION}")
    _load_setup_config()
    previous_update = _read_update_status()
    if (
        _safe_str(previous_update.get("state")) == "installing"
        and _safe_str(previous_update.get("target_version")) == APP_VERSION
    ):
        _write_update_status(
            "complete",
            f"Broker {APP_VERSION} installed successfully",
            target_version=APP_VERSION,
            backup_path=_safe_str(previous_update.get("backup_path")),
        )
    _ensure_license_trial_started()
    dac8x_repaired = False
    try:
        dac8x_outputs = [
            _safe_str(row.get("output"))
            for row in _pcp_player_sessions()
            if _safe_str(row.get("output")).startswith("dac8x_")
        ]
        if dac8x_outputs and _ensure_dac8x_asound_config(dac8x_outputs):
            dac8x_repaired = True
            dbg("DAC8x ALSA config repaired on startup")
    except Exception as e:
        dbg("DAC8x ALSA startup repair skipped: {}".format(_safe_str(e)))
    threading.Thread(target=_discovery_udp_thread, daemon=True).start()
    dbg(f"Listen {LISTEN_HOST}:{LISTEN_PORT}")
    dbg(f"LMS {LMS_BASE}")
    dbg(f"Periodic rescan every {RESCAN_SECS}s (0 disables periodic)")
    await lms.start()
    await _refresh_server_meta()
    if dac8x_repaired:
        try:
            await asyncio.to_thread(_restart_all_local_players)
            dbg("DAC8x players restarted after ALSA repair")
        except Exception as e:
            dbg("DAC8x player restart after ALSA repair failed: {}".format(_safe_str(e)))
    app["cometd_task"] = asyncio.create_task(cometd_loop(app))
    app["friendly_name_task"] = asyncio.create_task(_restore_friendly_player_names())
    app["mixer_normalize_task"] = asyncio.create_task(_normalize_mixer_levels_after_startup())


async def on_cleanup(app: web.Application) -> None:
    mixer_task = app.get("mixer_normalize_task")
    if mixer_task:
        mixer_task.cancel()
        try:
            await mixer_task
        except Exception:
            pass
    friendly_task = app.get("friendly_name_task")
    if friendly_task:
        friendly_task.cancel()
        try:
            await friendly_task
        except Exception:
            pass
    task = app.get("cometd_task")
    if task:
        task.cancel()
        try:
            await task
        except Exception:
            pass
    await lms.close()
    global _cometd_session
    if _cometd_session and not _cometd_session.closed:
        await _cometd_session.close()


def build_app() -> web.Application:
    app = web.Application()
    app.add_routes([
        web.get("/", root_page),
        web.get("/health", health),
        web.get("/api/players", api_players),
        web.get("/api/system/players-status", api_system_players_status),
        web.get("/api/pandora/v1", api_pandora_v1),
        web.get("/api/pandora/repository.xml", api_pandora_repository),
        web.get("/api/pandora/plugins/Pandora-{letter}.zip", api_pandora_plugin_zip),
        web.get("/rti", ws_rti),
        web.get("/art/main", art_main),
        web.get("/art/list", art_list),

        # Setup UI (does not affect RTI WS protocol)
        web.get("/setup", setup_page),
        web.get("/setup/players", setup_players_page),
        web.get("/setup/system", setup_system_page),
        web.get("/setup/lms-plugin-settings", setup_lms_plugin_settings_page),
        web.get("/setup/pandora-account", setup_pandora_account_page),
        web.get("/setup/assets/{filename}", setup_asset),
        web.get("/setup/advanced", setup_advanced_page),
        web.get("/setup/advanced/login", setup_advanced_login_page),
        web.post("/setup/advanced/login", setup_advanced_login_post),
        web.get("/setup/advanced/logout", setup_advanced_logout),
        web.get("/api/setup", api_setup_get),
        web.post("/api/setup", api_setup_post),
        web.post("/api/setup/mode", api_setup_mode),
        web.get("/api/setup/lms-discovery", api_setup_lms_discovery),
        web.post("/api/setup/advanced", api_setup_advanced_post),
        web.post("/api/setup/system-identity", api_setup_system_identity),
        web.post("/api/setup/players/apply", api_setup_players_apply),
        web.post("/api/setup/players/fixed-volume", api_setup_players_fixed_volume),
        web.post("/api/setup/players/action", api_setup_players_action),
        web.post("/api/setup/players/test-output", api_setup_players_test_output),
        web.post("/api/system/action", api_system_action),
        web.post("/api/system/plugin", api_system_plugin),
        web.post("/api/pandora/account", api_pandora_account),
        web.get("/api/system/backup", api_system_backup),
        web.post("/api/system/restore", api_system_restore),
        web.get("/api/update/check", api_update_check),
        web.get("/api/update/status", api_update_status),
        web.post("/api/update/install", api_update_install),
        web.get("/api/lms_root", api_lms_root),
        web.get("/api/mymusic_menu", api_mymusic_menu),
        web.get("/api/radio_menu", api_radio_menu),
    ])
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app


def _get_listen_ip_for_peer(peer_ip: str) -> str:
    try:
        t = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        t.connect((peer_ip, 9))
        ip = t.getsockname()[0]
        t.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _discovery_udp_thread(listen_host: str = "0.0.0.0") -> None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((listen_host, DISCOVERY_UDP_PORT))
        dbg(f"UDP discovery listening {listen_host}:{DISCOVERY_UDP_PORT}")
    except Exception as e:
        dbg(f"UDP discovery disabled (bind failed): {e}")
        return

    while True:
        try:
            data, addr = s.recvfrom(1024)
        except Exception:
            continue
        try:
            if data != DISCOVERY_MAGIC:
                continue
            if _broker_light_mode():
                continue
            msg = json.dumps({
                "t": "broker_announce",
                "ip": _get_listen_ip_for_peer(addr[0]),
                "port": LISTEN_PORT,
                "name": DISCOVERY_NAME or BROKER_ID or "Lyrion Gadget",
                "version": APP_VERSION,
            })
            s.sendto(msg.encode("utf-8"), addr)
        except Exception:
            continue


def main() -> None:
    web.run_app(build_app(), host=LISTEN_HOST, port=LISTEN_PORT)


if __name__ == "__main__":
    main()
