#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PCP_CONFIG="${PCP_CONFIG:-/usr/local/etc/pcp/pcp.cfg}"
TCE_DIR="${TCE_DIR:-$(readlink -f /etc/sysconfig/tcedir 2>/dev/null || true)}"
[ -n "$TCE_DIR" ] || TCE_DIR=/mnt/mmcblk0p2/tce
APP_DIR="${APP_DIR:-$TCE_DIR/lyrion-player}"
FILETOOL_LIST="${FILETOOL_LIST:-/opt/.filetool.lst}"
WEB_ROOT="${WEB_ROOT:-/var/www/index.html}"

if [ "${LYRION_ALLOW_UNSUPPORTED:-0}" != 1 ]; then
  machine="$(uname -m 2>/dev/null || true)"
  case "$machine" in
    armv6l|armv7l) ;;
    aarch64|arm64) echo "A 32-bit piCorePlayer userspace is required; found $machine." >&2; exit 1 ;;
    *) echo "A supported 32-bit ARM piCorePlayer userspace was not detected; found ${machine:-unknown}." >&2; exit 1 ;;
  esac
  model="$(tr -d '\000' </proc/device-tree/model 2>/dev/null || true)"
  case "$model" in *Raspberry\ Pi*) ;; *) echo "Raspberry Pi hardware was not detected." >&2; exit 1 ;; esac
fi
[ -f "$PCP_CONFIG" ] || { echo "piCorePlayer configuration not found: $PCP_CONFIG" >&2; exit 1; }
command -v pcp >/dev/null 2>&1 || { echo "This does not appear to be piCorePlayer (pcp missing)." >&2; exit 1; }
command -v squeezelite >/dev/null 2>&1 || { echo "Enable/install Squeezelite in piCorePlayer first." >&2; exit 1; }

mkdir -p "$APP_DIR"
cp "$SCRIPT_DIR/VERSION" "$APP_DIR/VERSION"
cp "$SCRIPT_DIR/lyrion-player" "$APP_DIR/lyrion-player"
chmod 755 "$APP_DIR/lyrion-player"
cp "$APP_DIR/lyrion-player" /usr/local/bin/lyrion-player
chmod 755 /usr/local/bin/lyrion-player
cp "$SCRIPT_DIR/lyrion-player-discovery" "$APP_DIR/lyrion-player-discovery"
chmod 755 "$APP_DIR/lyrion-player-discovery"
cp "$APP_DIR/lyrion-player-discovery" /usr/local/bin/lyrion-player-discovery
chmod 755 /usr/local/bin/lyrion-player-discovery
cp "$SCRIPT_DIR/lyrion-player.cgi" /var/www/cgi-bin/lyrion-player.cgi
chmod 755 /var/www/cgi-bin/lyrion-player.cgi
mkdir -p /var/www/lyrion-player-assets
cp "$SCRIPT_DIR"/web/*.png "$SCRIPT_DIR"/web/*.css /var/www/lyrion-player-assets/
if [ ! -f "$APP_DIR/players.conf" ]; then cp "$SCRIPT_DIR/players.conf.example" "$APP_DIR/players.conf"; fi
chmod 600 "$APP_DIR/players.conf"
if [ ! -f "$APP_DIR/web.conf" ]; then printf '%s\n' 'WEB_PASSWORD=LyrionGadget' > "$APP_DIR/web.conf"; fi
chmod 600 "$APP_DIR/web.conf"

if [ ! -e "$APP_DIR/index.html.original-link" ] && [ -L "$WEB_ROOT" ]; then
  readlink "$WEB_ROOT" > "$APP_DIR/index.html.original-link"
fi
rm -f "$WEB_ROOT"
cat > "$WEB_ROOT" <<'EOF'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="cache-control" content="no-store, no-cache, must-revalidate, max-age=0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="1;url=/cgi-bin/lyrion-player.cgi">
  <title>Lyrion Player</title>
  <script>
    var host = window.location.hostname || window.location.host.split(':')[0];
    window.location.replace(window.location.protocol + '//' + host + ':9099/cgi-bin/lyrion-player.cgi');
  </script>
</head>
<body style="font-family:Arial,sans-serif;margin:32px;line-height:1.45">
  <h1>Lyrion Player</h1>
  <p>Opening Lyrion Player setup...</p>
  <p><a href="#" onclick="this.href=location.protocol+'//'+location.hostname+':9099/cgi-bin/lyrion-player.cgi'">Open player setup</a></p>
</body>
</html>
EOF

for entry in opt/.filetool.lst usr/local/bin/lyrion-player usr/local/bin/lyrion-player-discovery var/www/index.html var/www/cgi-bin/lyrion-player.cgi var/www/lyrion-player-assets; do
  grep -qxF "$entry" "$FILETOOL_LIST" 2>/dev/null || echo "$entry" >> "$FILETOOL_LIST"
done

echo "Installed player-only appliance files in $APP_DIR"
"/usr/local/bin/lyrion-player" web-start
echo "Web root redirects to port 9099 Lyrion Player setup"
echo "Edit $APP_DIR/players.conf, then run: sudo lyrion-player apply"
command -v filetool.sh >/dev/null 2>&1 && filetool.sh -b >/dev/null || true
