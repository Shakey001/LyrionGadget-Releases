# Lyrion Gadget Player for piCorePlayer (32-bit)

A player-only Lyrion appliance for Raspberry Pi Zero W and older Raspberry Pis. It keeps the stock piCorePlayer web interface and native primary Squeezelite service, and can launch three additional Squeezelite processes (four players total).

This project is deliberately self-contained. It does not install Lyrion Music Server, Python, the Lyrion broker, an RTI server, or any DietPi components.

## Target

- 32-bit piCorePlayer on ARMv6/ARMv7
- Raspberry Pi Zero W, Zero, Pi 1, Pi 2, Pi 3, and older 32-bit-capable models
- One to four Squeezelite instances
- A remote LMS on the LAN

Start from an official **32-bit piCorePlayer image** appropriate for the board. Boot it, configure Wi-Fi through piCorePlayer, enable Squeezelite, and select the primary audio output in the normal pCP UI before installing this package.

## Install

Copy this directory to the pCP host, then run:

```sh
chmod +x install-picoreplayer-player.sh
sudo ./install-picoreplayer-player.sh
```

The installer refuses a 64-bit userspace and non-Raspberry-Pi hardware. Override only for offline/test roots with `LYRION_ALLOW_UNSUPPORTED=1`.

Configuration is persisted at `tce/lyrion-player/players.conf`. Edit it, then apply:

```sh
sudo /usr/local/bin/lyrion-player apply
sudo /usr/local/bin/lyrion-player status
sudo filetool.sh -b
```

Example configuration:

```sh
PLAYER_COUNT=4
LMS_SERVER=192.168.1.10
PLAYER1_NAME=Lyrion-Zero-Main
PLAYER1_OUTPUT=hw:CARD=Headphones,DEV=0
PLAYER1_MAC=02:00:00:00:00:a0
PLAYER1_AUDIO_PARAMS=80:4::1:
PLAYER2_NAME=Lyrion-Zero-USB1
PLAYER2_OUTPUT=hw:CARD=Device,DEV=0
PLAYER2_MAC=02:00:00:00:00:a1
PLAYER2_AUDIO_PARAMS=80:4::1:
PLAYER3_NAME=Lyrion-Zero-USB2
PLAYER3_OUTPUT=hw:CARD=Device_1,DEV=0
PLAYER3_MAC=02:00:00:00:00:a2
PLAYER3_AUDIO_PARAMS=80:4::1:
PLAYER4_NAME=Lyrion-Zero-USB3
PLAYER4_OUTPUT=hw:CARD=Device_2,DEV=0
PLAYER4_MAC=02:00:00:00:00:a3
PLAYER4_AUDIO_PARAMS=80:4::1:
```

Use `aplay -l` or the pCP Squeezelite output selector to identify ALSA device names. Player MAC addresses are managed as one shared five-octet prefix with fixed endings `a0`, `a1`, `a2`, and `a3`; this keeps player identities stable and consistent with full Lyrion Gadget units. Each enabled instance normally needs a distinct hardware output. Configuration values must use simple unquoted tokens (no whitespace or shell metacharacters); the manager validates every value before use.

## Commands

```text
lyrion-player apply       validate, update pCP, restart all configured players
lyrion-player start       start missing configured instances
lyrion-player stop        stop all configured instances
lyrion-player restart     stop and start all configured instances
lyrion-player status      show configured/running instances
lyrion-player validate    validate without changing the system
```

The primary instance is written to `/usr/local/etc/pcp/pcp.cfg` and restarted through `pcp slr`. One pCP `USER_COMMAND` slot invokes a persistent launcher for all additional instances, so four total players consume only one slot. Configuration changes are backed up before apply and persisted with Tiny Core's `filetool.sh`.

This 32-bit project is intended for legacy boards that cannot run the current 64-bit Lyrion Gadget broker stack. New 64-bit units should use the main Lyrion Gadget broker in lite mode instead.

Visiting the unit's web root opens the dedicated Lyrion Player setup page at `/cgi-bin/lyrion-player.cgi`. It displays live instance status and configures/applies all four players without a separate web service or Python runtime. The CGI page and replacement `/var/www/index.html` are included in the pCP backup list, and the original read-only symlink target is recorded in the appliance directory.

The same page is served directly on port `9099`, matching the full Lyrion Gadget convention. Port 80 redirects to `http://<unit>:9099/cgi-bin/lyrion-player.cgi`; the existing pCP pages remain available through their direct CGI paths.

The setup flow matches Lyrion Gadget: the branded installer login appears first, followed by the authenticated Player Setup page. The initial web password is `LyrionGadget` and can be changed in the persistent `tce/lyrion-player/web.conf` file.

The setup page reuses the Lyrion Gadget/NanoPi brand header, partner marks, light card layout, purple action styling, status presentation, and responsive behavior so legacy pCP units remain visually consistent with current Gadget appliances.

The appliance also runs a lightweight BusyBox UDP commissioning responder on port `9099`. It answers `LYRION_GADGET_COMMISSION_v1` with the same `gadget_announce` / `player_only` payload used by the DietPi NanoPi player, so Lyrion Gadget Finder can locate it without mistaking it for a broker or RTI server.

The Player Setup page shows only the enabled provisioning rows. Its **Find Lyrion Gadgets** action probes the configured server and active LAN neighbors in parallel for full broker health endpoints on port 9099, then presents all matches in a selectable list. Discovery messages dismiss automatically and the selector collapses after a server is chosen.

Playback Device fields are select lists generated from live `aplay -l` card/device pairs. A previously saved device remains selectable and is marked as saved when temporarily disconnected.

Detected ALSA inventory is presented as the same structured Card/ID/Name/Physical Path/Detail table used by the full Gadget; raw `aplay` diagnostic output is never shown in the normal setup flow.

Device hostname defaults to `Lyrion` plus the final four primary-MAC digits and can be edited in Player Setup. Hostname changes are persisted to pCP and show a reboot-required notice until the next boot. Each player has a Fixed Volume option synchronized to LMS; the page also provides Normalize Output Levels and Apply Volume Settings controls.

## Build a release archive

From PowerShell on the development machine:

```powershell
.\build-release.ps1
```

The resulting `.tgz` is created only inside this project's `dist` directory.
