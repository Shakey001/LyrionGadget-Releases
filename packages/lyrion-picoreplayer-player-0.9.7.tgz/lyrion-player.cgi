#!/bin/sh
set -u

APP_DIR="${APP_DIR:-/mnt/mmcblk0p2/tce/lyrion-player}"
CONFIG_FILE="$APP_DIR/players.conf"
MANAGER=/usr/local/bin/lyrion-player
MESSAGE=""
MESSAGE_CLASS="info"
WEB_CONFIG="$APP_DIR/web.conf"
[ -f "$WEB_CONFIG" ] || printf '%s\n' 'WEB_PASSWORD=LyrionGadget' > "$WEB_CONFIG"
# shellcheck disable=SC1090
. "$WEB_CONFIG"
AUTH_TOKEN="$(printf 'lyrion-player:%s' "${WEB_PASSWORD:-LyrionGadget}" | sha256sum | awk '{print $1}')"
POST_BODY=""
[ "${REQUEST_METHOD:-GET}" = POST ] && POST_BODY="$(dd bs=1 count="${CONTENT_LENGTH:-0}" 2>/dev/null)"

html() { busybox httpd -e "$1"; }
cfg() { eval "printf '%s' \"\${$1-}\""; }
post_value() {
  encoded="$(printf '%s' "$POST_BODY" | tr '&' '\n' | sed -n "s/^$1=//p" | head -1)"
  busybox httpd -d "$encoded"
}

render_alsa_rows() {
  exec 3< /proc/asound/cards
  while IFS= read -r line <&3; do
    printf '%s' "$line" | grep -q '^ *[0-9][0-9]* \[' || continue
    IFS= read -r detail <&3 || detail=""
    card="$(printf '%s' "$line" | sed -n 's/^[[:space:]]*\([0-9][0-9]*\).*/\1/p')"
    id="$(printf '%s' "$line" | sed -n 's/.*\[\([^]]*\)\].*/\1/p' | tr -d ' ')"
    name="$(printf '%s' "$line" | sed 's/.* - //')"
    detail="$(printf '%s' "$detail" | sed 's/^[[:space:]]*//')"
    path="$(printf '%s' "$detail" | sed -n 's/.* at \([^,]*\).*/\1/p')"
    printf '<tr><td>%s</td><td><code>%s</code></td><td>%s</td><td><code>%s</code></td><td>%s</td></tr>\n' \
      "$(html "$card")" "$(html "$id")" "$(html "$name")" "$(html "$path")" "$(html "$detail")"
  done
  exec 3<&-
}

brand_header() {
  cat <<'EOF'
<header class="brand-header"><div class="brand-strip"><img src="/lyrion-player-assets/lyrion.png" alt="Lyrion"><img src="/lyrion-player-assets/avpro.png" alt="AVPro"><img src="/lyrion-player-assets/rti.png" alt="RTI"><img src="/lyrion-player-assets/skunkworks.png" alt="Skunk Works"></div><div class="brand-bar"><div class="brand-bar-inner"><div class="brand-title">Lyrion piCorePlayer</div><div style="display:flex;align-items:center;gap:12px"><span class="unit-pill online">Player Online</span><a href="?logout=1" style="color:#c7ced8;font-size:12px">Logout</a></div></div></div></header>
EOF
}

login_page() {
  error="$1"
  printf 'Content-Type: text/html\r\nCache-Control: no-store\r\n\r\n'
  cat <<'EOF'
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lyrion Player Setup Login</title><link rel="stylesheet" href="/lyrion-player-assets/app.css"></head><body>
EOF
  brand_header | sed 's|<a href="?logout=1"[^<]*</a>||'
  cat <<EOF
<main class="page-shell" style="max-width:560px"><h2>Lyrion Player Setup</h2><div style="font-size:13px;color:#596579;margin-bottom:14px">Enter the installer password to configure this unit.</div><form method="post"><input type="hidden" name="ACTION" value="login"><label class="field" for="password">Password<input id="password" name="PASSWORD" type="password" autofocus required></label><div style="color:#b42318;margin-top:8px">$(html "$error")</div><div style="margin-top:14px"><button type="submit">Open Setup</button></div></form><section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:16px"><h3 style="margin:0 0 10px">Quick Links</h3><a href="/cgi-bin/about.cgi"><button type="button">pCP Web UI</button></a></section></main></body></html>
EOF
  exit 0
}

case "${QUERY_STRING:-}" in *logout=1*)
  printf 'Status: 303 See Other\r\nLocation: /cgi-bin/lyrion-player.cgi\r\nSet-Cookie: LYRION_PLAYER_AUTH=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict\r\n\r\n'
  exit 0
;; esac

if ! printf '%s' "${HTTP_COOKIE:-}" | grep -q "LYRION_PLAYER_AUTH=$AUTH_TOKEN"; then
  if [ "${REQUEST_METHOD:-GET}" = POST ] && [ "$(post_value ACTION)" = login ]; then
    if [ "$(post_value PASSWORD)" = "${WEB_PASSWORD:-LyrionGadget}" ]; then
      printf 'Status: 303 See Other\r\nLocation: /cgi-bin/lyrion-player.cgi\r\nSet-Cookie: LYRION_PLAYER_AUTH=%s; Max-Age=28800; Path=/; HttpOnly; SameSite=Strict\r\n\r\n' "$AUTH_TOKEN"
      exit 0
    fi
    login_page "Incorrect password."
  fi
  login_page ""
fi

save_post() {
  length="${CONTENT_LENGTH:-0}"
  case "$length" in ''|*[!0-9]*) MESSAGE="Invalid request length."; MESSAGE_CLASS=error; return ;; esac
  [ "$length" -le 16384 ] || { MESSAGE="Request is too large."; MESSAGE_CLASS=error; return; }
  body="$POST_BODY"
  tmp="$APP_DIR/players.conf.web-new"
  old="$APP_DIR/players.conf.web-backup"
  : > "$tmp"
  printf '%s' "$body" | tr '&' '\n' | while IFS= read -r pair; do
    key="${pair%%=*}"
    value="${pair#*=}"
    value="$(busybox httpd -d "$value")"
    case "$key" in
      PLAYER_COUNT|LMS_SERVER|HOSTNAME|PLAYER[1-4]_NAME|PLAYER[1-4]_OUTPUT|PLAYER[1-4]_MAC|PLAYER[1-4]_AUDIO_PARAMS|PLAYER[1-4]_EXTRA|PLAYER[1-4]_FIXED_VOLUME)
        printf '%s=%s\n' "$key" "$value" >> "$tmp"
        ;;
    esac
  done
  if ! CONFIG_FILE="$tmp" "$MANAGER" validate >/tmp/lyrion-player-web.out 2>&1; then
    MESSAGE="$(cat /tmp/lyrion-player-web.out)"
    MESSAGE_CLASS=error
    rm -f "$tmp"
    return
  fi
  cp "$CONFIG_FILE" "$old"
  cp "$tmp" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
  rm -f "$tmp"
  if "$MANAGER" apply >/tmp/lyrion-player-web.out 2>&1; then
    MESSAGE="$(cat /tmp/lyrion-player-web.out)"
    MESSAGE_CLASS=success
  else
    MESSAGE="Apply failed: $(cat /tmp/lyrion-player-web.out). The previous form configuration was restored."
    MESSAGE_CLASS=error
    cp "$old" "$CONFIG_FILE"
  fi
}

save_volume_post() {
  cp "$CONFIG_FILE" "$APP_DIR/players.conf.volume-backup"
  i=1
  while [ "$i" -le 4 ]; do
    value="$(printf '%s' "$POST_BODY" | tr '&' '\n' | sed -n "s/^PLAYER${i}_FIXED_VOLUME=//p" | tail -1)"
    value="$(busybox httpd -d "$value")"
    [ "$value" = 1 ] || value=0
    sed -i "s/^PLAYER${i}_FIXED_VOLUME=.*/PLAYER${i}_FIXED_VOLUME=${value}/" "$CONFIG_FILE"
    i=$((i + 1))
  done
  if "$MANAGER" volume-sync >/tmp/lyrion-player-web.out 2>&1; then
    command -v filetool.sh >/dev/null 2>&1 && filetool.sh -b >/dev/null 2>&1 || true
    MESSAGE="Volume settings applied."
    MESSAGE_CLASS=success
  else
    cp "$APP_DIR/players.conf.volume-backup" "$CONFIG_FILE"
    MESSAGE="Volume apply failed: $(cat /tmp/lyrion-player-web.out)"
    MESSAGE_CLASS=error
  fi
}

save_hostname_post() {
  value="$(post_value HOSTNAME)"
  if ! printf '%s' "$value" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9-]{0,62}$'; then
    MESSAGE="Hostname must use 1–63 letters, numbers, or hyphens."
    MESSAGE_CLASS=error
    return
  fi
  cp "$CONFIG_FILE" "$APP_DIR/players.conf.hostname-backup"
  sed -i "s/^HOSTNAME=.*/HOSTNAME=${value}/" "$CONFIG_FILE"
  if (
    . pcp-functions
    HOST="$value"
    pcp_mount_bootpart text
    pcp_write_to_host
    pcp_umount_bootpart text
    pcp_save_to_config
    pcp_backup
    pcp_reboot_required
  ) >/tmp/lyrion-player-hostname.out 2>&1; then
    MESSAGE="Hostname saved as ${value}. pCP has flagged this unit for reboot."
    MESSAGE_CLASS=success
  else
    cp "$APP_DIR/players.conf.hostname-backup" "$CONFIG_FILE"
    MESSAGE="Hostname save failed: $(tail -5 /tmp/lyrion-player-hostname.out)"
    MESSAGE_CLASS=error
  fi
}

discover_gadgets() {
  DISCOVERED_FILE=/tmp/lyrion-player-gadgets
  : > "$DISCOVERED_FILE"
  prefix="$(printf '%s' "${LMS_SERVER:-}" | awk -F. 'NF==4 && $1 != 127 {print $1"."$2"."$3"."}')"
  [ -n "$prefix" ] || { MESSAGE="Could not determine the local subnet."; MESSAGE_CLASS=error; return; }
  probe_gadget() {
    ip="$1"
    nc -z -w 1 "$ip" 9099 >/dev/null 2>&1 || return 0
    health="$(wget -T 1 -t 1 -qO- "http://${ip}:9099/health" 2>/dev/null || true)"
    printf '%s' "$health" | grep -q '"app"[[:space:]]*:[[:space:]]*"lyrion_broker"' || return 0
    name="$(printf '%s' "$health" | sed -n 's/.*"hostname"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
    ver="$(printf '%s' "$health" | sed -n 's/.*"ver"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
    printf '%s|%s|%s\n' "$ip" "${name:-Lyrion Gadget}" "$ver" >> "$DISCOVERED_FILE"
  }
  candidates=/tmp/lyrion-player-candidates
  {
    printf '%s\n' "${LMS_SERVER:-}"
    awk -v prefix="$prefix" 'NR > 1 && index($1, prefix) == 1 && tolower($4) ~ /^(b8:27:eb|dc:a6:32|e4:5f:01|d8:3a:dd|2c:cf:67|28:cd:c1)/ {print $1}' /proc/net/arp 2>/dev/null
  } | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | sort -u > "$candidates"
  while IFS= read -r candidate; do
    probe_gadget "$candidate" &
  done < "$candidates"
  wait
  sort -t '|' -k1,1V "$DISCOVERED_FILE" -o "$DISCOVERED_FILE" 2>/dev/null || true
  found="$(wc -l < "$DISCOVERED_FILE" | tr -d ' ')"
  if [ "$found" -gt 0 ]; then MESSAGE="Found $found full Lyrion Gadget server(s)."; MESSAGE_CLASS=success
  else MESSAGE="No full Lyrion Gadget servers were found among active local devices."; MESSAGE_CLASS=error; fi
}

if [ "${REQUEST_METHOD:-GET}" = POST ]; then
  action="$(post_value ACTION)"
  if [ "$action" = save ]; then
    save_post
  elif [ "$action" = hostname-save ]; then
    save_hostname_post
  elif [ "$action" = volume-save ]; then
    save_volume_post
  elif [ "$action" = discover ]; then
    # shellcheck disable=SC1090
    . "$CONFIG_FILE"
    discover_gadgets
  else
    case "$action" in start|stop|restart|normalize|volume-sync)
      if "$MANAGER" "$action" >/tmp/lyrion-player-web.out 2>&1; then
        MESSAGE="Players ${action} command completed."
        MESSAGE_CLASS=success
      else
        MESSAGE="$(cat /tmp/lyrion-player-web.out)"
        MESSAGE_CLASS=error
      fi
    ;; esac
  fi
fi

# shellcheck disable=SC1090
. "$CONFIG_FILE"
mac_tail="$(printf '%s' "${PLAYER1_MAC:-0000}" | tr -d ':' | tail -c 5 | tr '[:lower:]' '[:upper:]')"
HOSTNAME="${HOSTNAME:-Lyrion${mac_tail}}"
live_hostname="$(hostname 2>/dev/null || true)"
status="$($MANAGER status 2>&1 || true)"
OUTPUTS_FILE=/tmp/lyrion-player-outputs
aplay -l 2>/dev/null | sed -n 's/^card [0-9][0-9]*: \([^ ]*\) .* device \([0-9][0-9]*\):.*/hw:CARD=\1,DEV=\2/p' | awk '!seen[$0]++' > "$OUTPUTS_FILE"
gadget_health="$(wget -T 1 -t 1 -qO- "http://${LMS_SERVER}:9099/health" 2>/dev/null || true)"
if printf '%s' "$gadget_health" | grep -Eqi 'lyrion|broker|"ok"'; then
  gadget_state="Full Lyrion Gadget detected at ${LMS_SERVER}"
  gadget_class="gadget-found"
else
  gadget_state="No full Lyrion Gadget detected at the current LMS address"
  gadget_class="gadget-missing"
fi

printf 'Content-Type: text/html\r\n'
printf 'Cache-Control: no-store\r\n\r\n'
cat <<'EOF'
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lyrion Player Setup</title>
<link rel="stylesheet" href="/lyrion-player-assets/app.css">
<style>
:root{color-scheme:light;--ink:#17202b;--muted:#657286;--line:#d7dee8;--panel:#fff;--canvas:#edf1f6;--accent:#5f2aa6;--accent-dark:#442078;--success:#18794e;--danger:#b42318}
*{box-sizing:border-box}body{margin:0;color:var(--ink);background:var(--canvas);font:15px/1.5 Inter,"Segoe UI",Arial,sans-serif}.brand-header{background:#050607;border-bottom:3px solid var(--accent);box-shadow:0 5px 18px rgba(19,26,36,.24)}.brand-strip{display:grid;grid-template-columns:1.35fr 1.35fr 1fr .82fr;align-items:center;gap:clamp(14px,3vw,42px);width:min(1180px,calc(100% - 32px));min-height:112px;margin:auto;padding:14px 6px}.brand-strip img{display:block;width:100%;height:76px;object-fit:contain}.brand-strip img:last-child{height:88px}.brand-bar{border-top:1px solid #23262c;background:#0e1013}.brand-bar-inner{display:flex;align-items:center;justify-content:space-between;gap:20px;width:min(1180px,calc(100% - 32px));margin:auto;padding:12px 6px}.brand-title{color:#fff;font-size:18px;font-weight:700}.unit-pill{display:inline-flex;align-items:center;gap:7px;padding:4px 10px;border:1px solid #166534;border-radius:999px;background:#052e16;color:#86efac;font-size:12px;font-weight:700}.unit-pill:before{content:"";width:8px;height:8px;border-radius:50%;background:currentColor;box-shadow:0 0 9px currentColor}
.page-shell{width:min(1180px,calc(100% - 32px));margin:24px auto 44px}h2{margin:0 0 8px;font-size:25px}.page-nav{display:flex;gap:8px;margin-bottom:18px}.page-nav b{display:inline-block;padding:8px 13px;border:1px solid var(--accent);border-radius:6px;background:var(--accent);color:#fff}.card{padding:22px;border:1px solid var(--line);border-radius:8px;background:var(--panel);box-shadow:0 2px 8px rgba(25,39,58,.06);margin-bottom:18px}.card h2{font-size:18px;margin:0 0 14px;padding-bottom:8px;border-bottom:1px solid var(--line);color:#29384b}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.setup-grid{display:grid;grid-template-columns:minmax(220px,.8fr) minmax(360px,1.4fr);gap:16px;align-items:start;margin-bottom:16px}.setup-grid label{margin-top:0}.player-count-bar{display:flex;justify-content:flex-start;align-items:center;margin:6px 0 12px}.player-count-bar label{display:flex;align-items:center;gap:9px;width:auto;margin:0;color:var(--ink);font-size:15px}.player-count-bar select{width:64px;min-height:38px;margin:0}.players{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:20px}.player{border:1px solid #e1e7ee;border-radius:7px;padding:16px;background:#f8fafc}.player h3{margin:0 0 10px;color:#29384b;font-size:16px}.player:first-child{border-left:3px solid var(--accent)}label{display:block;color:#3a4759;font-size:13px;font-weight:650;margin-top:9px}input,select{display:block;width:100%;min-height:38px;margin-top:5px;padding:8px 10px;border:1px solid #b9c4d2;border-radius:5px;background:#fff;color:var(--ink);font:inherit}input:focus,select:focus{border-color:var(--accent);outline:3px solid rgba(95,42,166,.13)}button{min-height:38px;padding:8px 15px;border:1px solid var(--accent);border-radius:5px;background:var(--accent);color:#fff;font-weight:650;cursor:pointer}button:hover{background:var(--accent-dark)}td small{display:block;margin-top:2px;color:var(--muted);font-size:10px}.fixed-toggle{width:18px;min-width:18px;min-height:18px;margin:0 auto}
.message{padding:12px 14px;border-radius:6px;margin-bottom:18px;white-space:pre-wrap}.success{border-left:3px solid var(--success);background:#edf9f3;color:var(--success)}.error{border-left:3px solid var(--danger);background:#fff1f1;color:var(--danger)}.info{background:#eef3f8}.status{white-space:pre-wrap;padding:12px 14px;border:1px solid #e1e7ee;border-radius:6px;background:#f8fafc;color:var(--success);font:12px/1.8 ui-monospace,Consolas,monospace}.card>form{padding:0;border:0;box-shadow:none;margin:0;background:transparent}.button-row{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.button-row button.secondary{border-color:#b9c4d2;background:#fff;color:var(--accent-dark)}.button-row button.secondary:hover{border-color:var(--accent);background:#f3eef9;color:var(--accent-dark)}.actions{position:sticky;bottom:10px;display:flex;align-items:center;justify-content:flex-end;gap:14px;margin:24px -10px -10px;padding:12px 14px;border:1px solid #bcc9d8;border-radius:7px;background:rgba(247,249,252,.96);box-shadow:0 5px 20px rgba(23,32,43,.16)}.muted{margin-right:auto;color:var(--muted);font-size:13px}
@media(max-width:900px){.setup-grid{grid-template-columns:1fr 160px}.setup-server{grid-column:1/-1}}@media(max-width:760px){.brand-strip{grid-template-columns:1fr 1fr;min-height:0;gap:8px 18px}.brand-strip img,.brand-strip img:last-child{height:54px}.brand-bar-inner{align-items:flex-start;flex-direction:column;gap:5px}.page-shell{width:min(100% - 20px,1180px);margin-top:14px}.card{padding:14px}.grid,.players,.setup-grid{grid-template-columns:1fr}.setup-server{grid-column:auto}.actions{align-items:stretch;flex-direction:column}.muted{margin-right:0}}
</style>
</head>
<body>
EOF
brand_header
cat <<'EOF'
<main class="page-shell"><h2>Player Setup</h2><div class="page-nav"><b>Player Setup</b></div>
EOF
if [ -n "$MESSAGE" ]; then printf '<div id="flashMessage" class="message %s">%s</div>\n' "$MESSAGE_CLASS" "$(html "$MESSAGE")"; fi
cat <<EOF
<form method="post" class="card"><h2>Provisioning Preview</h2>
EOF
if [ -n "$live_hostname" ] && [ "$live_hostname" != "$HOSTNAME" ]; then
  printf '<div class="message info"><b>Reboot required.</b> Hostname is saved as <code>%s</code>, while this boot is still running as <code>%s</code>.</div>' "$(html "$HOSTNAME")" "$(html "$live_hostname")"
fi
cat <<EOF
<div class="setup-grid"><div><label for="hostname">Device hostname</label><input id="hostname" name="HOSTNAME" value="$(html "$HOSTNAME")" required><div class="gadget-state">Defaults to Lyrion plus the final four primary-MAC digits.</div><button type="submit" name="ACTION" value="hostname-save" style="margin-top:9px">Save Hostname</button></div><div class="setup-server"><label for="lms">Full Lyrion Gadget / LMS address</label><input id="lms" name="LMS_SERVER" value="$(html "${LMS_SERVER:-}")" required><div class="gadget-state $gadget_class">$(html "$gadget_state")</div><button type="submit" name="ACTION" value="discover" formnovalidate style="margin-top:9px">Find Lyrion Gadgets</button>
EOF
if [ -s /tmp/lyrion-player-gadgets ]; then
  printf '<label for="gadgetResults" style="margin-top:10px">Discovered servers</label><select id="gadgetResults"><option value="">Select a Lyrion Gadget…</option>'
  while IFS='|' read -r ip name ver; do
    printf '<option value="%s">%s — %s%s</option>' "$(html "$ip")" "$(html "$name")" "$(html "$ip")" "$([ -n "$ver" ] && printf ' — v%s' "$(html "$ver")")"
  done < /tmp/lyrion-player-gadgets
  printf '</select>'
fi
printf '</div></div><div class="player-count-bar"><label for="count">Players<select id="count" name="PLAYER_COUNT">'
i=1
while [ "$i" -le 4 ]; do
  selected=""; [ "${PLAYER_COUNT:-1}" = "$i" ] && selected=" selected"
  printf '<option value="%s"%s>%s</option>\n' "$i" "$selected" "$i"
  i=$((i + 1))
done
printf '</select></label></div>\n'
printf '<div class="table-wrap"><table><thead><tr><th>Slot</th><th>Player Name</th><th>Stable MAC</th><th>Playback Device</th><th>ALSA Tuning <small>(advanced)</small></th><th>Extra Options <small>(advanced)</small></th></tr></thead><tbody>\n'
i=1
while [ "$i" -le 4 ]; do
  printf '<tr class="player-config-row" data-slot="%s"><td><b>%s</b>%s</td>' "$i" "$i" "$([ "$i" = 1 ] && printf '<small>native pCP</small>')"
  for key in NAME MAC OUTPUT AUDIO_PARAMS EXTRA; do
    var="PLAYER${i}_${key}"; value="$(cfg "$var")"; required=""
    case "$key" in NAME|MAC|OUTPUT) required=" required" ;; esac
    if [ "$key" = OUTPUT ]; then
      printf '<td><select aria-label="Player %s Playback Device" name="%s"%s>' "$i" "$var" "$required"
      value_found=0
      while IFS= read -r detected_output; do
        selected=""; if [ "$detected_output" = "$value" ]; then selected=" selected"; value_found=1; fi
        printf '<option value="%s"%s>%s</option>' "$(html "$detected_output")" "$selected" "$(html "$detected_output")"
      done < "$OUTPUTS_FILE"
      if [ "$value_found" = 0 ] && [ -n "$value" ]; then
        printf '<option value="%s" selected>%s (saved — currently unavailable)</option>' "$(html "$value")" "$(html "$value")"
      fi
      printf '</select></td>'
    else
      printf '<td><input aria-label="Player %s %s" name="%s" value="%s"%s></td>' "$i" "$key" "$var" "$(html "$value")" "$required"
    fi
  done
  printf '</tr>\n'
  i=$((i + 1))
done
cat <<'EOF'
</tbody></table></div><p class="notice"><b>Playback Device</b> selects the physical ALSA output. <b>ALSA Tuning</b> is a separate optional pCP buffer/period string; Player 1's existing <code>::::</code> value is preserved from native pCP. Applying restarts local Squeezelite players and briefly interrupts playback.</p><div class="actions"><span class="muted">Player 1 is native pCP. One user-command launcher starts enabled Players 2–4.</span><button type="submit" name="ACTION" value="save">Apply Local Players</button></div></form>
EOF
cat <<'EOF'
<section class="card"><h2>Current pCP Sessions</h2><form method="post"><div class="table-wrap"><table><thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>LMS</th><th>Status</th><th>Fixed Volume</th></tr></thead><tbody>
EOF
i=1
while [ "$i" -le "${PLAYER_COUNT:-1}" ]; do
  name="$(cfg PLAYER${i}_NAME)"; mac="$(cfg PLAYER${i}_MAC)"; output="$(cfg PLAYER${i}_OUTPUT)"
  state="stopped"; printf '%s\n' "$status" | awk -v slot="$i" '$1 == slot && $2 == "running" {found=1} END{exit !found}' && state="running"
  fixed="$(cfg PLAYER${i}_FIXED_VOLUME)"; checked=""; [ "${fixed:-0}" = 1 ] && checked=" checked"
  printf '<tr><td>%s</td><td>%s</td><td><code>%s</code></td><td><code>%s</code></td><td>%s</td><td><b class="state-%s">%s</b></td><td style="text-align:center"><input type="hidden" name="PLAYER%s_FIXED_VOLUME" value="0"><input class="fixed-toggle" aria-label="Player %s Fixed Volume" type="checkbox" name="PLAYER%s_FIXED_VOLUME" value="1"%s></td></tr>\n' "$i" "$(html "$name")" "$(html "$mac")" "$(html "$output")" "$(html "$LMS_SERVER")" "$state" "$state" "$i" "$i" "$i" "$checked"
  i=$((i + 1))
done
cat <<EOF
</tbody></table></div><div class="button-row"><button name="ACTION" value="restart">Restart Players</button><button name="ACTION" value="start">Start Players</button><button name="ACTION" value="stop">Stop Players</button><button name="ACTION" value="normalize">Normalize Output Levels</button><button name="ACTION" value="volume-save">Apply Volume Settings</button></div></form><p class="notice">Fixed outputs are set to 100% and ignore LMS volume changes. Normalize Output Levels sets recognized hardware mixer controls to full and unmutes them.</p></section>
EOF
cat <<'EOF'
<section class="card"><h2>Detected ALSA Devices</h2><div class="table-wrap"><table><thead><tr><th>Card</th><th>ID</th><th>Name</th><th>Physical Path</th><th>Detail</th></tr></thead><tbody>
EOF
render_alsa_rows
cat <<'EOF'
</tbody></table></div></section></main></body></html>
EOF
cat <<'EOF'
<script>
(function(){
  var count=document.getElementById('count');
  function updateRows(){
    var enabled=parseInt(count.value||'1',10);
    document.querySelectorAll('.player-config-row').forEach(function(row){
      row.hidden=parseInt(row.getAttribute('data-slot'),10)>enabled;
    });
  }
  count.addEventListener('change',updateRows);
  var gadgets=document.getElementById('gadgetResults');
  if(gadgets) gadgets.addEventListener('change',function(){
    if(gadgets.value){
      document.getElementById('lms').value=gadgets.value;
      gadgets.parentElement.querySelector('.gadget-state').textContent='Selected '+gadgets.options[gadgets.selectedIndex].textContent+'. Apply Local Players to save.';
      gadgets.hidden=true;
      var label=document.querySelector('label[for="gadgetResults"]'); if(label) label.hidden=true;
    }
  });
  var flash=document.getElementById('flashMessage');
  if(flash) setTimeout(function(){flash.style.transition='opacity .25s';flash.style.opacity='0';setTimeout(function(){flash.remove();},260);},3500);
  updateRows();
}());
</script>
EOF
