#!/usr/bin/env python3
"""
Lyrion Broker (WS-first) + CometD push + WS control (v0.433d)

Fixes "no push" by:
- Using /slim/<clientId>/response as the CometD response channel (not /request)
- Explicitly /meta/subscribe to that response channel after handshake
- Always doing a one-time player scan+subscribe at startup (even if RESCAN_SECS=0)

Env:
  LMS_BASE=http://127.0.0.1:9000
  BROKER_HOST=0.0.0.0
  BROKER_PORT=9099
  BROKER_DIFF=0|1
  STATUS_TAGS=alydKJ   (recommended; matches RTI Music style)
  STATUS_SUBSCRIBE_SECS=300
  RESCAN_SECS=0        (0 disables periodic rescan; startup scan still happens)
  FORCE_STATUS_AFTER_COMMAND=0|1
"""

import asyncio
import copy
import json
import base64
import hashlib
import hmac
import html as html_lib
import io
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import tarfile
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
import uuid
import zipfile
from collections import OrderedDict
from typing import Any, Dict, List, Optional, Set, Tuple

from aiohttp import web, ClientSession, ClientTimeout, WSMsgType, ClientError
from PIL import Image, ImageChops, ImageDraw, ImageOps
from pandora_backend import PandoraBackend

APP_VERSION = "1.238"
PANDORA_PLUGIN_VERSION = "1.1.43"

LEGAL_TERMS_VERSION = "2026-06-28"

LICENSE_TRIAL_DAYS = 7
LICENSE_BETA_TRIAL_DAYS = {"beta": 30, "beta2": 60}
LICENSE_PUBLIC_N_B64 = "1LxM7t7lr7oHSkkhu7f8kHweEvrVlj9NVMGhsdPAgHvqlZMS1BDEjb5u4SiQL0wGf9DaMrBzQif8EFyt-YPtJCEnlG5OOo5w3tXsKdkDG7usnguYlRNEm7Z8XQ_65R0bKJqGwkXM6NJmFXzWzwUJKvrgOivCuH-_MqnFJaj1BqfR4IO2Fv3ZbM8QBuTleFrklOpG1KItCk44kX_8p9_zKvvDgmaB4eyk26g2ZI2PTCupA5-eAW6VIjLVNk4uvTc8WWsMY2FXuPDRD57z-36JUIcCzNQ0RL7uKZ4Ok4uC0LG9f2bknISIFoLB373qGFSJt7uMCAn_3LMYRZ86tsj7Gw"
LICENSE_PUBLIC_E = 65537
LICENSE_SHA256_DIGEST_INFO = bytes.fromhex("3031300d060960864801650304020105000420")

# --- UDP discovery responder (for RTI ID config stream) ---
DISCOVERY_UDP_PORT = int(os.environ.get("BROKER_DISCOVERY_UDP_PORT", "9099"))
DISCOVERY_MAGIC = b"LYRION_BROKER_DISCOVER_v1"
COMMISSION_DISCOVERY_MAGIC = b"LYRION_GADGET_COMMISSION_v1"
DISCOVERY_NAME = os.environ.get("BROKER_NAME", "").strip()

LISTEN_HOST = os.getenv("BROKER_HOST", "0.0.0.0")
LISTEN_PORT = int(os.getenv("BROKER_PORT", "9099"))
BROKER_PUBLIC_BASE = os.getenv("BROKER_PUBLIC_BASE", "").strip().rstrip("/")

LMS_BASE = os.getenv("LMS_BASE", "http://127.0.0.1:9000").rstrip("/")
LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
LMS_COMETD = LMS_BASE + "/cometd"
LOCAL_LMS_BASE = "http://127.0.0.1:9000"
# Setup UI persistent config (when LMS_BASE env var is NOT set)
SETUP_JSON_PATH = os.getenv("BROKER_SETUP_JSON", "/opt/lyriongadget/broker_setup.json")
ADVANCED_SETUP_PASSWORD = os.getenv("BROKER_ADVANCED_PASSWORD", "LyrionGadget")
ADVANCED_SETUP_PASSWORD_LEVEL2 = os.getenv("BROKER_ADVANCED_PASSWORD_LEVEL2", "LyrionGadget2")
ADVANCED_AUTH_COOKIE = "lyrion_advanced_auth"
ADVANCED_AUTH_MAX_AGE = 8 * 60 * 60
PCP_CONFIG_PATH = "/usr/local/etc/pcp/pcp.cfg"
PCP_NETMOUNTS_PATH = "/usr/local/etc/pcp/netmounts.conf"
PCP_BROKER_LAUNCH_PATH = "/mnt/mmcblk0p2/tce/lyriongadget/launch-lyrion-broker-pcp.sh"
PCP_LOCAL_STACK_PATH = "/mnt/mmcblk0p2/tce/lyriongadget/start-local-stack.sh"
ASOUND_CONFIG_PATH = "/etc/asound.conf"
FILETOOL_LIST_PATH = "/opt/.filetool.lst"
DAC8X_ASOUND_BEGIN = "# BEGIN LYRION GADGET DAC8X"
DAC8X_ASOUND_END = "# END LYRION GADGET DAC8X"
MAX_UNIT_PLAYERS = 6
PI3_MAX_UNIT_PLAYERS = 4
PI4_MAX_UNIT_PLAYERS = 5
PI5_MAX_UNIT_PLAYERS = 6
CLONE_MAX_PLAYERS = 3
RTI_MAX_PLAYERS = 9
UPDATE_MAX_PACKAGE_BYTES = 32 * 1024 * 1024
DEFAULT_UPDATE_MANIFEST_URL = os.environ.get(
    "BROKER_UPDATE_MANIFEST_URL",
    "https://raw.githubusercontent.com/Shakey001/LyrionGadget-Releases/main/update.json",
).strip()
UPDATE_REQUIRED_FILES = {
    "lyrion_broker.py",
    "pandora_backend.py",
    "repair-picoreplayer.sh",
    "requirements.txt",
    "start-lyrion-broker-pcp.sh",
}

# Home menu keys (webpage controls which appear on RTI "Home" list)
HOME_MENU_DEFAULT = [
    {"key": "mymusic", "label": "My Music", "enabled": True, "order": 10, "type": "core", "source_label": "My Music"},
    {"key": "radio", "label": "Radio", "enabled": True, "order": 20, "type": "core", "source_label": "Radio"},
    {"key": "favorites", "label": "Favorites", "enabled": True, "order": 30, "type": "core", "source_label": "Favorites"},
]

RPC_TIMEOUT = float(os.getenv("RPC_TIMEOUT", "8"))

DEFAULT_PLAYERID = (os.getenv("DEFAULT_PLAYERID", "") or "").strip()

TRACK_META_CACHE: Dict[str, Dict[str, Any]] = {}
TRACK_META_CACHE_MAX = int(os.getenv("TRACK_META_CACHE_MAX", "2000"))

BROKER_ID = ""
LYRION_VERSION = ""

_np_station_by_playerid: Dict[str, str] = {}
_np_source_by_playerid: Dict[str, str] = {}
_pandora_station_by_playerid: Dict[str, str] = {}
_pandora_station_by_url: Dict[str, str] = {}
_pandora_station_art_by_url: Dict[str, str] = {}
_pandora_station_art_by_label: Dict[str, str] = {}
_pandora_station_unknown_playerids: Set[str] = set()
_random_mix_queue_players: Set[str] = set()
_podcast_refresh_generation: Dict[str, int] = {}
_pandora_status_refresh_tasks: Dict[str, asyncio.Task] = {}
_podcast_players: Set[str] = set()
_np_path_by_playerid: Dict[str, str] = {}
pandora_backend = PandoraBackend()
_pandora_plugin_zip_cache: Dict[Tuple[str, str], bytes] = {}


def _b64u_decode(value: str) -> bytes:
    raw = _safe_str(value).strip()
    return base64.urlsafe_b64decode(raw + ("=" * ((4 - len(raw) % 4) % 4)))


def _normalize_license_mac(value: Any) -> str:
    chars = "".join(ch for ch in _safe_str(value).upper() if ch in "0123456789ABCDEF")
    if len(chars) != 12 or chars == "000000000000":
        return ""
    return ":".join(chars[i:i + 2] for i in range(0, 12, 2))


def _device_license_mac() -> str:
    override = _normalize_license_mac(os.getenv("BROKER_LICENSE_MAC", ""))
    if override:
        return override
    candidates: List[Tuple[int, str, str]] = []
    net_root = "/sys/class/net"
    try:
        for name in os.listdir(net_root):
            if name == "lo":
                continue
            try:
                with open(os.path.join(net_root, name, "address"), "r", encoding="ascii") as f:
                    mac = _normalize_license_mac(f.read())
            except Exception:
                continue
            if not mac:
                continue
            priority = 0 if name in ("eth0", "end0") else 1 if name.startswith(("eth", "en")) else 2 if name.startswith("wlan") else 3
            candidates.append((priority, name, mac))
    except Exception:
        pass
    if candidates:
        candidates.sort()
        return candidates[0][2]
    node = uuid.getnode()
    return _normalize_license_mac(f"{node:012X}")


def _verify_license_key(key: Any, device_mac: str) -> Tuple[bool, str]:
    text = _safe_str(key).strip()
    if not text:
        return False, "no_key"
    if text.lower() in LICENSE_BETA_TRIAL_DAYS:
        return False, "beta_trial"
    try:
        prefix, payload_b64, signature_b64 = text.split(".", 2)
        if prefix != "LYR1":
            return False, "bad_format"
        payload_bytes = _b64u_decode(payload_b64)
        signature = _b64u_decode(signature_b64)
        payload = json.loads(payload_bytes.decode("utf-8"))
        if not isinstance(payload, dict) or _safe_int(payload.get("v"), 0) != 1:
            return False, "bad_payload"
        if _normalize_license_mac(payload.get("mac")) != _normalize_license_mac(device_mac):
            return False, "wrong_mac"
        expires = _safe_int(payload.get("expires"), 0)
        if expires and time.time() > expires:
            return False, "key_expired"

        modulus = int.from_bytes(_b64u_decode(LICENSE_PUBLIC_N_B64), "big")
        size = (modulus.bit_length() + 7) // 8
        if len(signature) != size:
            return False, "bad_signature"
        encoded = pow(int.from_bytes(signature, "big"), LICENSE_PUBLIC_E, modulus).to_bytes(size, "big")
        digest_info = LICENSE_SHA256_DIGEST_INFO + hashlib.sha256(payload_bytes).digest()
        padding_len = size - len(digest_info) - 3
        expected = b"\x00\x01" + (b"\xff" * padding_len) + b"\x00" + digest_info
        if padding_len < 8 or not hmac.compare_digest(encoded, expected):
            return False, "bad_signature"
        return True, "licensed"
    except Exception:
        return False, "bad_format"


def _license_status(now: Optional[float] = None) -> Dict[str, Any]:
    current = time.time() if now is None else float(now)
    mac = _device_license_mac()
    if _broker_light_mode():
        return {
            "valid": True,
            "state": "not_required",
            "reason": "",
            "device_mac": mac,
            "trial_days": 0,
            "trial_started_at": 0,
            "trial_ends_at": 0,
            "trial_seconds_remaining": 0,
            "key_valid": False,
        }
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    key_valid, key_reason = _verify_license_key(license_key, mac)
    trial_days = LICENSE_BETA_TRIAL_DAYS.get(license_key.lower(), LICENSE_TRIAL_DAYS)
    trial_start = float(_setup_cache.get("license_trial_started_at") or 0)
    trial_end = trial_start + (trial_days * 86400) if trial_start > 0 else 0
    remaining = max(0, int(trial_end - current)) if trial_end else trial_days * 86400
    trial_valid = bool(trial_end and current < trial_end)
    return {
        "valid": bool(key_valid or trial_valid),
        "state": "licensed" if key_valid else "trial" if trial_valid else "expired",
        "reason": key_reason if not key_valid and not trial_valid else "",
        "device_mac": mac,
        "trial_days": trial_days,
        "trial_started_at": int(trial_start),
        "trial_ends_at": int(trial_end),
        "trial_seconds_remaining": remaining,
        "key_valid": key_valid,
    }


def _legal_terms_accepted() -> bool:
    return (
        bool(_setup_cache.get("legal_accepted", False))
        and _safe_str(_setup_cache.get("legal_terms_version")) == LEGAL_TERMS_VERSION
    )


def _ensure_license_trial_started() -> None:
    if float(_setup_cache.get("license_trial_started_at") or 0) > 0:
        return
    _setup_cache["license_trial_started_at"] = int(time.time())
    _save_setup_config()

def _clean_text(v: Any) -> str:
    s = _safe_str(v).strip()
    if not s:
        return ""
    if s.lower() in ("null", "none", "undefined", "n/a"):
        return ""
    return s

def _is_internal_label(s: str) -> bool:
    raw = _clean_text(s).strip().lower()
    n = _norm_key(s)
    if n in ("pyrrha", "apppyrrha", "pandora", "frpandora0", "appfrpandora0", "spotty", "spotify"):
        return True
    return (
        raw.startswith(("fr_pandora", "frpandora", "pyrrha:"))
        or n.startswith(("frpandora", "appfrpandora"))
    )

def _provider_from_payload(payload: Dict[str, Any]) -> str:
    try:
        for obj in (payload.get("remoteMeta") or {}, payload, _current_playlist_item(payload) or {}):
            btns = obj.get("buttons") if isinstance(obj, dict) else None
            if isinstance(btns, dict):
                for bk in ("repeat", "shuffle"):
                    b = btns.get(bk)
                    if isinstance(b, dict):
                        cmd = b.get("command")
                        if isinstance(cmd, list) and cmd:
                            head = _safe_str(cmd[0]).strip().lower()
                            if head.startswith("fr_pandora"):
                                return "pandora"
                            if head.startswith("spotty") or head.startswith("spotify"):
                                return "spotify"
        cur = _current_playlist_item(payload) or {}
        rm = payload.get("remoteMeta") or {}
        current_path = " ".join(
            _safe_str(cur.get(k)).strip().lower()
            for k in ("url", "file", "uri", "path")
            if isinstance(cur, dict)
        )
        if current_path.startswith("file://"):
            return "mymusic"
        hay = " ".join(_safe_str(x).strip().lower() for x in (
            payload.get("url"), payload.get("file"), payload.get("uri"), payload.get("path"),
            payload.get("remote_url"), payload.get("source"), payload.get("plugin"),
            payload.get("artwork_url"), payload.get("artwork_url2"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            rm.get("source") if isinstance(rm, dict) else "",
            rm.get("artwork_url") if isinstance(rm, dict) else "",
            rm.get("artwork_url2") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
            cur.get("type") if isinstance(cur, dict) else "",
            cur.get("artwork_url") if isinstance(cur, dict) else "",
        ))
        if "qobuz:" in hay or "qobuz://" in hay or "static.qobuz.com" in hay:
            return "qobuz"
        if "tidal:" in hay or "tidal://" in hay or "tidal.com" in hay:
            return "tidal"
        if (
            "sounds://" in hay
            or "bbcsounds" in hay
            or "sounds.files.bbci.co.uk" in hay
            or "bbc.co.uk/sounds" in hay
            or "rms.api.bbc.co.uk" in hay
        ):
            return "bbcsounds"
        if "spotify:" in hay or "spotty" in hay:
            return "spotify"
        if "fr_pandora" in hay or "pandora" in hay or "pyrrha" in hay:
            return "pandora"
        if "airplay://" in hay or "raop://" in hay or "shairtunes" in hay:
            return "airplay"
        if "podcast:" in hay or "podcasts:" in hay or "/podcast" in hay:
            return "podcast"
        if "tunein" in hay or "/plugins/tunein/" in hay or "secure shoutcast" in hay:
            return "radio"
        if (
            "iheart" in hay
            or "iheartradio" in hay
            or "ihrhls" in hay
            or "iheart.com" in hay
        ):
            return "iheart"
        if _safe_int(payload.get("remote"), 0) != 0 and _safe_int(payload.get("playlist_tracks"), 0) <= 1:
            return "radio"
        if isinstance(cur, dict):
            if _safe_int(cur.get("track_id"), 0) > 0 or _safe_int(cur.get("id"), 0) > 0:
                return "mymusic"
        if isinstance(payload.get("playlist_loop"), list) and _safe_int(payload.get("playlist_tracks"), 0) > 0:
            return "mymusic"
    except Exception:
        pass
    return ""

def _configured_source_label(provider: str) -> str:
    p = _norm_key(provider)
    if not p:
        return ""
    try:
        rows = _setup_cache.get("home_menu") or _home_menu_cache or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            key = _norm_key(row.get("key"))
            vals = [key, row.get("label"), row.get("source_label")]
            joined = " ".join([_safe_str(x) for x in vals]).lower()
            matched = key == p
            if p == "pandora":
                matched = "pandora" in joined or "pyrrha" in joined or "fr_pandora" in joined
            elif p == "pyrrha":
                matched = "pyrrha" in joined
            elif p == "spotify":
                matched = "spotty" in joined or "spotify" in joined
            elif p == "qobuz":
                matched = "qobuz" in joined
            elif p == "tidal":
                matched = "tidal" in joined
            if matched:
                lab = _clean_text(row.get("label") or row.get("source_label"))
                if lab and not _is_internal_label(lab):
                    return lab
    except Exception:
        pass
    return ""

def _configured_home_source_enabled(provider: str) -> bool:
    """Return whether a provider is enabled as its own RTI home-menu app."""
    p = _norm_key(provider)
    if not p:
        return False
    try:
        rows = _setup_cache.get("home_menu") or _home_menu_cache or []
        for row in rows:
            if not isinstance(row, dict) or not bool(row.get("enabled", False)):
                continue
            joined = _norm_key(" ".join(
                _safe_str(row.get(key)) for key in ("key", "label", "source_label")
            ))
            if p == "iheart" and "iheart" in joined:
                return True
            if _norm_key(row.get("key")) == p:
                return True
    except Exception:
        pass
    return False

def _payload_is_pyrrha(payload: Dict[str, Any]) -> bool:
    try:
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        cur = _current_playlist_item(payload) or {}
        vals = [
            payload.get("np_path"), payload.get("path"), payload.get("url"), payload.get("file"), payload.get("uri"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
        ]
        for item in payload.get("playlist_loop") or []:
            if isinstance(item, dict):
                vals.extend([item.get("url"), item.get("file"), item.get("uri")])
        return any(_safe_str(v).strip().lower().startswith("pyrrha:") for v in vals)
    except Exception:
        return False

def _payload_pandora_instance_index(payload: Dict[str, Any]) -> Optional[int]:
    try:
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        cur = _current_playlist_item(payload) or {}
        vals = [
            payload.get("np_path"), payload.get("path"), payload.get("url"), payload.get("file"), payload.get("uri"),
            rm.get("url") if isinstance(rm, dict) else "",
            rm.get("file") if isinstance(rm, dict) else "",
            rm.get("uri") if isinstance(rm, dict) else "",
            cur.get("url") if isinstance(cur, dict) else "",
            cur.get("file") if isinstance(cur, dict) else "",
            cur.get("uri") if isinstance(cur, dict) else "",
        ]
        for item in payload.get("playlist_loop") or []:
            if isinstance(item, dict):
                vals.extend([item.get("url"), item.get("file"), item.get("uri")])
        for v in vals:
            m = _re.match(r"^\s*frpandora([0-3])\s*:", _safe_str(v), flags=_re.I)
            if m:
                return _safe_int(m.group(1), -1)
    except Exception:
        pass
    return None

def _configured_pandora_instance_label(index: Optional[int]) -> str:
    if index is None or index < 0 or index > 3:
        return _configured_source_label("pandora")
    letter = chr(65 + index)
    tokens = {
        f"frpandora{index}",
        f"fr_pandora_{index}",
        f"pandora{letter.lower()}",
        f"pandora {letter.lower()}",
    }
    try:
        rows = _setup_cache.get("home_menu") or _home_menu_cache or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            joined = " ".join(_safe_str(x).lower() for x in (row.get("key"), row.get("label"), row.get("source_label")))
            norm_joined = _norm_key(joined)
            if (
                f"frpandora{index}" in norm_joined
                or f"fr_pandora_{index}" in joined
                or f"pandora{letter.lower()}" in norm_joined
                or any(t in joined for t in tokens)
            ):
                lab = _clean_text(row.get("label") or row.get("source_label"))
                if lab and not _is_internal_label(lab):
                    return lab
    except Exception:
        pass
    try:
        accounts = _pandora_accounts_cache()
        if index < len(accounts):
            name = _clean_text(accounts[index].get("name"))
            if name:
                return name
    except Exception:
        pass
    return f"Pandora {letter}"

def _cached_source_for_provider(pid: str, provider: str) -> str:
    cached = _clean_text(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()))
    if not cached:
        return ""
    c = _norm_key(cached)
    p = _norm_key(provider)
    if p == "pandora" and ("pandora" in c or "pyrrha" in c):
        return cached
    if p == "pyrrha" and "pyrrha" in c:
        return cached
    if p == "spotify" and ("spotify" in c or "spotty" in c):
        return cached
    if p == "qobuz" and "qobuz" in c:
        return cached
    if p == "tidal" and "tidal" in c:
        return cached
    if p in ("bbc", "bbcsounds") and ("bbc" in c or "bbcsounds" in c):
        return cached
    if p == "radio" and ("radio" in c or "tunein" in c or "iheart" in c):
        return cached
    if p == "iheart" and ("iheart" in c or "radio" in c):
        return cached if "iheart" in c else ""
    if p == "podcast" and ("podcast" in c or "podcasts" in c):
        return cached
    if p == "mymusic" and c in ("mymusic", "mymusiclibrary", "library"):
        return cached
    return ""

def _current_player_provider(pid: str, payload: Optional[Dict[str, Any]] = None) -> str:
    snap = payload if isinstance(payload, dict) and payload else (_last_status_by_key.get(pid) or _last_status_by_key.get(pid.lower()) or {})
    provider = _provider_from_payload(snap) if isinstance(snap, dict) else ""
    if provider:
        return provider
    src = _norm_key(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()) or "")
    if "pandora" in src or "pyrrha" in src:
        return "pandora"
    if "spotify" in src or "spotty" in src:
        return "spotify"
    if "qobuz" in src:
        return "qobuz"
    if "tidal" in src:
        return "tidal"
    if "bbcsounds" in src or "bbc" in src:
        return "bbcsounds"
    if "iheart" in src:
        return "iheart"
    if "podcast" in src:
        return "podcast"
    if "radio" in src or "tunein" in src:
        return "radio"
    return ""

def _random_mix_active(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    raw = payload.get("randomplay")
    text = _safe_str(raw).strip().lower()
    if text not in ("", "0", "off", "false", "none", "disable", "disabled"):
        return True
    playlist_mode = _safe_str(
        payload.get("playlist mode", payload.get("playlist_mode"))
    ).strip().lower()
    return "random" in playlist_mode


def _is_podcast_item(item: Any) -> bool:
    if not isinstance(item, dict):
        return False
    hay = " ".join(_safe_str(item.get(key)).lower() for key in (
        "url", "uri", "file", "path", "artwork_url", "artwork_url2", "type", "source"
    ))
    return "/podcast" in hay or "podcast:" in hay or "podcasts:" in hay


def _is_podcast_episode_actions(actions: Any) -> bool:
    if not isinstance(actions, dict):
        return False
    # TuneIn podcast categories expose both play and go/items. The go target
    # means this is a browse node even when touchToPlaySingle is also present.
    if isinstance(actions.get("go"), dict):
        return False
    play = actions.get("play") if isinstance(actions.get("play"), dict) else {}
    play_cmd = play.get("cmd") if isinstance(play.get("cmd"), list) else []
    play_params = play.get("params") if isinstance(play.get("params"), dict) else {}
    if (
        len(play_cmd) >= 3
        and _safe_str(play_cmd[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(play_cmd[1]).strip().lower() == "playlist"
        and _safe_str(play_cmd[2]).strip().lower() == "play"
        and _safe_int(play_params.get("touchToPlaySingle"), 0) == 1
    ):
        return True

    # Older podcast rows identify an episode through playControl and do not
    # expose a separate drill destination.
    for name, action in actions.items():
        if not isinstance(action, dict):
            continue
        cmd = action.get("cmd") if isinstance(action.get("cmd"), list) else []
        params = action.get("params") if isinstance(action.get("params"), dict) else {}
        head = _safe_str(cmd[0]).strip().lower() if cmd else ""
        menu = _safe_str(params.get("menu")).strip().lower()
        if (
            name.lower() == "playcontrol"
            and (head in ("podcast", "podcasts") or menu in ("podcast", "podcasts"))
        ):
            return True
    return False


async def _verify_random_mix_start(pid: str, args: Any, response: Any) -> Any:
    if (
        not isinstance(args, list)
        or len(args) < 2
        or _safe_str(args[0]).strip().lower() != "randomplay"
        or _safe_str(args[1]).strip().lower() in ("disable", "off")
    ):
        return response
    await asyncio.sleep(0.9)
    try:
        check = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
        payload = (check.get("result") or {}) if isinstance(check, dict) else {}
        if not _random_mix_active(payload):
            dbg(f"RANDOM MIX start not active for {pid}; retrying {_safe_str(args[1])} once")
            return await lms.rpc(pid, args)
    except Exception as e:
        dbg(f"RANDOM MIX start verification failed: {type(e).__name__}: {_safe_str(e)}")
    return response

def _provider_from_action_args(args: Any) -> str:
    if not isinstance(args, list) or not args:
        return ""
    head = _safe_str(args[0]).strip().lower()
    joined = " ".join(_safe_str(x).strip().lower() for x in args)
    if head.startswith("fr_pandora") or head == "pyrrha" or "menu:fr_pandora" in joined or "menu:pyrrha" in joined:
        return "pandora"
    if head == "qobuz" or "qobuz:" in joined or "menu:qobuz" in joined:
        return "qobuz"
    if head == "tidal" or "tidal:" in joined or "menu:tidal" in joined:
        return "tidal"
    if head in ("sounds", "bbcsounds") or "sounds://" in joined or "menu:bbcsounds" in joined:
        return "bbcsounds"
    if head in ("spotty", "spotify") or "spotify:" in joined or "menu:spotty" in joined:
        return "spotify"
    if head in ("iheartradio", "fr_iheartradio") or "iheart" in joined:
        return "radio"
    if head in ("playlistcontrol", "browselibrary") or "menu:1" in joined or "track_id:" in joined or "album_id:" in joined or "artist_id:" in joined or "playlist_id:" in joined:
        return "mymusic"
    return ""

def _recursive_first(obj: Any, keys: Tuple[str, ...], max_depth: int = 4) -> str:
    try:
        if max_depth < 0:
            return ""
        if isinstance(obj, dict):
            for k in keys:
                if k in obj:
                    s = _clean_text(obj.get(k))
                    if s:
                        return s
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    s = _recursive_first(v, keys, max_depth - 1)
                    if s:
                        return s
        elif isinstance(obj, list):
            for v in obj:
                if isinstance(v, (dict, list)):
                    s = _recursive_first(v, keys, max_depth - 1)
                    if s:
                        return s
    except Exception:
        pass
    return ""

def _now_playing_path(payload: Dict[str, Any], rm: Dict[str, Any], cur: Dict[str, Any]) -> str:
    for obj in (payload, rm, cur):
        if not isinstance(obj, dict):
            continue
        for key in ("path", "url", "file", "track_path", "stream_url", "remote_url", "uri"):
            path = _clean_text(obj.get(key))
            if path:
                return path
    return ""

def _iheart_station_from_payload(payload: Dict[str, Any]) -> str:
    try:
        current_title = _clean_text(payload.get("current_title"))
        rm = payload.get("remoteMeta") if isinstance(payload.get("remoteMeta"), dict) else {}
        current_track = _clean_text(rm.get("title") if isinstance(rm, dict) else "")
        for item in payload.get("playlist_loop") or []:
            if not isinstance(item, dict):
                continue
            title = _clean_text(item.get("title")).splitlines()[0].strip()
            if not title or _is_internal_label(title):
                continue
            if _clean_text(item.get("artist")):
                continue
            if title == current_title or title == current_track:
                continue
            hay = " ".join(_safe_str(item.get(k)).lower() for k in ("url", "file", "uri", "artwork_url", "artwork_url2"))
            if not any(token in hay for token in ("iheart", "ihrhls", "revma.", "streamtheworld.com", "amperwave", "audacy")):
                continue
            title = _re.sub(r"\s*\((?:secure\s+)?shoutcast\)\s*$", "", title, flags=_re.I).strip()
            return title
        if isinstance(rm, dict) and not _clean_text(rm.get("artist")) and _safe_int(rm.get("duration"), 0) <= 0:
            title = _clean_text(rm.get("title")).splitlines()[0].strip()
            if title and not _is_internal_label(title) and title != current_title:
                return title
        if current_title and " - " not in current_title and not _is_internal_label(current_title):
            return current_title.splitlines()[0].strip()
    except Exception:
        pass
    return ""

def _normalize_player_display_fields(pid: str, payload: Dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        return
    rm = payload.get("remoteMeta") or {}
    cur = _current_playlist_item(payload) or {}

    genre = _clean_text(payload.get("genre") or (rm.get("genre") if isinstance(rm, dict) else "") or cur.get("genre") or payload.get("genres") or (rm.get("genres") if isinstance(rm, dict) else ""))
    if genre:
        payload["np_genre"] = genre

    path = _now_playing_path(payload, rm if isinstance(rm, dict) else {}, cur if isinstance(cur, dict) else {})
    if path:
        _np_path_by_playerid[pid] = path
        payload["np_path"] = path
    else:
        payload["np_path"] = ""

    provider = _provider_from_payload(payload)
    if provider == "mymusic" and _safe_int(payload.get("remote"), 0) != 0:
        cached_source = _norm_key(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()))
        if "iheart" in cached_source:
            provider = "iheart"
        elif "radio" in cached_source or "tunein" in cached_source:
            provider = "radio"
    current_id = _safe_str(cur.get("id")).strip() if isinstance(cur, dict) else ""
    if provider in ("spotify", "pandora") or (current_id.isdigit() and _safe_int(current_id, 0) > 0):
        _podcast_players.discard(pid.lower())
    if not provider:
        known_art = _safe_str(_main_art_source_by_playerid.get(pid) or _main_art_source_by_playerid.get(pid.lower())).lower()
        rm_duration = (rm.get("duration") if isinstance(rm, dict) else None)
        cached_source = _norm_key(_np_source_by_playerid.get(pid) or _np_source_by_playerid.get(pid.lower()))
        if "iheart" in known_art or (
            cached_source == "radio"
            and _safe_int(payload.get("remote"), 0) != 0
            and _safe_int(payload.get("duration") if payload.get("duration") is not None else rm_duration, 0) <= 0
        ):
            provider = "radio"
    source = ""
    if provider == "pandora":
        if _payload_is_pyrrha(payload):
            source = _configured_source_label("pyrrha") or _cached_source_for_provider(pid, "pyrrha") or "Pyrrha"
        else:
            source = _configured_pandora_instance_label(_payload_pandora_instance_index(payload)) or _cached_source_for_provider(pid, "pandora") or "Pandora"
    elif provider == "spotify":
        source = _configured_source_label("spotify") or _cached_source_for_provider(pid, "spotify") or "Spotify"
    elif provider == "qobuz":
        source = _configured_source_label("qobuz") or _cached_source_for_provider(pid, "qobuz") or "Qobuz"
    elif provider == "tidal":
        source = _configured_source_label("tidal") or _cached_source_for_provider(pid, "tidal") or "TIDAL"
    elif provider == "bbcsounds":
        source = _configured_source_label("bbcsounds") or _configured_source_label("bbc_sounds") or _cached_source_for_provider(pid, "bbcsounds") or "BBC Sounds"
    elif provider == "iheart":
        if _configured_home_source_enabled("iheart"):
            source = _configured_source_label("iheart") or _cached_source_for_provider(pid, "iheart") or "iHeartRadio"
        else:
            source = _configured_source_label("radio") or _cached_source_for_provider(pid, "radio") or "Radio"
    elif provider == "podcast":
        source = _configured_source_label("podcast") or _cached_source_for_provider(pid, "podcast") or "Podcasts"
    elif provider == "airplay":
        source = _configured_source_label("airplay") or _cached_source_for_provider(pid, "airplay") or "Airplay 2"
    elif provider == "radio":
        source = _configured_source_label("radio") or _cached_source_for_provider(pid, "radio") or "Radio"
    elif provider == "mymusic":
        source = _configured_source_label("mymusic") or "My Music"
    else:
        source = _clean_text(payload.get("np_source") or payload.get("source") or (rm.get("source") if isinstance(rm, dict) else "") or payload.get("service") or payload.get("plugin"))
    if provider:
        payload["is_live_radio"] = provider in ("radio", "iheart")
        payload["genre"] = genre
        payload["np_genre"] = genre
        safe_path = path
        if not safe_path or len(safe_path) > 512:
            safe_path = provider
        payload["np_path"] = safe_path
        _np_path_by_playerid[pid] = safe_path
    generic = _norm_key(source)
    if provider not in ("radio", "iheart") and generic in ("playthisstation", "play", "radio", "station"):
        source = _cached_source_for_provider(pid, provider)
    if source:
        _np_source_by_playerid[pid] = source
        payload["np_source"] = source

    if provider == "bbcsounds" and isinstance(rm, dict):
        real_title = _clean_text(rm.get("title")).strip()
        current_title = _clean_text(payload.get("current_title") or payload.get("title")).strip()
        if real_title and (not current_title or _norm_key(current_title).startswith("play")):
            payload["current_title"] = real_title
            payload["title"] = real_title
            payload["remote_title"] = real_title

    source_hay = " ".join(
        _safe_str(v).lower()
        for v in (
            payload.get("np_source"),
            payload.get("source"),
            payload.get("np_path"),
            path,
            payload.get("plugin"),
            (rm.get("source") if isinstance(rm, dict) else ""),
            (rm.get("url") if isinstance(rm, dict) else ""),
        )
    )
    source_icon = ""
    if provider == "qobuz" or "qobuz" in source_hay:
        source_icon = _broker_source_art_url("source-qobuz.png", APP_VERSION)
    elif provider == "tidal" or "tidal" in source_hay:
        source_icon = _broker_source_art_url("source-tidal.png", APP_VERSION)
    elif provider == "bbcsounds" or "bbc sounds" in source_hay or "bbcsounds" in source_hay:
        source_icon = _broker_source_art_url("source-bbc.png", APP_VERSION)
    elif provider == "iheart" or "iheart" in source_hay:
        source_icon = _broker_source_art_url("source-iheart.png", APP_VERSION)
    elif provider == "spotify" or "spotify" in source_hay or "spotty" in source_hay:
        source_icon = _broker_source_art_url("source-spotify.png", APP_VERSION)
    elif provider == "pyrrha" or "pyrrha" in source_hay:
        source_icon = _broker_source_art_url("source-pyrrha.png", APP_VERSION)
    elif provider == "pandora" or "pandora" in source_hay or "fr_pandora" in source_hay:
        source_icon = _broker_source_art_url("source-pandora.png", APP_VERSION)
    payload["source_icon_url"] = source_icon
    payload["np_source_icon"] = source_icon

    station = ""
    if provider not in ("mymusic", "spotify", "qobuz", "tidal", "podcast", "bbcsounds"):
        station = _clean_text(payload.get("station") or payload.get("station_name"))
        if not station and isinstance(rm, dict):
            station = _clean_text(rm.get("station") or rm.get("station_name"))
        if not station:
            cand_remote = _clean_text(payload.get("remote_title") or (rm.get("remote_title") if isinstance(rm, dict) else ""))
            if cand_remote and not _is_internal_label(cand_remote) and _norm_key(cand_remote) not in ("playthisstation", "play", "radio", "station"):
                station = cand_remote
        if provider == "iheart" and not station:
            station = _iheart_station_from_payload(payload)
        if not station:
            cand = _clean_text(payload.get("source") or (rm.get("source") if isinstance(rm, dict) else ""))
            bad = {
                _clean_text(payload.get("title")),
                _clean_text(payload.get("current_title")),
                _clean_text(payload.get("np_source")),
                _clean_text(_np_source_by_playerid.get(pid)),
                "Play this station",
                "Play",
                "Radio",
                "Station",
            }
            if cand and cand not in bad and not _is_internal_label(cand):
                station = cand
    if provider == "pandora":
        station = _valid_station_label(station)
        current_station_hint = _valid_station_label(payload.get("current_title") or payload.get("title"))
        current_song_title = _clean_text(
            (rm.get("title") if isinstance(rm, dict) else "")
            or (cur.get("title") if isinstance(cur, dict) else "")
        )
        if current_station_hint and current_song_title and _norm_key(current_station_hint) == _norm_key(current_song_title):
            current_station_hint = ""
        if not station and current_station_hint:
            station = current_station_hint
    if provider in ("mymusic", "spotify", "qobuz", "tidal", "podcast", "bbcsounds"):
        _np_station_by_playerid.pop(pid, None)
        _np_station_by_playerid.pop(pid.lower(), None)
        payload["np_station"] = ""
    elif provider == "airplay":
        station = "Use AirPlay device for control"
        _np_station_by_playerid[pid] = station
        _np_station_by_playerid[pid.lower()] = station
        payload["np_station"] = station
    elif station:
        if provider == "pandora":
            _pandora_station_unknown_playerids.discard(pid.lower())
        _np_station_by_playerid[pid] = station
        payload["np_station"] = station
    elif provider == "pandora":
        path_key = _pandora_url_key(payload.get("np_path") or path)
        if pid.lower() in _pandora_station_unknown_playerids:
            st = ""
        else:
            st = _clean_text(
                _pandora_station_by_url.get(path_key)
                or _pandora_station_by_playerid.get(pid)
                or _pandora_station_by_playerid.get(pid.lower())
                or _np_station_by_playerid.get(pid)
                or _np_station_by_playerid.get(pid.lower())
            )
        payload["np_station"] = st
    elif provider == "iheart":
        st = _clean_text(_np_station_by_playerid.get(pid) or _np_station_by_playerid.get(pid.lower()))
        payload["np_station"] = st
    else:
        st = _clean_text(_np_station_by_playerid.get(pid))
        if st:
            payload["np_station"] = st

    btns = None
    for obj in (payload, rm, cur):
        if isinstance(obj, dict) and isinstance(obj.get("buttons"), dict):
            btns = obj.get("buttons")
            break

    def is_pandora_rate_button(name: str, value: int) -> bool:
        if not isinstance(btns, dict):
            return False
        button = btns.get(name)
        if not isinstance(button, dict):
            return False
        command = button.get("command")
        return (
            isinstance(command, list)
            and len(command) >= 3
            and _provider_from_action_args(command) == "pandora"
            and _safe_str(command[1]).strip().lower() == "rate"
            and _safe_int(command[2], -1) == value
        )

    can_rate_positive = (
        is_pandora_rate_button("repeat", 1)
    )
    can_rate_negative = (
        is_pandora_rate_button("shuffle", 0)
    )
    payload["canRatePositive"] = can_rate_positive
    payload["canThumbsUp"] = can_rate_positive
    payload["canRateNegative"] = can_rate_negative
    payload["canThumbsDown"] = can_rate_negative
    payload["canRate"] = can_rate_positive or can_rate_negative


async def _supplement_player_display_fields(pid: str, payload: Dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        return
    need_path = not _clean_text(payload.get("np_path"))
    need_source = not _clean_text(payload.get("np_source"))
    need_station = not _clean_text(payload.get("np_station"))
    if not (need_path or need_source or need_station):
        return
    try:
        r = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
        full = (r.get("result") or {}) if isinstance(r, dict) else {}
        if not isinstance(full, dict) or not full:
            return
        _normalize_art_fields(full)
        _enrich_status_payload(full, pid)
        _normalize_player_display_fields(pid, full)
        if need_path:
            rm = full.get("remoteMeta") or {}
            cur = _current_playlist_item(full) or {}
            path = _clean_text(full.get("np_path") or _now_playing_path(full, rm if isinstance(rm, dict) else {}, cur if isinstance(cur, dict) else {}))
            if path:
                _np_path_by_playerid[pid] = path
                payload["np_path"] = path
        if need_source:
            src = _clean_text(full.get("np_source"))
            if src:
                _np_source_by_playerid[pid] = src
                payload["np_source"] = src
        if need_station:
            st = _clean_text(full.get("np_station"))
            if st:
                _np_station_by_playerid[pid] = st
                payload["np_station"] = st
    except Exception:
        pass


# RTI Music style tags (album/artist/title/duration/artwork/etc). Override if you want.
STATUS_TAGS = os.getenv("STATUS_TAGS", "aglydKJpu")

# How many playlist items to include in CometD subscribe status responses (queue window)
STATUS_SUBSCRIBE_COUNT = int(os.getenv("STATUS_SUBSCRIBE_COUNT", "50"))
if STATUS_SUBSCRIBE_COUNT < 1: STATUS_SUBSCRIBE_COUNT = 1
if STATUS_SUBSCRIBE_COUNT > 200: STATUS_SUBSCRIBE_COUNT = 200
STATUS_SUBSCRIBE_SECS = int(os.getenv("STATUS_SUBSCRIBE_SECS", "300"))
if STATUS_SUBSCRIBE_SECS < 0: STATUS_SUBSCRIBE_SECS = 0
if STATUS_SUBSCRIBE_SECS > 3600: STATUS_SUBSCRIBE_SECS = 3600
STATUS_SUBSCRIBE_RENEW_MARGIN_SECS = float(os.getenv("STATUS_SUBSCRIBE_RENEW_MARGIN_SECS", "30"))
if STATUS_SUBSCRIBE_RENEW_MARGIN_SECS < 1: STATUS_SUBSCRIBE_RENEW_MARGIN_SECS = 1

# How often to rescan LMS for new players and subscribe them (seconds)
RESCAN_SECS = float(os.getenv("RESCAN_SECS", "0"))

# 0 = passthrough full payload on change (no broker diff)
# 1 = broker diff (only changed keys; first full)
BROKER_DIFF = (os.getenv("BROKER_DIFF", "1").strip() == "1")

# 0 = trust CometD long-poll status changes after commands.
# 1 = also do one-shot status reads after selected write commands for debugging/legacy panels.
FORCE_STATUS_AFTER_COMMAND = (os.getenv("FORCE_STATUS_AFTER_COMMAND", "0").strip() == "1")

# CometD status pushes from LMS often omit queue mode fields when another
# controller changes them. Probe lightly so RTI stays in sync with external UI.
TRANSPORT_MODE_VERIFY_DELAY_SECS = float(os.getenv("TRANSPORT_MODE_VERIFY_DELAY_SECS", "0.45"))
if TRANSPORT_MODE_VERIFY_DELAY_SECS < 0.1:
    TRANSPORT_MODE_VERIFY_DELAY_SECS = 0.1
if TRANSPORT_MODE_VERIFY_DELAY_SECS > 5:
    TRANSPORT_MODE_VERIFY_DELAY_SECS = 5

# RTI XP can receive WebSocket data before its upgrade callback has settled.
# Give the driver a small quiet window after prepare() before sending hello/status.
RTI_WS_FIRST_SEND_DELAY_SECS = float(os.getenv("RTI_WS_FIRST_SEND_DELAY_SECS", "0.75"))
if RTI_WS_FIRST_SEND_DELAY_SECS < 0:
    RTI_WS_FIRST_SEND_DELAY_SECS = 0
if RTI_WS_FIRST_SEND_DELAY_SECS > 10:
    RTI_WS_FIRST_SEND_DELAY_SECS = 10
RTI_QUEUE_COALESCE_SECS = 0.25



def dbg(msg: str) -> None:
    try:
        print(msg, flush=True)
    except Exception:
        pass



def _compute_broker_id() -> str:
    try:
        mac = _device_license_mac()
        chars = "".join(ch for ch in _safe_str(mac).upper() if ch in "0123456789ABCDEF")
        if len(chars) == 12:
            return "Lyrion" + chars[-4:]
    except Exception:
        pass
    try:
        node = uuid.getnode()
        tail = ("%012X" % int(node))[-4:]
        return "Lyrion" + tail
    except Exception:
        return "Lyrion0000"


async def _fetch_lyrion_version() -> str:
    try:
        r = await lms.rpc("", ["serverstatus", 0, 1])
        res = (r.get("result") or {}) if isinstance(r, dict) else {}
        for k in ("version", "serverversion", "server_version"):
            v = _safe_str(res.get(k)).strip()
            if v:
                return v
    except Exception as e:
        dbg("Lyrion version fetch failed: " + _safe_str(e))
    return ""


async def _refresh_server_meta() -> None:
    global BROKER_ID, LYRION_VERSION
    if not BROKER_ID:
        BROKER_ID = _compute_broker_id()
    try:
        ver = await _fetch_lyrion_version()
        if ver:
            LYRION_VERSION = ver
    except Exception:
        pass


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def _rti_json_dumps(obj: Any) -> str:
    """Serialize RTI wire messages as ASCII-safe JSON.

    Some RTI processors expose UTF-8 WebSocket payload bytes to JavaScript as
    Latin-1 characters. JSON Unicode escapes avoid that runtime boundary while
    decoding to the original text in every standards-compliant JSON parser.
    """
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=True)


_RTI_MENU_ROW_ALWAYS_KEYS = {
    "id",
    "label",
    "name",
    "title",
    "text",
    "type",
    "can_open",
}

_RTI_MENU_ROW_TRUE_ONLY_KEYS = {
    "can_search",
    "canAddFavorite",
    "canRemoveFavorite",
    "canRenamePlaylist",
    "canDeletePlaylist",
    "canRemovePlaylistItem",
    "canPlayLoad",
    "canPlayAdd",
    "canPlayInsert",
    "retain_target",
    "hasitems",
    "hasItems",
    "checkbox",
}


def _rti_trim_menu_row(row: Any) -> Any:
    if not isinstance(row, dict):
        return row
    out: Dict[str, Any] = {}
    for key, value in row.items():
        k = _safe_str(key)
        if not k or k.startswith("_"):
            continue
        if k in _RTI_MENU_ROW_ALWAYS_KEYS:
            if value is not None:
                out[k] = value
            continue
        if k in _RTI_MENU_ROW_TRUE_ONLY_KEYS:
            if bool(value):
                out[k] = True
            continue
        if value is None or value == "":
            continue
        if isinstance(value, bool) and not value:
            continue
        if isinstance(value, (list, dict)) and not value:
            continue
        out[k] = value
    return out


def _rti_trim_ws_payload(obj: Any) -> Any:
    if not isinstance(obj, dict):
        return obj
    msg_type = _safe_str(obj.get("t"))
    if msg_type == "queue":
        return _rti_trim_queue_ws_payload(obj)
    if msg_type not in ("menu", "favorites"):
        return obj
    items = obj.get("items")
    if not isinstance(items, list):
        return obj
    out = {k: v for k, v in obj.items() if not _safe_str(k).startswith("_")}
    out["items"] = [_rti_trim_menu_row(row) for row in items]
    return out


def _rti_trim_queue_item(item: Any) -> Any:
    if not isinstance(item, dict):
        return item
    out: Dict[str, Any] = {}
    for key in (
        "title",
        "track",
        "artwork_url",
        "art",
        "playlist index",
        "playlist_index",
        "id",
    ):
        if key in item and item.get(key) not in (None, ""):
            out[key] = item.get(key)
    return out


def _rti_trim_queue_ws_payload(obj: Dict[str, Any]) -> Dict[str, Any]:
    out = {k: v for k, v in obj.items() if not _safe_str(k).startswith("_")}
    payload = obj.get("payload")
    if not isinstance(payload, dict):
        return out
    compact_payload: Dict[str, Any] = {}
    for key in (
        "playlist_cur_index",
        "playlist_tracks",
        "playlist_timestamp",
        "playlist mode",
        "playlist_mode",
    ):
        if key in payload and payload.get(key) not in (None, ""):
            compact_payload[key] = payload.get(key)
    loop = payload.get("playlist_loop")
    if isinstance(loop, list):
        compact_payload["playlist_loop"] = [_rti_trim_queue_item(item) for item in loop]
    out["payload"] = compact_payload
    return out


def _rti_menu_payload_stats(obj: Any) -> Tuple[int, int, int]:
    if not isinstance(obj, dict) or not isinstance(obj.get("items"), list):
        return 0, 0, 0
    item_count = 0
    id_total = 0
    id_max = 0
    for row in obj.get("items") or []:
        if not isinstance(row, dict):
            continue
        item_count += 1
        row_id = _safe_str(row.get("id"))
        row_len = len(row_id.encode("utf-8", errors="ignore"))
        id_total += row_len
        if row_len > id_max:
            id_max = row_len
    return item_count, id_total, id_max


def _safe_str(x: Any) -> str:
    if x is None:
        return ""
    try:
        return str(x)
    except Exception:
        return ""




def _is_loopback_host(h: str) -> bool:
    h = _safe_str(h).strip().lower()
    return h in ("", "127.0.0.1", "localhost", "::1")


def _guess_local_base(port: int = 9000) -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = _safe_str(s.getsockname()[0]).strip()
        finally:
            s.close()
        if ip and not _is_loopback_host(ip):
            return f"http://{ip}:{port}"
    except Exception:
        pass
    return ""


def _public_lms_base() -> str:
    # Priority: saved setup/public -> env hint -> effective LMS_BASE when non-loopback -> guessed local host
    saved = _safe_str(_setup_cache.get("public_lms_base")).strip().rstrip("/") if isinstance(_setup_cache, dict) else ""
    if saved:
        return saved
    envb = _safe_str(os.getenv("PUBLIC_LMS_BASE")).strip().rstrip("/")
    if envb:
        return envb
    try:
        pu = urllib.parse.urlsplit(LMS_BASE)
        if pu.scheme and pu.netloc and not _is_loopback_host(pu.hostname or ""):
            return LMS_BASE.rstrip("/")
        if pu.scheme and pu.port:
            guessed = _guess_local_base(pu.port)
            if guessed:
                return guessed.rstrip("/")
    except Exception:
        pass
    guessed = _guess_local_base(9000)
    if guessed:
        return guessed.rstrip("/")
    return ""


def _public_broker_base() -> str:
    base = _safe_str(BROKER_PUBLIC_BASE).strip().rstrip("/")
    if base:
        return base
    guessed = _guess_local_base(LISTEN_PORT)
    if guessed:
        return guessed.rstrip("/")
    return f"http://127.0.0.1:{LISTEN_PORT}"


def _b64u_text(s: str) -> str:
    raw = _safe_str(s).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_text_dec(s: str) -> str:
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8")


def _broker_main_art_url(playerid: str, version: Any = "", size: int = 500) -> str:
    base = _public_broker_base().rstrip("/")
    q = {"playerid": _safe_str(playerid), "size": str(size)}
    v = _safe_str(version)
    if v:
        q["v"] = v
    return base + "/art/main?" + urllib.parse.urlencode(q)


def _broker_panel_asset_url(filename: str, version: Any = "") -> str:
    base = _public_broker_base().rstrip("/")
    v = _safe_str(version)
    suffix = ("?" + urllib.parse.urlencode({"v": v})) if v else ""
    return base + "/panel/assets/" + _safe_str(filename).strip().lstrip("/") + suffix


def _broker_source_art_url(filename: str, version: Any = "", size: int = 100) -> str:
    base = _public_broker_base().rstrip("/")
    q = {"name": _safe_str(filename).strip().lstrip("/"), "size": str(size)}
    v = _safe_str(version)
    if v:
        q["v"] = v
    return base + "/art/source?" + urllib.parse.urlencode(q)


def _broker_list_art_url(item_id: str, version: Any = "", rounded: bool = False) -> str:
    base = _public_broker_base().rstrip("/")
    q = {"id": _safe_str(item_id)}
    v = _safe_str(version)
    if v:
        q["v"] = v
    if rounded:
        q["r"] = "1"
    return base + "/art/list?" + urllib.parse.urlencode(q)


def _broker_rounded_list_art_url(src: str, version: Any = "") -> str:
    s = _safe_str(src).strip()
    if not s:
        return _broker_list_art_url("0", version, rounded=True)
    if _is_broker_art_url(s):
        return s
    norm = _normalize_art_url(s)
    if not norm:
        return _broker_list_art_url("0", version, rounded=True)
    return _broker_list_art_url("u." + _b64u_text(norm), version, rounded=True)


def _player_list_art_id(playerid: str) -> str:
    return "p." + _b64u_text(_safe_str(playerid).strip())


def _extract_cover_id_from_pathish(u: str) -> str:
    s = _safe_str(u).strip()
    if not s:
        return ""
    try:
        p = urllib.parse.urlsplit(s)
        path = p.path or s
    except Exception:
        path = s
    m = _re.search(r"/music/([^/]+)/cover(?:_[0-9]+x[0-9]+_o)?$", path, flags=_re.IGNORECASE)
    if m:
        return _safe_str(m.group(1))
    return ""


def _resize_local_cover_path(path: str, size: int) -> str:
    p = _safe_str(path).strip()
    if not p:
        return p
    if _re.search(r"/music/[^/]+/cover(?:_[0-9]+x[0-9]+_o)?$", p, flags=_re.IGNORECASE):
        p = _re.sub(r"/cover(?:_[0-9]+x[0-9]+_o)?$", f"/cover_{size}x{size}_o", p, flags=_re.IGNORECASE)
    return p


def _fallback_art_path(size: int) -> str:
    return f"/music/0/cover_{size}x{size}_o"


def _candidate_item_ids(it: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    for k in ("coverid", "cover_id", "artwork_track_id", "id"):
        v = _safe_str(it.get(k)).strip()
        if v and v not in out:
            out.append(v)
    src = _safe_str(it.get("artwork_url") or "").strip()
    cid = _extract_cover_id_from_pathish(src)
    if cid and cid not in out:
        out.append(cid)
    return out


def _item_list_art_id(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return "0"

    src = _safe_str(it.get("artwork_url") or "").strip()
    if src and not _is_broker_art_url(src):
        norm = _normalize_art_url(src)
        # For remote/Spotty/radio/imageproxy artwork, preserve the source URL
        # instead of collapsing to /music/<id>/cover from the item id. Remote
        # ids are often negative numeric values and resolve to generic icons.
        if norm.startswith("http://") or norm.startswith("https://"):
            try:
                p = urllib.parse.urlsplit(norm)
                host = (p.hostname or "").lower()
            except Exception:
                p = urllib.parse.SplitResult("", "", norm, "", "")
                host = ""
            lms_host = ""
            broker_host = ""
            try:
                lms_host = (urllib.parse.urlsplit(LMS_BASE).hostname or "").lower()
            except Exception:
                pass
            try:
                broker_host = (urllib.parse.urlsplit(_public_broker_base()).hostname or "").lower()
            except Exception:
                pass
            if host and host not in ("127.0.0.1", "localhost", "::1", lms_host, broker_host):
                return "u." + _b64u_text(norm)

        # Local LMS cover paths can still use a compact cover id.
        cid = _extract_cover_id_from_pathish(norm)
        if cid and ":" not in cid and "/" not in cid and "?" not in cid and "&" not in cid:
            return cid

        # Non-local absolute/opaque paths should stay URL-backed.
        if norm and (norm.startswith("http://") or norm.startswith("https://") or "/imageproxy/" in norm):
            return "u." + _b64u_text(norm)

    for v in _candidate_item_ids(it):
        if ":" not in v and "/" not in v and "?" not in v and "&" not in v:
            return v

    if src and not _is_broker_art_url(src):
        return "u." + _b64u_text(_normalize_art_url(src))
    return "0"


def _current_playlist_item(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict):
        return None
    loop = payload.get("playlist_loop")
    cur_idx = _safe_str(payload.get("playlist_cur_index"))
    if not isinstance(loop, list):
        return None
    picked = None
    for it in loop:
        if not isinstance(it, dict):
            continue
        if cur_idx and _safe_str(it.get("playlist index")) == cur_idx:
            picked = it
            break
    if picked is None:
        for it in loop:
            if isinstance(it, dict):
                picked = it
                break
    return picked if isinstance(picked, dict) else None


def _is_broker_art_url(src: str) -> bool:
    s = _safe_str(src).strip()
    return bool(s and ("/art/main" in s or "/art/list" in s))


def _main_art_version(payload: Dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        return ""
    parts: List[str] = []
    for v in (
        payload.get("playlist_timestamp"),
        payload.get("playlist_cur_index"),
        payload.get("current_title"),
    ):
        sv = _safe_str(v).strip()
        if sv:
            parts.append(sv)
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        for v in (rm.get("id"), rm.get("title"), rm.get("album"), rm.get("artist"), rm.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    picked = _current_playlist_item(payload)
    if isinstance(picked, dict):
        for v in (picked.get("playlist index"), picked.get("id"), picked.get("title"), picked.get("album"), picked.get("artist"), picked.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    version = "|".join(parts[:8])
    if not version:
        return ""
    return hashlib.sha1(version.encode("utf-8", errors="ignore")).hexdigest()[:16]


def _choose_main_art_source(playerid: str, payload: Dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        return ""

    # Prefer the explicit now-playing artwork first. For Spotty/radio/remote
    # sources this is usually the only authoritative image and can differ from
    # playlist/list-item cover lookups.
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        src = _safe_str(rm.get("artwork_url") or "").strip()
        if src and not _is_broker_art_url(src):
            return src

    src = _safe_str(payload.get("artwork_url") or "").strip()
    if src and not _is_broker_art_url(src):
        return src

    # Then try the current playlist item. This helps local library playback,
    # but should not override explicit remoteMeta art above.
    picked = _current_playlist_item(payload)
    if isinstance(picked, dict):
        src = _safe_str(picked.get("artwork_url") or "").strip()
        if src and not _is_broker_art_url(src):
            return src
        iid = _item_list_art_id(picked)
        if iid and iid != "0" and not iid.startswith("u."):
            return f"/music/{iid}/cover_500x500_o"

    # Finally fall back to local LMS cover lookup by id where available.
    if isinstance(rm, dict):
        iid = _safe_str(rm.get("id") or "").strip()
        if iid and ":" not in iid and "/" not in iid and "?" not in iid and "&" not in iid:
            return f"/music/{iid}/cover_500x500_o"
    return ""


def _rewrite_status_art_for_broker(payload: Any, playerid: str) -> None:
    if not isinstance(payload, dict):
        return
    pid = _safe_str(playerid).strip()
    if not pid:
        return
    main_version = _main_art_version(payload)
    list_version = _safe_str(payload.get("playlist_timestamp") or payload.get("playlist_cur_index") or main_version or "")
    src = _choose_main_art_source(pid, payload)
    if src:
        _main_art_source_by_playerid[pid] = src
    payload["artwork_url"] = _broker_main_art_url(pid, main_version, 500)
    payload["artwork_url2"] = _broker_main_art_url(pid, main_version, 1080)
    rm = payload.get("remoteMeta")
    if not isinstance(rm, dict):
        rm = {}
        payload["remoteMeta"] = rm
    rm["artwork_url"] = _broker_main_art_url(pid, main_version, 500)
    rm["artwork_url2"] = _broker_main_art_url(pid, main_version, 1080)

    loop = payload.get("playlist_loop")
    provider = _provider_from_payload(payload)
    live_radio_queue = (
        bool(payload.get("is_live_radio"))
        or provider in ("radio", "iheart")
        or (
            provider not in ("pandora", "spotify", "podcast")
            and
            _safe_int(payload.get("remote"), 0) != 0
            and _safe_int(payload.get("playlist_tracks"), 0) <= 1
        )
    )
    if isinstance(loop, list):
        for it in loop:
            if not isinstance(it, dict):
                continue
            if live_radio_queue:
                # TuneIn can put its complete metadata query string in the
                # queue artwork URL. Keep RTI on /art/list but use a compact
                # player-backed id instead of embedding that long URL.
                it["artwork_url"] = _broker_list_art_url(_player_list_art_id(pid), main_version or list_version)
            else:
                it["artwork_url"] = _broker_list_art_url(_item_list_art_id(it), list_version)




def _queue_refresh_signature(payload: Dict[str, Any], pid: str = "") -> str:
    if not isinstance(payload, dict):
        return ""
    parts: List[str] = []
    for v in (payload.get("playlist_timestamp"), payload.get("playlist_tracks"), payload.get("np_source"), payload.get("source"), payload.get("plugin"), payload.get("service")):
        sv = _safe_str(v).strip()
        if sv:
            parts.append(sv)
    rm0 = payload.get("remoteMeta") or {}
    if isinstance(rm0, dict):
        for v in (rm0.get("source"), rm0.get("plugin"), rm0.get("service")):
            sv = _safe_str(v).strip()
            if sv:
                parts.append(sv)
    if pid.lower() in _podcast_players:
        return "|".join(parts)
    rm = payload.get("remoteMeta") or {}
    if isinstance(rm, dict):
        for v in (rm.get("id"), rm.get("title"), rm.get("album"), rm.get("artist"), rm.get("artwork_url")):
            sv = _safe_str(v).strip()
            if sv and not _is_broker_art_url(sv):
                parts.append(sv)
    return "|".join(parts[:10])


async def _broadcast_queue_snapshot_for_player(pid: str, pname: str) -> None:
    try:
        st = await full_queue_status_for_push(pid)
        if not isinstance(st, dict) or not st:
            return
        await ws_broadcast({
            "t": "queue",
            "ok": True,
            "playerid": pid,
            "player_name": pname,
            "payload": st
        })
    except Exception:
        pass


def _schedule_podcast_selection_refresh(pid: str, expected_title: str) -> None:
    key = pid.lower()
    _podcast_players.add(key)
    expected_title = _safe_str(expected_title).splitlines()[0].strip()
    generation = _podcast_refresh_generation.get(key, 0) + 1
    _podcast_refresh_generation[key] = generation

    async def refresh_when_ready() -> None:
        for delay in (0.35, 0.75, 1.25, 2.0, 3.0, 4.0):
            await asyncio.sleep(delay)
            if _podcast_refresh_generation.get(key) != generation:
                return
            try:
                st = await lms.status(pid, 1)
                actual = _clean_text(
                    st.get("current_title")
                    or ((st.get("remoteMeta") or {}).get("title") if isinstance(st.get("remoteMeta"), dict) else "")
                )
                if actual and _norm_key(actual) == _norm_key(expected_title):
                    await _broadcast_queue_snapshot_for_player(
                        pid, _playerid_to_name.get(key, "")
                    )
                    return
            except Exception:
                continue

    asyncio.create_task(refresh_when_ready())


async def _collapse_iheart_queue_later(pid: str) -> None:
    try:
        await asyncio.sleep(3.0)
        st = await full_queue_status_for_push(pid, 200)
        loop = st.get("playlist_loop") if isinstance(st, dict) else None
        if not isinstance(loop, list) or len(loop) <= 1:
            return
        iheart_hay = " ".join(
            _safe_str(v).strip().lower()
            for item in loop if isinstance(item, dict)
            for v in (item.get("url"), item.get("file"), item.get("artwork_url"), item.get("title"))
        )
        if "iheart" not in iheart_hay and "streamtheworld.com" not in iheart_hay:
            return
        current = _safe_int(st.get("playlist_cur_index"), 0)
        for index in range(len(loop) - 1, -1, -1):
            if index != current:
                await lms.rpc(pid, ["playlist", "delete", index])
    except Exception as e:
        dbg(f"iHeart queue cleanup failed playerid={pid}: {_safe_str(e)}")

def _source_to_fetch_url(src: str, size: int) -> str:
    s = _safe_str(src).strip()
    if not s:
        return LMS_BASE.rstrip("/") + _fallback_art_path(size)

    # Already a broker art URL - fall back to latest known source behavior.
    if "/art/main" in s or "/art/list" in s:
        return LMS_BASE.rstrip("/") + _fallback_art_path(size)

    try:
        p = urllib.parse.urlsplit(s)
    except Exception:
        p = urllib.parse.SplitResult("", "", s, "", "")

    if p.scheme in ("http", "https"):
        host = (p.hostname or "").lower()
        netloc = (p.netloc or "").lower()
        lms_host = ""
        lms_netloc = ""
        try:
            lms_parts = urllib.parse.urlsplit(LMS_BASE)
            lms_host = (lms_parts.hostname or "").lower()
            lms_netloc = (lms_parts.netloc or "").lower()
        except Exception:
            lms_host = ""
            lms_netloc = ""
        broker_host = ""
        broker_netloc = ""
        try:
            broker_parts = urllib.parse.urlsplit(_public_broker_base())
            broker_host = (broker_parts.hostname or "").lower()
            broker_netloc = (broker_parts.netloc or "").lower()
        except Exception:
            broker_host = ""
            broker_netloc = ""
        public_lms_host = ""
        public_lms_netloc = ""
        try:
            public_lms_parts = urllib.parse.urlsplit(_public_lms_base())
            public_lms_host = (public_lms_parts.hostname or "").lower()
            public_lms_netloc = (public_lms_parts.netloc or "").lower()
        except Exception:
            public_lms_host = ""
            public_lms_netloc = ""

        local_netlocs = {v for v in (lms_netloc, broker_netloc, public_lms_netloc) if v}
        is_loopback = host in ("127.0.0.1", "localhost", "::1")
        if is_loopback or netloc in local_netlocs:
            path = p.path or "/"
            if path.startswith("/music/"):
                path = _resize_local_cover_path(path, size)
            if not path.startswith("/"):
                path = "/" + path
            return LMS_BASE.rstrip("/") + path + ((("?" + p.query) if p.query else ""))
        return s

    path = s
    if not path.startswith("/"):
        path = "/" + path
    if path.startswith("/music/"):
        path = _resize_local_cover_path(path, size)
    return LMS_BASE.rstrip("/") + path


_ART_CACHE_MAX = 192
_art_resized_cache: "OrderedDict[str, Tuple[bytes, str]]" = OrderedDict()


def _art_cache_get(key: str) -> Optional[Tuple[bytes, str]]:
    try:
        hit = _art_resized_cache.get(key)
        if hit is None:
            return None
        _art_resized_cache.move_to_end(key)
        return hit
    except Exception:
        return None


def _art_cache_put(key: str, body: bytes, ctype: str) -> None:
    try:
        _art_resized_cache[key] = (body, ctype)
        _art_resized_cache.move_to_end(key)
        while len(_art_resized_cache) > _ART_CACHE_MAX:
            _art_resized_cache.popitem(last=False)
    except Exception:
        pass


def _target_square_size(kind: str, size: int) -> int:
    s = _safe_int(size, 0)
    if kind == "list":
        if s < 50:
            s = 160
        if s > 200:
            s = 200
        return s
    if s < 50:
        s = 500
    if s > 2000:
        s = 2000
    return s


def _resize_image_bytes(body: bytes, size: int, rounded: bool = False, matte: str = "") -> Tuple[bytes, str]:
    with Image.open(io.BytesIO(body)) as img:
        img.load()
        fmt = (img.format or "").upper()
        mode = (img.mode or "").upper()
        resample = getattr(Image, "Resampling", Image).LANCZOS
        fitted = ImageOps.fit(img, (size, size), method=resample, centering=(0.5, 0.5))

        alpha = ("A" in mode) or (fmt in ("PNG", "WEBP") and "transparency" in img.info)
        out = io.BytesIO()
        if rounded:
            if fitted.mode != "RGBA":
                fitted = fitted.convert("RGBA")
            if matte == "white" and fitted.getbbox() is not None:
                white_tile = Image.new("RGBA", (size, size), (255, 255, 255, 255))
                white_tile.alpha_composite(fitted)
                fitted = white_tile
            radius = max(4, min(14, size // 14))
            mask = Image.new("L", (size, size), 0)
            draw = ImageDraw.Draw(mask)
            draw.rounded_rectangle((0, 0, size, size), radius=radius, fill=255)
            existing_alpha = fitted.getchannel("A")
            fitted.putalpha(ImageChops.multiply(existing_alpha, mask))
            fitted.save(out, format="PNG", optimize=True)
            return out.getvalue(), "image/png"
        if alpha:
            fitted.save(out, format="PNG", optimize=True)
            return out.getvalue(), "image/png"
        if fitted.mode not in ("RGB", "L"):
            fitted = fitted.convert("RGB")
        fitted.save(out, format="JPEG", quality=88, optimize=True, progressive=True)
        return out.getvalue(), "image/jpeg"


async def _fetch_image_response(url: str, size: int, kind: str, rounded: bool = False) -> web.Response:
    await lms.start()
    assert lms._session is not None
    target = _target_square_size(kind, size)
    matte = "white" if rounded and _is_pyrrha_icon_url(url) else ""
    cache_key = f"{kind}|{target}|{'rounded' if rounded else 'square'}|{matte}|{url}"
    cached = _art_cache_get(cache_key)
    if cached is not None:
        body, ctype = cached
        return web.Response(body=body, content_type=ctype, headers={"Cache-Control": "public, max-age=300"})
    try:
        # LMS can briefly serve the previous cover after its status metadata
        # has already advanced. Since each main-art URL is versioned, wait for
        # that transition before filling its otherwise long-lived cache entry.
        if kind == "main":
            await asyncio.sleep(0.75)
        async with lms._session.get(url) as resp:
            body = await resp.read()
            if resp.status != 200 or not body:
                raise RuntimeError(f"art_fetch_http_{resp.status}")
            try:
                resized_body, ctype = _resize_image_bytes(body, target, rounded=rounded, matte=matte)
            except Exception:
                resized_body = body
                ctype = _safe_str(resp.headers.get("Content-Type") or "image/jpeg")
            _art_cache_put(cache_key, resized_body, ctype)
            return web.Response(body=resized_body, content_type=ctype, headers={"Cache-Control": "public, max-age=300"})
    except Exception:
        return web.Response(status=404, text="art_not_found")


async def _fetch_list_image_or_default(src: str, size: int, rounded: bool = False) -> web.Response:
    url = _source_to_fetch_url(src, size)
    resp = await _fetch_image_response(url, size, "list", rounded=rounded)
    if resp.status != 404:
        return resp
    fallback_url = LMS_BASE.rstrip("/") + _fallback_art_path(size)
    return await _fetch_image_response(fallback_url, size, "list", rounded=rounded)


async def art_main(req: web.Request) -> web.Response:
    pid = _safe_str(req.query.get("playerid") or "").strip()
    if not pid:
        return web.Response(status=400, text="missing_playerid")

    # Prefer the preserved pre-rewrite source captured during status handling.
    # Recomputing from the rewritten snapshot can collapse remote artwork back
    # to generic /music/<id>/cover lookups.
    src = _safe_str(_main_art_source_by_playerid.get(pid)).strip()
    if not src:
        snap = _last_status_by_key.get(pid) or {}
        if isinstance(snap, dict):
            src = _choose_main_art_source(pid, snap)
    size = _target_square_size("main", _safe_int(req.query.get("size"), 500))
    url = _source_to_fetch_url(src, size)
    return await _fetch_image_response(url, size, "main", rounded=False)


async def art_list(req: web.Request) -> web.Response:
    item_id = _safe_str(req.query.get("id") or "").strip()
    if not item_id:
        return web.Response(status=400, text="missing_id")
    src = ""
    if item_id == "0":
        src = ""
    elif item_id.startswith("u."):
        try:
            src = _b64u_text_dec(item_id[2:])
        except Exception:
            src = ""
    elif item_id.startswith("p."):
        try:
            pid = _b64u_text_dec(item_id[2:])
        except Exception:
            pid = ""
        src = _safe_str(_main_art_source_by_playerid.get(pid) or _main_art_source_by_playerid.get(pid.lower())).strip()
    elif item_id.startswith("http://") or item_id.startswith("https://") or item_id.startswith("/"):
        src = item_id
    else:
        src = f"/music/{item_id}/cover_200x200_o"
    size = _target_square_size("list", _safe_int(req.query.get("size"), 160))
    rounded = _safe_str(req.query.get("r")).strip().lower() in ("1", "true", "yes")
    return await _fetch_list_image_or_default(src, size, rounded=rounded)


async def art_source(req: web.Request) -> web.Response:
    filename = _safe_str(req.query.get("name") or "").strip().lower()
    allowed = {
        "source-pandora.png",
        "source-spotify.png",
        "source-qobuz.png",
        "source-bbc.png",
        "source-iheart.png",
        "source-tidal.png",
        "source-pyrrha.png",
    }
    if filename not in allowed:
        return web.Response(status=404, text="source_art_not_found")
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets", filename)
    if not os.path.isfile(path):
        return web.Response(status=404, text="source_art_not_found")
    try:
        size = _target_square_size("list", _safe_int(req.query.get("size"), 100))
        with Image.open(path) as img:
            img.load()
            source = img.convert("RGBA")
        if source.size != (size, size):
            resample = getattr(Image, "Resampling", Image).LANCZOS
            source = ImageOps.fit(source, (size, size), method=resample, centering=(0.5, 0.5))
        out = io.BytesIO()
        source.save(out, format="PNG")
        return web.Response(body=out.getvalue(), content_type="image/png", headers={"Cache-Control": "public, max-age=300"})
    except Exception:
        return web.Response(status=404, text="source_art_not_found")

# ---------------- Setup config helpers ----------------

_setup_cache: Dict[str, Any] = {}
_home_menu_cache: List[Dict[str, Any]] = []

def _iheart_region_setting(value: Any = None) -> str:
    region = _safe_str(_setup_cache.get("iheart_region") if value is None else value).strip().upper()
    if region == "MC":
        region = "MX"
    return region if region in ("US", "NZ", "AU", "CA", "MX") else ""


def _iheart_skip_intro_when_filtered() -> bool:
    return bool(_setup_cache.get("iheart_skip_intro_when_filtered", False))


def _iheart_label_region(label: Any) -> str:
    upper = _safe_str(label).upper()
    for candidate in ("US", "NZ", "AU", "CA", "MX", "MC"):
        if f"({candidate})" in upper:
            return "MX" if candidate == "MC" else candidate
    return ""


def _filter_iheart_region_items(items: List[Any]) -> List[Any]:
    region = _iheart_region_setting()
    if not region:
        return items

    filtered: List[Any] = []
    for item in items:
        if not isinstance(item, dict):
            filtered.append(item)
            continue
        tagged_region = _iheart_label_region(_pick_label(item))
        if not tagged_region or tagged_region == region:
            filtered.append(item)
    return filtered


def _iheart_genre_follow_item(items: List[Any], region: str = "") -> Optional[Dict[str, Any]]:
    fallback: Optional[Dict[str, Any]] = None
    for item in items:
        if not isinstance(item, dict):
            continue
        go_action = (item.get("actions") or {}).get("go")
        if not isinstance(go_action, dict):
            continue
        label_key = _norm_key(_pick_label(item))
        if "genre" not in label_key or "podcast" in label_key:
            continue
        if (
            ("station" in label_key and ("live" in label_key or "genre" in label_key))
            or "radiobygenre" in label_key
        ):
            tagged_region = _iheart_label_region(_pick_label(item))
            if region and tagged_region == region:
                return item
            if fallback is None and (not region or not tagged_region):
                fallback = item
    return fallback

def _filter_spotty_menu_items(items: List[Any]) -> List[Any]:
    if not bool(_setup_cache.get("hide_spotty_transfer_playback", True)):
        return items
    filtered: List[Any] = []
    for item in items:
        if not isinstance(item, dict):
            filtered.append(item)
            continue
        if _norm_key(_pick_label(item)) == "transferplayback":
            continue
        filtered.append(item)
    return filtered


def _pandora_accounts_cache() -> List[Dict[str, Any]]:
    saved = _setup_cache.get("pandora_accounts")
    saved = saved if isinstance(saved, list) else []
    out: List[Dict[str, Any]] = []
    for index in range(4):
        row = saved[index] if index < len(saved) and isinstance(saved[index], dict) else {}
        username = _safe_str(row.get("username")).strip()
        password = _safe_str(row.get("password"))
        out.append({
            "enabled": bool(row.get("enabled", False) or (username and password)),
            "name": _safe_str(row.get("name") or f"Pandora {chr(65 + index)}").strip(),
            "username": username,
            "password": password,
        })
    return out


def _broker_mode() -> str:
    mode = _safe_str(_setup_cache.get("broker_mode")).strip().lower()
    return mode if mode in ("full", "light") else "full"


def _broker_light_mode() -> bool:
    return _broker_mode() == "light"


def _jivelite_player_slot_setting(value: Any = None) -> str:
    raw = _safe_str(_setup_cache.get("jivelite_player_slot") if value is None else value).strip().lower()
    if raw in ("", "auto"):
        return "auto"
    if raw in ("none", "off", "disabled"):
        return "none"
    slot = _safe_int(raw, 0)
    if 1 <= slot <= MAX_UNIT_PLAYERS:
        return str(slot)
    return "auto"


def _normalize_unique_menu_orders(rows: List[Dict[str, Any]], step: int = 10) -> List[Dict[str, Any]]:
    """Return menu rows sorted with unique order values."""
    out: List[Dict[str, Any]] = []
    used: Set[int] = set()
    for row in sorted(
        [dict(r) for r in rows if isinstance(r, dict)],
        key=lambda r: (
            _safe_int(r.get("order"), 100),
            _safe_str(r.get("label") or r.get("source_label") or r.get("key")),
        ),
    ):
        order = max(0, _safe_int(row.get("order"), 100))
        while order in used:
            order += step
        used.add(order)
        row["order"] = order
        out.append(row)
    return out


def _next_home_app_order(rows: List[Dict[str, Any]], start: int = 100, stop: int = 500, step: int = 10) -> int:
    used = {
        _safe_int(row.get("order"), 0)
        for row in rows
        if isinstance(row, dict)
    }
    for order in range(start, stop + 1, step):
        if order not in used:
            return order
    return stop


def _load_setup_config() -> None:
    """Load broker setup JSON from disk into caches. Safe to call multiple times."""
    global _setup_cache, _home_menu_cache, LMS_BASE, LMS_JSONRPC, LMS_COMETD

    # Start with defaults
    _setup_cache = {
        "lms_base": "",
        "broker_mode": "full",
        "public_lms_base": "",
        "first_run_update_checked_version": "",
        "hostname_reboot_required_since": 0,
        "hostname_reboot_target": "",
        "home_menu": list(HOME_MENU_DEFAULT),
        "track_drilldown": False,
        "hide_spotty_transfer_playback": True,
        "mymusic_menu": [],
        "radio_menu": [],
        "iheart_region": "",
        "iheart_skip_intro_when_filtered": False,
        "show_analog_outputs": False,
        "license_key": "",
        "license_trial_started_at": 0,
        "legal_accepted": False,
        "legal_accepted_at": 0,
        "legal_terms_version": "",
        "pandora_accounts": [],
        "local_player_mode": "",
        "local_player_friendly_names": {},
        "local_player_rows": [],
        "rti_player_cache": [],
        "jivelite_player_slot": "auto",
        "web_panel_enabled": True,
        "web_panel_bg": "#135093",
        "web_panel_content_bg": "#0e52a5",
        "web_panel_accent": "#ffffff",
        "web_panel_broker_bg": "",
        "web_panel_broker_content_bg": "",
        "web_panel_broker_accent": "",
        "web_panel_material_bg": "",
        "web_panel_material_content_bg": "",
        "web_panel_material_accent": "",
        "web_panel_default_mode": "control",
        "web_panel_card_art": False,
        "web_panel_material_mode": "user",
    }

    try:
        with open(SETUP_JSON_PATH, "r", encoding="utf-8") as f:
            disk = json.load(f)
        if isinstance(disk, dict):
            _setup_cache.update(disk)
    except Exception:
        pass

    # Home menu cache (sorted)
    hm = _setup_cache.get("home_menu")
    if not isinstance(hm, list) or not hm:
        hm = list(HOME_MENU_DEFAULT)
    # sanitize rows
    clean: List[Dict[str, Any]] = []
    for row in hm:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key"))
        if not key:
            continue
        clean.append({
            "key": key,
            "label": _safe_str(row.get("label")) or key,
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
            "type": _safe_str(row.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core",
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "icon": (
                _pyrrha_classic_icon_url()
                if _is_pyrrha_home_item(key, row.get("source_label") or row.get("label") or key)
                else _safe_str(row.get("icon") or "")
            ),
        })
    clean = _normalize_unique_menu_orders(clean)
    _setup_cache["home_menu"] = clean
    _home_menu_cache = clean

    # A blank saved value explicitly means LMS is local to the broker.
    lmsb = _safe_str(_setup_cache.get("lms_base")).rstrip("/")
    if not lmsb:
        lmsb = LOCAL_LMS_BASE
    LMS_BASE = lmsb
    LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
    LMS_COMETD = LMS_BASE + "/cometd"


def _save_setup_config() -> None:
    """Persist setup JSON to disk."""
    payload = {
        "lms_base": _safe_str(_setup_cache.get("lms_base")).strip(),
        "broker_mode": _broker_mode(),
        "public_lms_base": _safe_str(_setup_cache.get("public_lms_base")).strip(),
        "update_manifest_url": _safe_str(_setup_cache.get("update_manifest_url")).strip(),
        "first_run_update_checked_version": _safe_str(_setup_cache.get("first_run_update_checked_version")).strip(),
        "hostname_reboot_required_since": _safe_int(_setup_cache.get("hostname_reboot_required_since"), 0),
        "hostname_reboot_target": _safe_str(_setup_cache.get("hostname_reboot_target")).strip(),
        "home_menu": (_setup_cache.get("home_menu") if isinstance(_setup_cache.get("home_menu"), list) else (_home_menu_cache if isinstance(_home_menu_cache, list) else list(HOME_MENU_DEFAULT))),
        "track_drilldown": bool(_setup_cache.get("track_drilldown", False)),
        "hide_spotty_transfer_playback": bool(_setup_cache.get("hide_spotty_transfer_playback", True)),
        "mymusic_menu": _mymusic_menu_cache(),
        "radio_menu": _radio_menu_cache(),
        "iheart_region": _iheart_region_setting(),
        "iheart_skip_intro_when_filtered": _iheart_skip_intro_when_filtered(),
        "show_analog_outputs": bool(_setup_cache.get("show_analog_outputs", False)),
        "license_key": _safe_str(_setup_cache.get("license_key")).strip(),
        "license_trial_started_at": _safe_int(_setup_cache.get("license_trial_started_at"), 0),
        "legal_accepted": bool(_setup_cache.get("legal_accepted", False)),
        "legal_accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        "legal_terms_version": _safe_str(_setup_cache.get("legal_terms_version")),
        "pandora_accounts": _pandora_accounts_cache(),
        "local_player_mode": _safe_str(_setup_cache.get("local_player_mode")).lower(),
        "local_player_friendly_names": (
            _setup_cache.get("local_player_friendly_names")
            if isinstance(_setup_cache.get("local_player_friendly_names"), dict)
            else {}
        ),
        "local_player_rows": (
            _setup_cache.get("local_player_rows")
            if isinstance(_setup_cache.get("local_player_rows"), list)
            else []
        ),
        "jivelite_player_slot": _jivelite_player_slot_setting(),
        "web_panel_enabled": bool(_setup_cache.get("web_panel_enabled", True)),
        "web_panel_bg": _safe_panel_color(_setup_cache.get("web_panel_bg"), "#135093"),
        "web_panel_content_bg": _safe_panel_color(_setup_cache.get("web_panel_content_bg"), "#0e52a5"),
        "web_panel_accent": _safe_panel_color(_setup_cache.get("web_panel_accent"), "#ffffff"),
        "web_panel_broker_bg": _safe_optional_panel_color(_setup_cache.get("web_panel_broker_bg")),
        "web_panel_broker_content_bg": _safe_optional_panel_color(_setup_cache.get("web_panel_broker_content_bg")),
        "web_panel_broker_accent": _safe_optional_panel_color(_setup_cache.get("web_panel_broker_accent")),
        "web_panel_material_bg": _safe_optional_panel_color(_setup_cache.get("web_panel_material_bg")),
        "web_panel_material_content_bg": _safe_optional_panel_color(_setup_cache.get("web_panel_material_content_bg")),
        "web_panel_material_accent": _safe_optional_panel_color(_setup_cache.get("web_panel_material_accent")),
        "web_panel_default_mode": _safe_panel_mode(_setup_cache.get("web_panel_default_mode")),
        "web_panel_card_art": bool(_setup_cache.get("web_panel_card_art", False)),
        "web_panel_material_mode": _safe_material_mode(_setup_cache.get("web_panel_material_mode")),
    }
    tmp_path = SETUP_JSON_PATH + ".tmp"
    os.makedirs(os.path.dirname(SETUP_JSON_PATH), exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(tmp_path, SETUP_JSON_PATH)


def _mymusic_menu_cache() -> List[Dict[str, Any]]:
    rows = _setup_cache.get("mymusic_menu")
    out: List[Dict[str, Any]] = []
    if not isinstance(rows, list):
        return out
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key") or row.get("id")).strip()
        if not key:
            continue
        out.append({
            "key": key,
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "alias": _safe_str(row.get("alias") or row.get("label") or row.get("source_label") or key),
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
        })
    return out


def _radio_menu_cache() -> List[Dict[str, Any]]:
    rows = _setup_cache.get("radio_menu")
    out: List[Dict[str, Any]] = []
    if not isinstance(rows, list):
        return out
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key") or row.get("id")).strip()
        if not key:
            continue
        out.append({
            "key": key,
            "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
            "alias": _safe_str(row.get("alias") or row.get("label") or row.get("source_label") or key),
            "enabled": bool(row.get("enabled", True)),
            "order": _safe_int(row.get("order"), 100),
            "icon": _safe_str(row.get("icon") or ""),
        })
    return out


def _menu_row_saved_lookup(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    lookup: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        for value in (
            row.get("key"),
            row.get("id"),
            row.get("source_label"),
            row.get("label"),
            row.get("alias"),
        ):
            raw = _safe_str(value).strip()
            if raw:
                lookup[raw] = row
                lookup[_norm_key(raw)] = row
    return lookup


def _menu_saved_row_for_item(saved_lookup: Dict[str, Dict[str, Any]], item: Dict[str, Any]) -> Dict[str, Any]:
    for value in (
        item.get("key"),
        item.get("id"),
        item.get("source_label"),
        item.get("label"),
        item.get("text"),
        item.get("title"),
        item.get("name"),
        _pick_label(item),
    ):
        raw = _safe_str(value).strip()
        if raw and raw in saved_lookup:
            return saved_lookup[raw]
        norm = _norm_key(raw)
        if norm and norm in saved_lookup:
            return saved_lookup[norm]
    return {}


def _saved_enabled_or_default(saved: Dict[str, Any], default_enabled: bool) -> bool:
    if isinstance(saved, dict) and "enabled" in saved:
        return bool(saved.get("enabled"))
    return bool(default_enabled)


def _merge_mymusic_menu_with_discovered(discovered: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    saved_lookup = _menu_row_saved_lookup(_mymusic_menu_cache())
    out: List[Dict[str, Any]] = []
    next_order = 10
    for it in discovered:
        key = _safe_str(it.get("key") or it.get("id")).strip()
        if not key:
            continue
        source_label = _safe_str(it.get("source_label") or it.get("label") or key)
        saved = _menu_saved_row_for_item(saved_lookup, it)
        default_enabled = _mymusic_menu_default_enabled(key, source_label)
        order = _safe_int(saved.get("order"), _safe_int(it.get("order"), next_order))
        out.append({
            "key": key,
            "source_label": source_label,
            "alias": _safe_str(saved.get("alias") or source_label),
            "enabled": _saved_enabled_or_default(saved, default_enabled),
            "order": order,
        })
        next_order += 10
    out.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return out


def _merge_radio_menu_with_discovered(discovered: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    saved_lookup = _menu_row_saved_lookup(_radio_menu_cache())
    out: List[Dict[str, Any]] = []
    next_order = 10
    for it in discovered:
        key = _safe_str(it.get("key") or it.get("id")).strip()
        if not key:
            continue
        source_label = _safe_str(it.get("source_label") or _pick_label(it) or it.get("label") or key)
        saved = _menu_saved_row_for_item(saved_lookup, it)
        default_enabled = _radio_menu_default_enabled(key, source_label)
        fallback_icon = _curated_plugin_home_icon(key, source_label)
        icon = _safe_str(
            saved.get("icon")
            or it.get("icon")
            or it.get("art")
            or fallback_icon
            or ""
        )
        out.append({
            "key": key,
            "source_label": source_label,
            "alias": _safe_str(saved.get("alias") or source_label),
            "enabled": _saved_enabled_or_default(saved, default_enabled),
            "order": _safe_int(saved.get("order"), _safe_int(it.get("order"), next_order)),
            "icon": _normalize_icon_url(icon) if icon else "",
        })
        next_order += 10
    out.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return out


async def _pick_setup_playerid(req: Optional[web.Request] = None) -> str:
    pid = ""
    if req is not None:
        try:
            pid = _safe_str(req.query.get("playerid") or req.query.get("player") or "").strip()
        except Exception:
            pid = ""
    if pid:
        return pid
    if DEFAULT_PLAYERID:
        return DEFAULT_PLAYERID
    try:
        players = await lms.get_players()
        return pick_default_player(players)
    except Exception:
        return ""


async def _discover_mymusic_menu_rows(pid: str) -> List[Dict[str, Any]]:
    top = await _top_menu_raw(pid)
    raw = _extract_menu_items(top)
    rows: List[Dict[str, Any]] = []
    for it in raw:
        if _safe_str(it.get("node")) != "myMusic":
            continue
        key = _safe_str(it.get("id") or "").strip()
        if not key:
            continue
        rows.append({
            "key": key,
            "source_label": _pick_label(it),
            "alias": _pick_label(it),
            "enabled": True,
            "order": _safe_int(it.get("weight"), 100),
        })
    if not any("playlist" in _norm_key(row.get("key")) or "playlist" in _norm_key(row.get("source_label")) for row in rows):
        rows.append({
            "key": "cmd:playlists",
            "source_label": "Playlists",
            "alias": "Playlists",
            "enabled": True,
            "order": 80,
        })
    rows.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return rows


async def _discover_mymusic_menu_merged(pid: str) -> List[Dict[str, Any]]:
    return _merge_mymusic_menu_with_discovered(await _discover_mymusic_menu_rows(pid))


async def _discover_radio_menu_rows(pid: str) -> List[Dict[str, Any]]:
    top = await _top_menu_raw(pid)
    rows: List[Dict[str, Any]] = []
    for it in _extract_menu_items(top):
        if _safe_str(it.get("node")) != "radios":
            continue
        key = _safe_str(it.get("id") or "").strip()
        if not key:
            continue
        rows.append({
            "key": key,
            "source_label": _pick_label(it),
            "alias": _pick_label(it),
            "enabled": True,
            "order": _safe_int(it.get("weight"), 100),
            "icon": _pick_art(it) or _curated_plugin_home_icon(key, _pick_label(it)),
        })
    rows.sort(key=lambda r: (_safe_int(r.get("order"), 100), _safe_str(r.get("source_label"))))
    return rows


async def _discover_radio_menu_merged(pid: str) -> List[Dict[str, Any]]:
    return _merge_radio_menu_with_discovered(await _discover_radio_menu_rows(pid))




async def _myapps_raw(pid: str) -> Dict[str, Any]:
    r = await lms.rpc(pid, ["myapps", "items", 0, 200])
    return (r.get("result") or {})


def _core_home_rows() -> List[Dict[str, Any]]:
    out=[]
    for row in _home_menu_cache:
        key=_safe_str(row.get("key")).strip().lower()
        if key in ("mymusic","radio","favorites"):
            out.append(dict(row))
    if not out:
        out=[dict(r) for r in HOME_MENU_DEFAULT]
    out.sort(key=lambda r: (_safe_int(r.get("order"),100), _safe_str(r.get("label"))))
    return out


def _core_home_icon(key: Any) -> str:
    k = _safe_str(key).strip().lower()
    if k == "mymusic":
        return _broker_panel_asset_url("icon-home-mymusic.svg", APP_VERSION)
    if k == "radio":
        return _broker_panel_asset_url("icon-home-radio.svg", APP_VERSION)
    if k == "favorites":
        return _broker_panel_asset_url("icon-home-favorites.svg", APP_VERSION)
    return ""


def _core_home_icon_path(key: Any) -> str:
    k = _safe_str(key).strip().lower()
    if k == "mymusic":
        return "/panel/assets/icon-home-mymusic.svg?v=" + urllib.parse.quote(APP_VERSION, safe="")
    if k == "radio":
        return "/panel/assets/icon-home-radio.svg?v=" + urllib.parse.quote(APP_VERSION, safe="")
    if k == "favorites":
        return "/panel/assets/icon-home-favorites.svg?v=" + urllib.parse.quote(APP_VERSION, safe="")
    return ""


def _mymusic_menu_default_enabled(key: Any = "", label: Any = "") -> bool:
    hay = _norm_key(" ".join([_safe_str(key), _safe_str(label)]))
    if "musicfolder" in hay or ("music" in hay and "folder" in hay):
        return False
    if "virtuallibrary" in hay or "selectvirtuallibrary" in hay:
        return False
    return True


def _radio_menu_default_enabled(key: Any = "", label: Any = "") -> bool:
    return True


def _home_app_default_enabled(key: Any = "", label: Any = "") -> bool:
    hay = _norm_key(" ".join([_safe_str(key), _safe_str(label)]))
    if "iheart" in hay or "pyrrha" in hay or "bbcsounds" in hay or "bbc" in hay:
        return True
    if "shairtunes" in hay or "airplay" in hay:
        return False
    return False


def _plugin_placement_managed_by_lms(plugin_id: Any = "") -> bool:
    return _safe_str(plugin_id).strip() in ("iHeartRadio", "Pyrrha", "BBCSounds")


def _lms_managed_plugin_row_matches(row: Dict[str, Any], plugin_id: Any = "", label: Any = "") -> bool:
    hay = _norm_key(" ".join([
        _safe_str(plugin_id),
        _safe_str(label),
        _safe_str(row.get("key")),
        _safe_str(row.get("source_label")),
        _safe_str(row.get("label")),
        _safe_str(row.get("alias")),
    ]))
    pid = _safe_str(plugin_id).strip()
    if pid == "iHeartRadio":
        return "iheart" in hay
    if pid == "Pyrrha":
        return "pyrrha" in hay
    if pid == "BBCSounds":
        return "bbcsounds" in hay or "bbc" in hay
    return False


def _set_lms_managed_plugin_visible(plugin_id: Any = "", label: Any = "", enabled: bool = True) -> bool:
    changed = False
    plugin_key = _curated_plugin_home_key(_safe_str(plugin_id))
    source_label = _curated_plugin_home_label(_safe_str(plugin_id), _safe_str(label))
    fallback_icon = _curated_plugin_home_icon(plugin_key, source_label)
    for menu_key in ("home_menu", "radio_menu"):
        rows = _setup_cache.get(menu_key)
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict) or not _lms_managed_plugin_row_matches(row, plugin_id, label):
                continue
            if bool(row.get("enabled", True)) != bool(enabled):
                row["enabled"] = bool(enabled)
                changed = True
    if not changed and bool(enabled) and plugin_key:
        rows = _setup_cache.get("home_menu")
        rows = [dict(row) for row in rows] if isinstance(rows, list) else []
        wanted_source = _norm_key(source_label)
        exists = False
        for row in rows:
            row_key = _safe_str(row.get("key")).strip()
            row_source = _norm_key(row.get("source_label") or row.get("label") or row_key)
            if row_key == plugin_key or (wanted_source and row_source == wanted_source):
                row["enabled"] = True
                exists = True
                changed = True
                break
        if not exists:
            rows.append({
                "key": plugin_key,
                "label": source_label,
                "enabled": True,
                "order": _next_home_app_order(rows),
                "type": "app",
                "source_label": source_label,
                "icon": fallback_icon,
            })
            changed = True
        _setup_cache["home_menu"] = _normalize_unique_menu_orders(rows)
    if changed:
        _save_setup_config()
    return changed


def _curated_plugin_home_default_enabled(plugin_id: Any = "", label: Any = "") -> bool:
    hay = _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))
    if "iheart" in hay:
        return False
    if "shairtunes" in hay or "airplay" in hay:
        return False
    return True


def _curated_plugin_home_icon(plugin_id: Any = "", label: Any = "") -> str:
    plugin_key = _safe_str(plugin_id).strip()
    if plugin_key.lower().startswith("app:"):
        plugin_key = plugin_key[4:]
    hay = _norm_key(" ".join([plugin_key, _safe_str(label)]))
    if "pyrrha" in hay:
        return _pyrrha_classic_icon_url()
    if "frpandora" in hay or "pandora" in hay:
        return _pandora_classic_icon_url(plugin_key, label)
    if "spotty" in hay or "spotify" in hay:
        return _broker_panel_asset_url("badge-spotify.png", APP_VERSION)
    if "qobuz" in hay:
        return _broker_panel_asset_url("badge-qobuz.png", APP_VERSION)
    if "bbcsounds" in hay or "bbc sounds" in hay or "bbcsound" in hay:
        return _broker_panel_asset_url("badge-bbc.png", APP_VERSION)
    if "iheart" in hay:
        return _normalize_icon_url("/plugins/iHeartRadio/html/images/iheartradio.png")
    if "podcast" in hay:
        return _broker_panel_asset_url("icon-podcast.png", APP_VERSION)
    if "shairtunes" in hay or "airplay" in hay:
        return _broker_panel_asset_url("icon-home-radio.svg", APP_VERSION)
    if "tidal" in hay:
        return _broker_panel_asset_url("icon-tidal.png", APP_VERSION)
    return ""


def _curated_plugin_setup_icon_fallback(plugin_id: Any = "", label: Any = "") -> str:
    hay = _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))
    if "frpandora" in hay or "pandora" in hay:
        return _broker_panel_asset_url("icon-pandora.png", APP_VERSION)
    if "pyrrha" in hay:
        return _broker_panel_asset_url("icon-pyrrha.png", APP_VERSION)
    if "iheart" in hay:
        return _broker_panel_asset_url("icon-iheart.png", APP_VERSION)
    if "podcast" in hay:
        return _broker_panel_asset_url("icon-podcast.png", APP_VERSION)
    return _curated_plugin_home_icon(plugin_id, label)


def _is_airplay_service_item(plugin_id: Any = "", label: Any = "") -> bool:
    hay = _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))
    return "shairtunes" in hay or "airplay" in hay


def _curated_saved_icon_or_fallback(plugin_id: Any, label: Any, saved_icon: Any = "", live_icon: Any = "") -> str:
    fallback = _curated_plugin_home_icon(plugin_id, label)
    saved = _safe_str(saved_icon).strip()
    live = _safe_str(live_icon).strip()
    hay = _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))
    if "tidal" in hay and fallback:
        return fallback
    return saved or live or fallback or ""


def _is_pyrrha_home_item(plugin_id: Any = "", label: Any = "") -> bool:
    return "pyrrha" in _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))


def _pyrrha_classic_icon_url() -> str:
    return _normalize_icon_url("/plugins/Pyrrha/html/images/icon.png")


def _pandora_classic_icon_url(plugin_id: Any = "", label: Any = "") -> str:
    hay = _norm_key(" ".join([_safe_str(plugin_id), _safe_str(label)]))
    for index, letter in enumerate("abcd"):
        if f"frpandora{index}" in hay or f"pandora{letter}" in hay:
            return _normalize_icon_url(f"/plugins/FR_Pandora_{index}/html/icon.png")
    return _normalize_icon_url("/plugins/FR_Pandora_0/html/icon.png")


def _is_pyrrha_icon_url(value: Any) -> bool:
    try:
        path = urllib.parse.urlsplit(_safe_str(value)).path
    except Exception:
        path = _safe_str(value)
    return "/plugins/Pyrrha/html/images/" in path and path.rsplit("/", 1)[-1] in ("icon.png", "icon_svg.png")


def _canonical_home_app_key(plugin_id: Any = "", label: Any = "") -> str:
    clean = _safe_str(plugin_id).strip()
    hay = _norm_key(" ".join([clean, _safe_str(label)]))
    if "frpandora0" in hay or "pandoraa" in hay:
        return "app:FR_Pandora_0"
    if "frpandora1" in hay or "pandorab" in hay:
        return "app:FR_Pandora_1"
    if "frpandora2" in hay or "pandorac" in hay:
        return "app:FR_Pandora_2"
    if "frpandora3" in hay or "pandorad" in hay:
        return "app:FR_Pandora_3"
    if "qobuz" in hay:
        return "app:Qobuz"
    if "tidal" in hay:
        return "app:TIDAL"
    if "podcast" in hay:
        return "app:Podcast"
    if "pyrrha" in hay:
        return "app:Pyrrha"
    if "spotty" in hay or "spotify" in hay:
        return "app:Spotty"
    if "iheart" in hay:
        return "app:iHeartRadio"
    if "bbcsounds" in hay or "bbcsound" in hay:
        return "app:BBCSounds"
    return "app:" + clean if clean else ""


async def _discover_home_app_rows(pid: str) -> List[Dict[str, Any]]:
    try:
        raw = _extract_menu_items(await _myapps_raw(pid))
    except Exception as error:
        dbg("Home app discovery skipped: {}".format(_safe_str(error)))
        return []
    top_items: List[Dict[str, Any]] = []
    try:
        top_items = _extract_menu_items(await _top_menu_raw(pid))
    except Exception:
        pass
    top_art_by_label: Dict[str, str] = {}
    top_art_by_id: Dict[str, str] = {}
    for top_item in top_items:
        art = _pick_art(top_item)
        if not art:
            continue
        label_key = _norm_key(_pick_label(top_item))
        item_key = _norm_key(top_item.get("id"))
        if label_key:
            top_art_by_label[label_key] = art
        if item_key:
            top_art_by_id[item_key] = art
    rows=[]
    for i,it in enumerate(raw):
        key=_safe_str(it.get("id") or "").strip()
        if not key:
            continue
        if (
            _safe_str(it.get("type")).strip().lower() == "text"
            and _safe_int(it.get("isaudio"), 0) == 0
            and _safe_int(it.get("hasitems"), 0) == 0
        ):
            continue
        label=_pick_label(it)
        if _norm_key(label) in ("no app installed", "no apps installed", "no app"):
            continue
        canonical_key = _canonical_home_app_key(key, label)
        fallback_icon = _curated_plugin_home_icon(key, label)
        icon = (
            (fallback_icon if canonical_key == "app:Pyrrha" else "")
            or top_art_by_label.get(_norm_key(label))
            or top_art_by_id.get(_norm_key(key))
            or _pick_art(it)
            or fallback_icon
            or ""
        )
        rows.append({
            "key": canonical_key,
            "label": label,
            "source_label": label,
            "enabled": _home_app_default_enabled(key, label),
            "order": 100 + i*10,
            "type": "app",
            "icon": icon,
        })
    return rows


async def _merge_home_menu_with_live_apps(pid: str) -> List[Dict[str, Any]]:
    saved_by_key={}
    saved_by_source={}
    for row in (_setup_cache.get("home_menu") or []):
        if not isinstance(row, dict):
            continue
        key=_safe_str(row.get("key")).strip()
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        if key:
            saved_by_key[key]=dict(row)
        if src:
            saved_by_source[src]=dict(row)
    out=[]
    for row in _core_home_rows():
        key=_safe_str(row.get("key")).strip()
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        saved=saved_by_key.get(key) or saved_by_source.get(src) or {}
        rr=dict(row)
        if saved:
            rr["label"]=_safe_str(saved.get("label") or rr.get("label") or key)
            rr["enabled"]=bool(saved.get("enabled", rr.get("enabled", True)))
            rr["order"]=_safe_int(saved.get("order"), _safe_int(rr.get("order"),100))
            rr["icon"]=_safe_str(saved.get("icon") or rr.get("icon") or _core_home_icon(key))
        else:
            rr["icon"]=_safe_str(rr.get("icon") or _core_home_icon(key))
        out.append(rr)
    for row in await _discover_home_app_rows(pid):
        key=_safe_str(row.get("key")).strip()
        if _is_airplay_service_item(key, row.get("source_label") or row.get("label")):
            continue
        if any(_safe_str(existing.get("key")).strip() == key for existing in out):
            continue
        src=_norm_key(row.get("source_label") or row.get("label") or key)
        saved=saved_by_key.get(key) or saved_by_source.get(src) or {}
        rr=dict(row)
        if saved:
            rr["label"]=_safe_str(saved.get("label") or rr.get("label") or key)
            rr["enabled"]=bool(saved.get("enabled", rr.get("enabled", False)))
            rr["order"]=_safe_int(saved.get("order"), _safe_int(rr.get("order"),100))
            rr["icon"]=_safe_str(
                rr.get("icon")
                or saved.get("icon")
                or _curated_plugin_home_icon(key, rr.get("label") or src)
                or ""
            )
        else:
            rr["order"] = _next_home_app_order(out)
        out.append(rr)
    return _normalize_unique_menu_orders(out)


async def _merge_setup_home_menu_with_active_curated_plugins(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [dict(row) for row in rows if isinstance(row, dict)]
    saved_by_key: Dict[str, Dict[str, Any]] = {}
    saved_by_source: Dict[str, Dict[str, Any]] = {}
    for row in (_setup_cache.get("home_menu") or []):
        if not isinstance(row, dict):
            continue
        key = _safe_str(row.get("key")).strip()
        source = _norm_key(row.get("source_label") or row.get("label") or key)
        if key:
            saved_by_key[key] = dict(row)
        if source:
            saved_by_source[source] = dict(row)
    existing_keys = {_safe_str(row.get("key")).strip() for row in out}
    existing_sources = {_norm_key(row.get("source_label") or row.get("label") or row.get("key")) for row in out}
    next_order = _next_home_app_order(out)
    try:
        curated = await _curated_lms_plugins()
    except Exception as error:
        dbg("Setup Home Menu curated plugin merge skipped: {}".format(_safe_str(error)))
        return _normalize_unique_menu_orders(out)
    for plugin in curated:
        if _safe_str(plugin.get("state")).lower() != "active":
            continue
        plugin_id = _safe_str(plugin.get("id")).strip()
        if _is_airplay_service_item(plugin_id, plugin.get("label")):
            continue
        if _plugin_placement_managed_by_lms(plugin_id):
            continue
        key = _curated_plugin_home_key(plugin_id)
        label = _curated_plugin_home_label(plugin_id, _safe_str(plugin.get("label") or plugin_id))
        source = _norm_key(label)
        if key in existing_keys or (source and source in existing_sources):
            fallback_icon = _curated_plugin_home_icon(plugin_id, label)
            if fallback_icon:
                for row in out:
                    row_key = _safe_str(row.get("key")).strip()
                    row_source = _norm_key(row.get("source_label") or row.get("label") or row_key)
                    if row_key == key or (source and row_source == source):
                        if plugin_id == "TIDAL" or not _safe_str(row.get("icon")).strip():
                            row["icon"] = fallback_icon
                        break
            continue
        saved = saved_by_key.get(key) or saved_by_source.get(source) or {}
        default_enabled = _curated_plugin_home_default_enabled(plugin_id, label)
        default_order = 650 if plugin_id == "ShairTunes2W" else next_order
        out.append({
            "key": key,
            "label": _safe_str(saved.get("label") or label),
            "enabled": bool(saved.get("enabled", default_enabled)),
            "order": _safe_int(saved.get("order"), default_order),
            "type": "app",
            "source_label": _safe_str(saved.get("source_label") or label),
            "icon": _curated_saved_icon_or_fallback(plugin_id, label, saved.get("icon"), plugin.get("icon") or plugin.get("art")),
        })
        existing_keys.add(key)
        if source:
            existing_sources.add(source)
        next_order = _next_home_app_order(out)
    return _normalize_unique_menu_orders(out)


async def _sources_in_use(pid: str) -> Dict[str, bool]:
    """Return stable source flags for RTI auto-configuration."""
    flags = {
        "airplay": False,
        "bbc_sounds": False,
        "favorites": False,
        "iheart": False,
        "mymusic": False,
        "pandora": False,
        "pandora_a": False,
        "pandora_b": False,
        "pandora_c": False,
        "pandora_d": False,
        "podcasts": False,
        "pyrrha": False,
        "qobuz": False,
        "radio": False,
        "siriusxm": False,
        "soundmachine": False,
        "soundcloud": False,
        "spotify": False,
        "tidal": False,
        "deezer": False,
    }
    try:
        rows = await _merge_home_menu_with_live_apps(pid)
    except Exception:
        rows = list(_home_menu_cache)

    for row in rows:
        if not isinstance(row, dict) or not bool(row.get("enabled", False)):
            continue
        row_key = _norm_key(row.get("key"))
        hay = _norm_key(" ".join(
            _safe_str(row.get(key))
            for key in ("key", "label", "source_label", "icon")
        ))
        if "mymusic" in hay:
            flags["mymusic"] = True
        elif "favorite" in hay:
            flags["favorites"] = True
        elif row_key == "radio":
            flags["radio"] = True
        if "spotty" in hay or "spotify" in hay:
            flags["spotify"] = True
        if "frpandora" in hay or "pandora" in hay:
            flags["pandora"] = True
            for index, letter in enumerate(("a", "b", "c", "d")):
                if "frpandora{}".format(index) in hay or "pandora{}".format(letter) in hay:
                    flags["pandora_" + letter] = True
        if "pyrrha" in hay:
            flags["pyrrha"] = True
        if "iheart" in hay:
            flags["iheart"] = True
        if "podcast" in hay:
            flags["podcasts"] = True
        if "bbcsound" in hay:
            flags["bbc_sounds"] = True
        if "qobuz" in hay:
            flags["qobuz"] = True
        if "sirius" in hay:
            flags["siriusxm"] = True
        if "soundmachine" in hay:
            flags["soundmachine"] = True
        if "tidal" in hay:
            flags["tidal"] = True
        if "deezer" in hay:
            flags["deezer"] = True
        if "soundcloud" in hay:
            flags["soundcloud"] = True

    try:
        await lms.start()
        assert lms._session is not None
        async with lms._session.get(
            LMS_BASE + "/plugins/ShairTunes2W/settings/basic.html",
            allow_redirects=False,
        ) as response:
            flags["airplay"] = response.status == 200
    except Exception:
        flags["airplay"] = False
    return flags


async def _apply_lms_base(new_base: str) -> None:
    """Apply LMS base URL and force reconnects (RPC session + CometD)."""
    global LMS_BASE, LMS_JSONRPC, LMS_COMETD, _cometd_client_id, _cometd_response_channel, _cometd_session

    nb = _safe_str(new_base).strip().rstrip("/")
    if not nb:
        return
    if nb == LMS_BASE:
        return

    LMS_BASE = nb
    LMS_JSONRPC = LMS_BASE + "/jsonrpc.js"
    LMS_COMETD = LMS_BASE + "/cometd"

    # Reset LMS RPC session
    try:
        await lms.close()
    except Exception:
        pass

    # Force CometD loop to re-handshake by closing the session and clearing ids
    _cometd_client_id = None
    _cometd_response_channel = None
    try:
        if _cometd_session and not _cometd_session.closed:
            await _cometd_session.close()
    except Exception:
        pass


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return default


import re as _re

def _normalize_art_url(url: str) -> str:
    """Normalize artwork URLs for RTI panels."""
    u = (url or "").strip()
    if not u:
        return u

    # /imageproxy/<percent-encoded-https-url>/image.jpg  ->  https://...
    if "/imageproxy/" in u:
        try:
            after = u.split("/imageproxy/", 1)[1]
            after = _re.sub(r"/image\.(jpg|jpeg|png)$", "", after, flags=_re.IGNORECASE)
            after = urllib.parse.unquote(after)
            u = after.strip()
        except Exception:
            pass

    # strip trailing /image.xxx if still present
    u = _re.sub(r"/image\.(jpg|jpeg|png)$", "", u, flags=_re.IGNORECASE)

    pub = _public_lms_base().rstrip("/")
    base = pub or LMS_BASE

    # Rewrite loopback URLs to a reachable LMS base
    if u.startswith("http://127.0.0.1") or u.startswith("http://localhost"):
        if pub:
            try:
                p_old = urllib.parse.urlsplit(u)
                p_new = urllib.parse.urlsplit(pub)
                u = urllib.parse.urlunsplit((p_new.scheme, p_new.netloc, p_old.path, p_old.query, p_old.fragment))
            except Exception:
                pass
        return u

    if u.startswith("/"):
        return base + u
    if not _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        return base + "/" + u.lstrip("/")
    return u


def _normalize_icon_url(url: str) -> str:
    """Normalize menu/icon URLs so RTI gets a simple absolute URL."""
    u = (url or "").strip()
    if not u:
        return u

    # remove LMS image suffix first
    u = _re.sub(r"/image\.(jpg|jpeg|png|gif)$", "", u, flags=_re.IGNORECASE)

    # Older broker builds leaked icon_svg.png from FR_Pandora metadata. Normalize
    # those stale classic/RTI URLs back to the colorful plugin icon.
    u = _re.sub(
        r"(/plugins/FR_Pandora_[0-3]/html/)icon_svg\.png(\?.*)?$",
        r"\1icon.png\2",
        u,
        flags=_re.IGNORECASE,
    )
    u = _re.sub(
        r"^(plugins/FR_Pandora_[0-3]/html/)icon_svg\.png(\?.*)?$",
        r"\1icon.png\2",
        u,
        flags=_re.IGNORECASE,
    )

    # If LMS wrapped an external imageproxy URL, unwrap to the direct image URL
    if "/imageproxy/" in u:
        try:
            after = u.split("/imageproxy/", 1)[1]
            after = urllib.parse.unquote(after).strip()
            if _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", after):
                return after
        except Exception:
            pass

    pub = _public_lms_base().rstrip("/")
    base = pub or LMS_BASE

    # Local LMS library art in browse rows is usually music/<id>/cover.
    # RTI does better with the explicit sized cover URL.
    if u.startswith("music/") and u.endswith("/cover"):
        return base + "/" + u + "_100x100_o"
    if u.startswith("/music/") and u.endswith("/cover"):
        return base + u + "_100x100_o"

    # Rewrite loopback URLs to a reachable LMS base
    if u.startswith("http://127.0.0.1") or u.startswith("http://localhost"):
        if pub:
            try:
                p_old = urllib.parse.urlsplit(u)
                p_new = urllib.parse.urlsplit(pub)
                u = urllib.parse.urlunsplit((p_new.scheme, p_new.netloc, p_old.path, p_old.query, p_old.fragment))
            except Exception:
                pass
        return u

    if u.startswith("/"):
        return base + u
    if u.startswith("plugins/"):
        return base + "/" + u
    if not _re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        return base + "/" + u.lstrip("/")
    return u


def _normalize_art_fields(obj: Any) -> None:
    """Walk a status payload and normalize art/icon URL fields."""
    if not isinstance(obj, dict):
        return

    for k in list(obj.keys()):
        v = obj.get(k)
        if isinstance(v, str):
            lk = k.lower()
            if ("art" in lk and "url" in lk) or lk in ("artwork_url", "coverart", "cover_url"):
                obj[k] = _normalize_art_url(v)
            elif lk in ("icon", "icon-id", "icon_url"):
                obj[k] = _normalize_icon_url(v)
        elif isinstance(v, dict):
            _normalize_art_fields(v)
        elif isinstance(v, list):
            for it in v:
                _normalize_art_fields(it)

    # Common LMS nested lists
    for lk in ("playlist_loop", "item_loop", "loop_loop"):
        v = obj.get(lk)
        if isinstance(v, list):
            for it in v:
                _normalize_art_fields(it)
def _default_cover_url() -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    return base + "/music/0/cover_500x500_o"


def _item_art_url(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return _default_cover_url()
    v = _safe_str(it.get("artwork_url") or "").strip()
    if v:
        return _normalize_art_url(v)
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    atid = _safe_str(it.get("artwork_track_id") or it.get("coverid") or it.get("cover_id") or "").strip()
    if atid:
        return f"{base}/music/{atid}/cover_500x500_o"
    if _safe_str(it.get("coverart")).strip() in ("1", "true", "True"):
        tid = _safe_str(it.get("id") or "").strip()
        if tid:
            return f"{base}/music/{tid}/cover_100x100_o"
    return _default_cover_url()


def _enrich_status_payload(obj: Any, pid: str = "") -> None:
    """Make local-library payloads look more like stream/Spotty payloads."""
    if not isinstance(obj, dict):
        return

    loop = obj.get("playlist_loop")
    if isinstance(loop, list):
        for it in loop:
            if not isinstance(it, dict):
                continue
            art = _item_art_url(it)
            if art:
                it["artwork_url"] = art

    cur_idx = _safe_str(obj.get("playlist_cur_index"))
    cur_item = None
    if isinstance(loop, list) and loop:
        for it in loop:
            if not isinstance(it, dict):
                continue
            if _safe_str(it.get("playlist index")) == cur_idx:
                cur_item = it
                break
        if cur_item is None:
            cur_item = loop[0] if isinstance(loop[0], dict) else None

    if isinstance(cur_item, dict):
        title = _safe_str(cur_item.get("title"))
        artist = _safe_str(cur_item.get("artist"))
        album = _safe_str(cur_item.get("album"))
        year = cur_item.get("year")
        duration = cur_item.get("duration")
        iid = cur_item.get("id")
        art = _item_art_url(cur_item)

        if title and not _safe_str(obj.get("current_title")):
            obj["current_title"] = title

        rm = obj.get("remoteMeta")
        if not isinstance(rm, dict):
            rm = {}
            obj["remoteMeta"] = rm
        if iid is not None and rm.get("id") in (None, ""):
            rm["id"] = iid
        if title and not _safe_str(rm.get("title")):
            rm["title"] = title
        if artist and not _safe_str(rm.get("artist")):
            rm["artist"] = artist
        if album and not _safe_str(rm.get("album")):
            rm["album"] = album
        if year not in (None, "") and rm.get("year") in (None, ""):
            rm["year"] = year
        if duration not in (None, "") and rm.get("duration") in (None, ""):
            rm["duration"] = duration
        if art and not _safe_str(rm.get("artwork_url")):
            rm["artwork_url"] = art

        # Podcast deltas often omit these fields. Emit explicit blanks so
        # metadata from the previously playing library track cannot survive.
        if _is_podcast_item(cur_item) or _is_podcast_item(rm) or pid.lower() in _podcast_players:
            if not artist:
                cur_item["artist"] = ""
                rm["artist"] = ""
                obj["artist"] = ""
            if not album:
                cur_item["album"] = ""
                rm["album"] = ""
                obj["album"] = ""

    # Normalize again after synthesis
    _normalize_art_fields(obj)


class LMSClient:
    def __init__(self) -> None:
        self._session: Optional[ClientSession] = None
        self._id = 0

    async def start(self) -> None:
        if self._session is None or self._session.closed:
            self._session = ClientSession(timeout=ClientTimeout(total=RPC_TIMEOUT))

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None

    async def rpc(self, playerid: str, params: List[Any]) -> Dict[str, Any]:
        last_error: Optional[BaseException] = None
        for attempt in range(2):
            await self.start()
            assert self._session is not None
            self._id += 1
            canonical_playerid = _safe_str(playerid).strip().lower()
            payload = {"id": self._id, "method": "slim.request", "params": [canonical_playerid, params]}
            dbg(f"RPC POST {payload}")
            try:
                async with self._session.post(LMS_JSONRPC, json=payload) as resp:
                    txt = await resp.text()
                    dbg(f"RPC HTTP {resp.status} {txt[:200]}")
                    if resp.status != 200:
                        raise RuntimeError(f"LMS RPC HTTP {resp.status}: {txt[:200]}")
                    return json.loads(txt)
            except (ClientError, asyncio.TimeoutError, ConnectionResetError, OSError) as error:
                last_error = error
                dbg(f"RPC retryable error attempt={attempt + 1} {type(error).__name__}: {_safe_str(error)}")
                await self.close()
                if attempt == 0:
                    await asyncio.sleep(0.35)
                    continue
                raise
        if last_error:
            raise last_error
        raise RuntimeError("LMS RPC failed")

    async def get_players(self) -> List[Dict[str, Any]]:
        r = await self.rpc("", ["players", 0, 999])
        loop = (((r.get("result") or {}).get("players_loop")) or [])
        outp: List[Dict[str, Any]] = []
        for p in loop:
            outp.append({
                "playerid": _safe_str(p.get("playerid")),
                "name": _safe_str(p.get("name")),
                "connected": _safe_int(p.get("connected"), 0),
                "power": _safe_int(p.get("power"), 0),
            })
        return outp

    async def ensure_playlist_dir(self) -> str:
        pref = await self.rpc("", ["pref", "playlistdir", "?"])
        cur = _safe_str((pref.get("result") or {}).get("_p2")).strip()
        candidates = [
            cur,
            "/mnt/mmcblk0p2/tce/slimserver/Playlists",
            "/mnt/mmcblk0p2/tce/lyriongadget/playlists",
            os.path.join(os.path.dirname(os.path.abspath(SETUP_JSON_PATH)), "playlists"),
        ]
        target = ""
        for path in candidates:
            path = _safe_str(path).strip()
            if not path:
                continue
            try:
                os.makedirs(path, exist_ok=True)
                if os.path.isdir(path) and os.access(path, os.W_OK):
                    target = path
                    break
            except Exception as e:
                dbg(f"playlistdir candidate failed path={path} err={type(e).__name__}:{_safe_str(e)}")
        if not target:
            raise RuntimeError("No writable playlist folder is available")
        if cur != target:
            await self.rpc("", ["pref", "playlistdir", target])
            verify = await self.rpc("", ["pref", "playlistdir", "?"])
            got = _safe_str((verify.get("result") or {}).get("_p2")).strip()
            if got != target:
                raise RuntimeError(f"LMS rejected playlist folder {target}")
            dbg(f"playlistdir set to {target}")
        return target

    async def status(self, playerid: str, count: int = 1) -> Dict[str, Any]:
        cnt = _safe_int(count, 1)
        if cnt < 1: cnt = 1
        if cnt > 999: cnt = 999
        r = await self.rpc(playerid, ["status", "-", cnt, f"tags:{STATUS_TAGS}"])
        return (r.get("result") or {})

    async def track_metadata(self, track_id: str) -> Dict[str, Any]:
        tid = _safe_str(track_id).strip()
        if not tid:
            return {}
        cached = TRACK_META_CACHE.get(tid)
        if isinstance(cached, dict) and cached:
            return dict(cached)

        def _merge_songinfo_dict(meta: Dict[str, Any], info: Dict[str, Any]) -> None:
            if not isinstance(info, dict):
                return
            aliases = {
                "title": ["title", "track", "name"],
                "artist": ["artist", "artistname", "contributor", "artist_name"],
                "album": ["album", "albumtitle", "album_name"],
                "genre": ["genre", "genrename"],
                "duration": ["duration", "secs", "seconds"],
                "track_id": ["track_id", "trackid", "id"],
                "album_id": ["album_id", "albumid"],
                "coverid": ["coverid", "cover_id", "artwork_track_id"],
                "artwork_url": ["artwork_url", "art", "icon", "icon-id", "image"]
            }
            # direct keyed dicts
            for outk, keys in aliases.items():
                if meta.get(outk) not in (None, ""):
                    continue
                for k in keys:
                    v = info.get(k)
                    if v not in (None, ""):
                        meta[outk] = v
                        break
            # LMS songinfo_loop often comes back as name/value or id/value pairs.
            raw_key = _safe_str(info.get("name") or info.get("id") or info.get("key") or info.get("title")).strip().lower()
            raw_val = info.get("value")
            if raw_key and raw_val not in (None, ""):
                key_map = {
                    "title": "title", "track": "title", "name": "title",
                    "artist": "artist", "artistname": "artist", "contributor": "artist",
                    "album": "album", "albumtitle": "album",
                    "genre": "genre", "genrename": "genre",
                    "duration": "duration", "secs": "duration", "seconds": "duration",
                    "track_id": "track_id", "trackid": "track_id",
                    "album_id": "album_id", "albumid": "album_id",
                    "coverid": "coverid", "cover_id": "coverid", "artwork_track_id": "coverid",
                    "artwork_url": "artwork_url", "icon": "artwork_url", "image": "artwork_url"
                }
                mk = key_map.get(raw_key)
                if mk and meta.get(mk) in (None, ""):
                    meta[mk] = raw_val

        # songinfo is the most reliable way to enrich album drilldown rows that only expose
        # action payloads plus a concrete track_id.
        r = await self.rpc("", ["songinfo", 0, 100, f"track_id:{tid}"])
        res = (r.get("result") or {}) if isinstance(r, dict) else {}
        loop = res.get("songinfo_loop") or res.get("titles_loop") or res.get("tracks_loop") or []
        meta: Dict[str, Any] = {}
        if isinstance(loop, list) and loop:
            for info in loop:
                if isinstance(info, dict):
                    _merge_songinfo_dict(meta, info)
        # Some LMS builds expose useful top-level values on result too.
        if isinstance(res, dict):
            _merge_songinfo_dict(meta, res)
        # normalize strings
        for k in ("title", "artist", "album", "genre", "track_id", "album_id", "coverid", "artwork_url"):
            if k in meta and meta[k] is not None:
                meta[k] = _safe_str(meta[k])
        if meta.get("duration") not in (None, ""):
            try:
                meta["duration"] = float(meta.get("duration"))
            except Exception:
                pass
        if not _safe_str(meta.get("track_id")):
            meta["track_id"] = tid
        art = _track_album_art_url(meta) or _pick_art(meta) or _local_cover_art_url(meta)
        if art:
            meta["art"] = art
        if meta:
            TRACK_META_CACHE[tid] = dict(meta)
            if len(TRACK_META_CACHE) > TRACK_META_CACHE_MAX:
                try:
                    first_key = next(iter(TRACK_META_CACHE.keys()))
                    TRACK_META_CACHE.pop(first_key, None)
                except Exception:
                    pass
        dbg("TRACK META track_id=%s keys=%s title=%s artist=%s album=%s genre=%s duration=%s" % (
            tid,
            ",".join(sorted(meta.keys())),
            _safe_str(meta.get("title")),
            _safe_str(meta.get("artist")),
            _safe_str(meta.get("album")),
            _safe_str(meta.get("genre")),
            _safe_str(meta.get("duration"))
        ))
        return dict(meta)


    async def cmd(self, playerid: str, name: str, args: List[Any]) -> Dict[str, Any]:
        name = (name or "").strip().lower()
        cmd: List[Any]

        # --- Transport / basic controls ---
        if name in ("play", "pause", "stop"):
            cmd = [name]
        elif name == "next":
            cmd = ["playlist", "index", "+1"]
        elif name in ("prev", "previous"):
            cmd = ["playlist", "index", "-1"]
        elif name == "power":
            raw = _safe_str(args[0]).strip().lower() if args else "1"
            if raw == "toggle":
                st = await self.status(playerid, 1)
                cur = _safe_int((st.get("result") or {}).get("power"), 0)
                val = 0 if cur else 1
            elif raw in ("on", "true", "yes"):
                val = 1
            elif raw in ("off", "false", "no"):
                val = 0
            else:
                val = _safe_int(raw, 1)
            cmd = ["power", val]
        elif name == "mute":
            raw = _safe_str(args[0]).strip().lower() if args else "1"
            if raw == "toggle":
                st = await self.status(playerid, 1)
                cur = _safe_int((st.get("result") or {}).get("mixer muting"), _safe_int((st.get("result") or {}).get("muting"), 0))
                val = 0 if cur else 1
            elif raw in ("on", "true", "yes", "mute"):
                val = 1
            elif raw in ("off", "false", "no", "unmute"):
                val = 0
            else:
                val = _safe_int(raw, 1)
            cmd = ["mixer", "muting", val]
        elif name == "volume":
            raw = _safe_str(args[0]).strip() if args else "0"
            val = raw if raw.startswith(("+", "-")) else _safe_int(raw, 0)
            cmd = ["mixer", "volume", val]
        elif name in ("repeat", "shuffle"):
            raw = _safe_str(args[0]).strip().lower() if args else "next"
            key = name
            if raw == "next":
                snap = _last_status_by_key.get(playerid) or {}
                cur_raw = snap.get(f"playlist {key}", snap.get(f"playlist_{key}", snap.get(key, None)))
                if cur_raw is None:
                    st = await self.status(playerid, 1)
                    cur_raw = st.get(f"playlist {key}", st.get(f"playlist_{key}", st.get(key, 0)))
                cur = _safe_int(cur_raw, 0)
                val = (cur + 1) % 3
            elif raw in ("off", "none", "0", "false"):
                val = 0
            elif raw in ("song", "one", "track", "1", "true", "on"):
                val = 1
            elif name == "repeat" and raw in ("playlist", "all", "2"):
                val = 2
            elif name == "shuffle" and raw in ("album", "2"):
                val = 2
            elif name == "shuffle" and raw == "all":
                val = 1
            else:
                val = _safe_int(raw, 0)
            cmd = ["playlist", key, val]
            r = await self.rpc(playerid, cmd)
            return {"result": {f"playlist {key}": val, f"playlist_{key}": val, key: val, "lms_result": r.get("result") or {}}}
        elif name in ("position", "time"):
            raw = _safe_str(args[0]).strip() if args else "0"
            mode = _safe_str(args[1]).strip().lower() if len(args) > 1 else ""
            if mode == "percent":
                st = await self.status(playerid, 1)
                dur = _safe_int((st.get("result") or {}).get("duration"), 0)
                raw = str(int((dur * _safe_int(raw, 0)) / 100)) if dur > 0 else "0"
            cmd = ["time", raw]
        elif name == "sync":
            master = _safe_str(args[0]).strip() if args else ""
            if not master:
                raise ValueError("missing sync master")
            cmd = ["sync", master]
        elif name == "unsync":
            cmd = ["sync", "-"]
        elif name == "sync_toggle":
            slave = _safe_str(args[0]).strip() if args else ""
            if not slave:
                raise ValueError("missing sync slave")
            slave_status = await self.status(slave, 1)
            current_master = _safe_str(slave_status.get("sync_master")).strip()
            if current_master:
                return await self.rpc(slave, ["sync", "-"])
            cmd = ["sync", slave]
        elif name == "sync_all":
            action = _safe_str(args[0]).strip().lower() if args else "all"
            players = await self.get_players()
            result: Dict[str, Any] = {"players": []}
            for p in players:
                pid = _safe_str(p.get("playerid"))
                if not pid or pid == playerid:
                    continue
                if action in ("none", "off", "unsync"):
                    rr = await self.rpc(pid, ["sync", "-"])
                else:
                    rr = await self.rpc(playerid, ["sync", pid])
                result["players"].append({"playerid": pid, "result": rr.get("result") or {}})
            return {"result": result}
        elif name == "rate":
            direction = _safe_str(args[0]).strip().lower() if args else ""
            want_value = 1 if direction in ("positive", "up", "thumbup", "thumbs_up", "like") else 0
            preferred_button = "repeat" if want_value == 1 else "shuffle"
            status = await self.status(playerid, 1)
            candidates: List[Dict[str, Any]] = []
            if isinstance(status, dict):
                candidates.extend([
                    status,
                    status.get("remoteMeta") if isinstance(status.get("remoteMeta"), dict) else {},
                    _current_playlist_item(status) or {},
                ])
            rate_commands: List[List[Any]] = []
            for obj in candidates:
                btns = obj.get("buttons") if isinstance(obj, dict) else None
                if not isinstance(btns, dict):
                    continue
                names = [preferred_button] + [key for key in btns.keys() if key != preferred_button]
                for button_name in names:
                    button = btns.get(button_name)
                    if not isinstance(button, dict):
                        continue
                    command = button.get("command")
                    if (
                        isinstance(command, list)
                        and len(command) >= 3
                        and _safe_str(command[1]).strip().lower() == "rate"
                        and _safe_int(command[2], -1) == want_value
                    ):
                        rate_commands.append(command)
            if not rate_commands:
                return {"result": {"rate": "unavailable"}}
            rr = await self.rpc(playerid, rate_commands[0])
            return {"result": {"rate": direction or str(want_value), "lms_result": rr.get("result") or {}}}

        # --- Queue / list controls (new) ---
        elif name in ("queue_goto", "goto"):
            idx = _safe_int(args[0], 0) if args else 0
            cmd = ["playlist", "index", idx]
        elif name in ("queue_remove", "remove"):
            idx = _safe_int(args[0], 0) if args else 0
            cmd = ["playlist", "delete", idx]
        elif name in ("queue_clear", "clear"):
            cmd = ["playlist", "clear"]
        elif name in ("queue_saveas", "queue_save_as", "saveas"):
            playlist_name = _safe_str(args[0]).strip() if args else ""
            if not playlist_name:
                playlist_name = "New Playlist"
            await self.ensure_playlist_dir()
            cmd = ["playlist", "save", playlist_name, "silent:1"]
        elif name in ("queue_fetch", "queue"):
            # Implemented by ws_rti handler (special-cased) — not here.
            cmd = []

        # --- Library / browse (menu/items) ---
        elif name in ("menu", "library"):
            # Pass-through 'menu' RPC. args should be a list of menu args, e.g.
            #   [0, 50, "direct:1"]
            #   [0, 50, "direct:1", "item_id:..."]
            cmd = ["menu"] + (args or [])

        elif name == "items":
            # Pass-through 'items' RPC (LMS menu browsing). args should be list args, e.g.
            #   [0, 100, "menu:1"]
            #   [0, 100, "menu:1", "item_id:..."]
            cmd = ["items"] + (args or [])

        elif name in ("artists","albums","genres","playlists","titles","tracks","years"):
            # Stable library browse commands (JSON-RPC)
            # args format: [offset, limit, ...optional filters like "artist_id:3", "album_id:1", "playlist_id:40"]
            cmd = [name] + (args or [])

        elif name == "playlistcontrol":
            # Compatibility shim for older/newer RTI driver JS that sends raw playlistcontrol
            # over the WS cmd path for selected track actions.
            # Example args: ["cmd:load", "track_id:22175", "menu:1"]
            cmd = ["playlistcontrol"] + (args or [])

        else:
            raise ValueError(f"unknown cmd '{name}'")

        if cmd:
            dbg(f"LMS CMD playerid={playerid} cmd={cmd}")
            return await self.rpc(playerid, cmd)

        return {"result": {}}


lms = LMSClient()


def pick_default_player(players: List[Dict[str, Any]]) -> str:
    if DEFAULT_PLAYERID:
        return DEFAULT_PLAYERID
    for p in players:
        if _safe_int(p.get("connected"), 0) == 1:
            return _safe_str(p.get("playerid"))
    return _safe_str(players[0].get("playerid")) if players else ""


_ws_clients: Set[web.WebSocketResponse] = set()
_panel_ws_by_key: Dict[str, web.WebSocketResponse] = {}
_queue_broadcast_pending: Dict[str, Any] = {}
_queue_broadcast_tasks: Dict[str, asyncio.Task] = {}

_main_art_source_by_playerid: Dict[str, str] = {}

_rti_ws_diag: Dict[str, Any] = {
    "connects": 0,
    "disconnects": 0,
    "active": 0,
    "last_peer": "",
    "last_connect_ts": 0.0,
    "last_disconnect_ts": 0.0,
    "last_disconnect_after_secs": 0.0,
    "last_send_ts": 0.0,
    "last_send_type": "",
    "last_send_bytes": 0,
    "last_error": "",
}


def _queue_ws_key(obj: Any) -> str:
    if not isinstance(obj, dict):
        return ""
    return "%s|%s" % (
        _safe_str(obj.get("playerid")).strip().lower(),
        _safe_str(obj.get("view")).strip().lower(),
    )


def _should_coalesce_queue_ws(obj: Any) -> bool:
    return (
        isinstance(obj, dict)
        and _safe_str(obj.get("t")) == "queue"
        and bool(obj.get("ok", True))
        and isinstance(obj.get("payload"), dict)
    )


async def _ws_broadcast_now(obj: Any) -> None:
    if not _ws_clients:
        return
    if not _license_status().get("valid"):
        for ws in list(_ws_clients):
            try:
                await ws.close(code=4003, message=b"license expired")
            except Exception:
                pass
        _ws_clients.clear()
        return
    msg = _rti_json_dumps(obj) + "\n"
    dead: List[web.WebSocketResponse] = []
    for ws in list(_ws_clients):
        try:
            await ws.send_str(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _ws_clients.discard(ws)


async def _flush_queue_broadcast_later(key: str) -> None:
    try:
        await asyncio.sleep(RTI_QUEUE_COALESCE_SECS)
        obj = _queue_broadcast_pending.pop(key, None)
        if obj is not None:
            await _ws_broadcast_now(obj)
    except asyncio.CancelledError:
        raise
    except Exception as e:
        _rti_ws_diag["last_error"] = f"queue_broadcast:{type(e).__name__}:{_safe_str(e)}"
    finally:
        _queue_broadcast_tasks.pop(key, None)


async def ws_broadcast(obj: Any) -> None:
    if isinstance(obj, dict):
        obj = _rti_trim_ws_payload(obj)
    if _should_coalesce_queue_ws(obj):
        key = _queue_ws_key(obj)
        if key:
            _queue_broadcast_pending[key] = obj
            task = _queue_broadcast_tasks.get(key)
            if task is None or task.done():
                _queue_broadcast_tasks[key] = asyncio.create_task(_flush_queue_broadcast_later(key))
            return
    await _ws_broadcast_now(obj)


# --- CometD state ---
_cometd_session: Optional[ClientSession] = None
_lms_proxy_session: Optional[ClientSession] = None
_cometd_client_id: str = ""
_cometd_msg_id: int = 0
_cometd_connected: bool = False
_cometd_response_channel: str = ""  # /slim/<clientId>/response

_last_status_by_key: Dict[str, Dict[str, Any]] = {}
_last_queue_refresh_sig_by_playerid: Dict[str, str] = {}
_transport_mode_verify_tasks: Dict[str, asyncio.Task] = {}
_transport_command_verify_tasks: Dict[str, asyncio.Task] = {}
_sync_status_refresh_task: Optional[asyncio.Task] = None
_name_to_playerid: Dict[str, str] = {}  # unique player_name -> playerid (MAC)
_playerid_to_name: Dict[str, str] = {}  # playerid (MAC) -> player_name
_ambiguous_player_names: Set[str] = set()
_cometd_subscribed_playerids: Set[str] = set()
_cometd_subscription_expires: Dict[str, float] = {}
_cometd_last_rescan: float = 0.0


def _reset_player_identity_maps() -> None:
    _name_to_playerid.clear()
    _playerid_to_name.clear()
    _ambiguous_player_names.clear()


def _remember_player_identity(playerid: Any, name: Any) -> None:
    pid = _safe_str(playerid).strip().lower()
    pname = _safe_str(name).strip()
    if not pid or not pname:
        return
    _playerid_to_name[pid] = pname
    key = pname.lower()
    if key in _ambiguous_player_names:
        return
    existing = _safe_str(_name_to_playerid.get(key)).strip().lower()
    if existing and existing != pid:
        _ambiguous_player_names.add(key)
        _name_to_playerid.pop(key, None)
        dbg("WARN duplicate player_name mapping disabled name=%s old=%s new=%s" % (pname, existing, pid))
        return
    _name_to_playerid[key] = pid


def _playerid_from_unique_name(name: Any) -> str:
    key = _safe_str(name).strip().lower()
    if not key or key in _ambiguous_player_names:
        return ""
    return _safe_str(_name_to_playerid.get(key)).strip().lower()


def _pid_norm(value: Any) -> str:
    return _safe_str(value).strip().lower()


def _pid_csv(value: Any) -> List[str]:
    out: List[str] = []
    for part in _safe_str(value).replace(";", ",").split(","):
        pid = _pid_norm(part)
        if pid and pid not in ("-", "none", "null", "undefined"):
            out.append(pid)
    return out


async def _sync_status_map(players: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    statuses: Dict[str, Dict[str, Any]] = {}

    async def fetch_one(player: Dict[str, Any]) -> None:
        pid = _pid_norm(player.get("playerid"))
        if not pid:
            return
        try:
            st = await lms.status(pid, 1)
        except Exception as e:
            dbg(f"SYNC LIST status failed playerid={pid}: {_safe_str(e)}")
            st = {}
        if isinstance(st, dict):
            statuses[pid] = st

    await asyncio.gather(*(fetch_one(p) for p in players))
    return statuses


def _sync_components(players: List[Dict[str, Any]], statuses: Dict[str, Dict[str, Any]]) -> Dict[str, Set[str]]:
    connected: Dict[str, Set[str]] = {}

    def add_node(pid: str) -> None:
        if pid and pid not in connected:
            connected[pid] = {pid}

    def union(a: str, b: str) -> None:
        a = _pid_norm(a)
        b = _pid_norm(b)
        if not a or not b or a == b:
            return
        add_node(a)
        add_node(b)
        ca = connected[a]
        cb = connected[b]
        if ca is cb:
            return
        merged = ca | cb
        for item in merged:
            connected[item] = merged

    for p in players:
        add_node(_pid_norm(p.get("playerid")))
    for pid, st in statuses.items():
        master = _pid_norm(st.get("sync_master") or st.get("syncmaster") or st.get("synced_to"))
        if master:
            union(pid, master)
        for slave in _pid_csv(st.get("sync_slaves") or st.get("syncslaves")):
            union(pid, slave)
    return connected


async def _sync_list_payload(anchor_pid: str, view: str = "") -> Dict[str, Any]:
    anchor = _pid_norm(anchor_pid)
    players = _rti_connected_players(await lms.get_players())
    statuses = await _sync_status_map(players)
    anchor_name = _playerid_to_name.get(anchor, "")

    def status_master(pid: str) -> str:
        st = statuses.get(_pid_norm(pid), {})
        return _pid_norm(st.get("sync_master") or st.get("syncmaster") or st.get("synced_to"))

    def status_slaves(pid: str) -> Set[str]:
        st = statuses.get(_pid_norm(pid), {})
        return set(_pid_csv(st.get("sync_slaves") or st.get("syncslaves")))

    anchor_master = status_master(anchor)
    anchor_slaves = status_slaves(anchor)

    rows: List[Dict[str, Any]] = []
    for p in players:
        pid = _pid_norm(p.get("playerid"))
        if not pid or pid == anchor:
            continue
        name = _safe_str(p.get("name")) or _playerid_to_name.get(pid, "") or pid
        target_master = status_master(pid)
        target_slaves = status_slaves(pid)
        checked = bool(anchor and (target_master == anchor or pid in anchor_slaves or anchor_master == pid or anchor in target_slaves))
        unsync_pid = pid
        if checked and (anchor_master == pid or anchor in target_slaves):
            unsync_pid = anchor
        rows.append({
            "playerid": pid,
            "name": name,
            "checked": checked,
            "synced": checked,
            "unsync_playerid": unsync_pid,
        })
    sig = "|".join(f"{_pid_norm(r.get('playerid'))}:{'1' if r.get('checked') else '0'}" for r in rows)
    return {
        "t": "sync_list",
        "ok": True,
        "playerid": anchor,
        "player_name": anchor_name,
        "view": _safe_str(view),
        "rows": rows,
        "count": len(rows),
        "any_synced": any(bool(r.get("checked")) for r in rows),
        "can_sync_all": bool(rows),
        "sig": sig,
    }


async def _send_sync_list(send_fn: Any, anchor_pid: str, view: str = "") -> None:
    try:
        await send_fn(await _sync_list_payload(anchor_pid, view))
    except Exception as e:
        dbg(f"SYNC LIST send failed playerid={anchor_pid}: {_safe_str(e)}")


_last_sync_list_broadcast_sig_by_anchor: Dict[str, str] = {}


async def _broadcast_sync_lists() -> None:
    try:
        players = [
            p for p in await lms.get_players()
            if _safe_int(p.get("connected"), 0) == 1 and _pid_norm(p.get("playerid"))
        ][:9]
        for p in players:
            anchor = _pid_norm(p.get("playerid"))
            payload = await _sync_list_payload(anchor)
            sig = _safe_str(payload.get("sig"))
            if _last_sync_list_broadcast_sig_by_anchor.get(anchor) == sig:
                continue
            _last_sync_list_broadcast_sig_by_anchor[anchor] = sig
            await ws_broadcast(payload)
    except Exception as e:
        dbg(f"SYNC LIST broadcast failed: {_safe_str(e)}")


async def _apply_sync_list_command(anchor_pid: str, command: str, args: List[Any]) -> Dict[str, Any]:
    anchor = _pid_norm(anchor_pid)
    command = _safe_str(command).strip().lower()
    before = await _sync_list_payload(anchor)
    rows = before.get("rows") if isinstance(before.get("rows"), list) else []

    if command == "sync_list_toggle":
        target = _pid_norm(args[0]) if args else ""
        row = next((r for r in rows if _pid_norm(r.get("playerid")) == target), None)
        if not target or not row:
            raise ValueError("missing sync list target")
        if bool(row.get("checked")):
            await lms.rpc(_pid_norm(row.get("unsync_playerid")) or target, ["sync", "-"])
        else:
            await lms.rpc(anchor, ["sync", target])
    elif command == "sync_list_sync_all":
        for row in rows:
            target = _pid_norm(row.get("playerid"))
            if target and not bool(row.get("checked")):
                await lms.rpc(anchor, ["sync", target])
    elif command == "sync_list_unsync_all":
        unsynced: Set[str] = set()
        for row in rows:
            target = _pid_norm(row.get("unsync_playerid") or row.get("playerid"))
            if target and bool(row.get("checked")) and target not in unsynced:
                await lms.rpc(target, ["sync", "-"])
                unsynced.add(target)
    elif command in ("sync_list_get", "sync_list_refresh", "sync_list_apply"):
        pass
    else:
        raise ValueError(f"unknown sync list command '{command}'")

    await asyncio.sleep(0.25)
    return await _sync_list_payload(anchor)


def _payload_has_sync_fields(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    return any(key in payload for key in ("sync_master", "sync_slaves", "syncmaster", "syncslaves", "synced_to"))


async def fresh_status_for_push(playerid: str, count: int = STATUS_SUBSCRIBE_COUNT) -> Dict[str, Any]:
    st = await lms.status(playerid, count)
    if isinstance(st, dict) and st:
        st.setdefault("sync_master", "")
        st.setdefault("sync_slaves", "")
        _normalize_art_fields(st)
        _enrich_status_payload(st, playerid)
        _rewrite_status_art_for_broker(st, playerid)
        _normalize_player_display_fields(playerid, st)
        _last_status_by_key[playerid] = dict(st)
    return st


async def verify_transport_modes_later(playerid: str, player_name: str, channel: str) -> None:
    try:
        await asyncio.sleep(TRANSPORT_MODE_VERIFY_DELAY_SECS)
        st = await lms.status(playerid, 1)
        if not isinstance(st, dict) or not st:
            return
        prev = _last_status_by_key.setdefault(playerid, {})
        payload: Dict[str, Any] = {}
        for key in ("repeat", "shuffle"):
            raw = st.get(f"playlist {key}", st.get(f"playlist_{key}", st.get(key, None)))
            if raw is None:
                continue
            val = _safe_int(raw, 0)
            old = prev.get(f"playlist {key}", prev.get(f"playlist_{key}", prev.get(key, None)))
            if old is None or _safe_int(old, -1) != val:
                payload[f"playlist {key}"] = val
                payload[f"playlist_{key}"] = val
                payload[key] = val
                prev[f"playlist {key}"] = val
                prev[f"playlist_{key}"] = val
                prev[key] = val
        if payload:
            await ws_broadcast_status({
                "t": "push",
                "src": "broker",
                "channel": channel or _cometd_response_channel or "/slim/_/response",
                "playerid": playerid,
                "player_name": player_name,
                "full": False,
                "complete": False,
                "payload": payload
            })
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"transport mode delayed verify failed for {playerid}: {_safe_str(e)}")
    finally:
        _transport_mode_verify_tasks.pop(playerid, None)

def schedule_transport_mode_verify(playerid: str, player_name: str, channel: str, payload: Dict[str, Any]) -> None:
    if not playerid or not isinstance(payload, dict):
        return
    if ("playlist repeat" in payload or "playlist_repeat" in payload) and ("playlist shuffle" in payload or "playlist_shuffle" in payload):
        return
    task = _transport_mode_verify_tasks.get(playerid)
    if task is not None and not task.done():
        return
    _transport_mode_verify_tasks[playerid] = asyncio.create_task(verify_transport_modes_later(playerid, player_name, channel))


async def verify_transport_command_later(playerid: str, player_name: str, command: str, before: Dict[str, Any]) -> None:
    try:
        before_sig = _queue_refresh_signature(before, playerid)
        before_mode = _safe_str(before.get("mode")).strip().lower()
        expected_mode = {"play": "play", "pause": "pause", "stop": "stop"}.get(command, "")
        for delay in (0.35, 0.9, 2.0):
            await asyncio.sleep(delay)
            try:
                st = await lms.status(playerid, 1)
            except Exception:
                continue
            if not isinstance(st, dict) or not st:
                continue
            st.setdefault("sync_master", "")
            st.setdefault("sync_slaves", "")
            _normalize_art_fields(st)
            _enrich_status_payload(st, playerid)
            _rewrite_status_art_for_broker(st, playerid)
            _normalize_player_display_fields(playerid, st)

            current_sig = _queue_refresh_signature(st, playerid)
            current_mode = _safe_str(st.get("mode")).strip().lower()
            confirmed = (
                (command in ("next", "prev", "queue_goto", "goto") and bool(current_sig) and current_sig != before_sig) or
                (bool(expected_mode) and current_mode == expected_mode and current_mode != before_mode)
            )
            previous = dict(_last_status_by_key.get(playerid) or before)
            payload = _diff(previous, st)
            _last_status_by_key[playerid] = dict(st)
            if payload:
                await ws_broadcast_status({
                    "t": "push",
                    "src": "broker",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": playerid,
                    "player_name": player_name,
                    "full": False,
                    "complete": False,
                    "payload": payload,
                })
            if confirmed:
                if current_sig and current_sig != before_sig:
                    _last_queue_refresh_sig_by_playerid[playerid] = current_sig
                    await _broadcast_queue_snapshot_for_player(playerid, player_name)
                break
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"TRANSPORT VERIFY failed playerid={playerid} command={command}: {_safe_str(e)}")
    finally:
        _transport_command_verify_tasks.pop(playerid, None)


def schedule_transport_command_verify(playerid: str, player_name: str, command: str) -> None:
    if not playerid:
        return
    old = _transport_command_verify_tasks.get(playerid)
    if old is not None and not old.done():
        old.cancel()
    before = dict(_last_status_by_key.get(playerid) or {})
    _transport_command_verify_tasks[playerid] = asyncio.create_task(
        verify_transport_command_later(playerid, player_name, command, before)
    )


async def _refresh_pandora_status_after_action(playerid: str, player_name: str) -> None:
    key = playerid.lower()
    try:
        for delay in (0.45, 1.0, 2.0, 4.0, 8.0):
            await asyncio.sleep(delay)
            try:
                st = await lms.status(playerid, 1)
            except Exception as e:
                dbg(f"PANDORA STATUS refresh failed playerid={playerid}: {type(e).__name__}: {_safe_str(e)}")
                continue
            if not isinstance(st, dict) or not st:
                continue
            st.setdefault("sync_master", "")
            st.setdefault("sync_slaves", "")
            _normalize_art_fields(st)
            _enrich_status_payload(st, playerid)
            _rewrite_status_art_for_broker(st, playerid)
            _normalize_player_display_fields(playerid, st)
            if _norm_key(st.get("current_title") or st.get("title")) == "playthisstation":
                path = _safe_str(st.get("np_path") or st.get("path") or st.get("url")).strip().lower()
                if path.startswith("frpandora") or "fr_pandora" in path:
                    continue
            previous = dict(_last_status_by_key.get(playerid) or _last_status_by_key.get(key) or {})
            payload = _diff(previous, st) if previous else st
            _last_status_by_key[playerid] = dict(st)
            _last_status_by_key[key] = dict(st)
            if payload:
                await ws_broadcast_status({
                    "t": "push",
                    "src": "broker",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": playerid,
                    "player_name": player_name or _playerid_to_name.get(key, ""),
                    "full": False,
                    "complete": False,
                    "payload": payload,
                })
    except asyncio.CancelledError:
        raise
    finally:
        if _pandora_status_refresh_tasks.get(key) is asyncio.current_task():
            _pandora_status_refresh_tasks.pop(key, None)


def schedule_pandora_status_refresh(playerid: str, player_name: str = "") -> None:
    if not playerid:
        return
    key = playerid.lower()
    old = _pandora_status_refresh_tasks.get(key)
    if old is not None and not old.done():
        old.cancel()
    _pandora_status_refresh_tasks[key] = asyncio.create_task(
        _refresh_pandora_status_after_action(playerid, player_name)
    )


async def full_queue_status_for_push(playerid: str, count: int = 200) -> Dict[str, Any]:
    cnt = _safe_int(count, 200)
    if cnt < 1:
        cnt = 1
    if cnt > 999:
        cnt = 999
    r = await lms.rpc(playerid, ["status", 0, cnt, f"tags:{STATUS_TAGS}"])
    st = (r.get("result") or {}) if isinstance(r, dict) else {}
    if isinstance(st, dict) and st:
        st.setdefault("sync_master", "")
        st.setdefault("sync_slaves", "")
        _normalize_art_fields(st)
        _enrich_status_payload(st, playerid)
        _rewrite_status_art_for_broker(st, playerid)
        _normalize_player_display_fields(playerid, st)
    return st


async def cometd_post(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    global _cometd_session
    if _cometd_session is None or _cometd_session.closed:
        _cometd_session = ClientSession(timeout=ClientTimeout(total=70))
    assert _cometd_session is not None
    async with _cometd_session.post(LMS_COMETD, json=msgs) as resp:
        txt = await resp.text()
        if resp.status != 200:
            raise RuntimeError(f"CometD HTTP {resp.status}: {txt[:200]}")
        return json.loads(txt)


def next_cometd_id() -> str:
    global _cometd_msg_id
    _cometd_msg_id += 1
    return str(_cometd_msg_id)


async def cometd_meta_subscribe(channel: str) -> None:
    if not channel:
        return
    res = await cometd_post([{
        "channel": "/meta/subscribe",
        "clientId": _cometd_client_id,
        "subscription": channel,
        "id": next_cometd_id()
    }])
    ok = any(m.get("channel") == "/meta/subscribe" and m.get("successful") is True for m in res)
    if ok:
        dbg(f"CometD subscribed to {channel}")
    else:
        dbg(f"CometD subscribe FAILED for {channel}: {res}")


async def cometd_handshake() -> None:
    global _cometd_client_id, _cometd_connected, _cometd_response_channel
    _cometd_connected = False
    res = await cometd_post([{
        "channel": "/meta/handshake",
        "id": next_cometd_id(),
        "version": "1.0",
        "supportedConnectionTypes": ["long-polling"]
    }])
    for m in res:
        if m.get("channel") == "/meta/handshake" and m.get("successful") is True and m.get("clientId"):
            _cometd_client_id = _safe_str(m.get("clientId"))
            _cometd_response_channel = f"/slim/{_cometd_client_id}/response"
            dbg(f"CometD handshake OK clientId={_cometd_client_id}")
            dbg(f"CometD mode: subscribe:{STATUS_SUBSCRIBE_SECS}, broker_diff={'ON' if BROKER_DIFF else 'OFF'}")
            _cometd_subscribed_playerids.clear()
            _cometd_subscription_expires.clear()
            _last_status_by_key.clear()
            global _cometd_last_rescan
            _cometd_last_rescan = 0.0
            await cometd_meta_subscribe(_cometd_response_channel)
            return
    raise RuntimeError(f"CometD handshake failed: {res}")


async def cometd_connect_once() -> List[Dict[str, Any]]:
    global _cometd_connected
    res = await cometd_post([{
        "channel": "/meta/connect",
        "clientId": _cometd_client_id,
        "connectionType": "long-polling",
        "id": next_cometd_id()
    }])
    for m in res:
        if m.get("channel") == "/meta/connect" and m.get("successful") is True:
            _cometd_connected = True
    return res


async def cometd_status_subscribe(playerid: str) -> None:
    if STATUS_SUBSCRIBE_SECS <= 0:
        return
    req = [{
        "channel": "/slim/request",
        "clientId": _cometd_client_id,
        "id": next_cometd_id(),
        "data": {
            "response": _cometd_response_channel,
            "request": [playerid, ["status", "-", str(STATUS_SUBSCRIBE_COUNT), f"tags:{STATUS_TAGS}", f"subscribe:{STATUS_SUBSCRIBE_SECS}"]]
        }
    }]
    res = await cometd_post(req)
    ok = any(m.get("channel") == "/slim/request" and m.get("successful") is True for m in res)
    if ok:
        _cometd_subscribed_playerids.add(playerid)
        try:
            _cometd_subscription_expires[playerid] = asyncio.get_running_loop().time() + float(STATUS_SUBSCRIBE_SECS)
        except Exception:
            pass
        dbg(f"CometD status subscribe request for {playerid} -> {_cometd_response_channel} (tags:{STATUS_TAGS}, subscribe:{STATUS_SUBSCRIBE_SECS})")
    else:
        dbg(f"CometD status subscribe FAILED for {playerid}: {res}")


async def cometd_scan_and_subscribe_connected() -> None:
    try:
        players = await lms.get_players()
    except Exception as e:
        dbg(f"CometD get_players error: {_safe_str(e)}")
        return

    _reset_player_identity_maps()
    for p in players:
        if _safe_int(p.get("connected"), 0) != 1:
            continue
        pid = _safe_str(p.get("playerid"))
        pname = _safe_str(p.get("name"))
        if pid and pname:
            _remember_player_identity(pid, pname)
        if not pid or pid in _cometd_subscribed_playerids:
            continue
        try:
            await cometd_status_subscribe(pid)
        except Exception as e:
            dbg(f"CometD subscribe error for {pid}: {_safe_str(e)}")


async def cometd_periodic_rescan_and_subscribe() -> None:
    global _cometd_last_rescan
    if RESCAN_SECS <= 0:
        return
    try:
        now = asyncio.get_running_loop().time()
    except Exception:
        return
    if _cometd_last_rescan and (now - _cometd_last_rescan) < RESCAN_SECS:
        return
    _cometd_last_rescan = now
    await cometd_scan_and_subscribe_connected()


async def cometd_renew_status_subscriptions() -> None:
    if STATUS_SUBSCRIBE_SECS <= 0:
        return
    try:
        now = asyncio.get_running_loop().time()
    except Exception:
        return

    # Refresh the player list if this is an empty startup/recovery window.
    if not _playerid_to_name:
        await cometd_scan_and_subscribe_connected()
        return

    for pid in list(_playerid_to_name.keys()):
        if pid.lower() != pid:
            continue
        expires = _cometd_subscription_expires.get(pid, 0.0)
        if not expires or now >= (expires - STATUS_SUBSCRIBE_RENEW_MARGIN_SECS):
            try:
                await cometd_status_subscribe(pid)
            except Exception as e:
                _cometd_subscribed_playerids.discard(pid)
                _cometd_subscription_expires.pop(pid, None)
                dbg(f"CometD renew subscribe error for {pid}: {_safe_str(e)}")
            await asyncio.sleep(0.05)


def _diff(prev: Dict[str, Any], cur: Dict[str, Any]) -> Dict[str, Any]:
    d: Dict[str, Any] = {}
    for k, v in cur.items():
        if k not in prev or prev.get(k) != v:
            d[k] = v
    for k in ("np_source", "np_station", "np_path", "is_live_radio"):
        if k in cur:
            d[k] = cur.get(k)
    return d


def _rti_status_payload(payload: Any) -> Dict[str, Any]:
    """Keep RTI status pushes small; queue/list data is sent as separate messages."""
    if not isinstance(payload, dict):
        return {}

    out: Dict[str, Any] = {}
    keep = (
        "playerid", "player_name", "name",
        "mode", "power", "time", "duration",
        "can_play", "can_pause", "can_stop", "can_next", "can_prev", "can_previous",
        "canPlay", "canPause", "canStop", "canNext", "canPrev", "canPrevious",
        "playlist_cur_index", "playlist_tracks",
        "current_title", "title", "artist", "album", "year", "genre",
        "trackartist", "albumartist", "composer", "conductor",
        "remote_title", "station", "station_name", "np_station", "np_source", "np_path",
        "source_icon_url", "np_source_icon",
        "is_live_radio",
        "artwork_url", "artworkUrl", "artwork_url2", "coverid",
        "mixer volume", "mixer_volume", "volume",
        "playlist repeat", "playlist_repeat", "repeat",
        "playlist shuffle", "playlist_shuffle", "shuffle",
        "sync_master", "sync_slaves",
        "rate", "rating", "canRate", "canRatePositive", "canRateNegative",
        "canThumbsUp", "canThumbsDown", "bitrate", "samplerate",
    )
    for key in keep:
        if key in payload:
            out[key] = payload.get(key)

    rm = payload.get("remoteMeta")
    if isinstance(rm, dict):
        out_rm: Dict[str, Any] = {}
        rm_keep = (
            "id", "title", "artist", "album", "year", "duration",
            "remote_title", "station", "station_name",
            "artwork_url", "artwork_url2",
            "rate", "rating", "canRate", "canRatePositive", "canRateNegative",
            "canThumbsUp", "canThumbsDown",
        )
        for key in rm_keep:
            if key in rm:
                out_rm[key] = rm.get(key)
        if out_rm:
            out["remoteMeta"] = out_rm

    return out


async def ws_broadcast_status(obj: Dict[str, Any]) -> None:
    if not isinstance(obj, dict):
        return
    msg = dict(obj)
    if isinstance(msg.get("payload"), dict):
        msg["payload"] = _rti_status_payload(msg.get("payload"))
    await ws_broadcast(msg)


async def _refresh_sync_status_after_command() -> None:
    global _sync_status_refresh_task
    try:
        await asyncio.sleep(0.45)
        players = await lms.get_players()
        connected = [p for p in players if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))]

        async def fetch_one(player: Dict[str, Any]) -> None:
            pid = _safe_str(player.get("playerid"))
            pname = _safe_str(player.get("name")) or _playerid_to_name.get(pid.lower(), "")
            try:
                st = await lms.status(pid, 1)
            except Exception as e:
                dbg(f"SYNC REFRESH status failed playerid={pid}: {_safe_str(e)}")
                return
            if not isinstance(st, dict):
                return
            sync_payload = {
                "sync_master": _safe_str(st.get("sync_master")).strip(),
                "sync_slaves": _safe_str(st.get("sync_slaves")).strip(),
            }
            prev = _last_status_by_key.setdefault(pid, {})
            changed = any(_safe_str(prev.get(k)).strip() != v for k, v in sync_payload.items())
            prev.update(sync_payload)
            if changed:
                await ws_broadcast_status({
                    "t": "push",
                    "src": "broker",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": pid,
                    "player_name": pname,
                    "full": False,
                    "complete": False,
                    "payload": sync_payload,
                })

        await asyncio.gather(*(fetch_one(p) for p in connected))
        await _broadcast_sync_lists()
    except asyncio.CancelledError:
        raise
    except Exception as e:
        dbg(f"SYNC REFRESH failed: {_safe_str(e)}")
    finally:
        _sync_status_refresh_task = None


def schedule_sync_status_refresh() -> None:
    global _sync_status_refresh_task
    if _sync_status_refresh_task is not None and not _sync_status_refresh_task.done():
        _sync_status_refresh_task.cancel()
    _sync_status_refresh_task = asyncio.create_task(_refresh_sync_status_after_command())


async def cometd_loop(_app: web.Application) -> None:
    global _cometd_client_id, _cometd_connected
    while True:
        try:
            if not _cometd_client_id:
                await cometd_handshake()
                # one-time scan+subscribe ALWAYS
                await cometd_scan_and_subscribe_connected()

            await cometd_periodic_rescan_and_subscribe()
            await cometd_renew_status_subscriptions()

            res = await cometd_connect_once()

            for m in res:
                ch = _safe_str(m.get("channel"))
                if not ch or ch.startswith("/meta/"):
                    continue

                data = m.get("data") or {}
                if not isinstance(data, dict):
                    continue


                # Normalize artwork URLs so RTI doesn't see /imageproxy/.../image.jpg
                _normalize_art_fields(data)

                if ch == _cometd_response_channel:
                    pid = _safe_str(data.get("playerid"))
                    pname = _safe_str(data.get("player_name")) or _safe_str(data.get("player")) or ""
                    if not pid and pname:
                        pid = _playerid_from_unique_name(pname)
                        if pid:
                            dbg("COMETD RECOVER playerid=%s from player_name=%s channel=%s" % (pid, pname, ch))
                    if not pid:
                        dbg("COMETD DROP missing playerid channel=%s player_name=%s keys=%s raw=%s" % (
                            ch,
                            pname,
                            ",".join(sorted([_safe_str(k) for k in data.keys()])),
                            _json_dumps(data)
                        ))
                        continue

                    data.setdefault("sync_master", "")
                    data.setdefault("sync_slaves", "")
                    _enrich_status_payload(data, pid)
                    _rewrite_status_art_for_broker(data, pid)
                    _normalize_player_display_fields(pid, data)
                    schedule_transport_mode_verify(pid, pname, ch, data)

                    try:
                        qsig = _queue_refresh_signature(data, pid)
                        if qsig:
                            last_qsig = _last_queue_refresh_sig_by_playerid.get(pid)
                            if last_qsig != qsig:
                                _last_queue_refresh_sig_by_playerid[pid] = qsig
                                await _broadcast_queue_snapshot_for_player(pid, pname)
                    except Exception:
                        pass

                    if not BROKER_DIFF:
                        _last_status_by_key[pid] = dict(data)
                        await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": True, "payload": data})
                        if _payload_has_sync_fields(data):
                            schedule_sync_status_refresh()
                        continue

                    prev = _last_status_by_key.get(pid)
                    if prev is None:
                        _last_status_by_key[pid] = dict(data)
                        await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": True, "payload": data})
                        if _payload_has_sync_fields(data):
                            schedule_sync_status_refresh()
                    else:
                        d = _diff(prev, data)
                        if d:
                            prev.update(data)
                            await ws_broadcast_status({"t": "push", "src": "cometd", "channel": ch, "playerid": pid, "player_name": pname, "full": False, "payload": d})
                            if _payload_has_sync_fields(d):
                                schedule_sync_status_refresh()

        except asyncio.CancelledError:
            break
        except Exception as e:
            dbg(f"CometD loop error: {_safe_str(e)}")
            _cometd_client_id = ""  # force new handshake
            _cometd_connected = False
            await asyncio.sleep(3)


async def health(_req: web.Request) -> web.Response:
    license_info = _license_status()
    unit_name = _pcp_config_hostname()
    light_mode = _broker_light_mode()
    cometd_connected = bool(_cometd_connected) and not light_mode
    return web.json_response({
        "ok": True,
        "app": "lyrion_broker",
        "ver": APP_VERSION,
        "lyrion_ver": LYRION_VERSION,
        "broker_id": BROKER_ID,
        "hostname": unit_name or _default_unit_hostname(),
        "live_hostname": _live_system_hostname(),
        "hostname_reboot_required": _hostname_reboot_required(),
        "hostname_reboot_pending": _hostname_reboot_pending(),
        "hostname_reboot_target": _safe_str(_setup_cache.get("hostname_reboot_target")).strip(),
        "license": license_info,
        "legal": {
            "accepted": _legal_terms_accepted(),
            "terms_version": LEGAL_TERMS_VERSION,
            "accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        },
        "listen": f"{LISTEN_HOST}:{LISTEN_PORT}",
        "lms_base": LMS_BASE,
        "mode": {
            "broker_mode": _broker_mode(),
            "broker_diff": BROKER_DIFF,
            "status_subscribe_secs": STATUS_SUBSCRIBE_SECS,
            "force_status_after_command": FORCE_STATUS_AFTER_COMMAND,
            "rti_ws_first_send_delay_secs": RTI_WS_FIRST_SEND_DELAY_SECS,
            "pi_model": _raspberry_pi_model(),
            "local_player_limit": _local_player_limit(),
            "broker_startup": "bootsync_watchdog",
        },
        "rti_ws": dict(_rti_ws_diag),
        "cometd": {
            "url": "" if light_mode else LMS_COMETD,
            "clientId": "" if light_mode else _cometd_client_id,
            "response_channel": "" if light_mode else _cometd_response_channel,
            "connected": cometd_connected,
        }
    })


def _rti_player_sort_key(player: Dict[str, Any]) -> Tuple[int, str, int, int, str]:
    local_prefix = ":".join(_safe_str(_license_status().get("device_mac")).lower().split(":")[:5])

    def managed_mac_parts(playerid: str) -> Tuple[str, int]:
        parts = playerid.split(":")
        if len(parts) != 6:
            return ("", 9999)
        match = re.fullmatch(r"a([0-8])", parts[5])
        if not match:
            return ("", 9999)
        return (":".join(parts[:5]), int(match.group(1)))

    playerid = _safe_str(player.get("playerid") or player.get("mac")).lower()
    prefix, slot = managed_mac_parts(playerid)
    name = _safe_str(player.get("name")).lower()
    if prefix and prefix == local_prefix:
        return (0, prefix, slot, 0, name)
    if prefix:
        return (1, prefix, slot, 0, name)
    match = re.search(r"(\d+)", name)
    return (2, "", 9999, int(match.group(1)) if match else 9999, name)


def _rti_connected_players(players: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    connected_players = [
        p for p in players
        if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
    ]

    connected_players.sort(key=_rti_player_sort_key)
    return connected_players[:RTI_MAX_PLAYERS]


def _rti_cached_players() -> List[Dict[str, Any]]:
    raw = _setup_cache.get("rti_player_cache")
    if not isinstance(raw, list):
        return []
    out: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        pid = _safe_str(item.get("playerid") or item.get("mac")).strip().lower()
        if not pid or pid in seen:
            continue
        seen.add(pid)
        out.append({
            "name": _safe_str(item.get("name") or pid),
            "playerid": pid,
            "mac": pid,
            "connected": _safe_int(item.get("connected"), 0),
            "power": _safe_int(item.get("power"), 0),
        })
    out.sort(key=_rti_player_sort_key)
    return out[:RTI_MAX_PLAYERS]


def _rti_export_players(players: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    live_by_pid: Dict[str, Dict[str, Any]] = {}
    for player in players:
        pid = _safe_str(player.get("playerid")).strip().lower()
        if not pid:
            continue
        live_by_pid[pid] = {
            "name": _safe_str(player.get("name") or pid),
            "playerid": pid,
            "mac": pid,
            "connected": _safe_int(player.get("connected"), 0),
            "power": _safe_int(player.get("power"), 0),
        }

    cached_by_pid: Dict[str, Dict[str, Any]] = {
        _safe_str(player.get("playerid")).strip().lower(): player
        for player in _rti_cached_players()
        if _safe_str(player.get("playerid")).strip()
    }

    merged: Dict[str, Dict[str, Any]] = dict(cached_by_pid)
    for pid, player in live_by_pid.items():
        cached = cached_by_pid.get(pid)
        if _safe_int(player.get("connected"), 0) == 1 or cached:
            merged[pid] = player

    exported = list(merged.values())
    exported.sort(key=_rti_player_sort_key)
    exported = exported[:RTI_MAX_PLAYERS]

    refreshed_cache = []
    for player in exported:
        if _safe_int(player.get("connected"), 0) == 1 or _safe_str(player.get("playerid")) in cached_by_pid:
            refreshed_cache.append({
                "name": _safe_str(player.get("name") or player.get("playerid")),
                "playerid": _safe_str(player.get("playerid")).strip().lower(),
                "mac": _safe_str(player.get("playerid")).strip().lower(),
                "connected": _safe_int(player.get("connected"), 0),
                "power": _safe_int(player.get("power"), 0),
            })
    if refreshed_cache != _setup_cache.get("rti_player_cache"):
        _setup_cache["rti_player_cache"] = refreshed_cache
        _save_setup_config()

    return exported


def _player_inventory_warnings(players: List[Dict[str, Any]]) -> List[str]:
    connected_players = [
        p for p in players
        if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
    ]
    warnings: List[str] = []
    seen: Dict[str, List[str]] = {}
    for player in connected_players:
        mac = _safe_str(player.get("playerid")).strip().lower()
        if not mac:
            continue
        seen.setdefault(mac, []).append(_safe_str(player.get("name")) or mac)
    duplicates = {
        mac: names for mac, names in seen.items()
        if len(names) > 1
    }
    if duplicates:
        warnings.append(
            "Duplicate LMS player MAC addresses detected: " + "; ".join(
                "{} ({})".format(mac, ", ".join(names))
                for mac, names in sorted(duplicates.items())
            )
        )
    if len(connected_players) > RTI_MAX_PLAYERS:
        warnings.append(
            "RTI supports {} mapped players. {} connected players were found; only the first {} are exported.".format(
                RTI_MAX_PLAYERS,
                len(connected_players),
                RTI_MAX_PLAYERS,
            )
        )
    return warnings


async def api_players(_req: web.Request) -> web.Response:
    """Return LMS players in the exact shape needed for RTI driver setup."""
    try:
        if _broker_light_mode():
            return web.json_response({
                "ok": True,
                "players": [],
                "warnings": ["Broker Light does not export RTI server/player mapping."],
                "connected_count": 0,
                "exported_count": 0,
                "max_players": RTI_MAX_PLAYERS,
            })
        players = await lms.get_players()
        out: List[Dict[str, Any]] = []
        export_players = _rti_export_players(players)
        for i, p in enumerate(export_players):
            playerid = _safe_str(p.get("playerid"))
            out.append({
                "index": i,
                "rti_player": f"Player {i + 1}",
                "rti_name_setting": f"Player{i}_Name",
                "rti_mac_setting": f"Player{i}_MAC",
                "name": _safe_str(p.get("name")),
                "playerid": playerid,
                "mac": playerid,
                "connected": _safe_int(p.get("connected"), 0),
                "power": _safe_int(p.get("power"), 0),
            })
        return web.json_response({
            "ok": True,
            "players": out,
            "warnings": _player_inventory_warnings(players),
            "connected_count": len([
                p for p in players
                if _safe_int(p.get("connected"), 0) == 1 and _safe_str(p.get("playerid"))
            ]),
            "exported_count": len(out),
            "max_players": RTI_MAX_PLAYERS,
        })
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e)}, status=500)


async def api_system_players_status(_req: web.Request) -> web.Response:
    try:
        rows = _pcp_player_sessions()
        macs = {
            _safe_str(row.get("mac")).strip().lower()
            for row in rows
            if _safe_str(row.get("mac")).strip()
        }
        running_macs = _running_squeezelite_macs(macs) if macs else set()
        running_processes = _managed_squeezelite_processes(macs) if macs else []
        ready = bool(rows) and len(running_macs) >= len(macs)
        return web.json_response({
            "ok": True,
            "configured": len(rows),
            "running": len(running_macs),
            "process_count": len(running_processes),
            "duplicate_processes": max(0, len(running_processes) - len(running_macs)),
            "ready": ready,
        })
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e)}, status=500)


async def api_pandora_v1(req: web.Request) -> web.Response:
    if not _license_status().get("valid"):
        return web.Response(text="Broker license expired", status=403)
    try:
        account = _safe_int(req.query.get("account"), -1)
        action = _safe_str(req.query.get("action")).strip()
        if account < 0 or account > 3:
            return web.Response(text="Invalid Pandora account", status=400)
        if not action:
            return web.Response(text="Missing Pandora action", status=400)
        _load_setup_config()
        config = _pandora_accounts_cache()[account]
        params = {str(key): _safe_str(value) for key, value in req.query.items()}
        result = await asyncio.to_thread(
            pandora_backend.handle,
            account,
            action,
            params,
            config,
        )
        if isinstance(result, str):
            return web.Response(text=result, content_type="text/plain")
        return web.json_response(result if result is not None else {})
    except Exception as e:
        dbg("PANDORA API account=%s action=%s error=%s" % (
            _safe_str(req.query.get("account")),
            _safe_str(req.query.get("action")),
            _safe_str(e),
        ))
        return web.Response(text=_safe_str(e) or "Pandora request failed", status=502)


def _pandora_plugin_zip(letter: str) -> str:
    clean_letter = _safe_str(letter).strip().upper()
    if clean_letter not in ("A", "B", "C", "D"):
        return ""
    return os.path.join(os.path.dirname(__file__), "pandora_plugins", f"Pandora-{clean_letter}.zip")


def _copy_bytes_if_changed(path: str, data: bytes) -> bool:
    try:
        if os.path.exists(path):
            with open(path, "rb") as handle:
                if handle.read() == data:
                    return False
    except Exception:
        pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as handle:
        handle.write(data)
    return True


def _strip_pandora_icon_override_pm(text: str) -> str:
    return _re.sub(
        r"\nsub _pluginDataFor \{\n\s+my \(\$class, \$key\) = @_;\n.*?\n\}\n(?=\nsub )",
        "\n",
        text,
        count=1,
        flags=_re.S,
    )


def _ensure_pandora_classic_icon_pm(text: str) -> str:
    return _strip_pandora_icon_override_pm(text)


def _installed_pandora_plugin_roots() -> List[str]:
    roots = []
    for base in (
        "/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins",
        "/var/lib/squeezeboxserver/cache/InstalledPlugins/Plugins",
        "/var/lib/squeezeboxserver/Cache/InstalledPlugins/Plugins",
    ):
        if os.path.isdir(base):
            roots.append(base)
    return roots


def _pandora_plugin_expected_assets(letter: str, plugin_id: str) -> Dict[str, bytes]:
    source_path = _pandora_plugin_zip(letter)
    if not source_path or not os.path.isfile(source_path):
        return {}
    with zipfile.ZipFile(source_path, "r") as source:
        zip_html = f"HTML/EN/plugins/{plugin_id}/html"
        names = set(source.namelist())
        return {
            name: source.read(f"{zip_html}/{name}")
            for name in ("icon_old.png", "icon.png", "icon.svg", "icon_svg.png")
            if f"{zip_html}/{name}" in names
        }


def _repair_installed_pandora_plugin_icons() -> bool:
    changed = False
    for index, letter in enumerate(("A", "B", "C", "D")):
        plugin_id = f"FR_Pandora_{index}"
        try:
            assets = _pandora_plugin_expected_assets(letter, plugin_id)
        except Exception as error:
            dbg(f"Pandora icon repair source read failed for {plugin_id}: {error}")
            continue
        if not assets:
            continue
        for base in _installed_pandora_plugin_roots():
            plugin_root = os.path.join(base, plugin_id)
            if not os.path.isdir(plugin_root):
                continue
            html_dir = os.path.join(plugin_root, "HTML", "EN", "plugins", plugin_id, "html")
            for name, data in assets.items():
                try:
                    if _copy_bytes_if_changed(os.path.join(html_dir, name), data):
                        changed = True
                except Exception as error:
                    dbg(f"Pandora icon repair write failed for {plugin_id}/{name}: {error}")
            install_xml = os.path.join(plugin_root, "install.xml")
            try:
                if os.path.isfile(install_xml):
                    with open(install_xml, "r", encoding="utf-8") as handle:
                        text = handle.read()
                    repaired = _re.sub(r"<version>[^<]+</version>", f"<version>{PANDORA_PLUGIN_VERSION}</version>", text, count=1)
                    repaired = _re.sub(
                        rf"<icon>plugins/{plugin_id}/html/icon(?:_svg)?\.png</icon>",
                        f"<icon>plugins/{plugin_id}/html/icon.png</icon>",
                        repaired,
                        count=1,
                    )
                    if repaired != text:
                        with open(install_xml, "w", encoding="utf-8") as handle:
                            handle.write(repaired)
                        changed = True
            except Exception as error:
                dbg(f"Pandora install.xml repair failed for {plugin_id}: {error}")
            plugin_pm = os.path.join(plugin_root, "Plugin.pm")
            try:
                if os.path.isfile(plugin_pm):
                    with open(plugin_pm, "r", encoding="utf-8") as handle:
                        text = handle.read()
                    repaired = _ensure_pandora_classic_icon_pm(text)
                    if repaired != text:
                        with open(plugin_pm, "w", encoding="utf-8") as handle:
                            handle.write(repaired)
                        changed = True
            except Exception as error:
                dbg(f"Pandora Plugin.pm repair failed for {plugin_id}: {error}")
    return changed


def _installed_pandora_plugin_needs_repair() -> bool:
    for index, letter in enumerate(("A", "B", "C", "D")):
        plugin_id = f"FR_Pandora_{index}"
        try:
            expected_assets = _pandora_plugin_expected_assets(letter, plugin_id)
        except Exception:
            expected_assets = {}
        for base in _installed_pandora_plugin_roots():
            plugin_root = os.path.join(base, plugin_id)
            if not os.path.isdir(plugin_root):
                continue
            install_xml = os.path.join(plugin_root, "install.xml")
            try:
                if os.path.isfile(install_xml):
                    with open(install_xml, "r", encoding="utf-8") as handle:
                        text = handle.read()
                    if f"<version>{PANDORA_PLUGIN_VERSION}</version>" not in text:
                        return True
                    if f"<icon>plugins/{plugin_id}/html/icon.png</icon>" not in text:
                        return True
            except Exception:
                return True
            plugin_pm = os.path.join(plugin_root, "Plugin.pm")
            try:
                if os.path.isfile(plugin_pm):
                    with open(plugin_pm, "r", encoding="utf-8") as handle:
                        text = handle.read()
                        if _ensure_pandora_classic_icon_pm(text) != text:
                            return True
            except Exception:
                return True
            html_dir = os.path.join(plugin_root, "HTML", "EN", "plugins", plugin_id, "html")
            for asset_name in ("icon_old.png", "icon.png", "icon.svg", "icon_svg.png"):
                path = os.path.join(html_dir, asset_name)
                expected = expected_assets.get(asset_name)
                if not os.path.isfile(path):
                    return True
                if expected is not None:
                    try:
                        with open(path, "rb") as handle:
                            if handle.read() != expected:
                                return True
                    except Exception:
                        return True
    return False


def _pandora_proxy_base_for_plugin(req: web.Request) -> str:
    if not _broker_light_mode() and (LMS_BASE.rstrip("/") == LOCAL_LMS_BASE):
        return f"http://127.0.0.1:{LISTEN_PORT}"
    return f"{req.scheme}://{req.host}".rstrip("/")


def _pandora_plugin_zip_bytes(letter: str, broker_base: str) -> bytes:
    clean_letter = _safe_str(letter).strip().upper()
    clean_base = _safe_str(broker_base).strip().rstrip("/")
    cache_key = (clean_letter, clean_base)
    cached = _pandora_plugin_zip_cache.get(cache_key)
    if cached is not None:
        return cached
    source_path = _pandora_plugin_zip(clean_letter)
    if not source_path or not os.path.isfile(source_path):
        return b""
    output = io.BytesIO()
    with zipfile.ZipFile(source_path, "r") as source, zipfile.ZipFile(output, "w") as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename in ("Plugin.pm", "ProtocolHandler.pm"):
                text = data.decode("utf-8")
                text = _re.sub(
                    r"https?://[^'\"\s]+/api/pandora/v1",
                    clean_base + "/api/pandora/v1",
                    text,
                )
                if info.filename == "Plugin.pm":
                    text = _ensure_pandora_classic_icon_pm(text)
                data = text.encode("utf-8")
            elif os.path.basename(info.filename) == "install.xml":
                text = data.decode("utf-8")
                text = _re.sub(r"<version>[^<]+</version>", f"<version>{PANDORA_PLUGIN_VERSION}</version>", text, count=1)
                text = _re.sub(
                    rf"<icon>plugins/FR_Pandora_([0-3])/html/icon(?:_svg)?\.png</icon>",
                    r"<icon>plugins/FR_Pandora_\1/html/icon.png</icon>",
                    text,
                    count=1,
                )
                text = _re.sub(
                    r"<description>[^<]*</description>",
                    "<description>Play music from Pandora. A paid Pandora account is recommended for ad-free playback.</description>",
                    text,
                    count=1,
                )
                text = _re.sub(
                    r"<creator>[^<]*</creator>",
                    "<creator>Original plugin by Fusion Research. Modified by Skunk Works with assistance from OpenAI Codex.</creator>",
                    text,
                    count=1,
                )
                text = _re.sub(r"\s*<email>[^<]*</email>", "", text, count=1)
                data = text.encode("utf-8")
            elif info.filename == "strings.txt":
                text = data.decode("utf-8")
                text = _re.sub(
                    r"PLUGIN_FR_PANDORA_DESC(?=\r?\n)",
                    "PLUGIN_FR_PANDORA_DESC_V2",
                    text,
                    count=1,
                )
                text = text.replace(
                    "Play music from Pandora. Requires a Pandora One account.",
                    "Play music from Pandora. A paid Pandora account is recommended for ad-free playback.",
                )
                text = text.replace(
                    "No Pandora One credentials are defined for this account.",
                    "No Pandora credentials are defined for this account.",
                )
                data = text.encode("utf-8")
            info.create_system = 3
            if info.filename.endswith("/"):
                info.external_attr = (0o40755 << 16) | 0x10
            else:
                info.external_attr = 0o100644 << 16
            target.writestr(info, data)
    result = output.getvalue()
    _pandora_plugin_zip_cache[cache_key] = result
    return result


async def api_pandora_plugin_zip(req: web.Request) -> web.StreamResponse:
    letter = _safe_str(req.match_info.get("letter")).strip().upper()
    data = _pandora_plugin_zip_bytes(letter, _pandora_proxy_base_for_plugin(req))
    if not data:
        raise web.HTTPNotFound()
    return web.Response(
        body=data,
        content_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="Pandora-{letter}.zip"'},
    )


async def api_pandora_repository(req: web.Request) -> web.Response:
    base = f"{req.scheme}://{req.host}"
    proxy_base = _pandora_proxy_base_for_plugin(req)
    plugin_rows = []
    for index, letter in enumerate(("A", "B", "C", "D")):
        data = _pandora_plugin_zip_bytes(letter, proxy_base)
        if not data:
            continue
        sha = hashlib.sha1(data).hexdigest()
        plugin_rows.append(f"""
    <plugin name="FR_Pandora_{index}" version="{PANDORA_PLUGIN_VERSION}" minTarget="7.5" maxTarget="*">
      <title lang="EN">Pandora {letter}</title>
      <desc lang="EN">Broker-backed Pandora account {index}. Paid account recommended for ad-free playback.</desc>
      <category>musicservices</category>
      <url>{base}/api/pandora/plugins/Pandora-{letter}.zip</url>
      <sha>{sha}</sha>
      <creator>Original plugin by Fusion Research. Modified by Skunk Works with assistance from OpenAI Codex.</creator>
    </plugin>""")
    xml = """<?xml version="1.0"?>
<extensions>
  <details><title lang="EN">Lyrion Broker Pandora A-D</title></details>
  <plugins>
{plugins}
  </plugins>
</extensions>
""".format(plugins="\n".join(plugin_rows))
    return web.Response(text=xml, content_type="application/xml")




# ---------------- Setup web UI (Option A: broker-only config) ----------------

def _html_escape(s: Any) -> str:
    s = _safe_str(s)
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;")
             .replace("'", "&#39;"))


_SETUP_STYLE = """
  :root {
    color-scheme: light;
    --ink: #17202b;
    --muted: #657286;
    --line: #d7dee8;
    --panel: #ffffff;
    --canvas: #edf1f6;
    --accent: #5f2aa6;
    --accent-dark: #442078;
    --success: #18794e;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0 !important;
    padding: 0 !important;
    max-width: none !important;
    color: var(--ink);
    background: var(--canvas);
    font-family: Inter, "Segoe UI", Arial, sans-serif !important;
  }
  .brand-header {
    background: #050607;
    border-bottom: 3px solid var(--accent);
    box-shadow: 0 5px 18px rgba(19, 26, 36, .24);
  }
  .brand-strip {
    display: grid;
    grid-template-columns: 1.35fr 1.35fr 1fr .82fr;
    align-items: center;
    gap: clamp(14px, 3vw, 42px);
    width: min(1180px, calc(100% - 32px));
    min-height: 112px;
    margin: 0 auto;
    padding: 14px 6px;
  }
  .brand-strip img {
    display: block;
    width: 100%;
    height: 76px;
    object-fit: contain;
  }
  .brand-strip img:last-child { height: 88px; }
  .brand-bar {
    border-top: 1px solid #23262c;
    background: #0e1013;
  }
  .brand-bar-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    width: min(1180px, calc(100% - 32px));
    margin: 0 auto;
    padding: 12px 6px;
  }
  .brand-title { color: #fff; font-size: 18px; font-weight: 700; }
  .brand-meta {
    color: #aeb7c5;
    font-size: 13px;
    text-align: right;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }
  .unit-pill {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    border: 1px solid #4b5563;
    background: #1f2937;
    color: #e5e7eb;
    white-space: nowrap;
  }
  .unit-pill::before {
    content: "";
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    box-shadow: 0 0 9px currentColor;
  }
  .unit-pill.ok { border-color: #166534; background: #052e16; color: #86efac; }
  .unit-pill.error { border-color: #991b1b; background: #450a0a; color: #fca5a5; }
  .page-shell {
    width: min(1180px, calc(100% - 32px));
    margin: 24px auto 44px;
  }
  .page-nav {
    display: flex;
    gap: 8px;
    margin-bottom: 18px;
  }
  .page-nav a, .page-nav b {
    display: inline-block;
    padding: 8px 13px;
    border: 1px solid var(--line);
    border-radius: 6px;
    background: #fff;
    color: var(--accent-dark);
    text-decoration: none;
  }
  .page-nav b { background: var(--accent); border-color: var(--accent); color: #fff; }
  form, .quick-links {
    padding: 22px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--panel);
    box-shadow: 0 2px 8px rgba(25, 39, 58, .06);
  }
  h2 { margin: 0 0 8px; font-size: 25px; }
  h3 {
    margin: 26px 0 12px !important;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--line);
    color: #29384b;
    font-size: 18px;
  }
  input[type="text"], input[type="password"], input[type="number"], textarea, select {
    min-height: 38px;
    max-width: 100%;
    padding: 8px 10px !important;
    border: 1px solid #b9c4d2;
    border-radius: 5px;
    background: #fff;
    color: var(--ink);
    font: inherit;
  }
  input:focus, textarea:focus, select:focus {
    border-color: var(--accent);
    outline: 3px solid rgba(95, 42, 166, .13);
  }
  button {
    min-height: 38px;
    padding: 8px 15px !important;
    border: 1px solid var(--accent) !important;
    border-radius: 5px !important;
    background: var(--accent) !important;
    color: #fff !important;
    font-weight: 650;
    cursor: pointer;
  }
  button:hover { background: var(--accent-dark) !important; }
  button.needs-account {
    border-color: #b45309 !important;
    background: #f59e0b !important;
    color: #111827 !important;
  }
  button.needs-account:hover {
    background: #d97706 !important;
    color: #111827 !important;
  }
  button:disabled, button:disabled:hover {
    border-color: #aeb7c3 !important;
    background: #c9cfd7 !important;
    color: #687383 !important;
    cursor: not-allowed;
    opacity: .82;
  }
  table {
    width: 100%;
    border: 1px solid var(--line) !important;
    border-collapse: separate !important;
    border-spacing: 0;
    border-radius: 6px;
    overflow: hidden;
  }
  th {
    padding: 9px 8px !important;
    border-bottom: 1px solid var(--line) !important;
    background: #f2f4f8 !important;
    color: #3a4759;
    font-size: 12px;
    text-align: left;
    text-transform: uppercase;
  }
  td { padding: 8px !important; border-top: 1px solid #e8edf3 !important; }
  tbody tr:hover { background: #f8f9fc; }
  code {
    padding: 2px 5px;
    border-radius: 4px;
    background: #eef1f5;
    color: #38465a;
  }
  .save-dock {
    position: sticky !important;
    bottom: 10px !important;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 14px;
    margin: 24px -10px -10px !important;
    padding: 12px 14px !important;
    border: 1px solid #bcc9d8 !important;
    border-radius: 7px;
    background: rgba(247, 249, 252, .96) !important;
    box-shadow: 0 5px 20px rgba(23, 32, 43, .16);
    backdrop-filter: blur(8px);
  }
  .quick-links { margin-top: 18px; }
  .quick-links h3 { margin-top: 0 !important; }
  .quick-links ul { columns: 2; padding-left: 20px; }
  .quick-links li { margin: 8px 0; }
  .update-callout {
    display: none;
    margin: 0 0 18px;
    padding: 12px 14px;
    border: 1px solid #f5c542;
    border-left: 5px solid #d97706;
    border-radius: 8px;
    background: #fff8e1;
    color: #613b00;
    box-shadow: 0 2px 8px rgba(25, 39, 58, .06);
  }
  .update-callout a { color: #5f2aa6; font-weight: 700; }
  .update-callout .muted { color: #765c2d; font-size: 12px; margin-top: 4px; }
  .service-card {
    min-height: 178px;
    height: 100%;
    padding: 15px;
    border: 1px solid var(--line);
    border-radius: 7px;
    background: #f8fafc;
    box-sizing: border-box;
  }
  .service-card-heading {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-bottom: 13px;
  }
  .service-card-heading img {
    width: 54px;
    height: 54px;
    flex: 0 0 54px;
    object-fit: contain;
    border-radius: 7px;
    background: #fff;
  }
  .service-card-heading h3 {
    margin: 0 !important;
    padding: 0;
    border: 0;
  }
  a { color: var(--accent-dark); }
  @media (max-width: 760px) {
    .brand-strip { grid-template-columns: 1fr 1fr; min-height: 0; gap: 8px 18px; }
    .brand-strip img, .brand-strip img:last-child { height: 54px; }
    .brand-bar-inner { align-items: flex-start; flex-direction: column; gap: 5px; }
    .brand-meta { text-align: left; }
    .page-shell { width: min(100% - 20px, 1180px); margin-top: 14px; }
    form, .quick-links { padding: 14px; overflow-x: auto; }
    .quick-links ul { columns: 1; }
    .save-dock { left: 0; right: 0; align-items: stretch; flex-direction: column; }
  }
"""


def _setup_brand_header(version: str, detail: str = "", show_reboot_banner: bool = True) -> str:
    try:
        unit_name = _pcp_config_hostname()
    except Exception:
        unit_name = _safe_str(socket.gethostname()).strip()
    if not unit_name:
        unit_name = "Unknown Unit"
    light_mode = _broker_light_mode()
    connected = bool(globals().get("_cometd_connected")) and not light_mode
    unit_status = "Broker Light" if light_mode else ("LMS Connected" if connected else "LMS Disconnected")
    unit_class = "ok" if connected or light_mode else "error"
    unit_pill = '<span id="unitStatusPill" class="unit-pill {}" data-unit="{}">{} | {}</span>'.format(
        unit_class,
        _html_escape(unit_name),
        _html_escape(unit_name),
        unit_status,
    )
    meta = "{} <span>Broker v{}</span>".format(unit_pill, _html_escape(version))
    if detail:
        meta += " <span>|</span> <span>" + detail + "</span>"
    live_hostname = _live_system_hostname()
    reboot_banner = ""
    if show_reboot_banner and _hostname_reboot_required():
        pending_text = (
            "Hostname change is saved, but pCP still needs one reboot to finish applying it."
            if _hostname_reboot_pending()
            else "Hostname changed to <code>__CONFIGURED_HOST__</code>, but this boot is still running as <code>__LIVE_HOST__</code>."
        )
        reboot_banner = """
<div id="hostnameRebootBanner" style="background:#fff7ed;border-bottom:1px solid #fed7aa;color:#9a3412;">
  <div style="width:min(100% - 32px,1180px);margin:0 auto;padding:12px 0;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;">
    <div><b>Reboot required.</b> __PENDING_TEXT__ Reboot before continuing setup.</div>
    <button id="hostnameRebootNow" type="button" style="font-weight:700;">Reboot Now</button>
  </div>
</div>
""".replace("__PENDING_TEXT__", pending_text).replace("__CONFIGURED_HOST__", _html_escape(unit_name)).replace("__LIVE_HOST__", _html_escape(live_hostname or "unknown"))
    return """
<header class="brand-header">
  <div class="brand-strip">
    <img src="/setup/assets/lyrion.png" alt="Lyrion">
    <img src="/setup/assets/avpro.png" alt="AVPro">
    <img src="/setup/assets/rti.png" alt="RTI">
    <img src="/setup/assets/skunkworks.png" alt="Skunk Works">
  </div>
  <div class="brand-bar">
    <div class="brand-bar-inner">
      <div class="brand-title">Lyrion RTI Broker</div>
      <div class="brand-meta">__BRAND_META__</div>
    </div>
  </div>
</header>
__HOSTNAME_REBOOT_BANNER__
<script>
(function(){
  var pill = document.getElementById('unitStatusPill');
  if (!pill) return;
  var hostnameRebootNow = document.getElementById('hostnameRebootNow');
  var forcedUntil = 0;
  var forcedConnected = false;
  var lmsWasDisconnected = false;
  var lmsReconnectReloadScheduled = false;
  var originalFetch = window.fetch ? window.fetch.bind(window) : null;
  var setupAuthExpiredShown = false;
  function setupLoginUrl() {
    return '/setup/advanced/login?next=' + encodeURIComponent(window.location.pathname + window.location.search);
  }
  function showSetupAuthExpired(message) {
    if (setupAuthExpiredShown) return;
    setupAuthExpiredShown = true;
    var box = document.getElementById('setupAuthExpiredNotice');
    if (!box) {
      box = document.createElement('div');
      box.id = 'setupAuthExpiredNotice';
      box.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:10000;max-width:min(520px,calc(100% - 28px));background:#fff7ed;border:1px solid #fed7aa;border-radius:7px;padding:12px 14px;color:#9a3412;box-shadow:0 4px 14px rgba(15,23,42,.16);font-weight:700;';
      document.body.appendChild(box);
    }
    box.innerHTML = '<div>' + (message || 'Setup session expired. Sign in again to continue.') + '</div>' +
      '<div style="margin-top:10px;"><a href="' + setupLoginUrl() + '"><button type="button">Sign In</button></a></div>';
  }
  function setupRequestUrl(input) {
    try {
      if (typeof input === 'string') return input;
      if (input && input.url) return '' + input.url;
    } catch (error) {}
    return '';
  }
  function isProtectedSetupRequest(url) {
    if (!url) return false;
    try {
      var parsed = new URL(url, window.location.href);
      if (parsed.origin !== window.location.origin) return false;
      var path = parsed.pathname || '';
      if (path === '/health' || path === '/api/setup/session') return false;
      return path.indexOf('/api/setup') === 0 ||
        path.indexOf('/api/update') === 0 ||
        path === '/api/lms_root' ||
        path === '/api/mymusic_menu' ||
        path === '/api/radio_menu' ||
        path === '/api/system/action' ||
        path === '/api/system/plugin' ||
        path === '/api/system/backup' ||
        path === '/api/system/restore' ||
        path === '/api/pandora/account' ||
        path === '/api/pandora/ensure-repository';
    } catch (error) {
      return false;
    }
  }
  if (originalFetch) {
    window.fetch = async function(input, init) {
      var response = await originalFetch(input, init);
      if (response && response.status === 401 && isProtectedSetupRequest(setupRequestUrl(input))) {
        try {
          var data = await response.clone().json();
          if (data && (data.auth_required || /auth|login|session/i.test(data.error || ''))) {
            showSetupAuthExpired(data.error);
          }
        } catch (error) {
          showSetupAuthExpired();
        }
      }
      return response;
    };
  }
  function setUnitState(unit, connected, label) {
    pill.classList.toggle('ok', !!connected);
    pill.classList.toggle('error', !connected);
    pill.textContent = (unit || pill.getAttribute('data-unit') || 'Unknown Unit') +
      ' | ' + (label || (connected ? 'LMS Connected' : 'LMS Disconnected'));
  }
  function setupPageDirty() {
    try {
      if (window.__lyrionSetupDirty === true) return true;
      if (typeof window.lyrionSetupDirty === 'function' && window.lyrionSetupDirty()) return true;
      var saveStatus = document.getElementById('saveStatus');
      if (saveStatus && /unsaved|ready to apply/i.test(saveStatus.textContent || '')) return true;
      var applyPlayers = document.getElementById('applyPlayers');
      if (applyPlayers && applyPlayers.disabled === false) return true;
      var volumeStatus = document.getElementById('volumeStatus');
      if (volumeStatus && /not been saved|unsaved/i.test(volumeStatus.textContent || '')) return true;
    } catch (error) {}
    return false;
  }
  function showReconnectNotice() {
    var box = document.getElementById('lmsReconnectNotice');
    if (!box) {
      box = document.createElement('div');
      box.id = 'lmsReconnectNotice';
      box.style.cssText = 'position:fixed;right:14px;top:14px;z-index:9999;max-width:min(440px,calc(100% - 28px));background:#fff7ed;border:1px solid #fed7aa;border-radius:7px;padding:10px 12px;color:#9a3412;box-shadow:0 4px 14px rgba(15,23,42,.14);font-weight:700;';
      document.body.appendChild(box);
    }
    box.textContent = 'LMS reconnected. Save changes first, then refresh this page.';
  }
  function handleLmsTransition(connected, lightMode) {
    if (lightMode) return;
    if (!connected) {
      lmsWasDisconnected = true;
      return;
    }
    if (!lmsWasDisconnected || lmsReconnectReloadScheduled) return;
    if (setupPageDirty()) {
      showReconnectNotice();
      return;
    }
    lmsReconnectReloadScheduled = true;
    setUnitState(pill.getAttribute('data-unit'), true, 'LMS Reconnected - refreshing');
    window.setTimeout(function(){ window.location.reload(); }, 900);
  }
  async function pollUnitState() {
    try {
      var res = await fetch('/health', {cache: 'no-store'});
      if (!res.ok) throw new Error('health ' + res.status);
      var data = await res.json();
      var lightMode = !!(data.mode && data.mode.broker_mode === 'light');
      var connected = lightMode || !!(data.cometd && data.cometd.connected);
      if (Date.now() < forcedUntil) connected = forcedConnected;
      setUnitState(data.hostname, connected, lightMode ? 'Broker Light' : '');
      handleLmsTransition(connected, lightMode);
      window.dispatchEvent(new CustomEvent('lyrion-health', {
        detail: {brokerReachable: true, lmsConnected: connected, data: data}
      }));
    } catch (error) {
      setUnitState(pill.getAttribute('data-unit'), false);
      window.dispatchEvent(new CustomEvent('lyrion-health', {
        detail: {brokerReachable: false, lmsConnected: false}
      }));
    }
  }
  window.setInterval(pollUnitState, 3000);
  async function pollSetupSession() {
    if (!originalFetch || setupAuthExpiredShown) return;
    try {
      var res = await originalFetch('/api/setup/session?next=' + encodeURIComponent(window.location.pathname + window.location.search), {
        cache: 'no-store',
        credentials: 'same-origin'
      });
      if (res.status === 401) {
        showSetupAuthExpired();
      }
    } catch (error) {}
  }
  if (originalFetch) {
    window.setInterval(pollSetupSession, 240000);
    window.setTimeout(pollSetupSession, 5000);
  }
  window.addEventListener('lyrion-force-lms-state', function(event) {
    var detail = (event && event.detail) || {};
    if (detail.clear) {
      forcedUntil = 0;
      pollUnitState();
      return;
    } else {
      forcedConnected = !!detail.connected;
      forcedUntil = Date.now() + (detail.untilMs || 15000);
    }
    setUnitState(detail.unit || pill.getAttribute('data-unit'), !!detail.connected);
  });
  if (hostnameRebootNow) {
    hostnameRebootNow.addEventListener('click', async function(){
      if (!window.confirm('Reboot now to finish hostname change?')) return;
      hostnameRebootNow.disabled = true;
      hostnameRebootNow.textContent = 'Rebooting...';
      try {
        await fetch('/api/system/action', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({action: 'reboot'})
        });
      } catch (error) {}
    });
  }
  pollUnitState();
})();
</script>""".replace("__BRAND_META__", meta).replace("__HOSTNAME_REBOOT_BANNER__", reboot_banner)


async def setup_asset(req: web.Request) -> web.StreamResponse:
    filename = _safe_str(req.match_info.get("filename")).lower()
    allowed = {"lyrion.png", "avpro.png", "rti.png", "skunkworks.png"}
    if filename not in allowed:
        raise web.HTTPNotFound()
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets", filename)
    if not os.path.isfile(path):
        raise web.HTTPNotFound()
    return web.FileResponse(path, headers={"Cache-Control": "public, max-age=86400"})


async def panel_asset(req: web.Request) -> web.StreamResponse:
    filename = _safe_str(req.match_info.get("filename")).lower()
    allowed = {
        "panel.css", "panel.js", "lyrion.png", "skunkworks.png",
        "badge-pandora.svg", "badge-spotify.svg", "badge-qobuz.svg", "badge-bbc.svg", "badge-iheart.svg",
        "badge-pandora.png", "badge-spotify.png", "badge-qobuz.png", "badge-bbc.png", "badge-iheart.png",
        "badge-tidal.png", "badge-transparent.png",
        "badge-pandora.jpg", "badge-spotify.jpg", "badge-qobuz.jpg", "badge-bbc.jpg", "badge-iheart.jpg",
        "badge-tidal.jpg",
        "icon-random-mix.svg", "icon-years.svg",
        "icon-play-all.svg", "icon-play-all.png",
        "icon-home-mymusic.svg", "icon-home-radio.svg", "icon-home-favorites.svg",
        "icon-tidal.png", "icon-tidal.svg", "icon-podcast.png", "icon-pyrrha.png", "icon-iheart.png", "icon-pandora.png",
    }
    if filename not in allowed:
        raise web.HTTPNotFound()
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets", filename)
    if not os.path.isfile(path):
        raise web.HTTPNotFound()
    headers = {"Cache-Control": "no-cache, must-revalidate"}
    if filename.endswith(".css"):
        headers["Content-Type"] = "text/css"
    elif filename.endswith(".js"):
        headers["Content-Type"] = "application/javascript"
    return web.FileResponse(path, headers=headers)


def _local_lms_material_skin_dir() -> str:
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(SETUP_JSON_PATH)), "..", "slimserver", "Prefs", "material-skin"),
        "/mnt/mmcblk0p2/tce/slimserver/Prefs/material-skin",
        "/var/lib/squeezeboxserver/prefs/material-skin",
        "/usr/local/slimserver/prefs/material-skin",
    ]
    for path in candidates:
        parent = os.path.dirname(os.path.abspath(path))
        if os.path.isdir(parent):
            return os.path.abspath(path)
    return os.path.abspath(candidates[0])


def _write_text_if_changed(path: str, text: str) -> None:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                if handle.read() == text:
                    return
    except Exception:
        pass
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def _copy_file_if_changed(src: str, dst: str) -> None:
    try:
        if os.path.exists(dst):
            with open(src, "rb") as src_f, open(dst, "rb") as dst_f:
                if src_f.read() == dst_f.read():
                    return
    except Exception:
        pass
    shutil.copyfile(src, dst)


def _material_custom_layer_key() -> str:
    return "lyriongadget-" + re.sub(r"[^0-9A-Za-z]+", "", APP_VERSION)


def _material_skin_plugin_dirs() -> List[str]:
    candidates = [
        "/mnt/mmcblk0p2/tce/slimserver/Cache/InstalledPlugins/Plugins/MaterialSkin",
        "/var/lib/squeezeboxserver/cache/InstalledPlugins/Plugins/MaterialSkin",
        "/var/lib/squeezeboxserver/Cache/InstalledPlugins/Plugins/MaterialSkin",
        "/usr/local/slimserver/Plugins/MaterialSkin",
    ]
    return [os.path.abspath(path) for path in candidates if os.path.isdir(path)]


def _patch_material_icon_map() -> None:
    entries = {}
    asset_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets")
    pandora_svg_src = os.path.join(asset_dir, "lyrion-pandora.svg")
    for index in range(4):
        base = f"plugins/FR_Pandora_{index}/html/"
        for name in ("icon.png", "icon_50x50.png", "icon_100x100.png", "icon_50x50_o.png"):
            entries[base + name] = {"svg": "lyrion-pandora", "myapps": {"svg": "lyrion-pandora"}}
    for plugin_dir in _material_skin_plugin_dirs():
        image_dir = os.path.join(plugin_dir, "HTML", "material", "html", "images")
        if os.path.isdir(image_dir):
            try:
                _copy_file_if_changed(pandora_svg_src, os.path.join(image_dir, "lyrion-pandora.svg"))
            except Exception as exc:
                dbg(f"Material Pandora SVG install skipped for {image_dir}: {exc}")
        path = os.path.join(plugin_dir, "HTML", "material", "html", "misc", "icon-map.json")
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            ends_with = data.setdefault("endsWith", {})
            changed = False
            for key, value in entries.items():
                if ends_with.get(key) != value:
                    ends_with[key] = value
                    changed = True
            if changed:
                tmp_path = path + ".tmp"
                with open(tmp_path, "w", encoding="utf-8") as handle:
                    json.dump(data, handle, indent=2, sort_keys=False)
                    handle.write("\n")
                os.replace(tmp_path, path)
                dbg(f"Material icon map patched for Pandora: {path}")
        except Exception as exc:
            dbg(f"Material icon map patch skipped for {path}: {exc}")


def _install_material_custom_layer() -> str:
    _load_setup_config()
    material_dir = _local_lms_material_skin_dir()
    css_dir = os.path.join(material_dir, "css")
    js_dir = os.path.join(material_dir, "js")
    os.makedirs(css_dir, exist_ok=True)
    os.makedirs(js_dir, exist_ok=True)

    asset_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_assets")
    css_src = os.path.join(asset_dir, "material-lyriongadget.css")
    js_src = os.path.join(asset_dir, "material-lyriongadget.js")
    layer_key = _material_custom_layer_key()
    css_dst = os.path.join(css_dir, layer_key + ".css")
    js_dst = os.path.join(js_dir, layer_key + ".js")
    legacy_css_dst = os.path.join(css_dir, "lyriongadget.css")
    legacy_js_dst = os.path.join(js_dir, "lyriongadget.js")

    bg = _effective_material_panel_color("bg", "#135093")
    content_bg = _effective_material_panel_color("content_bg", "#0e52a5")
    accent = _effective_material_panel_color("accent", "#ffffff")
    with open(css_src, "r", encoding="utf-8") as handle:
        css = handle.read()
    css = re.sub(r"--lyrion-gadget-bg:\s*#[0-9a-fA-F]{6};", f"--lyrion-gadget-bg: {bg};", css)
    css = re.sub(r"--lyrion-gadget-content-bg:\s*#[0-9a-fA-F]{6};", f"--lyrion-gadget-content-bg: {content_bg};", css)
    css = re.sub(r"--lyrion-gadget-accent:\s*#[0-9a-fA-F]{6};", f"--lyrion-gadget-accent: {accent};", css)
    _write_text_if_changed(css_dst, css)
    _write_text_if_changed(legacy_css_dst, css)
    with open(js_src, "r", encoding="utf-8") as handle:
        js = handle.read()
    js = js.replace("__LYRION_MATERIAL_MODE__", _safe_material_mode(_setup_cache.get("web_panel_material_mode")))
    js = js.replace("__LYRION_APP_VERSION__", APP_VERSION)
    _write_text_if_changed(js_dst, js)
    _write_text_if_changed(legacy_js_dst, js)
    _patch_material_icon_map()
    return material_dir


async def _refresh_material_custom_layer_after_startup() -> None:
    try:
        if not bool(_setup_cache.get("web_panel_enabled", True)):
            return
        await asyncio.sleep(4.0)
        await asyncio.to_thread(_install_material_custom_layer)
        dbg("Material custom layer refreshed")
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        dbg(f"Material custom layer refresh skipped: {exc}")


async def _ensure_pandora_repository_after_startup() -> None:
    try:
        await asyncio.sleep(12.0)
        result = await _ensure_pandora_repository_configured()
        if bool(result.get("changed")):
            dbg("Pandora plugin repository added: {}".format(result.get("repository")))
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        dbg("Pandora repository ensure skipped: {}".format(_safe_str(exc)))


async def _first_run_auto_update_after_startup() -> None:
    try:
        await asyncio.sleep(float(os.getenv("BROKER_FIRST_RUN_UPDATE_DELAY_SECS", "35")))
        _load_setup_config()
        if _safe_str(_setup_cache.get("first_run_update_checked_version")).strip() == APP_VERSION:
            return
        current_status = _read_update_status()
        if _safe_str(current_status.get("state")) in ("checking", "downloading", "installing"):
            return
        _write_update_status("checking", "First-run auto-update: checking for broker update", auto=True)
        manifest = await _fetch_update_manifest()
        if not manifest.get("available"):
            _setup_cache["first_run_update_checked_version"] = APP_VERSION
            _save_setup_config()
            _write_update_status(
                "current",
                f"First-run auto-update: broker {APP_VERSION} is current",
                target_version=_safe_str(manifest.get("version")),
                auto=True,
            )
            return
        result = await _install_available_update(auto=True)
        if result.get("ok"):
            _setup_cache["first_run_update_checked_version"] = APP_VERSION
            _save_setup_config()
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        _write_update_status("failed", "First-run auto-update failed: {}".format(_safe_str(exc)), auto=True)
        dbg("First-run auto-update failed: {}".format(_safe_str(exc)))


def _safe_panel_color(value: Any, default: str) -> str:
    raw = _safe_str(value).strip()
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", raw):
        return raw
    return default


def _safe_optional_panel_color(value: Any) -> str:
    raw = _safe_str(value).strip()
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", raw):
        return raw
    return ""


def _migrate_old_panel_default_color(name: str, value: Any) -> str:
    raw = _safe_optional_panel_color(value).lower()
    old_defaults = {
        "bg": "#050607",
        "content_bg": "#101214",
        "accent": "#b7ff8a",
    }
    return "" if raw and raw == old_defaults.get(name, "") else raw


def _effective_broker_panel_color(name: str, default: str) -> str:
    specific = _migrate_old_panel_default_color(name, _setup_cache.get("web_panel_broker_" + name))
    if specific:
        return specific
    legacy_key = {
        "bg": "web_panel_bg",
        "content_bg": "web_panel_content_bg",
        "accent": "web_panel_accent",
    }.get(name, "")
    legacy = _migrate_old_panel_default_color(name, _setup_cache.get(legacy_key))
    return legacy or default


def _effective_material_panel_color(name: str, default: str) -> str:
    specific = _migrate_old_panel_default_color(name, _setup_cache.get("web_panel_material_" + name))
    if specific:
        return specific
    legacy_key = {
        "bg": "web_panel_bg",
        "content_bg": "web_panel_content_bg",
        "accent": "web_panel_accent",
    }.get(name, "")
    legacy = _migrate_old_panel_default_color(name, _setup_cache.get(legacy_key))
    return legacy or default


def _safe_panel_mode(value: Any) -> str:
    raw = _safe_str(value).strip().lower()
    return raw if raw in ("control", "browse") else "control"


def _safe_material_mode(value: Any) -> str:
    raw = _safe_str(value).strip().lower()
    return raw if raw in ("user", "installer") else "user"


async def panel_page(req: web.Request) -> web.Response:
    _load_setup_config()
    mode = _safe_str(req.match_info.get("mode")).strip().lower()
    if mode not in ("control", "browse"):
        mode = _safe_panel_mode(_setup_cache.get("web_panel_default_mode"))
    if _broker_light_mode():
        try:
            parsed = urllib.parse.urlparse(LMS_BASE)
            host = _safe_str(parsed.hostname).strip()
            if host and not _is_loopback_host(host):
                target = "http://{}:{}/panel/{}".format(host, LISTEN_PORT, mode)
                if req.query_string:
                    target += "?" + req.query_string
                raise web.HTTPFound(target)
        except web.HTTPFound:
            raise
        except Exception:
            pass
    playerid = _safe_str(req.query.get("playerid")).strip().lower()
    if not playerid:
        playerid = _safe_str(req.query.get("player")).strip().lower()
    bg = _safe_panel_color(req.query.get("bg") or _effective_broker_panel_color("bg", "#135093"), "#135093")
    content_bg = _safe_panel_color(req.query.get("content_bg") or _effective_broker_panel_color("content_bg", "#0e52a5"), "#0e52a5")
    accent = _safe_panel_color(req.query.get("accent") or _effective_broker_panel_color("accent", "#ffffff"), "#ffffff")
    default_art = _broker_main_art_url(playerid or "panel", "default", 500) if playerid else ""
    config = {
        "mode": mode,
        "playerid": playerid,
        "bg": bg,
        "contentBg": content_bg,
        "accent": accent,
        "defaultArt": default_art,
        "version": APP_VERSION,
        "enabled": bool(_setup_cache.get("web_panel_enabled", True)),
        "cardArt": bool(_setup_cache.get("web_panel_card_art", False)),
    }
    missing = ""
    light_note = ""
    disabled_note = ""
    if _broker_light_mode():
        light_note = '<div class="message">Panel view runs from the Full Broker. This unit is Broker Light and cannot open the RTI websocket.</div>'
    if not bool(_setup_cache.get("web_panel_enabled", True)):
        disabled_note = '<div class="message">Web panel is disabled in Broker Setup. Enable it under Setup > Web Panel.</div>'
    if not playerid:
        missing = '<div class="message">Missing playerid. Use /panel/{mode}?playerid=88:a2:9e:c6:b7:a0</div>'.format(mode=mode)
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>Lyrion Panel</title>
  <link rel="stylesheet" href="/panel/assets/panel.css?v=__VERSION__">
</head>
<body>
<div class="app __MODE__">
  <header class="topbar">
    <button id="syncToggle" class="icon-only" title="Sync players" aria-label="Sync players"></button>
    <div class="brand">
      <div id="status" class="status hidden"></div>
    </div>
    <button id="detailsToggle" class="icon-only" title="Details" aria-label="Details"></button>
    <button id="nowToggle" class="icon-only" title="Now Playing" aria-label="Now Playing"></button>
    <button id="queueToggle" class="icon-only" title="Queue" aria-label="Queue"></button>
  </header>
  <main class="main">
    <section class="now">
      <div class="progress-track"><div id="progressBar" class="progress-bar"></div></div>
      <div class="transport">
        <button id="prev" class="icon-btn" title="Previous" aria-label="Previous"></button>
        <button id="playPause" class="icon-btn primary" title="Play/Pause" aria-label="Play/Pause"></button>
        <button id="next" class="icon-btn" title="Next" aria-label="Next"></button>
      </div>
      <img id="art" class="art" src="__DEFAULT_ART__" alt="">
      <div class="now-text">
        <div id="bigTitle" class="big-title">Connecting...</div>
        <div id="bigMeta" class="big-meta"></div>
      </div>
      <div class="volume">
        <span>Vol</span>
        <input id="volume" type="range" min="0" max="100" value="50">
        <span id="volumeLabel">50%</span>
      </div>
      <button id="thumbDown" class="icon-btn footer-action rating-action hidden" title="Thumbs down" aria-label="Thumbs down"></button>
      <button id="thumbUp" class="icon-btn footer-action rating-action hidden" title="Thumbs up" aria-label="Thumbs up"></button>
      <div id="timeLabel" class="time-label"></div>
    </section>
    <section class="browse-pane">
      <div class="backbar">
        <button id="home" class="icon-only" title="Home" aria-label="Home"></button>
        <button id="back" class="icon-only" title="Back" aria-label="Back"></button>
        <div id="crumb" class="crumb">Home</div>
        <button id="layoutToggle" class="icon-only" type="button" title="Toggle list/thumbnail view" aria-label="Toggle list/thumbnail view"></button>
        <button id="searchToggle" class="icon-only" title="Search" aria-label="Search"></button>
      </div>
      <div class="search">
        <input id="searchBox" type="search" placeholder="Search">
        <button id="searchButton" class="icon-only" title="Search" aria-label="Search"></button>
      </div>
      <div id="browseView" class="view active">
        <div id="list" class="list">__DISABLED_NOTE____LIGHT_NOTE____MISSING__</div>
      </div>
      <div id="queueView" class="view">
        <div id="queueList" class="list"></div>
      </div>
      <div id="detailsView" class="view">
        <div id="details" class="details"></div>
      </div>
    </section>
  </main>
  <aside id="queueDrawer" class="queue-drawer">
    <div class="drawer-head">
      <b>Queue</b>
      <button id="queueClose" type="button">Close</button>
    </div>
    <div id="queueDrawerList" class="list"></div>
  </aside>
  <aside id="syncDrawer" class="queue-drawer sync-drawer">
    <div class="drawer-head">
      <b>Sync</b>
      <button id="syncAll" type="button">Sync all</button>
    </div>
    <div id="syncList" class="list"></div>
  </aside>
  <div id="coverOverlay" class="cover-overlay">
    <div class="cover-panel">
      <button id="coverClose" class="cover-close" type="button">Close</button>
      <div class="cover-stage">
        <img id="coverArt" class="cover-art" src="__DEFAULT_ART__" alt="">
        <img id="coverBadge" class="cover-badge hidden" src="" alt="">
      </div>
      <div class="cover-copy">
        <div id="coverTitle" class="cover-title">Connecting...</div>
        <div id="coverMeta" class="cover-meta"></div>
      </div>
      <div class="cover-progress"><div class="progress-track"><div id="coverProgressBar" class="progress-bar"></div></div><div id="coverTimeLabel" class="cover-time"></div></div>
      <div class="transport cover-transport">
        <button id="coverPrev" class="icon-btn" title="Previous" aria-label="Previous"></button>
        <button id="coverPlayPause" class="icon-btn primary" title="Play/Pause" aria-label="Play/Pause"></button>
        <button id="coverNext" class="icon-btn" title="Next" aria-label="Next"></button>
      </div>
    </div>
  </div>
  <div id="actionSheet" class="action-sheet">
    <div class="action-card">
      <div id="actionTitle" class="action-title">Play</div>
      <button id="actionPlay" type="button">Play now</button>
      <button id="actionNext" type="button">Play next</button>
      <button id="actionAdd" type="button">Add to queue</button>
      <button id="actionCancel" type="button">Cancel</button>
    </div>
  </div>
</div>
<script>window.LYRION_PANEL=__CONFIG__;</script>
<script src="/panel/assets/panel.js?v=__VERSION__"></script>
</body>
</html>"""
    html = (
        html
        .replace("__MODE__", _html_escape(mode))
        .replace("__PLAYERID__", _html_escape(playerid or "No player selected"))
        .replace("__DEFAULT_ART__", _html_escape(default_art))
        .replace("__DISABLED_NOTE__", disabled_note)
        .replace("__LIGHT_NOTE__", light_note)
        .replace("__MISSING__", missing)
        .replace("__CONFIG__", _json_dumps(config))
        .replace("__VERSION__", _html_escape(APP_VERSION))
    )
    return web.Response(text=html, content_type="text/html")


def _material_panel_url(req: web.Request, mode: str = "mobile") -> str:
    playerid = _safe_str(req.query.get("playerid") or req.query.get("player") or "").strip().lower()
    query: Dict[str, str] = {}
    for key, value in req.query.items():
        if key in ("playerid", "player"):
            continue
        query[_safe_str(key)] = _safe_str(value)
    if playerid:
        query["player"] = playerid
        query["single"] = "1"
    query.setdefault("layout", mode)
    query.setdefault("kiosk", "1")
    query.setdefault("hidePlayers", "")
    query["css"] = "lyriongadget"
    query["js"] = "lyriongadget"
    query.setdefault("lgv", APP_VERSION)
    return "/material/?" + urllib.parse.urlencode(query)


def _material_direct_url(req: web.Request, mode: str = "mobile") -> str:
    proxied_path = _material_panel_url(req, mode)
    parsed_lms = urllib.parse.urlparse(LMS_BASE)
    lms_host = _safe_str(parsed_lms.hostname).strip()
    lms_scheme = parsed_lms.scheme or "http"
    lms_port = parsed_lms.port or (443 if lms_scheme == "https" else 9000)
    if not lms_host or _is_loopback_host(lms_host):
        req_host = _safe_str(req.host).split(":", 1)[0]
        lms_host = req_host or "127.0.0.1"
        lms_port = 9000
    netloc = f"{lms_host}:{lms_port}"
    return f"{lms_scheme}://{netloc}{proxied_path}"


async def material_panel_page(req: web.Request) -> web.Response:
    _load_setup_config()
    if not bool(_setup_cache.get("web_panel_enabled", True)):
        return web.Response(
            text="<html><body style='font-family:Arial;padding:20px;background:#111;color:#eee'>Web panel is disabled in Broker Setup.</body></html>",
            content_type="text/html",
        )
    if _broker_light_mode():
        try:
            parsed = urllib.parse.urlparse(LMS_BASE)
            host = _safe_str(parsed.hostname).strip()
            if host and not _is_loopback_host(host):
                target = "http://{}:{}/panel/material".format(host, LISTEN_PORT)
                if req.query_string:
                    target += "?" + req.query_string
                raise web.HTTPFound(target)
        except web.HTTPFound:
            raise
        except Exception:
            pass
    try:
        if not _broker_light_mode():
            await asyncio.to_thread(_install_material_custom_layer)
    except Exception as e:
        dbg(f"Material custom layer install skipped: {e}")
    raise web.HTTPFound(_material_direct_url(req), headers={"Cache-Control": "no-store, max-age=0"})


def _proxy_headers(req: web.Request) -> Dict[str, str]:
    headers: Dict[str, str] = {}
    skip = {
        "host",
        "content-length",
        "connection",
        "transfer-encoding",
        "content-encoding",
        "accept-encoding",
        "upgrade",
        "proxy-connection",
    }
    broker_origin = "{}://{}".format(req.scheme, req.host)
    lms_origin = LMS_BASE.rstrip("/")
    for key, value in req.headers.items():
        lk = key.lower()
        if lk in skip:
            continue
        if lk == "origin" and value:
            headers[key] = lms_origin
        elif lk == "referer" and value:
            headers[key] = value.replace(broker_origin, lms_origin)
        else:
            headers[key] = value
    return headers


async def lms_proxy(req: web.Request) -> web.StreamResponse:
    global _lms_proxy_session
    path = _safe_str(req.path).strip() or "/"
    if not path.startswith("/"):
        path = "/" + path
    if path.rstrip("/") == "/material" and (req.query.get("player") or req.query.get("playerid")):
        raise web.HTTPFound(_material_direct_url(req), headers={"Cache-Control": "no-store, max-age=0"})
    for prefix in ("/material/music/", "/material/imageproxy/", "/material/contributor/"):
        if path.startswith(prefix):
            path = path[len("/material"):]
            break
    target = LMS_BASE.rstrip("/") + path
    if req.query_string:
        target += "?" + req.query_string
    data = await req.read()
    if _lms_proxy_session is None or _lms_proxy_session.closed:
        _lms_proxy_session = ClientSession(timeout=ClientTimeout(total=None, connect=15, sock_read=90))
    async with _lms_proxy_session.request(req.method, target, data=data if data else None, headers=_proxy_headers(req), allow_redirects=False) as resp:
        body = await resp.read()
        headers: Dict[str, str] = {}
        for key, value in resp.headers.items():
            lk = key.lower()
            if lk in ("content-length", "transfer-encoding", "connection", "content-encoding"):
                continue
            headers[key] = value
        if resp.status in (301, 302, 303, 307, 308):
            loc = headers.get("Location") or headers.get("location")
            if loc:
                parsed = urllib.parse.urlparse(loc)
                if parsed.netloc:
                    lms_parsed = urllib.parse.urlparse(LMS_BASE)
                    if parsed.hostname == lms_parsed.hostname and parsed.port == lms_parsed.port:
                        loc = parsed.path + (("?" + parsed.query) if parsed.query else "")
                if loc.startswith("/"):
                    headers["Location"] = loc
        return web.Response(status=resp.status, body=body, headers=headers)


def _panel_volume_flags(status: Dict[str, Any]) -> Dict[str, Any]:
    digital_raw = status.get("digital_volume_control", status.get("digitalVolumeControl", None))
    use_raw = status.get("use_volume_control", status.get("useVolumeControl", None))
    digital_ok = True if digital_raw is None else bool(_safe_int(digital_raw, 0))
    use_ok = True if use_raw is None else bool(_safe_int(use_raw, 0))
    can_volume = bool(digital_ok and use_ok)
    return {
        "can_volume": can_volume,
        "fixed_volume": not can_volume,
        "volume": _safe_int(status.get("mixer volume", status.get("mixer_volume", status.get("volume", 0))), 0),
    }


async def _panel_pick_player(playerid: str = "") -> str:
    pid = _safe_str(playerid).strip().lower()
    if pid:
        return pid
    players = await lms.get_players()
    for p in players:
        if _safe_int(p.get("connected"), 0) == 1:
            pid = _safe_str(p.get("playerid")).strip().lower()
            if pid:
                return pid
    return ""


async def _panel_state_payload(playerid: str, include_queue: bool = False) -> Dict[str, Any]:
    pid = await _panel_pick_player(playerid)
    if not pid:
        return {"ok": False, "error": "no_player", "playerid": ""}
    st = await fresh_status_for_push(pid)
    if not isinstance(st, dict):
        st = {}
    payload = _rti_status_payload(st)
    payload.update(_panel_volume_flags(st))
    result: Dict[str, Any] = {
        "ok": True,
        "playerid": pid,
        "player_name": _playerid_to_name.get(pid.lower(), _safe_str(st.get("player_name"))),
        "status": payload,
    }
    try:
        result["players"] = [
            {
                "playerid": _safe_str(p.get("playerid")).strip().lower(),
                "name": _safe_str(p.get("name") or p.get("player_name")),
                "connected": _safe_int(p.get("connected"), 0),
            }
            for p in await lms.get_players()
            if _safe_str(p.get("playerid")).strip()
        ]
    except Exception:
        result["players"] = []
    if include_queue:
        try:
            q = await full_queue_status_for_push(pid, 80)
            result["queue"] = _rti_status_payload(q)
        except Exception as e:
            result["queue_error"] = _safe_str(e)
    return result


async def api_panel_state(req: web.Request) -> web.Response:
    if _broker_light_mode():
        return web.json_response({"ok": False, "error": "broker_light_mode"}, status=403)
    pid = _safe_str(req.query.get("playerid") or req.query.get("player") or "")
    include_queue = _safe_str(req.query.get("queue")).strip().lower() in ("1", "true", "yes")
    try:
        return web.json_response(await _panel_state_payload(pid, include_queue))
    except Exception as e:
        return web.json_response({"ok": False, "error": f"panel_state:{type(e).__name__}:{_safe_str(e)}"}, status=500)


async def api_panel_control(req: web.Request) -> web.Response:
    if _broker_light_mode():
        return web.json_response({"ok": False, "error": "broker_light_mode"}, status=403)
    try:
        body = await req.json()
    except Exception:
        body = {}
    pid = await _panel_pick_player(_safe_str(body.get("playerid") or body.get("player") or ""))
    name = _safe_str(body.get("name") or body.get("cmd") or body.get("command")).strip().lower()
    args = body.get("args") or []
    if isinstance(args, str):
        args = [args]
    if not isinstance(args, list):
        args = []
    if not pid or not name:
        return web.json_response({"ok": False, "error": "missing_player_or_name"}, status=400)
    if name == "playpause":
        try:
            snap = _last_status_by_key.get(pid) or {}
            if not snap:
                snap = await fresh_status_for_push(pid)
            name = "pause" if _safe_str(snap.get("mode")).strip().lower() == "play" else "play"
        except Exception:
            name = "play"
    try:
        res = await lms.cmd(pid, name, args)
        if name in ("play", "pause", "stop", "next", "prev", "previous"):
            schedule_transport_command_verify(pid, _playerid_to_name.get(pid.lower(), ""), name)
        try:
            await cometd_status_subscribe(pid)
        except Exception:
            pass
        await asyncio.sleep(0.25)
        state = await _panel_state_payload(
            pid,
            name in ("next", "prev", "previous", "play", "pause", "stop", "queue_goto", "goto"),
        )
        state["result"] = res.get("result") if isinstance(res, dict) else res
        return web.json_response(state)
    except Exception as e:
        return web.json_response({"ok": False, "error": f"panel_control:{type(e).__name__}:{_safe_str(e)}"}, status=500)


async def root_page(_req: web.Request) -> web.Response:
    raise web.HTTPFound("/setup")


def _pcp_root_redirect_html() -> str:
    return """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="cache-control" content="no-store, no-cache, must-revalidate, max-age=0">
  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="expires" content="0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lyrion Gadget</title>
  <script>
    (function () {
      var host = window.location.hostname || window.location.host.split(":")[0];
      window.location.replace(window.location.protocol + "//" + host + ":9099/setup?root=__APP_VERSION__");
    }());
  </script>
</head>
<body style="font-family:Arial,sans-serif;margin:32px;line-height:1.45;">
  <h1>Lyrion Gadget</h1>
  <p>Opening Lyrion Gadget setup...</p>
  <p><a href="#" onclick="this.href=location.protocol+'//'+location.hostname+':9099/setup'">Open Lyrion Gadget setup</a></p>
</body>
</html>
""".replace("__APP_VERSION__", urllib.parse.quote(APP_VERSION, safe=""))


def _pcp_root_index_candidates() -> List[str]:
    candidates = [
        "/var/www/index.html",
        "/usr/local/etc/www/index.html",
        "/usr/local/www/index.html",
        "/usr/local/share/www/index.html",
        "/usr/local/httpd/htdocs/index.html",
        "/usr/local/apache2/htdocs/index.html",
        "/usr/local/etc/pcp/www/index.html",
        "/usr/local/share/pcp/www/index.html",
        "/usr/local/etc/httpd/htdocs/index.html",
        "/tmp/www/index.html",
        "/tmp/httpd/index.html",
        "/tmp/var/www/index.html",
        "/home/httpd/html/index.html",
        "/www/index.html",
    ]
    seen: Set[str] = set()
    ordered: List[str] = []
    for path in candidates:
        if path not in seen:
            seen.add(path)
            ordered.append(path)
    for root in ("/tmp", "/usr/local", "/var", "/home", "/opt", "/www"):
        if not os.path.isdir(root):
            continue
        for base, dirs, files in os.walk(root):
            depth = base[len(root):].count(os.sep)
            if depth >= 5:
                dirs[:] = []
            if "index.html" not in files:
                continue
            path = os.path.join(base, "index.html")
            if path not in seen:
                seen.add(path)
                ordered.append(path)
    return ordered


def _ensure_pcp_root_redirect() -> bool:
    target = ""
    for path in _pcp_root_index_candidates():
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                text = handle.read(4096)
        except Exception:
            continue
        if "/cgi-bin/about.cgi" in text or "Lyrion Gadget setup" in text:
            target = path
            break
    if not target:
        target = "/var/www/index.html"
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        desired = _pcp_root_redirect_html()
        if os.path.islink(target):
            os.unlink(target)
            with open(target, "w", encoding="utf-8") as handle:
                handle.write(desired)
            dbg("pCP root redirect replaced symlink {}".format(target))
            return True
        if "/tmp/tcloop/" in target:
            overlay_dir = "/tmp/lyrion-pcp-root"
            overlay_file = os.path.join(overlay_dir, "index.html")
            os.makedirs(overlay_dir, exist_ok=True)
            with open(overlay_file, "w", encoding="utf-8") as handle:
                handle.write(desired)
            mounted = False
            try:
                with open("/proc/mounts", "r", encoding="utf-8", errors="replace") as handle:
                    mounted = any(line.split()[1:2] == [target] for line in handle)
            except Exception:
                mounted = False
            if not mounted:
                result = subprocess.run(
                    ["mount", "-o", "bind", overlay_file, target],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    result = subprocess.run(
                        ["mount", "--bind", overlay_file, target],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        timeout=10,
                    )
                if result.returncode != 0:
                    raise RuntimeError((result.stderr or result.stdout or "bind mount failed").strip())
            dbg("pCP root redirect bind-mounted {} over {}".format(overlay_file, target))
            return True
        current = ""
        try:
            with open(target, "r", encoding="utf-8", errors="replace") as handle:
                current = handle.read()
        except Exception:
            current = ""
        if current != desired:
            with open(target, "w", encoding="utf-8") as handle:
                handle.write(desired)
            dbg("pCP root redirect written to {}".format(target))
            return True
    except Exception as error:
        dbg("pCP root redirect repair failed: {}".format(_safe_str(error)))
    return False


def _read_pcp_config() -> Dict[str, str]:
    values: Dict[str, str] = {}
    try:
        with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
            for raw_line in handle:
                line = raw_line.strip()
                match = re.match(r'^([A-Z0-9_]+)="(.*)"$', line)
                if match:
                    values[match.group(1)] = match.group(2)
    except Exception:
        pass
    return values


def _pcp_network_mount_statuses(config: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    configured_rows: List[Dict[str, Any]] = []
    if isinstance(config, dict):
        slot_numbers = sorted({
            int(match.group(1))
            for key in config
            for match in [re.fullmatch(r"NETMOUNTPOINT([0-9]+)", key)]
            if match
        })
        for slot in slot_numbers:
            configured_rows.append({
                "slot": slot,
                "enabled": _safe_str(config.get("NETENABLE{}".format(slot))).strip().lower() in ("1", "yes", "true", "on"),
                "name": _safe_str(config.get("NETMOUNTPOINT{}".format(slot))).strip().strip("/"),
                "fstype": _safe_str(config.get("NETMOUNTFSTYPE{}".format(slot))),
            })
    else:
        current: Dict[str, Any] = {}
        try:
            with open(PCP_NETMOUNTS_PATH, "r", encoding="utf-8", errors="replace") as handle:
                for raw_line in handle:
                    line = raw_line.strip()
                    section = re.fullmatch(r"\[([0-9]+)\]", line)
                    if section:
                        if current:
                            configured_rows.append(current)
                        current = {"slot": int(section.group(1))}
                        continue
                    key, separator, value = line.partition("=")
                    if not separator or not current:
                        continue
                    if key == "NETENABLE":
                        current["enabled"] = value.strip().lower() in ("1", "yes", "true", "on")
                    elif key == "NETMOUNTPOINT":
                        current["name"] = value.strip().strip("/")
                    elif key == "NETMOUNTFSTYPE":
                        current["fstype"] = value.strip()
                if current:
                    configured_rows.append(current)
        except Exception:
            pass
    mounted_paths: Dict[str, Dict[str, str]] = {}
    try:
        with open("/proc/mounts", "r", encoding="utf-8", errors="replace") as handle:
            for raw_line in handle:
                fields = raw_line.split()
                if len(fields) < 3:
                    continue
                decode = lambda value: re.sub(
                    r"\\([0-7]{3})",
                    lambda match: chr(int(match.group(1), 8)),
                    value,
                )
                target = os.path.normpath(decode(fields[1]))
                mounted_paths[target] = {"source": decode(fields[0]), "fstype": fields[2]}
    except Exception:
        pass

    rows: List[Dict[str, Any]] = []
    configured_paths = set()
    for configured in configured_rows:
        name = _safe_str(configured.get("name")).strip().strip("/")
        if not configured.get("enabled") or not name:
            continue
        path = os.path.normpath("/mnt/" + name)
        configured_paths.add(path)
        mount = mounted_paths.get(path) or {}
        mounted = bool(mount)
        rows.append({
            "slot": configured.get("slot"),
            "path": path,
            "mounted": mounted,
            "readable": mounted and os.path.isdir(path) and os.access(path, os.R_OK),
            "source": _safe_str(mount.get("source")),
            "fstype": _safe_str(mount.get("fstype") or configured.get("fstype")),
        })
    for path, mount in mounted_paths.items():
        if path in configured_paths or not path.startswith("/mnt/") or _safe_str(mount.get("fstype")).lower() not in ("cifs", "nfs", "nfs4"):
            continue
        rows.append({
            "slot": None,
            "path": path,
            "mounted": True,
            "readable": os.path.isdir(path) and os.access(path, os.R_OK),
            "source": _safe_str(mount.get("source")),
            "fstype": _safe_str(mount.get("fstype")),
        })
    return rows


def _default_unit_hostname() -> str:
    broker_id = BROKER_ID or _compute_broker_id()
    return broker_id if re.fullmatch(r"[A-Za-z0-9-]{1,26}", broker_id) else "LyrionGadget"


def _is_generic_hostname(hostname: Any) -> bool:
    value = _safe_str(hostname).strip().split(".", 1)[0].lower()
    if value in ("", "pcp", "picoreplayer", "raspberrypi", "localhost", "lyriongadget"):
        return True
    if re.fullmatch(r"lyrion[0-9a-f]{4}", value):
        return True
    if re.fullmatch(r"lyriongadget[0-9]+", value):
        return True
    return False


def _ensure_default_unit_hostname() -> bool:
    hostname = _pcp_config_hostname()
    target = _default_unit_hostname()
    if not target or _safe_str(hostname).strip().lower() == target.lower():
        return False
    if not _is_generic_hostname(hostname):
        return False
    _apply_system_hostname(target)
    return True


def _pcp_config_hostname() -> str:
    configured = _safe_str(_read_pcp_config().get("HOST")).strip()
    if configured:
        return configured
    return _safe_str(socket.gethostname()).strip().split(".", 1)[0]


def _live_system_hostname() -> str:
    return _safe_str(socket.gethostname()).strip().split(".", 1)[0]


def _system_boot_time() -> int:
    try:
        with open("/proc/stat", "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if line.startswith("btime "):
                    return _safe_int(line.split()[1], 0)
    except Exception:
        pass
    try:
        uptime = float(open("/proc/uptime", "r", encoding="utf-8").read().split()[0])
        return int(time.time() - uptime)
    except Exception:
        return 0


def _hostname_reboot_pending() -> bool:
    marked_at = _safe_int(_setup_cache.get("hostname_reboot_required_since"), 0)
    if marked_at <= 0:
        return False
    boot_time = _system_boot_time()
    return boot_time <= 0 or boot_time <= marked_at


def _clear_hostname_reboot_pending_if_booted() -> bool:
    if not _safe_int(_setup_cache.get("hostname_reboot_required_since"), 0):
        return False
    if _hostname_reboot_pending():
        return False
    _setup_cache["hostname_reboot_required_since"] = 0
    _setup_cache["hostname_reboot_target"] = ""
    return True


def _mark_hostname_reboot_pending(hostname: str) -> None:
    _setup_cache["hostname_reboot_required_since"] = int(time.time())
    _setup_cache["hostname_reboot_target"] = _safe_str(hostname).strip()
    _save_setup_config()


def _hostname_reboot_required() -> bool:
    configured = _safe_str(_pcp_config_hostname()).strip()
    live = _live_system_hostname()
    return bool(_hostname_reboot_pending() or (configured and live and configured.lower() != live.lower()))


def _raspberry_pi_model() -> str:
    for path in ("/proc/device-tree/model", "/sys/firmware/devicetree/base/model"):
        try:
            with open(path, "rb") as handle:
                return handle.read().decode("utf-8", errors="replace").replace("\x00", "").strip()
        except Exception:
            continue
    return ""


def _raspberry_pi_major() -> int:
    match = re.search(r"Raspberry Pi\s+(\d+)", _raspberry_pi_model(), flags=re.I)
    return _safe_int(match.group(1), 0) if match else 0


def _local_player_limit() -> int:
    major = _raspberry_pi_major()
    if major == 3:
        return PI3_MAX_UNIT_PLAYERS
    if major == 4:
        return PI4_MAX_UNIT_PLAYERS
    if major == 5:
        return PI5_MAX_UNIT_PLAYERS
    return MAX_UNIT_PLAYERS


def _broker_uses_user_command_slot() -> bool:
    return False


def _local_stack_user_command_slot() -> int:
    return 1


def _encoded_command_matches(encoded: Any, command_path: str) -> bool:
    decoded = urllib.parse.unquote_plus(_safe_str(encoded).strip())
    return decoded.strip() == command_path


def _pcp_uses_local_stack(config: Dict[str, str]) -> bool:
    for index in range(1, 6):
        if _encoded_command_matches(config.get("USER_COMMAND_{}".format(index)), PCP_LOCAL_STACK_PATH):
            return True
    return False


def _current_provisioning_mode(config: Optional[Dict[str, str]] = None) -> str:
    config = config if isinstance(config, dict) else _read_pcp_config()
    if not config:
        return ""
    if _pcp_uses_local_stack(config):
        return "open"
    for index in range(1, 5):
        command = urllib.parse.unquote_plus(_safe_str(config.get("USER_COMMAND_{}".format(index))).strip())
        if "squeezelite" in command.lower():
            return "clone"
    return ""


def _player_session_matches_desired(current: Dict[str, Any], desired: Dict[str, str]) -> bool:
    current_name = _safe_str(current.get("name"))
    desired_name = _safe_str(desired.get("name"))
    desired_startup_name = _safe_str(desired.get("startup_name"))
    return (
        current_name in (desired_name, desired_startup_name)
        and _safe_str(current.get("mac")).lower() == _safe_str(desired.get("mac")).lower()
        and _safe_str(current.get("output")) == _safe_str(desired.get("output"))
        and _audio_params_signature(current.get("audio_params")) == _audio_params_signature(desired.get("audio_params"))
        and _squeezelite_option_signature(current) == _squeezelite_option_signature(desired)
        and _safe_str(current.get("server")).lower() == _safe_str(desired.get("server")).lower()
    )


def _squeezelite_option_signature(row: Dict[str, Any]) -> str:
    args: List[str] = []
    upsample_params = _safe_str(row.get("upsample_params")).strip()
    if upsample_params:
        args.extend(["-u", upsample_params])
    extra_options = _safe_str(row.get("extra_options") or row.get("other_options")).strip()
    if extra_options:
        try:
            args.extend(shlex.split(extra_options))
        except Exception:
            args.append(extra_options)
    return _shell_join(_dedupe_squeezelite_options(args))


def _dedupe_squeezelite_options(args: List[str]) -> List[str]:
    cleaned: List[str] = []
    seen: set = set()
    index = 0
    while index < len(args):
        arg = _safe_str(args[index])
        if arg == "-u" and index + 1 < len(args):
            value = _safe_str(args[index + 1])
            key = ("-u", value)
            if key not in seen:
                cleaned.extend([arg, value])
                seen.add(key)
            index += 2
            continue
        key = ("arg", arg)
        if key not in seen:
            cleaned.append(arg)
            seen.add(key)
        index += 1
    return cleaned


def _local_stack_player_rows(default_server: str = "") -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not os.path.isfile(PCP_LOCAL_STACK_PATH):
        return rows
    try:
        with open(PCP_LOCAL_STACK_PATH, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                text = line.strip()
                if not text or "squeezelite" not in text.lower():
                    continue
                command = re.sub(r"\s*>/dev/null\s+2>&1\s*&\s*$", "", text)
                command = re.sub(r"\s*&\s*$", "", command)
                row = _parse_squeezelite_command(command, len(rows) + 2)
                if row.get("mac") and row.get("output"):
                    if not _safe_str(row.get("server")).strip():
                        row["server"] = default_server
                    rows.append(row)
    except Exception as error:
        dbg("Local stack parse skipped: {}".format(_safe_str(error)))
    return rows


def _parse_squeezelite_command(command: str, slot: int) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "slot": slot,
        "name": "",
        "output": "",
        "mac": "",
        "server": "",
        "audio_params": "",
        "upsample_params": "",
        "extra_options": "",
        "command": command,
    }
    try:
        args = shlex.split(command)
        for option, key in (("-n", "name"), ("-o", "output"), ("-m", "mac"), ("-s", "server")):
            if option in args:
                index = args.index(option)
                if index + 1 < len(args):
                    row[key] = _safe_str(args[index + 1])
        if "-a" in args:
            index = args.index("-a")
            if index + 1 < len(args):
                row["audio_params"] = _safe_str(args[index + 1])
        if "-u" in args:
            index = args.index("-u")
            if index + 1 < len(args):
                row["upsample_params"] = _safe_str(args[index + 1])
        skip = False
        known_with_value = {"-n", "-o", "-a", "-u", "-m", "-s"}
        extras: List[str] = []
        for arg in args[1:]:
            if skip:
                skip = False
                continue
            if arg in known_with_value:
                skip = True
                continue
            extras.append(arg)
        row["extra_options"] = _shell_join(extras)
    except Exception:
        pass
    row["mac"] = _safe_str(row.get("mac")).strip().lower()
    return row


def _pcp_player_sessions() -> List[Dict[str, Any]]:
    config = _read_pcp_config()
    if not config:
        return []
    main_session = {
        "slot": 1,
        "name": _safe_str(config.get("NAME")),
        "output": _safe_str(config.get("OUTPUT")),
        "mac": _safe_str(config.get("MAC_ADDRESS")).strip().lower(),
        "server": _safe_str(config.get("SERVER_IP")),
        "audio_params": _audio_params_or_default(config.get("ALSA_PARAMS"), config.get("OUTPUT")),
        "upsample_params": _squeezelite_option_value(config.get("OTHER"), "-u"),
        "command": "",
    }

    saved_rows = _setup_cache.get("local_player_rows")
    saved_mode = _safe_str(_setup_cache.get("local_player_mode")).lower()
    stack_configured = _pcp_uses_local_stack(config)
    if (stack_configured or saved_mode == "open") and isinstance(saved_rows, list) and saved_rows:
        sessions = [main_session]
        server = _safe_str(config.get("SERVER_IP"))
        for saved in saved_rows[1:_local_player_limit()]:
            if not isinstance(saved, dict) or not bool(saved.get("enabled", True)):
                continue
            row = {
                "slot": _safe_int(saved.get("slot"), len(sessions) + 1),
                "name": _safe_str(saved.get("name")),
                "output": _safe_str(saved.get("output")),
                "mac": _safe_str(saved.get("mac")).strip().lower(),
                "server": _safe_str(saved.get("server")) or server,
                "audio_params": _audio_params_or_default(saved.get("audio_params"), saved.get("output")),
                "upsample_params": _safe_str(saved.get("upsample_params")),
                "extra_options": _safe_str(saved.get("extra_options")),
                "command": "",
            }
            if row["mac"] and row["output"]:
                sessions.append(row)
        return sessions

    if stack_configured:
        stack_rows = _local_stack_player_rows(_safe_str(config.get("SERVER_IP")))
        if stack_rows:
            return [main_session] + stack_rows[:max(0, _local_player_limit() - 1)]
    sessions = [main_session]
    for index in range(1, 5):
        encoded = _safe_str(config.get("USER_COMMAND_{}".format(index))).strip()
        if not encoded:
            continue
        command = urllib.parse.unquote_plus(encoded)
        if "squeezelite" not in command.lower():
            continue
        sessions.append(_parse_squeezelite_command(command, index + 1))
    return sessions


def _alsa_cards() -> List[Dict[str, str]]:
    cards: List[Dict[str, str]] = []
    try:
        with open("/proc/asound/cards", "r", encoding="utf-8", errors="replace") as handle:
            lines = handle.read().splitlines()
        index = 0
        while index < len(lines):
            match = re.match(r"^\s*(\d+)\s+\[([^\]]+)\s*\]:\s*(.+?)\s+-\s+(.*)$", lines[index])
            if not match:
                index += 1
                continue
            detail = lines[index + 1].strip() if index + 1 < len(lines) else ""
            path_match = re.search(r"\bat\s+([^,]+)", detail)
            cards.append({
                "index": match.group(1),
                "id": match.group(2).strip(),
                "driver": match.group(3).strip(),
                "name": match.group(4).strip(),
                "detail": detail,
                "path": path_match.group(1).strip() if path_match else "",
            })
            index += 2
    except Exception:
        pass
    return cards


def _alsa_output_for_card(card: Dict[str, str]) -> str:
    card_id = _safe_str(card.get("id")).strip()
    driver = _safe_str(card.get("driver")).lower()
    if not card_id:
        return ""
    # Legacy bcm2835 HDMI exposes hw/plughw PCMs but no ALSA hdmi: alias.
    # VC4 exposes the hdmi: alias and continues through the existing path.
    if "bcm2835_hdmi" in driver:
        return "hw:CARD={},DEV=0".format(card_id)
    if "hdmi" in driver or "hdmi" in card_id.lower():
        return "hdmi:CARD={},DEV=0".format(card_id)
    return "hw:CARD={},DEV=0".format(card_id)


def _is_low_quality_analog_card(card: Dict[str, str]) -> bool:
    text = " ".join(
        _safe_str(card.get(key)).lower()
        for key in ("id", "driver", "name", "detail")
    )
    if "hdmi" in text:
        return False
    return (
        "bcm2835_headpho" in text
        or "headphone" in text
        or "headphones" in text
    )


def _dac8x_card() -> Optional[Dict[str, str]]:
    if _raspberry_pi_major() != 5:
        return None
    for card in _alsa_cards():
        text = " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        )
        if "dac8x" in text:
            return card
    return None


def _dac8x_outputs() -> List[Dict[str, str]]:
    card = _dac8x_card()
    if not card:
        return []
    pairs = (
        ("dac8x_12", "DAC8x Outputs 1/2", 0, 1),
        ("dac8x_34", "DAC8x Outputs 3/4", 2, 3),
        ("dac8x_56", "DAC8x Outputs 5/6", 4, 5),
        ("dac8x_78", "DAC8x Outputs 7/8", 6, 7),
    )
    rows: List[Dict[str, str]] = []
    for pcm_name, label, left, right in pairs:
        row = dict(card)
        row["output"] = pcm_name
        row["label"] = "{} - {}".format(label, card.get("name"))
        row["virtual"] = "dac8x"
        row["dac8x_left"] = str(left)
        row["dac8x_right"] = str(right)
        rows.append(row)
    return rows


def _dac8x_asound_block(card_id: str) -> str:
    entries = []
    base = """pcm.dac8x_dmix {
    type dmix
    ipc_key 7908
    ipc_perm 0666
    slave {
        pcm "hw:CARD=%s,DEV=0"
        rate 48000
        channels 8
        period_time 0
        period_size 1024
        buffer_size 8192
    }
    bindings {
        0 0
        1 1
        2 2
        3 3
        4 4
        5 5
        6 6
        7 7
    }
}""" % card_id
    for name, left, right in (
        ("dac8x_12", 0, 1),
        ("dac8x_34", 2, 3),
        ("dac8x_56", 4, 5),
        ("dac8x_78", 6, 7),
    ):
        route_name = "{}_route".format(name)
        entries.append(
            """pcm.{name} {{
    type plug
    slave.pcm "{route_name}"
}}

pcm.{route_name} {{
    type route
    slave {{
        pcm "dac8x_dmix"
        channels 8
    }}
    ttable.0.{left} 1
    ttable.1.{right} 1
}}""".format(
                name=name,
                route_name=route_name,
                left=left,
                right=right,
            )
        )
    return DAC8X_ASOUND_BEGIN + "\n" + base + "\n\n" + "\n\n".join(entries) + "\n" + DAC8X_ASOUND_END + "\n"


def _replace_managed_block(text: str, begin: str, end: str, block: str) -> str:
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end) + r"\n?", flags=re.S)
    clean = pattern.sub("", text).rstrip() + "\n\n"
    return clean + block


def _strip_dac8x_asound_defs(text: str) -> str:
    for begin, end in (
        (DAC8X_ASOUND_BEGIN, DAC8X_ASOUND_END),
        ("# BEGIN LYRION DAC8X", "# END LYRION DAC8X"),
    ):
        text = re.sub(re.escape(begin) + r".*?" + re.escape(end) + r"\n?", "", text, flags=re.S)
    lines = text.splitlines()
    kept: List[str] = []
    index = 0
    while index < len(lines):
        line = lines[index]
        if re.match(r"^\s*pcm\.dac8x(?:_[A-Za-z0-9]+)?\s*\{", line):
            depth = line.count("{") - line.count("}")
            index += 1
            while index < len(lines) and depth > 0:
                depth += lines[index].count("{") - lines[index].count("}")
                index += 1
            continue
        kept.append(line)
        index += 1
    return "\n".join(kept).rstrip() + "\n"


def _replace_dac8x_asound_block(text: str, block: str) -> str:
    return _strip_dac8x_asound_defs(text).rstrip() + "\n\n" + block


def _ensure_filetool_entry(entry: str) -> None:
    try:
        existing = ""
        if os.path.exists(FILETOOL_LIST_PATH):
            with open(FILETOOL_LIST_PATH, "r", encoding="utf-8", errors="replace") as handle:
                existing = handle.read()
        lines = [line.strip() for line in existing.splitlines()]
        if entry in lines:
            return
        with open(FILETOOL_LIST_PATH, "a", encoding="utf-8", newline="\n") as handle:
            if existing and not existing.endswith("\n"):
                handle.write("\n")
            handle.write(entry + "\n")
    except Exception as error:
        raise RuntimeError("Could not update pCP backup file list: {}".format(_safe_str(error)))


def _ensure_dac8x_asound_config(outputs: List[str]) -> bool:
    if not any(_safe_str(output).strip().startswith("dac8x_") for output in outputs):
        return False
    card = _dac8x_card()
    if not card:
        raise RuntimeError("DAC8x outputs were selected, but no DAC8x ALSA card was detected")
    card_id = _safe_str(card.get("id")).strip()
    if not card_id:
        raise RuntimeError("DAC8x ALSA card did not expose a stable card id")
    original = ""
    if os.path.exists(ASOUND_CONFIG_PATH):
        with open(ASOUND_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
            original = handle.read()
    updated = _replace_dac8x_asound_block(original, _dac8x_asound_block(card_id))
    if updated != original:
        tmp_path = ASOUND_CONFIG_PATH + ".lyrion-new"
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, ASOUND_CONFIG_PATH)
    _ensure_filetool_entry("etc/asound.conf")
    _ensure_filetool_entry("opt/.filetool.lst")
    return updated != original


def _available_alsa_outputs() -> List[Dict[str, str]]:
    outputs = []
    show_analog = bool(_setup_cache.get("show_analog_outputs", False))
    for card in _alsa_cards():
        if not show_analog and _is_low_quality_analog_card(card):
            continue
        if "dac8x" in " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        ):
            continue
        output = _alsa_output_for_card(card)
        if not output:
            continue
        row = dict(card)
        row["output"] = output
        row["label"] = "{} - {}".format(card.get("id"), card.get("name"))
        outputs.append(row)
    outputs.extend(_dac8x_outputs())
    return outputs


def _available_alsa_pcm_names() -> Set[str]:
    """Return ALSA PCM names, including virtual devices defined by plugins."""
    try:
        result = subprocess.run(
            ["aplay", "-L"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=8,
            check=False,
        )
    except Exception:
        return set()
    if result.returncode != 0:
        return set()
    names: Set[str] = set()
    for raw_line in (result.stdout or "").splitlines():
        if not raw_line or raw_line[0].isspace():
            continue
        name = raw_line.strip()
        if name:
            names.add(name)
    return names


def _clone_usb_signature(row: Dict[str, str]) -> str:
    name = _safe_str(row.get("name")).strip().lower()
    detail = _safe_str(row.get("detail")).strip().lower()
    detail = re.sub(r"\s+at\s+usb-.+$", "", detail)
    detail = re.sub(r"\s+", " ", detail).strip()
    return "{}|{}".format(name, detail)


def _is_clone_usb_dac(row: Dict[str, str], path_suffix: str) -> bool:
    text = " ".join(
        _safe_str(row.get(key)).lower()
        for key in ("id", "driver", "name", "detail")
    )
    return (
        _safe_str(row.get("path")).endswith(path_suffix)
        and "usb" in _safe_str(row.get("driver")).lower()
        and "audio" in text
    )


def _is_clone_hifiberry_dac(row: Dict[str, str]) -> bool:
    text = " ".join(
        _safe_str(row.get(key)).lower()
        for key in ("id", "driver", "name", "detail")
    )
    return (
        "hifiberry" in text
        and "dac" in text
        and "digi" not in text
        and "spdif" not in text
    )


def _clone_outputs() -> Tuple[List[str], List[str]]:
    cards = _available_alsa_outputs()
    usb_one = next((
        row for row in cards
        if _is_clone_usb_dac(row, "-1.4")
    ), None)
    usb_two = next((
        row for row in cards
        if _is_clone_usb_dac(row, "-1.3")
    ), None)
    hifiberry = next((
        row for row in cards
        if _is_clone_hifiberry_dac(row)
    ), None)
    rows = (usb_one, usb_two, hifiberry)
    labels = ("Output 1 USB port 1-1.4", "Output 2 USB port 1-1.3", "Output 3 HiFiBerry DAC+")
    missing = [labels[index] for index, row in enumerate(rows) if row is None]
    clone_outputs = {
        _safe_str(row.get("output"))
        for row in rows
        if isinstance(row, dict) and _safe_str(row.get("output"))
    }
    extra_outputs = [
        row for row in cards
        if _safe_str(row.get("output")) and _safe_str(row.get("output")) not in clone_outputs
    ]
    if usb_one and usb_two and _clone_usb_signature(usb_one) != _clone_usb_signature(usb_two):
        usb_one = None
        usb_two = None
        rows = (usb_one, usb_two, hifiberry)
        missing = [
            "Output 1/2 matching USB DACs on fixed MS-3 ports",
        ]
        if hifiberry is None:
            missing.append(labels[2])
    elif not missing and extra_outputs:
        missing = [
            "MS-3 Clone requires only the two fixed USB DACs and HiFiBerry DAC+. Extra output detected: {}".format(
                ", ".join(_safe_str(row.get("id") or row.get("output")) for row in extra_outputs[:4])
            )
        ]
    return [
        _safe_str(row.get("output")) if isinstance(row, dict) else ""
        for row in rows
    ], missing


def _alsa_control_names(card_index: str) -> Set[str]:
    try:
        result = subprocess.run(
            ["amixer", "-c", str(card_index), "scontrols"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return set()
    controls: Set[str] = set()
    for line in (result.stdout or "").splitlines():
        match = re.search(r"Simple mixer control '([^']+)'", line)
        if match:
            controls.add(match.group(1))
    return controls


def _amixer_sset(card_index: str, control: str, *values: str) -> str:
    result = subprocess.run(
        ["amixer", "-c", str(card_index), "sset", control, *values],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=8,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stdout or "").strip()[-300:] or "amixer failed")
    return result.stdout or ""


def _normalize_mixer_levels_for_outputs(outputs: List[str], save_backup: bool = True) -> Dict[str, Any]:
    selected = {_safe_str(output).strip() for output in outputs if _safe_str(output).strip()}
    cards = [
        card for card in _available_alsa_outputs()
        if _safe_str(card.get("output")).strip() in selected
    ]
    changed: List[str] = []
    warnings: List[str] = []
    for card in cards:
        card_index = _safe_str(card.get("index")).strip()
        if not card_index:
            continue
        controls = _alsa_control_names(card_index)
        text = " ".join(
            _safe_str(card.get(key)).lower()
            for key in ("id", "driver", "name", "detail")
        )
        commands: List[Tuple[str, Tuple[str, ...]]] = []
        if "usb" in text or "c-media" in text or "cmedia" in text:
            commands.extend([
                ("Speaker", ("100%", "unmute")),
                ("Mic", ("0%", "mute")),
                ("Auto Gain Control", ("off",)),
            ])
        elif "hifiberry" in text or "sndrpihifiberry" in text:
            commands.extend([
                ("Digital", ("100%", "unmute")),
                ("Analogue", ("100%",)),
            ])
        elif "hdmi" in text:
            commands.extend([
                ("PCM", ("100%", "unmute")),
                ("Digital", ("100%", "unmute")),
                ("Master", ("100%", "unmute")),
            ])
        else:
            commands.extend([
                ("PCM", ("100%", "unmute")),
                ("Speaker", ("100%", "unmute")),
                ("Master", ("100%", "unmute")),
                ("Digital", ("100%", "unmute")),
            ])
        for control, values in commands:
            if control not in controls:
                continue
            try:
                _amixer_sset(card_index, control, *values)
                changed.append("{}: {}".format(card.get("id") or card_index, control))
            except Exception as error:
                warnings.append("{} {}: {}".format(card.get("id") or card_index, control, _safe_str(error)))
    if save_backup:
        backup = subprocess.run(
            ["/usr/bin/filetool.sh", "-b"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=60,
            check=False,
        )
        if backup.returncode != 0:
            raise RuntimeError("Mixer levels changed, but pCP backup failed: {}".format((backup.stdout or "")[-300:]))
    return {"changed": changed, "warnings": warnings}


async def _normalize_mixer_levels_after_startup() -> None:
    try:
        elapsed = 0.0
        for delay in (5.0, 18.0):
            await asyncio.sleep(max(0.0, delay - elapsed))
            elapsed = delay
            outputs = [
                _safe_str(row.get("output"))
                for row in _pcp_player_sessions()
                if _safe_str(row.get("output")).strip()
            ]
            if not outputs:
                continue
            result = await asyncio.to_thread(_normalize_mixer_levels_for_outputs, outputs, False)
            dbg(
                "Startup mixer normalize after {:.0f}s: {} controls{}".format(
                    delay,
                    len(result.get("changed", [])),
                    " warnings={}".format("; ".join(result.get("warnings", [])[:3]))
                    if result.get("warnings") else "",
                )
            )
    except asyncio.CancelledError:
        raise
    except Exception as error:
        dbg("Startup mixer normalize failed: {}".format(_safe_str(error)))


def _managed_player_mac(slot: int) -> str:
    device_mac = _safe_str(_license_status().get("device_mac")).lower()
    parts = device_mac.split(":")
    if len(parts) != 6:
        return ""
    return ":".join(parts[:5] + ["a{}".format(max(0, min(slot - 1, MAX_UNIT_PLAYERS - 1)))])


def _replace_pcp_config_values(text: str, updates: Dict[str, str]) -> str:
    remaining = dict(updates)
    lines = text.splitlines()
    output_lines = []
    for line in lines:
        match = re.match(r'^([A-Z0-9_]+)=".*"$', line)
        if match and match.group(1) in remaining:
            key = match.group(1)
            output_lines.append('{}="{}"'.format(key, remaining.pop(key)))
        else:
            output_lines.append(line)
    for key, value in remaining.items():
        output_lines.append('{}="{}"'.format(key, value))
    return "\n".join(output_lines) + "\n"


def _validate_player_text(value: Any, label: str) -> str:
    text = _safe_str(value).strip()
    if not text:
        raise ValueError("{} is required".format(label))
    if len(text) > 48 or any(char in text for char in ('"', "\r", "\n")):
        raise ValueError("{} contains unsupported characters".format(label))
    return text


def _player_startup_name(value: Any, slot: int) -> str:
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", _safe_str(value).strip())
    name = re.sub(r"_+", "_", name).strip("_.-")
    return (name or "Player_{}".format(slot))[:48]


def _default_audio_params_for_output(output: Any) -> str:
    text = _safe_str(output).strip().lower()
    if text.startswith("hdmi:"):
        return "80:4::0:"
    if text.startswith("dac8x_"):
        return "80:4::1:"
    return "80:4::0:"


def _audio_params_or_default(value: Any, output: Any) -> str:
    text = _safe_str(value).strip()
    if _safe_str(output).strip().lower().startswith("hdmi:") and text == "80::32:0":
        return _default_audio_params_for_output(output)
    if not text or text.replace(":", "").strip() == "":
        return _default_audio_params_for_output(output)
    return text


def _audio_params_signature(value: Any) -> str:
    return _safe_str(value).strip().rstrip(":")


def _clone_upsample_params(slot: int) -> str:
    if slot in (1, 2):
        return "::0"
    if slot == 3:
        return "::4"
    return ""


def _row_upsample_params(row: Dict[str, Any]) -> str:
    return _safe_str(
        row.get("upsample_params")
        or row.get("upsample")
        or row.get("resample_params")
    ).strip()


def _row_extra_options(row: Dict[str, Any]) -> str:
    return _safe_str(row.get("extra_options") or row.get("other_options")).strip()


def _extra_squeezelite_args(options: Any) -> List[str]:
    text = _safe_str(options).strip()
    if not text:
        return []
    args = shlex.split(text)
    reserved = {"-n", "-o", "-a", "-m", "-s"}
    if any(arg in reserved for arg in args):
        raise ValueError("Other options may not include -n, -o, -a, -m, or -s")
    return args


def _squeezelite_option_value(options: Any, option: str) -> str:
    try:
        args = shlex.split(_safe_str(options))
    except Exception:
        return ""
    if option in args:
        index = args.index(option)
        if index + 1 < len(args):
            return _safe_str(args[index + 1])
    return ""


def _merge_squeezelite_other_options(options: Any, upsample_params: str, extra_options: Any = "") -> str:
    try:
        args = shlex.split(_safe_str(options))
    except Exception:
        args = []
    cleaned: List[str] = []
    skip_next = False
    for index, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg in ("-u", "-R"):
            if index + 1 < len(args):
                skip_next = True
            continue
        cleaned.append(arg)
    if upsample_params:
        cleaned.extend(["-u", upsample_params])
    cleaned.extend(_extra_squeezelite_args(extra_options))
    return _shell_join(cleaned)


def _is_hdmi_output(output: Any) -> bool:
    text = _safe_str(output).strip().lower()
    return (
        text.startswith("hdmi:")
        or "vc4hdmi" in text
        or "vc4-hdmi" in text
        or "card=hdmi" in text
        or "bcm2835_hdmi" in text
        or re.search(r"(?:^|[:,])card=b[12](?:,|$)", text)
    )


def _player_lms_server_host() -> str:
    server = urllib.parse.urlsplit(LMS_BASE).hostname or "127.0.0.1"
    if not _broker_light_mode() and _is_loopback_host(server):
        return "127.0.0.1"
    if _is_loopback_host(server):
        public_lms = urllib.parse.urlsplit(_public_lms_base())
        public_host = _safe_str(public_lms.hostname).strip()
        if public_host and not _is_loopback_host(public_host):
            server = public_host
    return server


def _lms_target_display() -> str:
    saved = _safe_str(_setup_cache.get("lms_base")).strip().rstrip("/")
    if saved:
        return saved
    if _broker_light_mode():
        return ""
    return LOCAL_LMS_BASE


def _normalize_lms_base_input(value: Any, allow_blank: bool) -> str:
    text = _safe_str(value).strip().rstrip("/")
    if not text:
        return "" if allow_blank else LOCAL_LMS_BASE
    if not re.match(r"^https?://", text, flags=re.I):
        text = "http://" + text
    parts = urllib.parse.urlsplit(text)
    if not parts.hostname:
        raise ValueError("LMS target must be a valid URL or host/IP")
    netloc = parts.netloc
    if ":" not in netloc:
        netloc = parts.hostname + ":9000"
    return urllib.parse.urlunsplit((parts.scheme or "http", netloc, "", "", ""))


def _managed_squeezelite_processes(mac_values: Set[str]) -> List[int]:
    wanted = {value.lower() for value in mac_values if value}
    pids = []
    try:
        for name in os.listdir("/proc"):
            if not name.isdigit():
                continue
            try:
                with open("/proc/{}/cmdline".format(name), "rb") as handle:
                    args = [
                        part.decode("utf-8", errors="replace")
                        for part in handle.read().split(b"\0")
                        if part
                    ]
                if not args or "squeezelite" not in os.path.basename(args[0]).lower():
                    continue
                if "-m" not in args:
                    continue
                index = args.index("-m")
                mac_parts = args[index + 1:index + 7]
                if index + 1 >= len(args):
                    mac = ""
                elif ":" in args[index + 1]:
                    mac = args[index + 1].lower()
                elif len(mac_parts) == 6 and all(re.fullmatch(r"[0-9A-Fa-f]{2}", part) for part in mac_parts):
                    mac = ":".join(mac_parts).lower()
                else:
                    mac = args[index + 1].lower()
                if mac in wanted:
                    pids.append(int(name))
            except Exception:
                continue
    except Exception:
        pass
    return pids


def _running_squeezelite_macs(mac_values: Set[str]) -> Set[str]:
    wanted = {value.lower() for value in mac_values if value}
    running: Set[str] = set()
    try:
        for name in os.listdir("/proc"):
            if not name.isdigit():
                continue
            try:
                with open("/proc/{}/cmdline".format(name), "rb") as handle:
                    args = [
                        part.decode("utf-8", errors="replace")
                        for part in handle.read().split(b"\0")
                        if part
                    ]
                if not args or "squeezelite" not in os.path.basename(args[0]).lower():
                    continue
                if "-m" not in args:
                    continue
                index = args.index("-m")
                mac_parts = args[index + 1:index + 7]
                if index + 1 >= len(args):
                    mac = ""
                elif ":" in args[index + 1]:
                    mac = args[index + 1].lower()
                elif len(mac_parts) == 6 and all(re.fullmatch(r"[0-9A-Fa-f]{2}", part) for part in mac_parts):
                    mac = ":".join(mac_parts).lower()
                else:
                    mac = args[index + 1].lower()
                if mac in wanted:
                    running.add(mac)
            except Exception:
                continue
    except Exception:
        pass
    return running


def _wait_for_squeezelite_macs(mac_values: Set[str], expected_count: int, timeout: float = 15.0) -> List[int]:
    deadline = time.time() + max(1.0, timeout)
    pids: List[int] = []
    while time.time() < deadline:
        pids = _managed_squeezelite_processes(mac_values)
        if len(_running_squeezelite_macs(mac_values)) >= expected_count:
            return pids
        time.sleep(0.5)
    return pids


def _squeezelite_args(row: Dict[str, str], extra: bool = True) -> List[str]:
    args = [
        "/usr/local/bin/squeezelite",
        "-n", row.get("startup_name") or row["name"],
        "-o", row["output"],
    ]
    if extra:
        args.extend(["-a", _audio_params_or_default(row.get("audio_params"), row.get("output"))])
    upsample_params = _row_upsample_params(row)
    if upsample_params:
        args.extend(["-u", upsample_params])
    args.extend(_extra_squeezelite_args(_row_extra_options(row)))
    args.extend(["-m", row["mac"], "-s", row["server"]])
    return args


def _squeezelite_user_command(row: Dict[str, str]) -> str:
    return _shell_join(_squeezelite_args(row, extra=True))


def _shell_join(args: List[str]) -> str:
    return " ".join(shlex.quote(_safe_str(arg)) for arg in args)


def _write_local_stack_launcher(rows: List[Dict[str, str]]) -> None:
    app_dir = os.path.dirname(PCP_LOCAL_STACK_PATH)
    os.makedirs(app_dir, exist_ok=True)
    lines = [
        "#!/bin/sh",
        "# Generated by Lyrion Gadget. Re-apply local players in the broker to update.",
        "APP_DIR={}".format(shlex.quote(app_dir)),
        "\"$APP_DIR/launch-lyrion-broker-pcp.sh\" >/dev/null 2>&1 &",
        "sleep 1",
    ]
    for row in rows[1:]:
        if not bool(row.get("enabled", True)):
            continue
        lines.append(_shell_join(_squeezelite_args(row, extra=True)) + " >/dev/null 2>&1 &")
    lines.append("exit 0")
    temp_path = PCP_LOCAL_STACK_PATH + ".new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(temp_path, 0o755)
    os.replace(temp_path, PCP_LOCAL_STACK_PATH)


def _repair_full_local_player_server_target() -> bool:
    if _broker_light_mode() or _player_lms_server_host() != "127.0.0.1":
        return False
    if not os.path.isfile(PCP_CONFIG_PATH):
        return False
    config = _read_pcp_config()
    if not config:
        return False
    current_server = _safe_str(config.get("SERVER_IP")).strip()
    uses_stack = _pcp_uses_local_stack(config)
    updates: Dict[str, str] = {}
    changed = False
    if current_server and current_server != "127.0.0.1":
        updates["SERVER_IP"] = "127.0.0.1"
        changed = True
    if not uses_stack:
        for index in range(1, 5):
            key = "USER_COMMAND_{}".format(index)
            encoded = _safe_str(config.get(key)).strip()
            if not encoded:
                continue
            command = urllib.parse.unquote_plus(encoded)
            if "squeezelite" not in command.lower():
                continue
            row = _parse_squeezelite_command(command, index + 1)
            if not _safe_str(row.get("server")).strip() or _safe_str(row.get("server")).strip() == "127.0.0.1":
                continue
            row["server"] = "127.0.0.1"
            updates[key] = urllib.parse.quote_plus(_squeezelite_user_command(row), safe="")
            changed = True

    saved_rows = _setup_cache.get("local_player_rows")
    stack_fallback_rows: List[Dict[str, Any]] = []
    if uses_stack and not (isinstance(saved_rows, list) and saved_rows):
        stack_fallback_rows = _local_stack_player_rows(current_server or "127.0.0.1")
        if stack_fallback_rows:
            saved_rows = [dict(_pcp_player_sessions()[0])] + stack_fallback_rows
    if isinstance(saved_rows, list) and saved_rows:
        updated_rows: List[Dict[str, Any]] = []
        rows_for_stack: List[Dict[str, str]] = []
        for saved in saved_rows:
            if not isinstance(saved, dict):
                continue
            item = dict(saved)
            if _safe_str(item.get("server")).strip() != "127.0.0.1":
                item["server"] = "127.0.0.1"
                changed = True
            updated_rows.append(item)
            rows_for_stack.append({
                "slot": _safe_int(item.get("slot"), len(rows_for_stack) + 1),
                "enabled": bool(item.get("enabled", True)),
                "name": _safe_str(item.get("name")) or "Player {}".format(len(rows_for_stack) + 1),
                "startup_name": _player_startup_name(item.get("name"), len(rows_for_stack) + 1),
                "output": _safe_str(item.get("output")),
                "audio_params": _safe_str(item.get("audio_params")),
                "upsample_params": _safe_str(item.get("upsample_params")),
                "extra_options": _safe_str(item.get("extra_options")),
                "mac": _safe_str(item.get("mac")).strip().lower(),
                "server": "127.0.0.1",
            })
        if changed:
            _setup_cache["local_player_rows"] = updated_rows
            if uses_stack and rows_for_stack:
                _write_local_stack_launcher(rows_for_stack)

    if not changed:
        return False

    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()
    backup_dir = os.path.join(os.path.dirname(SETUP_JSON_PATH), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    backup_path = os.path.join(backup_dir, "pcp.cfg.server-target.{}".format(int(time.time())))
    with open(backup_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(original)
    updated = _replace_pcp_config_values(original, updates)
    temp_path = PCP_CONFIG_PATH + ".lyrion-new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, PCP_CONFIG_PATH)
    _save_setup_config()
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        dbg("Local player server target repaired, but pCP backup failed: {}".format((backup.stdout or "")[-300:]))
    else:
        dbg("Local player server target repaired to 127.0.0.1")
    return True


def _restart_pcp_main() -> str:
    pcp_binary = shutil.which("pcp") or "/usr/local/bin/pcp"
    result = subprocess.run(
        [pcp_binary, "slr"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=20,
        check=False,
    )
    return result.stdout or ""


def _launch_extra_sessions(rows: List[Dict[str, Any]]) -> None:
    for row in rows[1:]:
        if not bool(row.get("enabled", True)):
            continue
        row_mac = _safe_str(row.get("mac")).strip().lower()
        if row_mac and _running_squeezelite_macs({row_mac}):
            continue
        command = _safe_str(row.get("command")).strip()
        args = shlex.split(command) if command else _squeezelite_args(row, extra=True)
        subprocess.Popen(
            args,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )


def _stop_managed_squeezelite(mac_values: Set[str]) -> None:
    for pid in _managed_squeezelite_processes(mac_values):
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass
    time.sleep(1.0)


def _restore_local_players(
    backup_path: str,
    old_rows: List[Dict[str, Any]],
    cleanup_macs: Set[str],
) -> None:
    _stop_managed_squeezelite(cleanup_macs)
    shutil.copyfile(backup_path, PCP_CONFIG_PATH)
    _restart_pcp_main()
    time.sleep(1.5)
    _launch_extra_sessions(old_rows)
    time.sleep(1.5)


def _jivelite_config_paths() -> List[str]:
    candidates = (
        "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
        "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
    )
    return [candidate for candidate in candidates if os.path.isfile(candidate)]


def _update_jivelite_player(player: Dict[str, str]) -> bool:
    paths = _jivelite_config_paths()
    if not paths:
        return False
    changed = False
    try:
        for path in paths:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                original = handle.read()
            updated = re.sub(
                r'playerId="[^"]*"',
                'playerId="{}"'.format(player["mac"]),
                original,
            )
            updated = re.sub(
                r'currentPlayer="[^"]*"',
                'currentPlayer="{}"'.format(player["mac"]),
                updated,
            )
            updated = re.sub(
                r'playerInit=\{name="[^"]*"',
                'playerInit={{name="{}"'.format(player["name"]),
                updated,
            )
            if updated == original:
                continue
            shutil.copyfile(path, path + ".lyrion-backup")
            with open(path, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(updated)
                handle.flush()
                os.fsync(handle.fileno())
            changed = True
        return changed
    except Exception as error:
        dbg("JiveLite player mapping skipped: {}".format(_safe_str(error)))
        return False


def _restart_jivelite_if_present() -> None:
    if not shutil.which("pcp"):
        return
    try:
        subprocess.run(
            ["/usr/local/bin/pcp", "jivelite", "restart"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
    except Exception:
        pass


def _apply_local_players(mode: str, rows: List[Dict[str, str]], jivelite_slot: str = "auto") -> Dict[str, Any]:
    if not os.path.isfile(PCP_CONFIG_PATH):
        raise RuntimeError("pCP configuration was not found")
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()

    backup_dir = os.path.join(os.path.dirname(SETUP_JSON_PATH), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    backup_path = os.path.join(backup_dir, "pcp.cfg.{}".format(int(time.time())))
    with open(backup_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(original)

    for row in rows:
        row["mac"] = _safe_str(row.get("mac")).strip().lower()

    current_config = _read_pcp_config()
    dac8x_config_changed = _ensure_dac8x_asound_config([
        _safe_str(row.get("output")) for row in rows if bool(row.get("enabled", True))
    ])

    old_rows = _pcp_player_sessions()
    old_macs = {row.get("mac", "") for row in old_rows}
    server = rows[0]["server"]
    main = rows[0]
    updates = {
        "NAME": main["name"],
        "OUTPUT": main["output"],
        "MAC_ADDRESS": main["mac"],
        "SERVER_IP": server,
        "SQUEEZELITE": "yes",
        "ALSA_PARAMS": _audio_params_or_default(main.get("audio_params"), main.get("output")),
        "UPSAMPLE": "",
        "OTHER": _merge_squeezelite_other_options(
            current_config.get("OTHER") if isinstance(current_config, dict) else "",
            _row_upsample_params(main),
            _row_extra_options(main),
        ),
    }
    if mode == "clone":
        for index in range(1, 5):
            key = "USER_COMMAND_{}".format(index)
            if index < len(rows) and bool(rows[index].get("enabled", True)):
                command = _squeezelite_user_command(rows[index])
                updates[key] = urllib.parse.quote_plus(command, safe="")
            else:
                updates[key] = ""
    else:
        if len(rows) <= 4:
            for index in range(1, 6):
                key = "USER_COMMAND_{}".format(index)
                if index < len(rows) and bool(rows[index].get("enabled", True)):
                    command = _squeezelite_user_command(rows[index])
                    updates[key] = urllib.parse.quote_plus(command, safe="")
                else:
                    updates[key] = ""
        else:
            _write_local_stack_launcher(rows)
            stack_command_slot = _local_stack_user_command_slot()
            for index in range(1, 6):
                key = "USER_COMMAND_{}".format(index)
                updates[key] = urllib.parse.quote_plus(PCP_LOCAL_STACK_PATH, safe="") if index == stack_command_slot else ""

    updated = _replace_pcp_config_values(original, updates)
    temp_path = PCP_CONFIG_PATH + ".lyrion-new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, PCP_CONFIG_PATH)

    enabled_rows = [row for row in rows if bool(row.get("enabled", True))]
    new_macs = {row["mac"] for row in enabled_rows}
    _stop_managed_squeezelite(old_macs)
    restart_output = _restart_pcp_main()
    main_running = bool(_wait_for_squeezelite_macs({main["mac"]}, 1))
    if not main_running:
        _restore_local_players(backup_path, old_rows, old_macs | new_macs)
        raise RuntimeError(
            "pCP did not start the expected main player; the original configuration was restored: {}".format(
                restart_output[-300:]
            )
        )

    _launch_extra_sessions(rows)
    expected_macs = new_macs
    running_pids = _wait_for_squeezelite_macs(expected_macs, len(enabled_rows))
    if len(running_pids) != len(enabled_rows):
        _restore_local_players(backup_path, old_rows, old_macs | new_macs)
        raise RuntimeError(
            "Only {} of {} players started; the original configuration was restored".format(
                len(running_pids), len(enabled_rows)
            )
        )
    mixer_result = _normalize_mixer_levels_for_outputs([
        _safe_str(row.get("output")) for row in enabled_rows
    ])

    jivelite_slot = _jivelite_player_slot_setting(jivelite_slot)
    jivelite_player = None
    if mode != "clone" and jivelite_slot != "none":
        hdmi_rows = [row for row in enabled_rows if _is_hdmi_output(row.get("output"))]
        if jivelite_slot.isdigit():
            jivelite_player = next((
                row for row in hdmi_rows
                if _safe_int(row.get("slot"), 0) == _safe_int(jivelite_slot, 0)
            ), None)
        if jivelite_player is None:
            jivelite_player = hdmi_rows[0] if hdmi_rows else None
    jivelite_updated = bool(
        jivelite_player and _update_jivelite_player(jivelite_player)
    )
    if jivelite_updated:
        _restart_jivelite_if_present()
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("Players restarted, but pCP backup failed: {}".format(backup.stdout[-300:]))
    _setup_cache["local_player_mode"] = mode
    _setup_cache["local_player_rows"] = [
        {
            "slot": index + 1,
            "enabled": bool(row.get("enabled", True)),
            "name": _safe_str(row.get("name")),
            "output": _safe_str(row.get("output")),
            "audio_params": _safe_str(row.get("audio_params")),
            "upsample_params": _safe_str(row.get("upsample_params")),
            "extra_options": _safe_str(row.get("extra_options")),
            "mac": _safe_str(row.get("mac")).lower(),
            "server": _safe_str(row.get("server")),
        }
        for index, row in enumerate(rows)
    ]
    _setup_cache["jivelite_player_slot"] = jivelite_slot
    _save_setup_config()
    return {
        "backup": backup_path,
        "players": len(enabled_rows),
        "jivelite_updated": jivelite_updated,
        "jivelite_target": _safe_str(jivelite_player.get("name") if jivelite_player else ""),
        "mixer_changed": len(mixer_result.get("changed", [])),
        "mixer_warnings": mixer_result.get("warnings", []),
        "dac8x_asound_changed": dac8x_config_changed,
    }


async def _player_fixed_volume(playerid: str) -> bool:
    response = await lms.rpc(playerid, ["playerpref", "digitalVolumeControl", "?"])
    value = (response.get("result") or {}).get("_p2")
    return _safe_int(value, 1) == 0


async def _apply_friendly_player_names(rows: List[Dict[str, str]]) -> None:
    pending = {
        _safe_str(row.get("mac")).strip().lower(): _safe_str(row.get("name")).strip()
        for row in rows
        if _safe_str(row.get("mac")).strip() and _safe_str(row.get("name")).strip()
    }
    deadline = asyncio.get_running_loop().time() + 15.0
    while pending and asyncio.get_running_loop().time() < deadline:
        players = await lms.get_players()
        connected = {
            _safe_str(player.get("playerid")).strip().lower()
            for player in players
            if _safe_int(player.get("connected"), 0) == 1
        }
        for playerid in list(pending):
            if playerid not in connected:
                continue
            await lms.rpc(playerid, ["name", pending[playerid]])
            pending.pop(playerid, None)
        if pending:
            await asyncio.sleep(0.5)
    if pending:
        raise RuntimeError(
            "Players started, but LMS did not reconnect for friendly naming: {}".format(
                ", ".join(sorted(pending))
            )
        )


async def _restore_friendly_player_names() -> None:
    async def repair_once() -> int:
        saved = _setup_cache.get("local_player_friendly_names")
        if not isinstance(saved, dict) or not saved:
            return 0
        active_macs = {
            _safe_str(row.get("mac")).strip().lower()
            for row in _pcp_player_sessions()
            if _safe_str(row.get("mac")).strip()
        }
        desired = {
            _safe_str(mac).strip().lower(): _safe_str(name).strip()
            for mac, name in saved.items()
            if _safe_str(mac).strip().lower() in active_macs and _safe_str(name).strip()
        }
        if not desired:
            return 0
        changed = 0
        players = await lms.get_players()
        for player in players:
            playerid = _safe_str(player.get("playerid")).strip().lower()
            if playerid not in desired or _safe_int(player.get("connected"), 0) != 1:
                continue
            current_name = _safe_str(player.get("name")).strip()
            friendly_name = desired[playerid]
            if current_name == friendly_name:
                continue
            await lms.rpc(playerid, ["name", friendly_name])
            changed += 1
        return changed

    try:
        await asyncio.sleep(4.0)
        while True:
            try:
                changed = await repair_once()
                if changed:
                    dbg("Friendly player names repaired: {}".format(changed))
                    await cometd_scan_and_subscribe_connected()
            except Exception as error:
                dbg("Friendly player name repair failed: {}".format(_safe_str(error)))
            await asyncio.sleep(30.0)
    except asyncio.CancelledError:
        raise
    except Exception as error:
        dbg("Friendly player name restore failed: {}".format(_safe_str(error)))


async def setup_players_page(req: web.Request) -> web.Response:
    sessions = _pcp_player_sessions()
    cards = _alsa_cards()
    available_outputs = _available_alsa_outputs()
    dac8x_detected = bool(_dac8x_card())
    clone_output_values, clone_missing = _clone_outputs()
    pi_model = _raspberry_pi_model()
    local_player_limit = _local_player_limit()
    requested_mode = _safe_str(req.query.get("mode")).lower()
    current_mode = _current_provisioning_mode()
    mode = requested_mode or current_mode or ("open" if clone_missing else "clone")
    if mode not in ("clone", "open"):
        mode = current_mode or ("open" if clone_missing else "clone")
    if mode == "clone" and clone_missing:
        mode = "open"
    saved_player_rows = _setup_cache.get("local_player_rows")
    if not isinstance(saved_player_rows, list):
        saved_player_rows = []
    show_player_other_options = _advanced_setup_level(req) >= 2
    saved_count = max(
        [_safe_int(row.get("slot"), 0) for row in saved_player_rows if isinstance(row, dict)] or [0]
    )
    if mode == "clone":
        default_count = max(CLONE_MAX_PLAYERS, saved_count, len(sessions))
    elif saved_count:
        default_count = saved_count
    elif sessions:
        default_count = len(sessions)
    else:
        default_count = min(3, local_player_limit)
    requested_count = max(1, min(_safe_int(req.query.get("count"), default_count), local_player_limit))
    if mode == "clone":
        requested_count = min(requested_count, CLONE_MAX_PLAYERS)

    saved_friendly_names = _setup_cache.get("local_player_friendly_names")
    friendly_name_by_mac = {
        _safe_str(mac).strip().lower(): _safe_str(name).strip()
        for mac, name in (saved_friendly_names.items() if isinstance(saved_friendly_names, dict) else [])
        if _safe_str(mac).strip() and _safe_str(name).strip()
    }

    fixed_volume_by_mac: Dict[str, bool] = {}
    if sessions:
        try:
            states = await asyncio.gather(
                *(_player_fixed_volume(_safe_str(row.get("mac"))) for row in sessions),
                return_exceptions=True,
            )
            for row, state in zip(sessions, states):
                if isinstance(state, bool):
                    fixed_volume_by_mac[_safe_str(row.get("mac")).lower()] = state
        except Exception as error:
            dbg("Fixed-volume state read skipped: {}".format(_safe_str(error)))

    current_rows = []
    for row in sessions:
        mac = _safe_str(row.get("mac")).strip().lower()
        checked = " checked" if fixed_volume_by_mac.get(mac, False) else ""
        current_rows.append(
            "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td>"
            "<td><code>{output}</code></td><td>{server}</td>"
            '<td><input class="fixed-volume" type="checkbox" data-mac="{mac}"{checked}></td>'
            '<td><button class="test-output" type="button" data-slot="{slot}" '
            'data-mac="{mac}" data-output="{output}">Test Output</button></td></tr>'.format(
                slot=row["slot"],
                name=_html_escape(
                    friendly_name_by_mac.get(mac)
                    or row["name"]
                    or "Player {}".format(row["slot"])
                ),
                mac=_html_escape(mac),
                output=_html_escape(row["output"]),
                server=_html_escape(row["server"]),
                checked=checked,
            )
        )
    if not current_rows:
        current_rows.append('<tr><td colspan="7">pCP configuration was not found on this host.</td></tr>')

    jivelite_present = bool(_jivelite_config_paths())

    card_rows = []
    for card in cards:
        card_rows.append(
            "<tr><td>{index}</td><td><code>{card_id}</code></td><td>{name}</td>"
            "<td><code>{path}</code></td><td>{detail}</td></tr>".format(
                index=_html_escape(card["index"]),
                card_id=_html_escape(card["id"]),
                name=_html_escape(card["name"]),
                path=_html_escape(card["path"]),
                detail=_html_escape(card["detail"]),
            )
        )
    if not card_rows:
        card_rows.append('<tr><td colspan="5">No ALSA cards were detected.</td></tr>')

    clone_labels = ("USB DAC - fixed Output 1 port", "USB DAC - fixed Output 2 port", "HiFiBerry DAC+")
    preview_rows = []
    preview_config: List[Dict[str, str]] = []
    for slot in range(1, requested_count + 1):
        saved_row = next((
            row for row in saved_player_rows
            if isinstance(row, dict) and _safe_int(row.get("slot"), 0) == slot
        ), {})
        active_row = next((row for row in sessions if row["slot"] == slot), {})
        enabled = True if slot == 1 else bool(
            saved_row.get("enabled", bool(active_row) if saved_player_rows else True)
        )
        if mode == "clone":
            output = clone_labels[slot - 1]
            mac = _managed_player_mac(slot)
            name = (
                friendly_name_by_mac.get(mac)
                or _safe_str(saved_row.get("name"))
                or "Player {}".format(slot)
            )
            output_control = (
                '<input type="hidden" class="player-output" value="{}"><code>{}</code>'.format(
                    _html_escape(clone_output_values[slot - 1]),
                    _html_escape(output),
                )
            )
        else:
            current = active_row or saved_row
            output = _safe_str(current.get("output")) or "Select a detected output"
            current_mac = _safe_str(current.get("mac")).strip().lower()
            name = (
                friendly_name_by_mac.get(current_mac)
                or _safe_str(current.get("name"))
                or "Player {}".format(slot)
            )
            options = ['<option value="">Select a detected output</option>']
            for device in available_outputs:
                value = _safe_str(device.get("output"))
                selected = " selected" if value == output else ""
                options.append('<option value="{}"{}>{}</option>'.format(
                    _html_escape(value),
                    selected,
                    _html_escape(device.get("label")),
                ))
            output_control = '<select class="player-output">{}</select>'.format("".join(options))
        selected_output = clone_output_values[slot - 1] if mode == "clone" else _safe_str(output)
        audio_params = _audio_params_or_default(
            _safe_str(active_row.get("audio_params")) or _safe_str(saved_row.get("audio_params")),
            selected_output,
        )
        upsample_params = (
            _clone_upsample_params(slot)
            if mode == "clone"
            else _safe_str(saved_row.get("upsample_params"))
        )
        extra_options = _safe_str(active_row.get("extra_options")) or _safe_str(saved_row.get("extra_options"))
        preview_config.append({
            "slot": slot,
            "name": name,
            "startup_name": _player_startup_name(name, slot),
            "mac": _managed_player_mac(slot),
            "output": selected_output,
            "audio_params": audio_params,
            "upsample_params": upsample_params,
            "extra_options": extra_options,
            "server": _player_lms_server_host(),
            "enabled": enabled,
        })
        other_options_cell = (
            '<td><input class="player-extra-options" type="text" maxlength="96" value="{extra_options}" '
            'placeholder="-u ::1"></td>'.format(extra_options=_html_escape(extra_options))
            if show_player_other_options
            else '<td style="display:none"><input class="player-extra-options" type="hidden" value="{extra_options}"></td>'.format(
                extra_options=_html_escape(extra_options)
            )
        )
        preview_rows.append(
            '<tr class="player-row" data-slot="{slot}"><td>{slot}</td>'
            '<td><input class="player-enabled" type="checkbox"{enabled}{required}></td>'
            '<td><input class="player-name" type="text" maxlength="48" value="{name}"></td>'
            '<td><code class="player-mac">{mac}</code></td><td>{output}</td>'
            '<td><input class="player-audio-params" type="text" maxlength="32" value="{audio_params}"></td>{other_options}</tr>'.format(
                slot=slot,
                enabled=" checked" if enabled else "",
                required=" disabled title=\"Player 1 is the required primary player\"" if slot == 1 else "",
                name=_html_escape(name),
                mac=_html_escape(_managed_player_mac(slot)),
                output=output_control,
                audio_params=_html_escape(audio_params),
                other_options=other_options_cell,
            )
        )

    hdmi_preview_rows = [
        row for row in preview_config
        if bool(row.get("enabled", True)) and _is_hdmi_output(row.get("output"))
    ]
    saved_jivelite_slot = _jivelite_player_slot_setting()
    jivelite_control = ""
    if mode == "clone":
        jivelite_note = "JiveLite is not used in MS-3 Clone mode; HDMI display mapping is left unchanged."
    elif not jivelite_present:
        jivelite_note = "JiveLite was not detected. Install and configure it in pCP if this unit needs a local HDMI display."
    elif not hdmi_preview_rows:
        jivelite_note = "JiveLite is installed, but no enabled HDMI player is selected. JiveLite mapping is left unchanged."
    elif len(hdmi_preview_rows) == 1:
        row = hdmi_preview_rows[0]
        jivelite_note = "JiveLite is installed. Auto maps it to the enabled HDMI player: {}.".format(
            _safe_str(row.get("name") or "Player {}".format(row.get("slot")))
        )
        selected_auto = " selected" if saved_jivelite_slot == "auto" else ""
        selected_none = " selected" if saved_jivelite_slot == "none" else ""
        selected_slot = " selected" if saved_jivelite_slot == str(row.get("slot")) else ""
        jivelite_control = (
            '<label style="display:inline-block;margin-top:8px;">JiveLite Display Player '
            '<select id="jivelitePlayerSlot" class="player-jivelite">'
            '<option value="auto"{}>Auto - HDMI player</option>'
            '<option value="none"{}>Leave unchanged</option>'
            '<option value="{}"{}>Slot {} - {}</option>'
            '</select></label>'
        ).format(
            selected_auto,
            selected_none,
            _html_escape(row.get("slot")),
            selected_slot,
            _html_escape(row.get("slot")),
            _html_escape(row.get("name") or "Player {}".format(row.get("slot"))),
        )
    else:
        jivelite_note = "JiveLite is installed. Select which HDMI player should drive the local display."
        options = [
            '<option value="auto"{}>Auto - first HDMI player</option>'.format(
                " selected" if saved_jivelite_slot == "auto" else ""
            ),
            '<option value="none"{}>Leave unchanged</option>'.format(
                " selected" if saved_jivelite_slot == "none" else ""
            ),
        ]
        for row in hdmi_preview_rows:
            slot_value = str(row.get("slot"))
            selected = " selected" if saved_jivelite_slot == slot_value else ""
            options.append('<option value="{}"{}>Slot {} - {} ({})</option>'.format(
                _html_escape(slot_value),
                selected,
                _html_escape(slot_value),
                _html_escape(row.get("name") or "Player {}".format(slot_value)),
                _html_escape(row.get("output")),
            ))
        jivelite_control = (
            '<label style="display:inline-block;margin-top:8px;">JiveLite Display Player '
            '<select id="jivelitePlayerSlot" class="player-jivelite">{}</select></label>'
        ).format("".join(options))

    saved_player_mode = _safe_str(_setup_cache.get("local_player_mode")).lower()
    active_preview_config = [row for row in preview_config if bool(row.get("enabled", True))]
    active_saved_player_rows = [
        row for row in saved_player_rows
        if isinstance(row, dict) and bool(row.get("enabled", True))
    ]
    stored_rows_match = (
        not active_saved_player_rows
        or (
            len(active_saved_player_rows) == len(active_preview_config)
            and all(
                bool(saved.get("enabled", True)) == bool(desired.get("enabled", True))
                and _safe_str(saved.get("name")) == desired["name"]
                and _safe_str(saved.get("output")) == desired["output"]
                and _audio_params_signature(saved.get("audio_params")) == _audio_params_signature(desired.get("audio_params"))
                and _squeezelite_option_signature(saved) == _squeezelite_option_signature(desired)
                for saved, desired in zip(active_saved_player_rows, active_preview_config)
            )
        )
    )
    configuration_matches = (
        saved_player_mode in ("", mode)
        and stored_rows_match
        and len(sessions) == len(active_preview_config)
        and all(
            _player_session_matches_desired(current, desired)
            for current, desired in zip(sessions, active_preview_config)
        )
    )

    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Local Players</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    __SETUP_STYLE__
    .players-table { table-layout: fixed; width: 100%; }
    .players-table th, .players-table td { padding-left: 10px; padding-right: 10px; }
    .players-table th:nth-child(1), .players-table td:nth-child(1) { width: 42px; }
    .players-table th:nth-child(2), .players-table td:nth-child(2) { width: 78px; text-align: center; }
    .players-table th:nth-child(3), .players-table td:nth-child(3) { width: 210px; }
    .players-table th:nth-child(4), .players-table td:nth-child(4) { width: 150px; }
    .players-table th:nth-child(5), .players-table td:nth-child(5) { width: auto; }
    .players-table th:nth-child(6), .players-table td:nth-child(6) { width: 140px; }
    .players-table th:nth-child(7), .players-table td:nth-child(7) { width: 150px; }
    .players-table input[type="text"], .players-table select { width: 100%; min-width: 0; box-sizing: border-box; }
    .players-table code { white-space: nowrap; }
    @media (max-width: 1280px) {
      .players-table th:nth-child(3), .players-table td:nth-child(3) { width: 180px; }
      .players-table th:nth-child(4), .players-table td:nth-child(4) { width: 136px; }
      .players-table th:nth-child(6), .players-table td:nth-child(6) { width: 124px; }
      .players-table th:nth-child(7), .players-table td:nth-child(7) { width: 132px; }
    }
  </style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
    <h2>Local Players</h2>
    <div class="page-nav"><b>Local Players</b><a href="/setup">Setup</a>__WEB_NAV__<a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>

    <form method="get" action="/setup/players" style="margin-bottom:18px;" id="provisioningForm">
      <h3>Provisioning Preview</h3>
      <label>Mode
        <select name="mode" onchange="this.form.submit()">
          <option value="clone"__CLONE_SELECTED____CLONE_DISABLED__>MS-3 Clone__CLONE_AVAILABILITY__</option>
          <option value="open"__OPEN_SELECTED__>Open</option>
        </select>
      </label>
      <label style="margin-left:14px;">Players
        <select name="count" onchange="this.form.submit()">
          __COUNT_OPTIONS__
        </select>
      </label>
      <table class="players-table" style="margin-top:16px;">
        <thead><tr><th>Slot</th><th>Enabled</th><th>Player Name</th><th>Stable MAC</th><th>Playback Device</th><th>ALSA Parameters</th>__PLAYER_OTHER_OPTIONS_HEADER__</tr></thead>
        <tbody>__PREVIEW_ROWS__</tbody>
      </table>
      <div style="margin-top:12px;color:#596579;">
        Applying restarts local Squeezelite players and briefly interrupts playback.
        Friendly names may contain spaces. The broker automatically creates a safe underscore startup name
        for pCP, then applies the friendly name in LMS and RTI.
        This unit supports up to __LOCAL_PLAYER_LIMIT__ local players. __STARTUP_PROFILE__
        __OUTPUT_MODE_NOTE__
      </div>
      __CLONE_WARNING__
      <div class="save-dock">
        <span id="playerStatus">__AUTH_STATUS__</span>
        <button id="applyPlayers" type="button"__APPLY_DISABLED__>Apply Local Players</button>
      </div>
    </form>

    <div class="quick-links">
      <h3>Current pCP Sessions</h3>
      <table>
        <thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>LMS</th><th>Fixed Volume</th><th>Identify</th></tr></thead>
        <tbody>__CURRENT_ROWS__</tbody>
      </table>
      <div style="margin-top:10px;">
        <button class="player-action" type="button" data-action="restart">Restart Players</button>
        <button class="player-action" type="button" data-action="start">Start Players</button>
        <button class="player-action" type="button" data-action="stop">Stop Players</button>
        <button class="player-action" type="button" data-action="normalize">Normalize Output Levels</button>
        <button id="applyFixedVolume" type="button">Apply Volume Settings</button>
        <span id="volumeStatus" style="margin-left:10px;color:#596579;">Fixed outputs play at 100% and ignore RTI/LMS volume changes.</span>
      </div>
      <div style="font-size:12px;color:#596579;margin-top:8px;">__JIVELITE_NOTE__</div>
      <div style="font-size:12px;color:#596579;">__JIVELITE_CONTROL__</div>
      <h3>Detected ALSA Devices</h3>
      <table>
        <thead><tr><th>Card</th><th>ID</th><th>Name</th><th>Physical Path</th><th>Detail</th></tr></thead>
        <tbody>__CARD_ROWS__</tbody>
      </table>
    </div>
  </main>
  <script>
  (function () {
    var button = document.getElementById("applyPlayers");
    var status = document.getElementById("playerStatus");
    var playerEditors = Array.from(document.querySelectorAll(".player-enabled, .player-name, .player-output, .player-audio-params, .player-extra-options, .player-jivelite"));
    playerEditors.forEach(function (editor) {
      editor.addEventListener("input", function () {
        button.disabled = false;
        status.textContent = "Changes are ready to apply.";
        status.style.color = "#9a3412";
        status.style.fontWeight = "bold";
      });
      editor.addEventListener("change", function () {
        button.disabled = false;
        status.textContent = "Changes are ready to apply.";
        status.style.color = "#9a3412";
        status.style.fontWeight = "bold";
      });
    });
    button.addEventListener("click", async function () {
      if (!window.confirm("Back up pCP configuration and restart local players now?")) return;
      button.disabled = true;
      status.textContent = "Saving configuration and restarting players...";
      var players = Array.from(document.querySelectorAll(".player-row")).map(function (row) {
        return {
          enabled: row.querySelector(".player-enabled").checked,
          name: row.querySelector(".player-name").value,
          output: row.querySelector(".player-output").value,
          audio_params: row.querySelector(".player-audio-params").value,
          extra_options: row.querySelector(".player-extra-options").value
        };
      });
      var jiveliteSelect = document.getElementById("jivelitePlayerSlot");
      try {
        var response = await fetch("/api/setup/players/apply", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({
            mode: "__MODE__",
            players: players,
            jivelite_player_slot: jiveliteSelect ? jiveliteSelect.value : "auto"
          })
        });
        var data = await response.json();
        if (response.status === 401) {
          throw new Error("Open Advanced Setup and enter the password, then return here.");
        }
        if (!data.ok) throw new Error(data.error || "Apply failed");
        status.textContent = data.message || ("Applied " + data.players + " players. Refreshing...");
        window.setTimeout(function () { window.location.reload(); }, 2500);
      } catch (error) {
        status.textContent = error.message;
        button.disabled = false;
      }
    });

    var volumeButton = document.getElementById("applyFixedVolume");
    var volumeStatus = document.getElementById("volumeStatus");
    var volumeBoxes = Array.from(document.querySelectorAll(".fixed-volume"));
    var volumeDirty = false;
    function markVolumeDirty() {
      volumeDirty = true;
      volumeButton.textContent = "Save Volume Changes";
      volumeButton.style.background = "#b45309";
      volumeButton.style.borderColor = "#92400e";
      volumeButton.style.color = "#fff";
      volumeStatus.textContent = "Volume changes have not been saved.";
      volumeStatus.style.color = "#9a3412";
      volumeStatus.style.fontWeight = "bold";
    }
    function clearVolumeDirty() {
      volumeDirty = false;
      volumeButton.textContent = "Apply Volume Settings";
      volumeButton.style.background = "";
      volumeButton.style.borderColor = "";
      volumeButton.style.color = "";
      volumeStatus.style.color = "#18794e";
      volumeStatus.style.fontWeight = "bold";
    }
    volumeBoxes.forEach(function (box) {
      box.addEventListener("change", markVolumeDirty);
    });
    window.addEventListener("beforeunload", function (event) {
      if (!volumeDirty) return;
      event.preventDefault();
      event.returnValue = "";
    });
    Array.from(document.querySelectorAll(".player-action")).forEach(function (actionButton) {
      actionButton.addEventListener("click", async function () {
        var action = actionButton.getAttribute("data-action");
        if (!window.confirm(actionButton.textContent + " now?")) return;
        actionButton.disabled = true;
        volumeStatus.textContent = actionButton.textContent + " requested...";
        volumeStatus.style.color = "#596579";
        try {
          var response = await fetch("/api/setup/players/action", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({action: action})
          });
          var data = await response.json();
          if (!data.ok) throw new Error(data.error || "Player action failed");
          volumeStatus.textContent = data.message || "Player action completed.";
          volumeStatus.style.color = "#18794e";
          window.setTimeout(function () { window.location.reload(); }, 1500);
        } catch (error) {
          volumeStatus.textContent = error.message;
          volumeStatus.style.color = "#b42318";
          actionButton.disabled = false;
        }
      });
    });
    volumeButton.addEventListener("click", async function () {
      volumeButton.disabled = true;
      volumeStatus.textContent = "Applying volume settings...";
      var players = volumeBoxes.map(function (box) {
        return {mac: box.getAttribute("data-mac"), fixed: box.checked};
      });
      try {
        var response = await fetch("/api/setup/players/fixed-volume", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({players: players})
        });
        var data = await response.json();
        if (response.status === 401) {
          throw new Error("Open Advanced Setup and enter the password, then return here.");
        }
        if (!data.ok) throw new Error(data.error || "Volume update failed");
        volumeStatus.textContent = "Volume settings applied.";
        clearVolumeDirty();
      } catch (error) {
        volumeStatus.textContent = error.message;
        volumeStatus.style.color = "#b42318";
        volumeStatus.style.fontWeight = "bold";
      } finally {
        volumeButton.disabled = false;
      }
    });

    Array.from(document.querySelectorAll(".test-output")).forEach(function (testButton) {
      testButton.addEventListener("click", async function () {
        var originalText = testButton.textContent;
        testButton.disabled = true;
        testButton.textContent = "Testing...";
        volumeStatus.textContent = "Testing output " + testButton.getAttribute("data-slot") + "...";
        try {
          var response = await fetch("/api/setup/players/test-output", {
            method: "POST",
            credentials: "same-origin",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
              slot: Number(testButton.getAttribute("data-slot")),
              mac: testButton.getAttribute("data-mac"),
              output: testButton.getAttribute("data-output")
            })
          });
          var data = await response.json();
          if (response.status === 401) {
            throw new Error("Open Advanced Setup and enter the password, then return here.");
          }
          if (!data.ok) throw new Error(data.error || "Output test failed");
          volumeStatus.textContent = "Output test completed; selected player restarted.";
          volumeStatus.style.color = "#18794e";
        } catch (error) {
          volumeStatus.textContent = error.message;
          volumeStatus.style.color = "#b42318";
        } finally {
          testButton.disabled = false;
          testButton.textContent = originalText;
        }
      });
    });
  }());
  </script>
</body>
</html>"""
    count_options = []
    max_count = CLONE_MAX_PLAYERS if mode == "clone" else local_player_limit
    for value in range(1, max_count + 1):
        selected = " selected" if value == requested_count else ""
        count_options.append('<option value="{}"{}>{}</option>'.format(value, selected, value))
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Player setup preview"))
        .replace("__WEB_NAV__", _setup_web_nav_link(False))
        .replace("__CLONE_SELECTED__", " selected" if mode == "clone" else "")
        .replace("__CLONE_DISABLED__", " disabled" if clone_missing else "")
        .replace("__CLONE_AVAILABILITY__", " (Not Available)" if clone_missing else "")
        .replace("__OPEN_SELECTED__", " selected" if mode == "open" else "")
        .replace("__COUNT_OPTIONS__", "".join(count_options))
        .replace("__PREVIEW_ROWS__", "".join(preview_rows))
        .replace("__CURRENT_ROWS__", "".join(current_rows))
        .replace("__CARD_ROWS__", "".join(card_rows))
        .replace("__JIVELITE_NOTE__", _html_escape(jivelite_note))
        .replace("__JIVELITE_CONTROL__", jivelite_control)
        .replace("__MODE__", mode)
        .replace("__LOCAL_PLAYER_LIMIT__", str(local_player_limit))
        .replace("__PLAYER_OTHER_OPTIONS_HEADER__", "<th>Other Options</th>" if show_player_other_options else "")
        .replace(
            "__OUTPUT_MODE_NOTE__",
            _html_escape(
                "DAC8x stereo-pair outputs are available because a DAC8x card was detected; USB, HDMI, and other hats remain selectable too. Connect an active HDMI display or EDID emulator before provisioning HDMI outputs."
                if dac8x_detected
                else "Player choices come from detected ALSA outputs, so USB DACs, HDMI, and audio hats can be mixed as available. Connect an active HDMI display or EDID emulator before provisioning HDMI outputs."
            )
        )
        .replace(
            "__STARTUP_PROFILE__",
            _html_escape("MS-3 Clone keeps the fixed three-player layout; Open mode uses the selected local outputs.")
        )
        .replace(
            "__CLONE_WARNING__",
            '<div style="margin-top:12px;color:#b42318;"><b>Clone Mode cannot be applied:</b> {}</div>'.format(
                _html_escape(", ".join(clone_missing))
            ) if mode == "clone" and clone_missing else ""
        )
        .replace(
            "__APPLY_DISABLED__",
            " disabled" if (mode == "clone" and clone_missing) or configuration_matches else ""
        )
        .replace(
            "__AUTH_STATUS__",
            (
                "Configuration matches current players."
                if configuration_matches
                else "Changes are ready to apply."
            )
        )
    )
    return web.Response(text=html, content_type="text/html")


async def api_setup_players_apply(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        mode = _safe_str(body.get("mode")).lower()
        if mode not in ("clone", "open"):
            raise ValueError("Invalid player mode")
        requested = body.get("players")
        if not isinstance(requested, list):
            raise ValueError("Players are required")
        maximum = CLONE_MAX_PLAYERS if mode == "clone" else _local_player_limit()
        if len(requested) < 1 or len(requested) > maximum:
            raise ValueError("{} Mode supports 1-{} players".format(mode.title(), maximum))

        allowed_outputs = {row["output"] for row in _available_alsa_outputs()}
        if mode == "clone":
            clone_outputs, missing = _clone_outputs()
            if missing:
                raise ValueError("Clone hardware is missing: {}".format(", ".join(missing)))
            selected_outputs = clone_outputs[:len(requested)]
        else:
            selected_outputs = [
                _validate_player_text(row.get("output"), "Player {} output".format(index + 1))
                for index, row in enumerate(requested)
            ]
        if any(output not in allowed_outputs for output in selected_outputs):
            raise ValueError("A selected playback device is no longer available")
        if len(set(selected_outputs)) != len(selected_outputs):
            raise ValueError("Each player must use a different playback device")

        server = _player_lms_server_host()
        jivelite_player_slot = _jivelite_player_slot_setting(body.get("jivelite_player_slot"))
        rows = []
        for index, item in enumerate(requested):
            enabled = True if index == 0 else bool(item.get("enabled", True))
            audio_params = _audio_params_or_default(item.get("audio_params"), selected_outputs[index])
            if not audio_params or len(audio_params) > 32 or not re.fullmatch(r"[0-9:]+", audio_params):
                raise ValueError(
                    "Player {} ALSA parameters may contain only numbers and colons".format(index + 1)
                )
            player_name = _validate_player_text(
                item.get("name"), "Player {} name".format(index + 1)
            )
            extra_options = ""
            if mode == "open":
                extra_options = _safe_str(item.get("extra_options")).strip()
                try:
                    _extra_squeezelite_args(extra_options)
                except ValueError as error:
                    raise ValueError("Player {} {}".format(index + 1, _safe_str(error)))
            rows.append({
                "slot": index + 1,
                "enabled": enabled,
                "name": player_name,
                "startup_name": _player_startup_name(player_name, index + 1),
                "output": selected_outputs[index],
                "audio_params": audio_params,
                "upsample_params": _clone_upsample_params(index + 1) if mode == "clone" else "",
                "extra_options": extra_options,
                "mac": _managed_player_mac(index + 1),
                "server": server,
            })
        result = await asyncio.to_thread(_apply_local_players, mode, rows, jivelite_player_slot)
        enabled_rows = [row for row in rows if bool(row.get("enabled", True))]
        warnings: List[str] = []
        try:
            await _apply_friendly_player_names(enabled_rows)
        except Exception as warning:
            warnings.append(
                "Local players were applied, but LMS friendly-name sync is pending: {}".format(
                    _safe_str(warning)
                )
            )
        _setup_cache["local_player_friendly_names"] = {
            row["mac"]: row["name"] for row in rows
        }
        _save_setup_config()
        try:
            await cometd_scan_and_subscribe_connected()
        except Exception as warning:
            warnings.append(
                "Local players were applied, but LMS refresh is pending: {}".format(
                    _safe_str(warning)
                )
            )
        message = "Applied {} local player{}.".format(
            result.get("players", len(enabled_rows)),
            "" if _safe_int(result.get("players"), len(enabled_rows)) == 1 else "s",
        )
        if warnings:
            message += " " + " ".join(warnings)
        return web.json_response({"ok": True, **result, "warnings": warnings, "message": message})
    except Exception as error:
        dbg("Local player apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_players_fixed_volume(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        requested = body.get("players")
        if not isinstance(requested, list):
            raise ValueError("Players are required")
        allowed = {
            _safe_str(row.get("mac")).strip().lower()
            for row in _pcp_player_sessions()
            if _safe_str(row.get("mac")).strip()
        }
        changed = 0
        for item in requested:
            if not isinstance(item, dict):
                raise ValueError("Invalid player volume setting")
            playerid = _safe_str(item.get("mac")).strip().lower()
            if playerid not in allowed:
                raise ValueError("Unknown local player: {}".format(playerid))
            fixed = bool(item.get("fixed"))
            await lms.rpc(
                playerid,
                ["playerpref", "digitalVolumeControl", "0" if fixed else "1"],
            )
            if await _player_fixed_volume(playerid) != fixed:
                raise RuntimeError("LMS did not retain the volume setting for {}".format(playerid))
            changed += 1
        return web.json_response({"ok": True, "players": changed})
    except Exception as error:
        dbg("Fixed volume apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_players_action(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        action = _safe_str(body.get("action")).strip().lower()
        if action == "restart":
            await asyncio.to_thread(_restart_all_local_players)
            return web.json_response({"ok": True, "message": "Local players restarted."})
        if action == "start":
            result = await asyncio.to_thread(_start_all_local_players)
            return web.json_response({"ok": True, "message": "Started {} local players.".format(result["players"])})
        if action == "stop":
            result = await asyncio.to_thread(_stop_all_local_players)
            return web.json_response({"ok": True, "message": "Stopped {} local players.".format(result["players"])})
        if action == "normalize":
            outputs = [
                _safe_str(row.get("output"))
                for row in _pcp_player_sessions()
                if _safe_str(row.get("output")).strip()
            ]
            result = await asyncio.to_thread(_normalize_mixer_levels_for_outputs, outputs)
            message = "Normalized mixer levels on {} controls.".format(len(result.get("changed", [])))
            warnings = result.get("warnings") if isinstance(result.get("warnings"), list) else []
            if warnings:
                message += " Warnings: {}".format("; ".join(_safe_str(item) for item in warnings[:3]))
            return web.json_response({"ok": True, "message": message})
        raise ValueError("Unknown player action")
    except Exception as error:
        dbg("Local player action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _apply_system_hostname(hostname: str) -> None:
    if not os.path.isfile(PCP_CONFIG_PATH):
        raise RuntimeError("pCP configuration was not found")
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()

    try:
        query = urllib.parse.urlencode({"HOST": hostname, "SUBMIT": "Save"})
        with urllib.request.urlopen("http://127.0.0.1/cgi-bin/writetohost.cgi?" + query, timeout=20) as response:
            response.read()
        saved_host = _safe_str(_read_pcp_config().get("HOST")).strip()
        if saved_host.lower() != hostname.lower():
            raise RuntimeError("pCP hostname CGI did not update HOST")
    except Exception:
        updated = _replace_pcp_config_values(original, {"HOST": hostname})
        temp_path = PCP_CONFIG_PATH + ".hostname-new"
        with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, PCP_CONFIG_PATH)
        saved_host = _safe_str(_read_pcp_config().get("HOST")).strip()
        if saved_host.lower() != hostname.lower():
            with open(PCP_CONFIG_PATH, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(original)
            raise RuntimeError("Hostname save failed")
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("Hostname changed, but pCP backup failed: {}".format((backup.stdout or "")[-300:]))
    _mark_hostname_reboot_pending(hostname)


def _set_pcp_lms_autostart(enabled: bool) -> str:
    if not os.path.isfile(PCP_CONFIG_PATH):
        return "pCP configuration was not found; LMS autostart was not changed"
    config = _read_pcp_config()
    bool_value = "yes" if enabled else "no"
    updates: Dict[str, str] = {}
    for key in (
        "LMSERVER",
        "LMS_SERVER",
        "LOCAL_LMS",
        "SLIMSERVER",
        "SQUEEZEBOXSERVER",
    ):
        if key in config:
            updates[key] = bool_value
    if not updates:
        return "No pCP LMS autostart key was found; runtime LMS action only"
    with open(PCP_CONFIG_PATH, "r", encoding="utf-8", errors="replace") as handle:
        original = handle.read()
    updated = _replace_pcp_config_values(original, updates)
    if updated == original:
        return "pCP LMS autostart already {}".format("enabled" if enabled else "disabled")
    temp_path = PCP_CONFIG_PATH + ".lms-role-new"
    with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp_path, PCP_CONFIG_PATH)
    backup = subprocess.run(
        ["/usr/bin/filetool.sh", "-b"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=60,
        check=False,
    )
    if backup.returncode != 0:
        raise RuntimeError("pCP LMS autostart changed, but backup failed: {}".format((backup.stdout or "")[-300:]))
    return "pCP LMS autostart {}".format("enabled" if enabled else "disabled")


def _pcp_set_player_server_mode(full_mode: bool) -> str:
    mode_code = "30" if full_mode else "10"
    mode_name = "Player/Server" if full_mode else "Player"
    url = "http://127.0.0.1/cgi-bin/debug.cgi?m={}".format(mode_code)
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            body = response.read(2048)
            if response.status >= 400:
                raise RuntimeError("pCP mode switch returned HTTP {}".format(response.status))
    except Exception as error:
        raise RuntimeError("pCP {} mode switch failed: {}".format(mode_name, _safe_str(error)))
    return "pCP mode set to {}".format(mode_name)


async def api_setup_system_identity(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        current_host = _safe_str(_read_pcp_config().get("HOST") or socket.gethostname()).strip()
        live_host = _safe_str(socket.gethostname()).strip().split(".", 1)[0]
        has_hostname = "hostname" in body
        has_library_name = "library_name" in body or "libraryName" in body
        hostname = _safe_str(body.get("hostname") if has_hostname else current_host).strip()
        library_name = _safe_str(body.get("library_name", body.get("libraryName", ""))).strip()
        if has_hostname and (
            not hostname
            or len(hostname) > 26
            or not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", hostname)
        ):
            raise ValueError("Hostname must use 1-26 letters, numbers, or hyphens and cannot end with a hyphen")
        if has_library_name and (
            len(library_name) > 80 or any(char in library_name for char in ("\r", "\n"))
        ):
            raise ValueError("LMS library name contains unsupported characters")

        hostname_changed = has_hostname and hostname.lower() != current_host.lower()
        if hostname_changed:
            await asyncio.to_thread(_apply_system_hostname, hostname)
        effective_library_name = library_name or hostname
        library_name_saved = False
        if has_library_name and not _broker_light_mode():
            await lms.rpc("", ["pref", "libraryname", effective_library_name])
            verify = await lms.rpc("", ["pref", "libraryname", "?"])
            retained = _safe_str((verify.get("result") or {}).get("_p2")).strip()
            if retained != effective_library_name:
                raise RuntimeError("LMS did not retain the library name")
            library_name_saved = True
        return web.json_response({
            "ok": True,
            "hostname": hostname,
            "library_name": "" if _broker_light_mode() else (effective_library_name if has_library_name else ""),
            "library_name_saved": library_name_saved,
            "hostname_changed": hostname_changed,
            "reboot_required": has_hostname and (hostname_changed or live_host.lower() != hostname.lower()),
        })
    except Exception as error:
        dbg("System identity apply failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _test_player_output(row: Dict[str, Any]) -> str:
    playerid = _safe_str(row.get("mac")).strip().lower()
    output = _safe_str(row.get("output")).strip()
    slot = _safe_int(row.get("slot"), 0)
    speaker_test = shutil.which("speaker-test")
    if not speaker_test:
        raise RuntimeError("speaker-test is not installed on this pCP system")

    _stop_managed_squeezelite({playerid})
    test_error = ""
    test_output = ""
    try:
        result = subprocess.run(
            [speaker_test, "-D", output, "-c", "2", "-t", "sine", "-f", "880", "-l", "1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=12,
            check=False,
        )
        test_output = result.stdout or ""
        if result.returncode != 0:
            test_error = "Audio test failed: {}".format(test_output[-500:])
    except subprocess.TimeoutExpired:
        test_error = "Audio test timed out"
    finally:
        if slot == 1:
            _restart_pcp_main()
        else:
            _launch_extra_sessions([{}, row])
        if not _wait_for_squeezelite_macs({playerid}, 1, timeout=12):
            raise RuntimeError("Audio test finished, but the selected player did not restart")
    if test_error:
        raise RuntimeError(test_error)
    return test_output[-500:]


async def api_setup_players_test_output(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        slot = _safe_int(body.get("slot"), 0)
        playerid = _safe_str(body.get("mac")).strip().lower()
        output = _safe_str(body.get("output")).strip()
        row = next((
            item for item in _pcp_player_sessions()
            if _safe_int(item.get("slot"), 0) == slot
            and _safe_str(item.get("mac")).strip().lower() == playerid
            and _safe_str(item.get("output")).strip() == output
        ), None)
        if not isinstance(row, dict):
            raise ValueError("The selected active player/output no longer matches pCP configuration")
        detail = await asyncio.to_thread(_test_player_output, row)
        return web.json_response({"ok": True, "slot": slot, "detail": detail})
    except Exception as error:
        dbg("Player output test failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_setup_mode(req: web.Request) -> web.Response:
    try:
        _load_setup_config()
        ctype = _safe_str(req.headers.get("content-type")).lower()
        if "application/json" in ctype:
            body = await req.json()
        else:
            body = await req.post()
        requested_mode = _safe_str(body.get("broker_mode")).strip().lower()
        if requested_mode not in ("full", "light"):
            raise ValueError("Broker role must be Full or Light")
        previous_mode = _broker_mode()
        lms_base = _normalize_lms_base_input(body.get("lms_base"), allow_blank=(requested_mode == "full"))
        if requested_mode == "light" and not lms_base:
            raise ValueError("Broker Light requires an LMS Target for the main controller LMS")
        previous_lms_base = _safe_str(_setup_cache.get("lms_base")).strip() or LOCAL_LMS_BASE
        next_lms_base = "" if requested_mode == "full" and lms_base == LOCAL_LMS_BASE else lms_base
        effective_next_lms_base = next_lms_base or LOCAL_LMS_BASE
        lms_target_changed = previous_lms_base.rstrip("/").lower() != effective_next_lms_base.rstrip("/").lower()
        _setup_cache["broker_mode"] = requested_mode
        _setup_cache["lms_base"] = next_lms_base
        _save_setup_config()
        _load_setup_config()
        await _apply_lms_base(_safe_str(_setup_cache.get("lms_base")).strip() or LOCAL_LMS_BASE)

        service_message = ""
        if previous_mode != requested_mode:
            if requested_mode == "light":
                try:
                    pcp_mode_message = await asyncio.to_thread(_pcp_set_player_server_mode, False)
                    persist_message = await asyncio.to_thread(_set_pcp_lms_autostart, False)
                    runtime_message = await asyncio.to_thread(_stop_local_lms)
                    service_message = "{}. {}. {}".format(pcp_mode_message, persist_message, runtime_message)
                except Exception as error:
                    service_message = "Broker Light saved, but local LMS stop failed: {}".format(_safe_str(error))
            else:
                try:
                    pcp_mode_message = await asyncio.to_thread(_pcp_set_player_server_mode, True)
                    persist_message = await asyncio.to_thread(_set_pcp_lms_autostart, True)
                    runtime_message = await asyncio.to_thread(_start_local_lms)
                    service_message = "{}. {}. {}".format(pcp_mode_message, persist_message, runtime_message)
                except Exception as error:
                    service_message = "Full Broker saved, but local LMS start failed: {}".format(_safe_str(error))
        message = "Broker role saved as {}.".format("Broker Light" if requested_mode == "light" else "Full Broker")
        if service_message:
            message += " " + service_message
        if lms_target_changed:
            message += " LMS Target changed: re-apply Local Players so they register with the selected LMS, then re-run RTI discovery/config."
        if "application/json" not in ctype:
            raise web.HTTPFound("/setup")
        return web.json_response({"ok": True, "mode": requested_mode, "lms_base": LMS_BASE, "message": message})
    except web.HTTPFound:
        raise
    except Exception as error:
        dbg("Broker role save failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _local_ipv4_addresses() -> List[str]:
    out: List[str] = []
    try:
        result = subprocess.run(
            ["hostname", "-I"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3,
            check=False,
        )
        for token in (result.stdout or "").split():
            if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", token):
                out.append(token)
    except Exception:
        pass
    return out


def _neighbor_ipv4_addresses() -> List[str]:
    out: List[str] = []
    try:
        with open("/proc/net/arp", "r", encoding="utf-8", errors="replace") as handle:
            for line in handle.read().splitlines()[1:]:
                fields = line.split()
                if fields and re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", fields[0]):
                    out.append(fields[0])
    except Exception:
        pass
    return out


def _local_subnet_broadcasts() -> List[str]:
    out: List[str] = ["255.255.255.255"]
    for address in _local_ipv4_addresses():
        parts = address.split(".")
        if len(parts) == 4 and not address.startswith("127."):
            out.append("{}.255".format(".".join(parts[:3])))
    return list(OrderedDict((item, True) for item in out).keys())


def _discover_full_broker_hosts(timeout_sec: float = 1.25) -> List[str]:
    """Find Full Broker units via the same UDP path the Finder uses."""
    found: OrderedDict[str, bool] = OrderedDict()
    sock: Optional[socket.socket] = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.2)
        for target in _local_subnet_broadcasts():
            try:
                sock.sendto(COMMISSION_DISCOVERY_MAGIC, (target, DISCOVERY_UDP_PORT))
            except Exception:
                pass

        deadline = time.time() + max(0.2, timeout_sec)
        while time.time() < deadline:
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except Exception:
                break
            try:
                row = json.loads(data.decode("utf-8", errors="replace"))
            except Exception:
                continue
            if not isinstance(row, dict):
                continue
            mode = _safe_str(row.get("mode")).strip().lower()
            if mode == "light":
                continue
            host = _safe_str(row.get("ip")).strip() or _safe_str(addr[0]).strip()
            if host and not host.startswith("127."):
                found[host] = True
    except Exception:
        pass
    finally:
        try:
            if sock is not None:
                sock.close()
        except Exception:
            pass
    return list(found.keys())


def _host_from_lms_base(value: Any) -> str:
    text = _safe_str(value).strip()
    if not text:
        return ""
    if not re.match(r"^https?://", text, flags=re.I):
        text = "http://" + text
    try:
        return _safe_str(urllib.parse.urlsplit(text).hostname)
    except Exception:
        return ""


def _probe_lms_host(host: str) -> Optional[Dict[str, str]]:
    base = "http://{}:9000".format(host)
    payload = json.dumps({"id": 1, "method": "slim.request", "params": ["", ["serverstatus", 0, 1]]}).encode("utf-8")
    try:
        request = urllib.request.Request(
            base + "/jsonrpc.js",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=1.25) as response:
            data = json.loads(response.read(8192).decode("utf-8", errors="replace"))
        result = data.get("result") if isinstance(data, dict) else {}
        if not isinstance(result, dict) or not result:
            return None
        return {
            "host": host,
            "base": base,
            "name": _safe_str(result.get("servername") or result.get("version") or "LMS"),
            "version": _safe_str(result.get("version")),
            "uuid": _safe_str(result.get("uuid")),
            "mac": _safe_str(result.get("mac")),
            "server_ip": _safe_str(result.get("ip")),
        }
    except Exception:
        return None


async def api_setup_lms_discovery(_req: web.Request) -> web.Response:
    candidates: Set[str] = set()
    for base in (
        _setup_cache.get("lms_base"),
        LMS_BASE,
        os.environ.get("LMS_BASE", ""),
    ):
        host = _host_from_lms_base(base)
        if host:
            candidates.add(host)
    for address in _local_ipv4_addresses():
        parts = address.split(".")
        if len(parts) == 4 and not address.startswith("127."):
            prefix = ".".join(parts[:3])
            candidates.update("{}.{}".format(prefix, index) for index in range(1, 255))
    candidates.update(_discover_full_broker_hosts())
    candidates.update(_neighbor_ipv4_addresses())
    if not _broker_light_mode():
        candidates.update(("127.0.0.1", "localhost"))
    semaphore = asyncio.Semaphore(32)

    async def probe_one(host: str) -> Optional[Dict[str, str]]:
        async with semaphore:
            return await asyncio.to_thread(_probe_lms_host, host)

    found = await asyncio.gather(
        *(probe_one(host) for host in sorted(candidates)),
        return_exceptions=True,
    )
    deduped: OrderedDict[str, Dict[str, str]] = OrderedDict()
    for row in found:
        if not isinstance(row, dict) or not row.get("base"):
            continue
        key = _safe_str(row.get("uuid")).strip().lower()
        if not key:
            key = _safe_str(row.get("mac")).strip().lower()
        if not key:
            key = _safe_str(row.get("server_ip")).strip() or _safe_str(row.get("base")).lower()
        existing = deduped.get(key)
        if existing is None:
            deduped[key] = row
            continue
        existing_loopback = _safe_str(existing.get("host")).lower() in ("127.0.0.1", "localhost")
        row_loopback = _safe_str(row.get("host")).lower() in ("127.0.0.1", "localhost")
        if existing_loopback and not row_loopback:
            deduped[key] = row
    rows = list(deduped.values())
    rows.sort(key=lambda row: (row.get("host") in ("127.0.0.1", "localhost"), row.get("host", "")))
    return web.json_response({"ok": True, "servers": rows[:12]})


def _broker_mode_panel() -> str:
    mode = _broker_mode()
    target = _lms_target_display()
    full_checked = " checked" if mode == "full" else ""
    light_checked = " checked" if mode == "light" else ""
    target_hint = (
        "Full mode may be blank to use local LMS. Light mode should point to the main controller LMS. "
        "After changing LMS Target, re-apply Local Players so they register with that LMS, then re-run RTI discovery/config."
    )
    return """
<section class="quick-links" style="margin-bottom:18px;">
  <h3>Broker Role</h3>
  <form id="brokerModeForm" style="padding:0;border:0;box-shadow:none;margin:0;">
    <label style="display:block;margin:6px 0;"><input type="radio" name="broker_mode" value="full"__FULL_CHECKED__> Full Broker - LMS, RTI, sources, plugins, and local players</label>
    <label style="display:block;margin:6px 0;"><input type="radio" name="broker_mode" value="light"__LIGHT_CHECKED__> Broker Light - remote pCP player setup only</label>
    <label style="display:block;margin-top:12px;">LMS Target
      <input id="modeLmsBase" type="text" name="lms_base" value="__LMS_TARGET__" placeholder="192.168.88.139 or http://host:9000" style="width:420px;max-width:100%;padding:6px;box-sizing:border-box;">
    </label>
    <div style="font-size:12px;color:#666;margin-top:6px;">__TARGET_HINT__</div>
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <button id="saveBrokerMode" type="button">Save Broker Role</button>
      <button id="scanLmsServers" type="button">Find LMS Servers</button>
      <select id="lmsDiscoveryList" style="display:none;min-width:260px;"></select>
      <span id="brokerModeStatus" style="color:#596579;"></span>
    </div>
  </form>
</section>
<div id="updateCallout" class="update-callout" aria-live="polite">
  <b id="updateCalloutTitle">Broker update available.</b>
  <span id="updateCalloutText"></span>
  <div id="updateCalloutHint" class="muted">Recommended before provisioning players or configuring plugins. Open <a href="/setup/advanced">Advanced / Updates</a> to install.</div>
</div>
<script>
(function(){
  var form=document.getElementById("brokerModeForm");
  if(!form)return;
  var status=document.getElementById("brokerModeStatus");
  var target=document.getElementById("modeLmsBase");
  var list=document.getElementById("lmsDiscoveryList");
  document.getElementById("saveBrokerMode").addEventListener("click",async function(){
    var selected=form.querySelector("input[name=broker_mode]:checked");
    if(!selected)return;
    if(!window.confirm("Save broker role as "+selected.value+"? This may start or stop local LMS."))return;
    status.textContent="Saving broker role...";
    try{
      var response=await fetch("/api/setup/mode",{
        method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({broker_mode:selected.value,lms_base:target.value})
      });
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Save failed");
      status.textContent=data.message||"Broker role saved.";
      window.setTimeout(function(){window.location.reload();},1800);
    }catch(error){status.textContent=error.message;status.style.color="#b42318";}
  });
  document.getElementById("scanLmsServers").addEventListener("click",async function(){
    status.textContent="Scanning local network for LMS...";
    list.style.display="none";list.innerHTML="";
    try{
      var response=await fetch("/api/setup/lms-discovery",{cache:"no-store"});
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Scan failed");
      if(!(data.servers||[]).length){status.textContent="No LMS servers found.";return;}
      (data.servers||[]).forEach(function(server){
        var option=document.createElement("option");
        option.value=server.base;
        option.textContent=(server.name||"LMS")+" - "+server.base+(server.version?" ("+server.version+")":"");
        list.appendChild(option);
      });
      list.style.display="";
      target.value=list.value;
      status.textContent="Found "+data.servers.length+" LMS server(s).";
    }catch(error){status.textContent=error.message;status.style.color="#b42318";}
  });
  list.addEventListener("change",function(){target.value=list.value;});
  async function checkUpdateCallout(){
    var box=document.getElementById("updateCallout");
    var title=document.getElementById("updateCalloutTitle");
    var text=document.getElementById("updateCalloutText");
    var hint=document.getElementById("updateCalloutHint");
    if(!box||!title||!text||!hint)return;
    try{
      var response=await fetch("/api/update/peek",{cache:"no-store"});
      var data=await response.json();
      var st=(data&&data.status)||{};
      if(st&&(st.state==="checking"||st.state==="downloading"||st.state==="installing")){
        title.textContent="Broker update in progress.";
        text.textContent=" "+(st.message||"Updating broker...");
        hint.textContent="The broker may restart automatically. Refresh this page if it disconnects.";
        box.style.display="block";
        return;
      }
      if(data&&data.ok&&data.available){
        title.textContent="Broker update available.";
        text.textContent=" Installed "+data.current_version+"; available "+data.version+".";
        hint.innerHTML='Recommended before provisioning players or configuring plugins. Open <a href="/setup/advanced">Advanced / Updates</a> to install.';
        box.style.display="block";
      }
    }catch(_error){}
  }
  checkUpdateCallout();
  window.setInterval(checkUpdateCallout,8000);
}());
</script>""".replace("__FULL_CHECKED__", full_checked).replace(
        "__LIGHT_CHECKED__", light_checked
    ).replace("__LMS_TARGET__", _html_escape(target)).replace(
        "__TARGET_HINT__", _html_escape(target_hint)
    )


def _setup_web_nav_link(active: bool = False) -> str:
    if _broker_light_mode():
        return ""
    return "<b>Web Panel</b>" if active else '<a href="/setup/web">Web Panel</a>'


async def setup_light_page(req: web.Request) -> web.Response:
    status = await _system_status_snapshot()
    temp_text = "{} C".format(status["temperature"]) if status["temperature"] is not None else "Unavailable"
    loadavg = status["loadavg"]
    load_text = "Unavailable" if loadavg.get("one") is None else "{:.2f} / {:.2f} / {:.2f}".format(
        loadavg.get("one") or 0.0,
        loadavg.get("five") or 0.0,
        loadavg.get("fifteen") or 0.0,
    )
    mem_total = max(_safe_int(status["memory"].get("total"), 0), 1)
    mem_avail = _safe_int(status["memory"].get("available"), 0)
    mem_used = max(mem_total - mem_avail, 0)
    memory_text = "{:.0f}% used ({:.0f} MB free)".format(
        (mem_used / mem_total) * 100.0,
        mem_avail / 1048576.0,
    )
    player_rows = "".join(
        "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td><td><code>{output}</code></td>"
        "<td style=\"color:{color};font-weight:bold;\">{state}</td></tr>".format(
            slot=_html_escape(row.get("slot")),
            name=_html_escape(row.get("name")),
            mac=_html_escape(row.get("mac")),
            output=_html_escape(row.get("output")),
            color="#18794e" if row.get("running") else "#b42318",
            state="Running" if row.get("running") else "Stopped",
        )
        for row in status["players"]
    ) or '<tr><td colspan="5">No configured local players found.</td></tr>'
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Lyrion Gadget Light</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell">
<h2>Broker Light</h2>
<div class="page-nav"><a href="/setup/players">Local Players</a><b>Status</b>__WEB_NAV__<a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>
__BROKER_MODE_PANEL__
<section class="quick-links">
<h3>Device Status</h3>
<table><tbody>
<tr><th>Mode</th><td>Broker Light</td><th>Hostname</th><td>__HOSTNAME__</td></tr>
<tr><th>Broker</th><td>v__VERSION__</td><th>Uptime</th><td>__UPTIME__ minutes</td></tr>
<tr><th>CPU Temp</th><td>__TEMPERATURE__</td><th>CPU Load</th><td>__CPU_LOAD__</td></tr>
<tr><th>Memory</th><td>__MEMORY__</td><th>LMS Target</th><td><code>__LMS_BASE__</code></td></tr>
</tbody></table>

<h3>Local Players</h3>
<table><thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>Status</th></tr></thead>
<tbody>__PLAYER_ROWS__</tbody></table>

<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">
<a href="/setup/players"><button type="button">Configure Players</button></a>
<button class="light-action" data-action="restart_players">Restart Players</button>
<button class="light-action" data-action="restart_broker">Restart Broker</button>
<button class="light-action" data-action="reboot">Reboot Device</button>
<a href="/api/system/backup"><button type="button">Save Config Backup</button></a>
<a href="/setup/advanced"><button type="button">Advanced / Updates</button></a>
</div>
<div id="lightStatus" style="margin-top:10px;color:#596579;"></div>
</section>
</main>
<script>
(function(){
  var box=document.getElementById("lightStatus");
  function sleep(ms){return new Promise(function(resolve){window.setTimeout(resolve,ms);});}
  function setLightButtonsDisabled(disabled){
    Array.from(document.querySelectorAll(".light-action")).forEach(function(item){
      item.disabled=!!disabled;
    });
  }
  async function waitForBrokerReady(){
    var sawDown=false;
    var deadline=Date.now()+60000;
    while(Date.now()<deadline){
      try{
        var response=await fetch("/health?service="+Date.now(),{cache:"no-store"});
        if(response.ok&&sawDown) return true;
      }catch(_){
        sawDown=true;
        box.textContent="Waiting for broker to restart...";
        box.style.color="#596579";
      }
      await sleep(1000);
    }
    throw new Error("Timed out waiting for broker restart.");
  }
  async function waitForPlayersReady(){
    var deadline=Date.now()+30000;
    var lastText="";
    while(Date.now()<deadline){
      try{
        var response=await fetch("/api/system/players-status?ts="+Date.now(),{cache:"no-store"});
        var data=await response.json();
        if(data.ok){
          lastText=(data.running||0)+" of "+(data.configured||0)+" configured players running";
          box.textContent="Waiting for local players... "+lastText;
          box.style.color="#596579";
          if(data.ready) return data;
        }
      }catch(_){}
      await sleep(1000);
    }
    throw new Error("Timed out waiting for local players to restart. "+lastText);
  }
  Array.from(document.querySelectorAll(".light-action")).forEach(function(button){
    button.addEventListener("click",async function(){
      var action=button.getAttribute("data-action");
      if(!window.confirm("Run "+button.textContent+" now?"))return;
      setLightButtonsDisabled(true);box.textContent=button.textContent+" requested...";
      try{
        var response=await fetch("/api/system/action",{
          method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({action:action})
        });
        var data=await response.json();if(!data.ok)throw new Error(data.error||"Action failed");
        box.textContent=data.message||"Action requested.";
        if(action==="restart_players"){
          var playerStatus=await waitForPlayersReady();
          box.textContent="Local players ready: "+playerStatus.running+" of "+playerStatus.configured+" running.";
          window.setTimeout(function(){window.location.reload();},800);
        }
        else if(action==="restart_broker"){
          await waitForBrokerReady();
          window.location.reload();
        }
      }catch(error){
        box.textContent=error.message;box.style.color="#b42318";setLightButtonsDisabled(false);
      }
    });
  });
}());
</script></body></html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Broker Light"))
        .replace("__WEB_NAV__", _setup_web_nav_link(False))
        .replace("__BROKER_MODE_PANEL__", _broker_mode_panel())
        .replace("__HOSTNAME__", _html_escape(status["hostname"]))
        .replace("__VERSION__", _html_escape(APP_VERSION))
        .replace("__UPTIME__", str(status["uptime"] // 60))
        .replace("__TEMPERATURE__", _html_escape(temp_text))
        .replace("__CPU_LOAD__", _html_escape(load_text))
        .replace("__MEMORY__", _html_escape(memory_text))
        .replace("__LMS_BASE__", _html_escape(_lms_target_display() or "Not set"))
        .replace("__PLAYER_ROWS__", player_rows)
    )
    return web.Response(text=html, content_type="text/html")


async def setup_page(_req: web.Request) -> web.Response:
    _load_setup_config()
    if _broker_light_mode():
        return await setup_light_page(_req)
    _ensure_license_trial_started()
    effective = LMS_BASE
    saved = _safe_str(_setup_cache.get("lms_base"))
    iheart_region = _iheart_region_setting()
    iheart_skip_checked = " checked" if _iheart_skip_intro_when_filtered() else ""
    license_info = _license_status()
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    legal_checked = " checked" if _legal_terms_accepted() else ""
    if license_info["state"] == "licensed":
        license_summary = "Licensed"
        license_color = "#18794e"
    elif license_info["state"] == "trial":
        seconds = _safe_int(license_info.get("trial_seconds_remaining"), 0)
        license_summary = "Trial active - {:.1f} days remaining".format(seconds / 86400.0)
        license_color = "#8a5a00"
    else:
        license_summary = "Trial expired - enter a license key to enable RTI"
        license_color = "#b42318"
    iheart_region_options = []
    for value, label in (
        ("", "All regions"),
        ("US", "United States (US)"),
        ("NZ", "New Zealand (NZ)"),
        ("AU", "Australia (AU)"),
        ("CA", "Canada (CA)"),
        ("MX", "Mexico (MX)"),
    ):
        selected = " selected" if value == iheart_region else ""
        iheart_region_options.append(
            '<option value="{}"{}>{}</option>'.format(
                _html_escape(value), selected, _html_escape(label)
            )
        )

    pid = await _pick_setup_playerid(_req)
    iheart_installed = False
    iheart_candidates: List[Dict[str, Any]] = []
    try:
        iheart_candidates.extend(await _discover_radio_menu_rows(pid))
    except Exception:
        pass
    try:
        iheart_candidates.extend(_extract_menu_items(await _myapps_raw(pid)))
    except Exception:
        pass
    iheart_row = next((
        row for row in iheart_candidates
        if "iheart" in _norm_key(
            row.get("source_label") or _pick_label(row) or row.get("key") or row.get("id")
        )
    ), None)
    iheart_installed = iheart_row is not None
    iheart_icon_url = ""
    if iheart_installed:
        iheart_icon_url = _normalize_icon_url(
            _pick_art(iheart_row) or "/plugins/iHeartRadio/html/images/iheartradio.png"
        )
    player_inventory_warnings: List[str] = []
    try:
        all_lms_players = await lms.get_players()
        player_inventory_warnings = _player_inventory_warnings(all_lms_players)
        live_players = _rti_connected_players(all_lms_players)
    except Exception:
        live_players = []
        player_inventory_warnings = ["Could not read LMS players for RTI mapping."]
    player_rows = []
    for i, p in enumerate(live_players):
        name = _html_escape(_safe_str(p.get("name")))
        mac = _html_escape(_safe_str(p.get("playerid")))
        connected = "Yes" if _safe_int(p.get("connected"), 0) else "No"
        power = "On" if _safe_int(p.get("power"), 0) else "Off"
        player_rows.append("""
        <tr>
          <td style="padding:6px 8px;border-top:1px solid #eee;">Player {num}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>Player{idx}_Name</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{name}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>Player{idx}_MAC</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;"><code>{mac}</code></td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{connected}</td>
          <td style="padding:6px 8px;border-top:1px solid #eee;">{power}</td>
        </tr>
        """.format(num=i + 1, idx=i, name=name, mac=mac, connected=connected, power=power))
    if not player_rows:
        player_rows.append('<tr><td colspan="7" style="padding:8px;color:#666;">No LMS players found yet.</td></tr>')
    setup_order_warning = ""
    if not live_players:
        setup_order_warning = """
  <div style="margin:10px 0 16px;padding:12px;border:2px solid #f59e0b;background:#fff7ed;color:#9a3412;">
    <b>First step:</b> go to <a href="/setup/players" style="font-weight:bold;color:#9a3412;">Local Players</a>,
    provision and start at least one player, then return here. My Music, Radio, Favorites, and LMS plugin menu previews
    need an active LMS player before they can load.
  </div>"""

    try:
        curated_plugins_live = await _curated_lms_plugins()
    except Exception as error:
        dbg("Curated LMS plugin load skipped: {}".format(_safe_str(error)))
        curated_plugins_live = []

    home_rows_live = await _merge_home_menu_with_live_apps(pid)
    home_rows_live = await _merge_setup_home_menu_with_active_curated_plugins(home_rows_live)
    radio_home_enabled = any(
        _safe_str(row.get("key")).strip().lower() == "radio"
        and bool(row.get("enabled", True))
        for row in home_rows_live
    )
    mymusic_home_enabled = any(
        _safe_str(row.get("key")).strip().lower() == "mymusic"
        and bool(row.get("enabled", True))
        for row in home_rows_live
    )
    rows = []
    for row in home_rows_live:
        key = _html_escape(_safe_str(row.get("key")))
        label = _html_escape(_safe_str(row.get("label")))
        enabled = "checked" if row.get("enabled") else ""
        order = _safe_int(row.get("order"), 100)
        kind = _html_escape(_safe_str(row.get("type") or "core"))
        src = _html_escape(_safe_str(row.get("source_label") or row.get("label") or row.get("key") or ""))
        fallback_icon = _core_home_icon_path(row.get("key"))
        icon_raw = _safe_str(row.get("icon") or "").strip()
        icon = _normalize_icon_url(icon_raw) if icon_raw else fallback_icon
        display_icon = fallback_icon if fallback_icon else icon
        icon_html = (
            '<img src="%s" style="width:22px;height:22px;object-fit:contain;" onerror="this.onerror=null;this.src=\'%s\';">'
            % (_html_escape(display_icon), _html_escape(fallback_icon))
        ) if icon else ''
        rows.append("""
        <tr data-key="{key}" data-type="{kind}" data-source="{src}" data-icon="{icon}">
          <td style="padding:6px 8px;"><input class="hm-enabled" type="checkbox" {enabled}></td>
          <td style="padding:6px 8px;">{icon_html}</td>
          <td style="padding:6px 8px;"><code>{key}</code></td>
          <td style="padding:6px 8px;">{kind}</td>
          <td style="padding:6px 8px;">{src}</td>
          <td style="padding:6px 8px;"><input class="hm-label" type="text" value="{label}" style="width:220px;"></td>
          <td style="padding:6px 8px;"><input class="hm-order" type="number" value="{order}" style="width:80px;"></td>
        </tr>
        """.format(key=key, kind=kind, src=src, icon=_html_escape(icon), icon_html=icon_html, enabled=enabled, label=label, order=order))

    shairtunes_row = next((
        row for row in curated_plugins_live
        if _safe_str(row.get("id")).strip() == "ShairTunes2W"
    ), None)
    shairtunes_section = ""
    if shairtunes_row:
        shair_state = _safe_str(shairtunes_row.get("state")).lower() or "unknown"
        shair_color = "#18794e" if shair_state == "active" else ("#b42318" if shair_state == "inactive" else "#7a8694")
        shair_action = ""
        if shair_state == "active":
            shair_action = '<button class="plugin-action" type="button" data-plugin="ShairTunes2W" data-enable="0">Disable</button>'
        elif shair_state in ("inactive", "available"):
            shair_action = '<button class="plugin-action" type="button" data-plugin="ShairTunes2W" data-enable="1">{}</button>'.format(
                "Install" if shair_state == "available" else "Enable"
            )
        settings_url = _safe_str(shairtunes_row.get("settings_url")).strip()
        settings_link = (
            '<a class="plugin-settings-link" href="{}" target="_blank" rel="{}" data-needs-lms="1"><button type="button" class="plugin-settings-button">Open Settings</button></a>'.format(
                _html_escape(settings_url),
                "opener" if settings_url.startswith("/setup/") else "noopener",
            )
            if settings_url else '<span style="color:#7a8694;">No settings link</span>'
        )
        shairtunes_section = """
<div class="service-card">
  <div class="service-card-heading">
    <img src="{icon}" alt="AirPlay">
    <h3>AirPlay / ShairTunes</h3>
  </div>
  <div><b>Status:</b> <span style="color:{color};font-weight:bold;">{state}</span></div>
  <div style="display:flex;gap:8px;align-items:center;margin-top:10px;">{action}{settings}</div>
  <div style="font-size:12px;color:#555;margin-top:8px;">ShairTunes makes AirPlay endpoints work. It is not shown as an RTI Home Menu source tile.</div>
</div>
""".format(
            icon=_html_escape(_broker_panel_asset_url("icon-home-radio.svg", APP_VERSION)),
            color=_html_escape(shair_color),
            state=_html_escape(shair_state.title()),
            action=shair_action,
            settings=settings_link,
        )

    plugin_rows = _curated_lms_plugin_rows(curated_plugins_live)
    warn = "".join(
        '<div style="margin:10px 0;padding:10px;border:1px solid #f59e0b;background:#fff7ed;color:#9a3412;">{}</div>'.format(
            _html_escape(message)
        )
        for message in player_inventory_warnings
    )

    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Broker Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
  <h2>Lyrion Broker Setup</h2>
  <div class="page-nav"><a href="/setup/players">Local Players</a><b>Setup</b>__WEB_NAV__<a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>
  __BROKER_MODE_PANEL__
  __WARN__
  __SETUP_ORDER_WARNING__

  <h3>Lyrion Server</h3>
  <form method="post" action="/api/setup" style="margin-bottom:18px;" id="setupForm">
    <h3>License</h3>
    <div><b>Device MAC:</b> <code>__LICENSE_MAC__</code></div>
    <div style="margin-top:6px;color:__LICENSE_COLOR__;"><b>__LICENSE_SUMMARY__</b></div>
    <label style="display:block;margin-top:10px;">License key:</label>
    <textarea name="license_key" rows="3" placeholder="LYR1..." style="width:100%;max-width:900px;padding:6px;box-sizing:border-box;">__LICENSE_KEY__</textarea>

    <h3 style="margin-top:22px;">Required Risk Acceptance</h3>
    <div style="border:2px solid #8b1e1e;background:#fff7f7;padding:12px;max-width:900px;">
      <div style="font-weight:bold;">AS-IS SOFTWARE, ASSUMPTION OF RISK, RELEASE, AND INDEMNITY</div>
      <div style="margin-top:8px;font-size:13px;line-height:1.45;max-height:190px;overflow:auto;">
        This software and related components are experimental and provided "AS IS" and "WITH ALL FAULTS,"
        without warranties of any kind, express or implied, including merchantability, fitness for a
        particular purpose, title, non-infringement, availability, accuracy, security, or uninterrupted
        operation. You assume all risks arising from installation, configuration, operation, malfunction,
        data loss, service interruption, equipment damage, network activity, third-party services, and use
        or misuse of the software. To the fullest extent permitted by law, you release and hold harmless
        Skunk Works and every past, present, and future developer, contributor, maintainer, distributor,
        tester, agent, affiliate, and tool or service provider involved with this software from all claims,
        liabilities, losses, damages, costs, and expenses, whether direct, indirect, incidental, special,
        consequential, exemplary, or otherwise. You agree to defend and indemnify those parties against
        third-party claims arising from your installation, configuration, distribution, or use of the
        software. You are solely responsible for backups, security, legal compliance, third-party account
        terms, and determining whether the software is suitable for your system. These terms apply only to
        the fullest extent allowed by applicable law; rights that cannot legally be waived are not waived.
      </div>
      <label style="display:block;margin-top:12px;font-weight:bold;">
        <input type="checkbox" name="legal_accept" value="1"__LEGAL_CHECKED__>
        I have read, understand, and accept these terms (version __LEGAL_VERSION__).
      </label>
      <div style="margin-top:6px;font-size:12px;color:#8b1e1e;">
        RTI WebSocket access remains disabled until these terms are accepted and saved.
      </div>
    </div>

    <input type="hidden" name="lms_base" value="__SAVED__">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Set broker role and LMS target in the Broker Role panel above.
    </div>

    <h3 style="margin-top:22px;">Curated LMS Plugins</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Install, enable, disable, and open settings for integrations tested with Lyrion Gadget. Plugin changes can require an LMS restart.</div>
    <div style="font-size:12px;color:#7a4c00;background:#fff8e6;border:1px solid #efd49b;border-radius:6px;padding:8px 10px;margin-bottom:10px;max-width:900px;">
      Install plugins in small batches, about 1 or 2 at a time. When LMS asks to restart, select Apply/Reboot, wait for the broker to reconnect, then continue with the next batch. Do not open plugin Settings until the broker is back online.
      iHeartRadio installs in Radio by default. BBC Sounds defaults to My Apps; in its Settings, enable "Place in the Radio menu" if you want it under Radio. Pyrrha can also move between Home and Radio. Menu placement changes require an LMS restart before Lyrion Gadget sees the new location.
    </div>
    <table><thead><tr><th>Plugin</th><th>Version</th><th>State</th><th>Action</th><th>Settings</th></tr></thead>
    <tbody>__PLUGIN_ROWS__</tbody></table>
    <div id="pluginActionStatus" style="margin-top:10px;color:#596579;"></div>

    <h3 style="margin-top:18px;">RTI Player Mapping</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Use these exact values in Apex. The RTI driver ignores player status unless the configured MAC matches the LMS playerid.</div>
    <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 820px;">
      <thead>
        <tr style="background:#f7f7f7;">
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">RTI Player</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Name Setting</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Value</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">MAC Setting</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Value</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Connected</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Power</th>
        </tr>
      </thead>
      <tbody>
        __PLAYER_ROWS__
      </tbody>
    </table>

    <h3 style="margin-top:18px;">Home Menu (what RTI will show at top level)</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Enable items and set order (lower comes first). Labels are what RTI displays.</div>
    <table style="border-collapse:collapse;border:1px solid #ddd;">
      <thead>
        <tr style="background:#f7f7f7;">
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Icon</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Type</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Label</th>
          <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Order</th>
        </tr>
      </thead>
      <tbody id="homeRows">
        __HOME_ROWS__
      </tbody>
    </table>
    <input type="hidden" name="home_menu_json" id="homeMenuJson" value="[]">

    <div id="myMusicMenuSection" style="display:__MYMUSIC_MENU_DISPLAY__;">
    <h3 style="margin-top:18px;">My Music Menu</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">Loads the live My Music tree from LMS, then lets you pick what to show, rename it, and sort it. Original drill/play behavior is preserved.</div>
    <div style="margin-bottom:8px;">
      <button type="button" id="btnLoadMyMusic" style="padding:6px 12px;">Load My Music Tree</button>
      <span id="mymusicStatus" style="margin-left:10px;color:#666;"></span>
    </div>
    <div id="mymusicWrap" style="display:none;">
      <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 760px;">
        <thead>
          <tr style="background:#f7f7f7;">
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Custom Name</th>
            <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Sort</th>
          </tr>
        </thead>
        <tbody id="mymusicRows"></tbody>
      </table>
    </div>
    <input type="hidden" name="mymusic_menu_json" id="mymusicMenuJson" value="[]">
    </div>

    <div id="radioMenuSection" style="display:__RADIO_MENU_DISPLAY__;">
      <h3 style="margin-top:18px;">Radio Menu</h3>
      <div style="font-size:12px;color:#666;margin-bottom:8px;">Loads the live Radio tree from LMS. Choose what RTI shows, rename entries, and set their order without changing drill or playback behavior.</div>
      <div style="margin-bottom:8px;">
        <button type="button" id="btnLoadRadio" style="padding:6px 12px;">Load Radio Tree</button>
        <span id="radioStatus" style="margin-left:10px;color:#666;"></span>
      </div>
      <div id="radioWrap" style="display:none;">
        <table style="border-collapse:collapse;border:1px solid #ddd; min-width: 760px;">
          <thead>
            <tr style="background:#f7f7f7;">
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Show</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Icon</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Key</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">LMS Item</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Custom Name</th>
              <th style="padding:6px 8px;border-bottom:1px solid #ddd;">Sort</th>
            </tr>
          </thead>
          <tbody id="radioRows"></tbody>
        </table>
      </div>
    </div>
    <input type="hidden" name="radio_menu_json" id="radioMenuJson" value="[]">

    <h3 style="margin-top:18px;">Service Options</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;align-items:start;">
      __IHEART_REGION_SECTION__
      __SHAIRTUNES_SECTION__
    </div>

    <div class="save-dock" style="z-index:10;">
      <b id="saveStatus" style="margin-right:14px;color:#555;">Changes are not saved automatically.</b>
      <button type="submit" style="font-size:16px;">Save Setup</button>
    </div>
  </form>

  <section class="quick-links">
  <h3>Quick Links</h3>
  <ul>
    <li><a href="/health">/health</a></li>
    <li><a href="/api/setup">/api/setup</a></li>
    <li><a href="/api/players">/api/players</a> (RTI player MAC/name mapping)</li>
    <li><a href="/api/lms_root">/api/lms_root</a> (preview LMS root menu)</li>
    <li><a href="/api/mymusic_menu">/api/mymusic_menu</a> (preview live My Music tree)</li>
    <li><a href="/api/radio_menu">/api/radio_menu</a> (preview live Radio tree)</li>
  </ul>
  </section>
  </main>
<script>
(function(){{
  var savedRadioMenuAtLoad = __RADIO_MENU_SAVED_JSON__;
  function esc(s){{ return String(s == null ? '' : s); }}
  function compactMenuRows(rows){{
    var out = [];
    rows = rows || [];
    for (var i = 0; i < rows.length; i++) {{
      var r = rows[i] || {{}};
      out.push({{
        key: esc(r.key || r.id || ''),
        source_label: esc(r.source_label || r.label || ''),
        alias: esc(r.alias || r.source_label || r.label || ''),
        enabled: !!r.enabled,
        order: parseInt(esc(r.order || 100), 10) || 100,
        icon: esc(r.icon || '')
      }});
    }}
    out.sort(function(a,b){{ return (a.key < b.key ? -1 : (a.key > b.key ? 1 : 0)); }});
    return JSON.stringify(out);
  }}
  function setStatus(msg){{ document.getElementById('mymusicStatus').textContent = msg || ''; }}
  function renderRows(items){{
    var wrap = document.getElementById('mymusicWrap');
    var body = document.getElementById('mymusicRows');
    body.innerHTML = '';
    for (var i = 0; i < items.length; i++) {{
      var it = items[i] || {{}};
      var tr = document.createElement('tr');
      tr.setAttribute('data-key', esc(it.key || ''));
      tr.innerHTML = '' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-enabled" type="checkbox" ' + (it.enabled ? 'checked' : '') + '></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><code>' + esc(it.key || '') + '</code></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;">' + esc(it.source_label || '') + '</td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-alias" type="text" value="' + esc(it.alias || it.source_label || '') + '" style="width:220px;"></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="mm-order" type="number" value="' + esc(it.order || 100) + '" style="width:80px;"></td>';
      body.appendChild(tr);
    }}
    wrap.style.display = items.length ? '' : 'none';
    syncHidden();
  }}
  function collectRows(){{
    var out = [];
    var rows = document.querySelectorAll('#mymusicRows tr');
    for (var i = 0; i < rows.length; i++) {{
      var tr = rows[i];
      out.push({{
        key: tr.getAttribute('data-key') || '',
        source_label: tr.children[2] ? tr.children[2].textContent : '',
        alias: tr.querySelector('.mm-alias') ? tr.querySelector('.mm-alias').value : '',
        enabled: !!(tr.querySelector('.mm-enabled') && tr.querySelector('.mm-enabled').checked),
        order: parseInt((tr.querySelector('.mm-order') && tr.querySelector('.mm-order').value) || '100', 10) || 100
      }});
    }}
    return out;
  }}
  function collectHomeRows(){
    var out = [];
    var rows = document.querySelectorAll('#homeRows tr[data-key]');
    for (var i = 0; i < rows.length; i++) {
      var tr = rows[i];
      out.push({
        key: tr.getAttribute('data-key') || '',
        type: tr.getAttribute('data-type') || 'core',
        source_label: tr.getAttribute('data-source') || '',
        icon: tr.getAttribute('data-icon') || '',
        label: tr.querySelector('.hm-label') ? tr.querySelector('.hm-label').value : '',
        enabled: !!(tr.querySelector('.hm-enabled') && tr.querySelector('.hm-enabled').checked),
        order: parseInt((tr.querySelector('.hm-order') && tr.querySelector('.hm-order').value) || '100', 10) || 100
      });
    }
    return out;
  }
  function setRadioStatus(msg){{ document.getElementById('radioStatus').textContent = msg || ''; }}
  function renderRadioRows(items){{
    var wrap = document.getElementById('radioWrap');
    var body = document.getElementById('radioRows');
    body.innerHTML = '';
    for (var i = 0; i < items.length; i++) {{
      var it = items[i] || {{}};
      var tr = document.createElement('tr');
      tr.setAttribute('data-key', esc(it.key || ''));
      tr.setAttribute('data-icon', esc(it.icon || ''));
      var iconHtml = it.icon ? '<img src="' + esc(it.icon) + '" style="width:22px;height:22px;object-fit:contain;" onerror="this.style.visibility=\\'hidden\\';">' : '';
      tr.innerHTML = '' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-enabled" type="checkbox" ' + (it.enabled ? 'checked' : '') + '></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;">' + iconHtml + '</td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><code>' + esc(it.key || '') + '</code></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;">' + esc(it.source_label || '') + '</td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-alias" type="text" value="' + esc(it.alias || it.source_label || '') + '" style="width:220px;"></td>' +
        '<td style="padding:6px 8px;border-top:1px solid #eee;"><input class="rm-order" type="number" value="' + esc(it.order || 100) + '" style="width:80px;"></td>';
      body.appendChild(tr);
    }}
    wrap.style.display = items.length ? '' : 'none';
    syncHidden();
    if (compactMenuRows(collectRadioRows()) !== compactMenuRows(savedRadioMenuAtLoad)) {{
      markUnsaved();
    }}
  }}
  function collectRadioRows(){{
    var out = [];
    var rows = document.querySelectorAll('#radioRows tr');
    for (var i = 0; i < rows.length; i++) {{
      var tr = rows[i];
      out.push({{
        key: tr.getAttribute('data-key') || '',
        source_label: tr.children[3] ? tr.children[3].textContent : '',
        icon: tr.getAttribute('data-icon') || '',
        alias: tr.querySelector('.rm-alias') ? tr.querySelector('.rm-alias').value : '',
        enabled: !!(tr.querySelector('.rm-enabled') && tr.querySelector('.rm-enabled').checked),
        order: parseInt((tr.querySelector('.rm-order') && tr.querySelector('.rm-order').value) || '100', 10) || 100
      }});
    }}
    return out;
  }}
  function syncHidden(){
    document.getElementById('homeMenuJson').value = JSON.stringify(collectHomeRows());
    document.getElementById('mymusicMenuJson').value = JSON.stringify(collectRows());
    document.getElementById('radioMenuJson').value = JSON.stringify(collectRadioRows());
  }
  function homeEnabled(key){{
    var row = document.querySelector('#homeRows tr[data-key="' + key + '"]');
    var box = row && row.querySelector('.hm-enabled');
    return !!(box && box.checked);
  }}
  function updateSectionVisibility(){{
    var mm = document.getElementById('myMusicMenuSection');
    var radio = document.getElementById('radioMenuSection');
    if (mm) mm.style.display = homeEnabled('mymusic') ? '' : 'none';
    if (radio) radio.style.display = homeEnabled('radio') ? '' : 'none';
  }}
  function markUnsaved(){{
    var status = document.getElementById('saveStatus');
    if (status) {{
      status.textContent = 'Unsaved changes - click Save Setup';
      status.style.color = '#9a3412';
    }}
  }}
  function setPluginSettingsAvailable(available){{
    Array.from(document.querySelectorAll('.plugin-settings-link')).forEach(function(link){{
      var button = link.querySelector('button');
      link.setAttribute('data-disabled', available ? '0' : '1');
      if (button) {{
        button.disabled = !available;
        button.title = available ? '' : 'Wait for broker/LMS reconnect before opening plugin settings.';
      }}
    }});
  }}
  async function postSystemAction(action, extra) {{
    var response = await fetch('/api/system/action', {{
      method: 'POST',
      credentials: 'same-origin',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify(Object.assign({{action: action}}, extra || {{}}))
    }});
    var data = await response.json();
    if (!data.ok) throw new Error(data.error || 'Action failed');
    return data;
  }}
  function sleepMs(ms) {{
    return new Promise(function(resolve){{ window.setTimeout(resolve, ms); }});
  }}
  function isNetworkDrop(error) {{
    var message = String((error && error.message) || error || '').toLowerCase();
    return message.indexOf('network') >= 0 || message.indexOf('failed to fetch') >= 0 || message.indexOf('load failed') >= 0;
  }}
  async function waitForLmsReconnect(box) {{
    var sawDown = false;
    var started = Date.now();
    for (var i = 0; i < 90; i++) {{
      try {{
        var response = await fetch('/health?setup_lms_restart=' + Date.now(), {{cache: 'no-store'}});
        if (response.ok) {{
          var data = await response.json();
          var connected = !!(data.cometd && data.cometd.connected);
          if (!connected) sawDown = true;
          if (connected && (sawDown || Date.now() - started > 10000)) {{
            box.textContent = 'LMS is responding again. Refreshing plugin state...';
            window.dispatchEvent(new CustomEvent('lyrion-force-lms-state', {{detail: {{connected: true, clear: true}}}}));
            window.setTimeout(function(){{ window.location.reload(); }}, 2500);
            return true;
          }}
        }}
      }} catch (error) {{
        sawDown = true;
      }}
      await sleepMs(1000);
    }}
    return false;
  }}
  function showRestartLmsPrompt(message, box) {{
    box.innerHTML = '';
    var text = document.createElement('span');
    text.textContent = message + ' ';
    var restart = document.createElement('button');
    restart.type = 'button';
    restart.textContent = 'Restart LMS Now';
    restart.style.fontWeight = 'bold';
    var later = document.createElement('button');
    later.type = 'button';
    later.textContent = 'Later';
    restart.addEventListener('click', async function(){{
      if (!window.confirm('Restart LMS now to finish plugin changes?')) return;
      restart.disabled = true;
      later.disabled = true;
      window.dispatchEvent(new CustomEvent('lyrion-force-lms-state', {{detail: {{connected: false, untilMs: 45000}}}}));
      box.appendChild(document.createTextNode(' Restarting LMS...'));
      try {{
        var data = await postSystemAction('restart_lms');
        box.textContent = (data.message || 'LMS restart requested.') + ' Waiting for LMS to reconnect...';
        if (!(await waitForLmsReconnect(box))) {{
          box.textContent = 'LMS restart command completed. Refreshing setup...';
          window.setTimeout(function(){{ window.location.reload(); }}, 900);
        }}
      }} catch (error) {{
        if (isNetworkDrop(error)) {{
          box.textContent = 'LMS restart command sent. Waiting for broker/LMS to reconnect...';
          if (!(await waitForLmsReconnect(box))) {{
            box.textContent = 'LMS restart command completed. Refreshing setup...';
            window.setTimeout(function(){{ window.location.reload(); }}, 900);
          }}
        }} else {{
          box.textContent = error.message;
          restart.disabled = false;
          later.disabled = false;
        }}
      }}
    }});
    later.addEventListener('click', function(){{
          box.textContent = 'Plugin change saved. Restart LMS later to finish applying it.';
      window.setTimeout(function(){{ window.location.reload(); }}, 2500);
    }});
    box.appendChild(text);
    box.appendChild(restart);
    box.appendChild(document.createTextNode(' '));
    box.appendChild(later);
    box.scrollIntoView({{behavior: 'smooth', block: 'nearest'}});
  }}
  async function loadTree(){{
    setStatus('Loading...');
    try {{
      var r = await fetch('/api/mymusic_menu', {{cache:'no-store'}});
      var j = await r.json();
      if (!j.ok) {{
        setStatus('Load failed: ' + (j.error || 'unknown'));
        return;
      }}
      renderRows(j.items || []);
      setStatus('Loaded ' + ((j.items || []).length) + ' item(s)');
    }} catch (e) {{
      setStatus('Load failed: ' + e);
    }}
  }}
  async function loadRadioTree(){{
    setRadioStatus('Loading...');
    try {{
      var r = await fetch('/api/radio_menu', {{cache:'no-store'}});
      var j = await r.json();
      if (!j.ok) {{
        setRadioStatus('Load failed: ' + (j.error || 'unknown'));
        return;
      }}
      renderRadioRows(j.items || []);
      setRadioStatus('Loaded ' + ((j.items || []).length) + ' item(s)');
    }} catch (e) {{
      setRadioStatus('Load failed: ' + e);
    }}
  }}
  document.getElementById('btnLoadMyMusic').addEventListener('click', loadTree);
  document.getElementById('btnLoadRadio').addEventListener('click', loadRadioTree);
  window.addEventListener('message', function(event){{
    var data = event && event.data ? event.data : {{}};
    if (!data || data.type !== 'lyrion-settings-saved') return;
    setRadioStatus('LMS settings saved. Refreshing Radio tree...');
    window.setTimeout(function(){{
      if (homeEnabled('mymusic')) loadTree();
      if (homeEnabled('radio')) loadRadioTree();
    }}, 2200);
  }});
  window.addEventListener('lyrion-health', function(event){{
    var detail = (event && event.detail) || {{}};
    setPluginSettingsAvailable(!!(detail.brokerReachable && detail.lmsConnected));
  }});
  Array.from(document.querySelectorAll('.plugin-settings-link')).forEach(function(link){{
    link.addEventListener('click', function(event){{
      if (link.getAttribute('data-disabled') === '1') {{
        event.preventDefault();
        var box = document.getElementById('pluginActionStatus');
        if (box) box.textContent = 'Wait for the broker to reconnect to LMS before opening plugin settings.';
      }}
    }});
  }});
  Array.from(document.querySelectorAll('.plugin-action')).forEach(function(button){{
    button.addEventListener('click', async function(){{
      var plugin = button.getAttribute('data-plugin');
      var enable = button.getAttribute('data-enable') === '1';
      var pluginStatusBox = document.getElementById('pluginActionStatus');
      if (!window.confirm((enable ? 'Install/enable ' : 'Disable ') + plugin + '?')) return;
      button.disabled = true;
      pluginStatusBox.textContent = 'Updating ' + plugin + '...';
      try {{
        var response = await fetch('/api/system/plugin', {{
          method: 'POST',
          credentials: 'same-origin',
          headers: {{'Content-Type': 'application/json'}},
          body: JSON.stringify({{plugin: plugin, enable: enable}})
        }});
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || 'Plugin update failed');
        var message = data.message || 'Plugin change saved.';
        if (data.home_menu_changed) message += ' Home menu visibility was updated.';
        if (data.restart_required) {{
          showRestartLmsPrompt(message + ' LMS restart is required to finish.', pluginStatusBox);
        }} else {{
          pluginStatusBox.textContent = message;
          window.setTimeout(function(){{ window.location.reload(); }}, 1500);
        }}
      }} catch (error) {{
        pluginStatusBox.textContent = error.message;
        button.disabled = false;
      }}
    }});
  }});
  document.getElementById('mymusicRows').addEventListener('input', syncHidden);
  document.getElementById('mymusicRows').addEventListener('change', syncHidden);
  document.getElementById('radioRows').addEventListener('input', syncHidden);
  document.getElementById('radioRows').addEventListener('change', syncHidden);
  document.getElementById('setupForm').addEventListener('input', function(){{
    syncHidden();
    updateSectionVisibility();
    markUnsaved();
  }});
  document.getElementById('setupForm').addEventListener('change', function(){{
    syncHidden();
    updateSectionVisibility();
    markUnsaved();
  }});
  document.getElementById('setupForm').addEventListener('submit', syncHidden);
  updateSectionVisibility();
  if (homeEnabled('mymusic')) loadTree();
  if (homeEnabled('radio')) loadRadioTree();
}})();
</script>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(
            APP_VERSION,
            "LMS: <code>{}</code>".format(_html_escape(effective)),
        ))
        .replace("__WEB_NAV__", _setup_web_nav_link(False))
        .replace("__BROKER_MODE_PANEL__", _broker_mode_panel())
        .replace("__APP_VERSION__", _html_escape(APP_VERSION))
        .replace("__EFFECTIVE__", _html_escape(effective))
        .replace("__WARN__", warn)
        .replace("__SETUP_ORDER_WARNING__", setup_order_warning)
        .replace("__LICENSE_MAC__", _html_escape(license_info.get("device_mac")))
        .replace("__LICENSE_COLOR__", _html_escape(license_color))
        .replace("__LICENSE_SUMMARY__", _html_escape(license_summary))
        .replace("__LICENSE_KEY__", _html_escape(license_key))
        .replace("__LEGAL_CHECKED__", legal_checked)
        .replace("__LEGAL_VERSION__", _html_escape(LEGAL_TERMS_VERSION))
        .replace("__SAVED__", _html_escape(saved))
        .replace("__RADIO_MENU_SAVED_JSON__", json.dumps(_radio_menu_cache()))
        .replace("__PLAYER_ROWS__", ''.join(player_rows))
        .replace("__HOME_ROWS__", ''.join(rows))
        .replace("__PLUGIN_ROWS__", plugin_rows)
        .replace("__MYMUSIC_MENU_DISPLAY__", ("block" if mymusic_home_enabled else "none"))
        .replace("__RADIO_MENU_DISPLAY__", ("block" if radio_home_enabled else "none"))
        .replace("__IHEART_REGION_SECTION__", (
            '<div class="service-card">'
            '<div class="service-card-heading">'
            '<img src="{}" alt="iHeartRadio">'
            '<h3>iHeartRadio Station Region Filter</h3>'
            '</div>'
            '<label for="iheartRegion"><b>Show iHeartRadio stations for:</b></label><br>'
            '<select id="iheartRegion" name="iheart_region" style="min-width:280px;padding:6px;margin-top:6px;">'
            .format(_html_escape(iheart_icon_url))
            + ''.join(iheart_region_options) +
            '</select>'
            '<label style="display:block;margin-top:10px;">'.format()
            + '<input type="checkbox" name="iheart_skip_intro_when_filtered" value="1"{}> '.format(iheart_skip_checked) +
            'When a region is selected, open iHeartRadio directly to Genres'
            '</label>'
            '<div style="font-size:12px;color:#555;margin-top:8px;">Filters region-tagged iHeartRadio choices shown under RTI Radio. '
            'Choose <b>All regions</b> to show every station returned by the plugin. The direct-to-Genres option only applies when a specific region is selected. '
            'This does not change your iHeartRadio account or make unavailable stations playable.</div>'
            '</div>'
            if iheart_installed else
            '<input type="hidden" name="iheart_region" value="{}">'.format(_html_escape(iheart_region))
        ))
        .replace("__SHAIRTUNES_SECTION__", shairtunes_section)
        .replace("{{", "{")
        .replace("}}", "}")
    )
    return web.Response(text=html, content_type="text/html")


async def setup_web_page(req: web.Request) -> web.Response:
    _load_setup_config()
    if _broker_light_mode():
        raise web.HTTPFound("/setup")

    enabled_checked = " checked" if bool(_setup_cache.get("web_panel_enabled", True)) else ""
    material_bg = _effective_material_panel_color("bg", "#135093")
    material_content_bg = _effective_material_panel_color("content_bg", "#0e52a5")
    material_accent = _effective_material_panel_color("accent", "#ffffff")
    material_mode = _safe_material_mode(_setup_cache.get("web_panel_material_mode"))
    material_mode_options = "".join(
        '<option value="{value}"{selected}>{label}</option>'.format(
            value=value,
            selected=" selected" if material_mode == value else "",
            label=label,
        )
        for value, label in (
            ("user", "User mode - hide setup controls and show Sync"),
            ("installer", "Installer mode - allow Material menus/settings"),
        )
    )
    base = "{}://{}:{}".format(req.scheme, req.host.split(":", 1)[0], LISTEN_PORT)
    try:
        players = _rti_connected_players(await lms.get_players())
    except Exception:
        players = []
    rows: List[str] = []
    for p in players:
        pid = _safe_str(p.get("playerid")).strip().lower()
        if not pid:
            continue
        name = _safe_str(p.get("name") or pid)
        material = "{}/panel/material?playerid={}".format(base, urllib.parse.quote(pid, safe=""))
        interface_settings = _material_direct_url(
            req.clone(
                rel_url=req.rel_url.with_query({
                    "player": pid,
                    "layout": "mobile",
                    "action": "dlg.open/uisettings",
                    "admin": "1",
                    "lgv": APP_VERSION,
                })
            )
        )
        rows.append("""
        <tr>
          <td>{name}</td>
          <td><code>{pid}</code></td>
          <td><a href="{material}">{material}</a></td>
          <td><a href="{interface_settings}" target="_blank">Interface Settings</a></td>
        </tr>
        """.format(
            name=_html_escape(name),
            pid=_html_escape(pid),
            material=_html_escape(material),
            interface_settings=_html_escape(interface_settings),
        ))
    if not rows:
        rows.append('<tr><td colspan="4" style="color:#666;">No connected players found.</td></tr>')
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Web Panel Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
  <h2>Web Panel <span style="font-size:13px;color:#8a5a00;background:#fff3cd;border:1px solid #f1d28b;border-radius:999px;padding:3px 8px;vertical-align:middle;">Beta</span></h2>
  <div class="page-nav"><a href="/setup/players">Local Players</a><a href="/setup">Setup</a><b>Web Panel</b><a href="/setup/system">System</a><a href="/setup/advanced">Advanced</a></div>
  <form method="post" action="/api/setup/web">
    <h3>Panel Availability</h3>
    <label><input type="checkbox" name="web_panel_enabled" value="1"__ENABLED__> Enable broker web panel</label>
    <div style="font-size:12px;color:#666;margin-top:6px;">When disabled, /panel shows a disabled message and does not connect.</div>

    <h3>Material Layer Appearance <span style="font-size:12px;color:#8a5a00;">Beta</span></h3>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Material Skin is the recommended beta web object path. Keep classic RTI controls available while testing.
    </div>
    <label style="display:block;margin-top:10px;">Material toolbar/background:
      <input type="color" name="web_panel_material_bg" value="__MATERIAL_BG__">
      <code>__MATERIAL_BG__</code>
    </label>
    <label style="display:block;margin-top:10px;">Material content:
      <input type="color" name="web_panel_material_content_bg" value="__MATERIAL_CONTENT_BG__">
      <code>__MATERIAL_CONTENT_BG__</code>
    </label>
    <label style="display:block;margin-top:10px;">Material accent:
      <input type="color" name="web_panel_material_accent" value="__MATERIAL_ACCENT__">
      <code>__MATERIAL_ACCENT__</code>
    </label>
    <label style="display:block;margin-top:10px;">Material panel mode:
      <select name="web_panel_material_mode">__MATERIAL_MODE_OPTIONS__</select>
    </label>
    <div style="font-size:12px;color:#666;margin-top:6px;">Installer mode leaves Material's menu/settings available so you can adjust and save its interface. User mode restores the Lyrion sync shortcut and hides setup/server controls.</div>
    <div style="margin-top:14px;">
      <button type="submit">Save Web Panel Settings</button>
    </div>
  </form>

  <h3>Material Panel URLs <span style="font-size:12px;color:#8a5a00;">Beta</span></h3>
  <div style="font-size:12px;color:#666;margin-bottom:8px;">Use these in RTI web objects, iPad, Android tablets, or phone browsers for beta testing. Material opens directly on LMS with the selected player and Lyrion Gadget custom layer.</div>
  <table>
    <thead><tr><th>Player</th><th>MAC</th><th>Material URL</th><th>Admin</th></tr></thead>
    <tbody>__ROWS__</tbody>
  </table>
  </main>
</body>
</html>"""
    html = (
        html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Web Panel"))
        .replace("__ENABLED__", enabled_checked)
        .replace("__MATERIAL_BG__", _html_escape(material_bg))
        .replace("__MATERIAL_CONTENT_BG__", _html_escape(material_content_bg))
        .replace("__MATERIAL_ACCENT__", _html_escape(material_accent))
        .replace("__MATERIAL_MODE_OPTIONS__", material_mode_options)
        .replace("__ROWS__", "".join(rows))
    )
    return web.Response(text=html, content_type="text/html")


def _update_root_dir() -> str:
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    return os.path.join(app_dir, "updates")


def _update_status_path() -> str:
    return os.path.join(_update_root_dir(), "update_status.json")


def _write_update_status(state: str, message: str, **extra: Any) -> None:
    try:
        os.makedirs(_update_root_dir(), exist_ok=True)
        payload = {
            "state": state,
            "message": message,
            "current_version": APP_VERSION,
            "updated_at": int(time.time()),
        }
        payload.update(extra)
        path = _update_status_path()
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        os.replace(tmp, path)
    except Exception:
        pass


def _read_update_status() -> Dict[str, Any]:
    try:
        with open(_update_status_path(), "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _version_tuple(value: Any) -> Tuple[int, ...]:
    parts = _re.findall(r"\d+", _safe_str(value))
    return tuple(int(part) for part in parts[:4]) if parts else (0,)


def _validated_https_url(value: Any, field: str) -> str:
    url = _safe_str(value).strip()
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise ValueError(f"{field} must be an HTTPS URL")
    return url


def _dropbox_direct_url(value: str) -> str:
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or "").lower()
    if host not in ("dropbox.com", "www.dropbox.com"):
        return value
    query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    query["dl"] = ["1"]
    return urllib.parse.urlunsplit((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        urllib.parse.urlencode(query, doseq=True),
        parsed.fragment,
    ))


async def _download_bytes(url: str, maximum: int) -> bytes:
    timeout = ClientTimeout(total=90, connect=15, sock_read=45)
    body = bytearray()
    async with ClientSession(timeout=timeout) as session:
        async with session.get(url, allow_redirects=True) as response:
            if response.status != 200:
                raise RuntimeError(f"download returned HTTP {response.status}")
            length = _safe_int(response.headers.get("Content-Length"), 0)
            if length > maximum:
                raise RuntimeError("download is larger than the allowed package size")
            async for chunk in response.content.iter_chunked(65536):
                body.extend(chunk)
                if len(body) > maximum:
                    raise RuntimeError("download is larger than the allowed package size")
    return bytes(body)


async def _fetch_update_manifest() -> Dict[str, Any]:
    _load_setup_config()
    manifest_url = _validated_https_url(
        _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL,
        "Manifest URL",
    )
    raw = await _download_bytes(_dropbox_direct_url(manifest_url), 256 * 1024)
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as error:
        raise RuntimeError(f"manifest is not valid JSON: {error}")
    if not isinstance(manifest, dict):
        raise RuntimeError("manifest must contain a JSON object")

    version = _safe_str(manifest.get("version")).strip()
    package_url = _validated_https_url(manifest.get("package_url") or manifest.get("url"), "Package URL")
    sha256 = _safe_str(manifest.get("sha256")).strip().lower()
    if not version:
        raise RuntimeError("manifest is missing version")
    if not _re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise RuntimeError("manifest SHA-256 must contain 64 hexadecimal characters")
    return {
        "version": version,
        "package_url": _dropbox_direct_url(package_url),
        "sha256": sha256,
        "notes": _safe_str(manifest.get("notes")).strip(),
        "available": _version_tuple(version) > _version_tuple(APP_VERSION),
        "manifest_url": manifest_url,
    }


def _safe_archive_members(archive: tarfile.TarFile) -> List[tarfile.TarInfo]:
    members = archive.getmembers()
    names: Set[str] = set()
    for member in members:
        name = member.name.replace("\\", "/").lstrip("./")
        if (
            not name
            or name.startswith("/")
            or name == ".."
            or name.startswith("../")
            or "/../" in name
            or member.issym()
            or member.islnk()
            or not (member.isdir() or member.isfile())
        ):
            raise RuntimeError(f"unsafe archive entry: {member.name}")
        member.name = name
        names.add(name)
    missing = sorted(UPDATE_REQUIRED_FILES - names)
    if missing:
        raise RuntimeError("package is missing: " + ", ".join(missing))
    return members


def _extract_update_package(package_path: str, stage_dir: str) -> None:
    os.makedirs(stage_dir, exist_ok=False)
    with tarfile.open(package_path, "r:gz") as archive:
        members = _safe_archive_members(archive)
        for member in members:
            target = os.path.abspath(os.path.join(stage_dir, member.name))
            if os.path.commonpath((os.path.abspath(stage_dir), target)) != os.path.abspath(stage_dir):
                raise RuntimeError(f"unsafe archive path: {member.name}")
            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"could not read archive entry: {member.name}")
            with source, open(target, "wb") as output:
                while True:
                    chunk = source.read(65536)
                    if not chunk:
                        break
                    output.write(chunk)
            os.chmod(target, member.mode & 0o777)
    for script in ("repair-picoreplayer.sh", "start-lyrion-broker-pcp.sh", "install-picoreplayer.sh"):
        path = os.path.join(stage_dir, script)
        if os.path.isfile(path):
            os.chmod(path, 0o755)


def _backup_current_install() -> str:
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    backup_dir = os.path.join(_update_root_dir(), "backups")
    os.makedirs(backup_dir, exist_ok=True)
    path = os.path.join(backup_dir, f"broker-{APP_VERSION}-{int(time.time())}.tgz")
    include = (
        "lyrion_broker.py",
        "pandora_backend.py",
        "requirements.txt",
        "start-lyrion-broker-pcp.sh",
        "pandora_plugins",
        "web_assets",
    )
    with tarfile.open(path, "w:gz") as archive:
        for name in include:
            source = os.path.join(app_dir, name)
            if os.path.exists(source):
                archive.add(source, arcname=name, recursive=True)
    return path


async def _install_available_update(auto: bool = False) -> Dict[str, Any]:
    package_path = ""
    stage_dir = ""
    manifest = await _fetch_update_manifest()
    if not manifest["available"]:
        return {
            "ok": False,
            "error": f"version {manifest['version']} is not newer than {APP_VERSION}",
            "current_version": APP_VERSION,
            "target_version": manifest["version"],
            "state": "current",
        }

    prefix = "First-run auto-update" if auto else "Update"
    _write_update_status(
        "downloading",
        f"{prefix}: downloading broker {manifest['version']}",
        target_version=manifest["version"],
        auto=bool(auto),
    )
    package = await _download_bytes(manifest["package_url"], UPDATE_MAX_PACKAGE_BYTES)
    digest = hashlib.sha256(package).hexdigest()
    if not hmac.compare_digest(digest, manifest["sha256"]):
        raise RuntimeError("downloaded package SHA-256 does not match the manifest")

    root = _update_root_dir()
    os.makedirs(root, exist_ok=True)
    package_path = os.path.join(root, f"broker-{manifest['version']}.tgz")
    with open(package_path + ".tmp", "wb") as handle:
        handle.write(package)
    os.replace(package_path + ".tmp", package_path)

    stage_dir = tempfile.mkdtemp(prefix="stage-", dir=root)
    os.rmdir(stage_dir)
    _extract_update_package(package_path, stage_dir)
    backup_path = _backup_current_install()
    repair = os.path.join(stage_dir, "repair-picoreplayer.sh")
    log_path = os.path.join(root, "update-install.log")
    _write_update_status(
        "installing",
        f"{prefix}: installing broker {manifest['version']}",
        target_version=manifest["version"],
        backup_path=backup_path,
        auto=bool(auto),
    )

    command = f"sleep 2; /bin/sh {repair!r} >> {log_path!r} 2>&1"
    subprocess.Popen(
        ["/bin/sh", "-c", command],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {
        "ok": True,
        "state": "installing",
        "current_version": APP_VERSION,
        "target_version": manifest["version"],
        "message": "Update verified. The broker will restart now.",
        "auto": bool(auto),
    }


async def api_update_check(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    try:
        manifest = await _fetch_update_manifest()
        return web.json_response({"ok": True, "current_version": APP_VERSION, **manifest})
    except Exception as error:
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_update_peek(_req: web.Request) -> web.Response:
    try:
        manifest = await _fetch_update_manifest()
        status = _read_update_status()
        return web.json_response({
            "ok": True,
            "current_version": APP_VERSION,
            "version": manifest["version"],
            "available": bool(manifest["available"]),
            "notes": _safe_str(manifest.get("notes")),
            "status": status,
        })
    except Exception as error:
        return web.json_response({
            "ok": False,
            "current_version": APP_VERSION,
            "error": _safe_str(error),
            "status": _read_update_status(),
        }, status=200)


async def api_update_status(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    return web.json_response({"ok": True, **_read_update_status()})


async def api_update_install(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
    try:
        result = await _install_available_update(auto=False)
        if not result.get("ok"):
            return web.json_response(result, status=409)
        return web.json_response(result)
    except Exception as error:
        _write_update_status("failed", _safe_str(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _read_first_line(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.readline().strip()
    except Exception:
        return ""


def _broker_rollback_archives() -> List[Dict[str, Any]]:
    backup_dir = os.path.join(_update_root_dir(), "backups")
    rows: List[Dict[str, Any]] = []
    try:
        for name in os.listdir(backup_dir):
            if not re.fullmatch(r"broker-[A-Za-z0-9_.-]+\.tgz", name):
                continue
            path = os.path.join(backup_dir, name)
            if not os.path.isfile(path):
                continue
            stat = os.stat(path)
            rows.append({
                "name": name,
                "size": stat.st_size,
                "modified": int(stat.st_mtime),
            })
    except Exception:
        pass
    rows.sort(key=lambda row: row["modified"], reverse=True)
    return rows[:12]


CURATED_LMS_PLUGINS: Tuple[Tuple[str, str], ...] = (
    ("FR_Pandora_0", "Pandora A"),
    ("FR_Pandora_1", "Pandora B"),
    ("FR_Pandora_2", "Pandora C"),
    ("FR_Pandora_3", "Pandora D"),
    ("Pyrrha", "Pyrrha"),
    ("Spotty", "Spotify / Spotty"),
    ("iHeartRadio", "iHeartRadio"),
    ("Podcast", "Podcasts"),
    ("ShairTunes2W", "AirPlay / ShairTunes"),
    ("BBCSounds", "BBC Sounds"),
    ("Qobuz", "Qobuz"),
    ("TIDAL", "TIDAL"),
)

def _curated_plugin_home_label(plugin_id: str, fallback: str = "") -> str:
    plugin_id = _safe_str(plugin_id).strip()
    pandora_index = _pandora_account_index(plugin_id)
    if pandora_index >= 0:
        return _configured_pandora_instance_label(pandora_index)
    labels = {
        "Pyrrha": "Pyrrha",
        "Spotty": "Spotty",
        "iHeartRadio": "iHeartRadio",
        "Podcast": "Podcasts",
        "ShairTunes2W": "AirPlay",
        "BBCSounds": "BBC Sounds",
        "Qobuz": "Qobuz",
        "TIDAL": "TIDAL",
    }
    return labels.get(plugin_id, fallback or plugin_id)


def _curated_plugin_home_key(plugin_id: str) -> str:
    clean = _safe_str(plugin_id).strip()
    return "app:" + clean if clean else ""


def _set_curated_plugin_home_enabled(plugin_id: str, enabled: bool, label: str = "") -> bool:
    key = _curated_plugin_home_key(plugin_id)
    if not key:
        return False
    source_label = _curated_plugin_home_label(plugin_id, label)
    fallback_icon = _curated_plugin_home_icon(plugin_id, source_label)
    rows = _setup_cache.get("home_menu")
    rows = [dict(row) for row in rows] if isinstance(rows, list) else []
    wanted_source = _norm_key(source_label)
    matched = False
    next_order = 650 if plugin_id == "ShairTunes2W" else _next_home_app_order(rows)
    for row in rows:
        if not isinstance(row, dict):
            continue
        row_key = _safe_str(row.get("key")).strip()
        row_source = _norm_key(row.get("source_label") or row.get("label") or row_key)
        if row_key == key or (wanted_source and row_source == wanted_source):
            row["key"] = row_key or key
            row["label"] = _safe_str(row.get("label") or source_label)
            row["source_label"] = _safe_str(row.get("source_label") or source_label)
            row["enabled"] = bool(enabled)
            row["type"] = _safe_str(row.get("type") or "app") or "app"
            row["order"] = _safe_int(row.get("order"), next_order)
            if fallback_icon and not _safe_str(row.get("icon")).strip():
                row["icon"] = fallback_icon
            matched = True
            break
    if not matched and enabled:
        rows.append({
            "key": key,
            "label": source_label,
            "enabled": bool(enabled),
            "order": next_order,
            "type": "app",
            "source_label": source_label,
            "icon": fallback_icon,
        })
        matched = True
    if matched:
        _setup_cache["home_menu"] = _normalize_unique_menu_orders(rows)
        _save_setup_config()
        _load_setup_config()
    return matched


def _pandora_repository_url() -> str:
    return _public_broker_base().rstrip("/") + "/api/pandora/repository.xml"


def _repo_values_contain(repo_values: List[str], repo_url: str) -> bool:
    wanted = _safe_str(repo_url).strip().rstrip("/")
    if not wanted:
        return True
    for line in _normalize_repo_values(repo_values):
        if line.rstrip("/") == wanted:
            return True
    return False


def _normalize_repo_values(repo_values: List[str]) -> List[str]:
    repos: List[str] = []
    seen: Set[str] = set()
    for value in repo_values:
        text = html_lib.unescape(_safe_str(value)).strip()
        if not text:
            continue
        # LMS stores repositories in a textarea, but malformed prior saves can
        # concatenate URLs. Split before any embedded http(s) scheme too.
        text = re.sub(r"(?<!^)(?=https?://)", "\n", text, flags=re.I)
        for line in re.split(r"[\r\n\s]+", text):
            clean = line.strip()
            if not clean:
                continue
            key = clean.rstrip("/")
            if key in seen:
                continue
            seen.add(key)
            repos.append(clean)
    return repos


def _repo_is_pandora_repository(value: Any) -> bool:
    try:
        parts = urllib.parse.urlsplit(_safe_str(value).strip())
        return parts.path.rstrip("/").lower() == "/api/pandora/repository.xml"
    except Exception:
        return False


async def _lms_plugin_manager_html() -> str:
    await lms.start()
    assert lms._session is not None
    url = LMS_BASE.rstrip("/") + "/Default/settings/server/plugins.html"
    async with lms._session.get(url) as response:
        text = await response.text()
        if response.status != 200:
            raise RuntimeError("LMS plugin manager returned HTTP {}".format(response.status))
    return text


def _parse_lms_plugin_catalog(text: str) -> Dict[str, Dict[str, Any]]:
    active_at = text.find('id="activePlugins"')
    inactive_at = text.find('id="inactivePlugins"')
    catalog: Dict[str, Dict[str, Any]] = {}
    for item in re.finditer(
        r'"([A-Za-z0-9_]+)"\s*:\s*\{[^{}]*"category"\s*:\s*"[^"]*"[^{}]*\}',
        text,
        flags=re.I | re.S,
    ):
        plugin_id = html_lib.unescape(item.group(1)).strip()
        if not plugin_id:
            continue
        catalog.setdefault(plugin_id, {
            "id": plugin_id,
            "name": plugin_id,
            "version": "",
            "state": "available",
            "action_type": "install",
            "settings_url": "",
        })
    for item in re.finditer(
        r'<li[^>]+id="plugin-([^"]+)"[^>]*>(.*?)</li>',
        text,
        flags=re.I | re.S,
    ):
        plugin_id = html_lib.unescape(item.group(1)).strip()
        block = item.group(2)
        state = "available"
        if active_at >= 0 and item.start() > active_at and (inactive_at < 0 or item.start() < inactive_at):
            state = "active"
        elif inactive_at >= 0 and item.start() > inactive_at:
            state = "inactive"
        id_pattern = re.escape(plugin_id)
        input_match = re.search(
            r'<input(?=[^>]+\bid="' + id_pattern + r'")[^>]*>',
            block,
            flags=re.I | re.S,
        )
        value_match = re.search(r'\bvalue="([^"]*)"', input_match.group(0), flags=re.I | re.S) if input_match else None
        name = html_lib.unescape(value_match.group(1)).strip() if value_match else plugin_id
        if input_match and re.search(r"\bchecked\b", input_match.group(0), flags=re.I):
            state = "active"
        version_match = re.search(r'\(v([^)]+)\)', block, flags=re.I)
        version = ""
        if version_match:
            version_text = html_lib.unescape(version_match.group(1)).strip()
            version_text = re.sub(r"<[^>]+>", " ", version_text)
            clean_version = re.search(r"\d+(?:[._-][0-9A-Za-z]+)*", version_text)
            version = clean_version.group(0) if clean_version else version_text.strip()
        action_match = re.search(r'name="(manual|install):' + id_pattern + r'"', block, flags=re.I)
        settings_match = re.search(
            r'<a\b[^>]+\bhref="([^"]+)"[^>]*>\s*Settings\s*</a>',
            block,
            flags=re.I | re.S,
        )
        catalog[plugin_id] = {
            "id": plugin_id,
            "name": name or plugin_id,
            "version": version,
            "state": state,
            "action_type": action_match.group(1).lower() if action_match else "",
            "settings_url": html_lib.unescape(settings_match.group(1)).strip() if settings_match else "",
        }
    return catalog


def _broker_owned_plugin_catalog_entry(plugin_id: str, label: str) -> Dict[str, Any]:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    if match:
        letter = chr(ord("A") + int(match.group(1)))
        if _pandora_plugin_zip(letter):
            return {
                "id": plugin_id,
                "name": label,
                "version": PANDORA_PLUGIN_VERSION,
                "state": "available",
                "action_type": "install",
                "settings_url": "",
            }
    return {}


def _public_lms_page_url(path_or_url: Any) -> str:
    value = _safe_str(path_or_url).strip()
    if not value:
        return ""
    parts = urllib.parse.urlsplit(value)
    if parts.scheme and parts.netloc:
        return value
    base = _public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")
    if value.startswith("/"):
        return base + value
    return base + "/" + value.lstrip("/")


def _lms_settings_wrapper_url(path_or_url: Any) -> str:
    value = _safe_str(path_or_url).strip()
    if not value:
        return ""
    parts = urllib.parse.urlsplit(value)
    path = parts.path if parts.scheme and parts.netloc else value
    if not _is_lms_plugin_helper_path(path):
        return ""
    return "/setup/lms-plugin-settings?path=" + urllib.parse.quote(path, safe="")


def _is_lms_plugin_helper_path(path: Any) -> bool:
    value = _safe_str(path).strip()
    return bool(re.search(r"^/Default/plugins/[^/]+/(?:settings(?:/[^?#]+)?|auth)\.html$", value, flags=re.I))


def _pandora_account_settings_url(plugin_id: str) -> str:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    if not match:
        return ""
    return "/setup/pandora-account?index=" + match.group(1)


def _pandora_account_index(plugin_id: str) -> int:
    match = re.fullmatch(r"FR_Pandora_([0-3])", _safe_str(plugin_id).strip())
    return int(match.group(1)) if match else -1


async def _curated_lms_plugins() -> List[Dict[str, Any]]:
    catalog = _parse_lms_plugin_catalog(await _lms_plugin_manager_html())
    rows: List[Dict[str, Any]] = []
    for plugin_id, label in CURATED_LMS_PLUGINS:
        row = dict(catalog.get(plugin_id) or _broker_owned_plugin_catalog_entry(plugin_id, label))
        icon = _safe_str(row.get("icon") or row.get("art") or _curated_plugin_home_icon(plugin_id, label))
        if plugin_id == "TIDAL":
            icon = _curated_plugin_home_icon(plugin_id, label) or icon
        pandora_index = _pandora_account_index(plugin_id)
        pandora_account_ready = True
        if pandora_index >= 0:
            account = _pandora_accounts_cache()[pandora_index]
            pandora_account_ready = bool(_safe_str(account.get("username")).strip() and _safe_str(account.get("password")))
        row.update({
            "id": plugin_id,
            "label": label,
            "name": _safe_str(row.get("name") or label),
            "version": _safe_str(row.get("version")),
            "state": _safe_str(row.get("state") or "unavailable"),
            "action_type": _safe_str(row.get("action_type")),
            "icon": icon,
            "settings_url": _pandora_account_settings_url(plugin_id) or _lms_settings_wrapper_url(row.get("settings_url")),
            "pandora_account": pandora_index >= 0,
            "pandora_account_ready": pandora_account_ready,
        })
        rows.append(row)
    return rows


def _curated_lms_plugin_rows(plugin_rows: List[Dict[str, Any]]) -> str:
    rows: List[str] = []
    for row in plugin_rows:
        if _is_airplay_service_item(row.get("id"), row.get("label")):
            continue
        state = _safe_str(row.get("state")).lower()
        state_color = "#18794e" if state == "active" else ("#b42318" if state == "inactive" else "#7a8694")
        state_label = '<span style="color:{};font-weight:bold;">{}</span>'.format(
            state_color,
            _html_escape(state.title() or "Unknown"),
        )
        if state == "active":
            action = '<button class="plugin-action" type="button" data-plugin="{id}" data-enable="0">Disable</button>'.format(
                id=_html_escape(row.get("id"))
            )
        elif state in ("inactive", "available"):
            label = "Install" if state == "available" else "Enable"
            action = '<button class="plugin-action" type="button" data-plugin="{id}" data-enable="1">{label}</button>'.format(
                id=_html_escape(row.get("id")),
                label=label,
            )
        else:
            action = "Not available from configured LMS repositories"

        if row.get("settings_url"):
            needs_account = bool(row.get("pandora_account") and not row.get("pandora_account_ready"))
            settings_url = _safe_str(row.get("settings_url"))
            settings = '<a class="plugin-settings-link" href="{url}" target="_blank" rel="{rel}" data-needs-lms="1"><button type="button" class="plugin-settings-button {cls}">{label}</button></a>'.format(
                url=_html_escape(row.get("settings_url")),
                rel="opener" if settings_url.startswith("/setup/") else "noopener",
                cls="needs-account" if needs_account else "",
                label="Needs Account" if needs_account else "Open Settings",
            )
        else:
            settings = '<span style="color:#7a8694;">No settings link</span>'

        icon = _safe_str(row.get("icon")).strip()
        fallback_icon = _safe_str(_curated_plugin_setup_icon_fallback(row.get("id"), row.get("label"))).strip()
        display_icon = icon or fallback_icon
        icon_html = (
            '<img src="{icon}" style="width:26px;height:26px;object-fit:contain;border-radius:5px;vertical-align:middle;margin-right:8px;" onerror="this.onerror=null;this.src=\'{fallback}\';">'.format(
                icon=_html_escape(_normalize_icon_url(display_icon)),
                fallback=_html_escape(fallback_icon),
            )
            if display_icon else ""
        )
        rows.append(
            "<tr><td>{label}</td><td>{version}</td><td>{state}</td><td>{action}</td><td>{settings}</td></tr>".format(
                label=icon_html + _html_escape(row.get("label")),
                version=_html_escape(row.get("version")),
                state=state_label,
                action=action,
                settings=settings,
            )
        )
    return "".join(rows) or '<tr><td colspan="5">No curated LMS plugin data returned.</td></tr>'


def _same_host_http_base(req: web.Request, port: int) -> str:
    host = _safe_str(req.host).strip()
    if host.startswith("["):
        parsed_host = host.split("]", 1)[0] + "]"
    else:
        parsed_host = host.split(":", 1)[0]
    parsed_host = parsed_host or "127.0.0.1"
    return "http://{}:{}".format(parsed_host, port)


async def _system_status_snapshot() -> Dict[str, Any]:
    uptime = 0
    try:
        uptime = int(float(_read_first_line("/proc/uptime").split()[0]))
    except Exception:
        pass
    temperature = None
    try:
        temperature = round(float(_read_first_line("/sys/class/thermal/thermal_zone0/temp")) / 1000.0, 1)
    except Exception:
        pass
    loadavg = {"one": None, "five": None, "fifteen": None}
    try:
        parts = _read_first_line("/proc/loadavg").split()
        loadavg = {
            "one": float(parts[0]),
            "five": float(parts[1]),
            "fifteen": float(parts[2]),
        }
    except Exception:
        pass
    memory = {"total": 0, "available": 0}
    try:
        meminfo: Dict[str, int] = {}
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                key, _, rest = line.partition(":")
                value = rest.strip().split()[0] if rest.strip() else "0"
                meminfo[key] = int(value) * 1024
        memory = {
            "total": meminfo.get("MemTotal", 0),
            "available": meminfo.get("MemAvailable", meminfo.get("MemFree", 0)),
        }
    except Exception:
        pass
    disk = {"total": 0, "free": 0}
    try:
        stat = os.statvfs(os.path.dirname(SETUP_JSON_PATH))
        disk = {"total": stat.f_blocks * stat.f_frsize, "free": stat.f_bavail * stat.f_frsize}
    except Exception:
        pass

    sessions = _pcp_player_sessions()
    running = {
        _safe_str(row.get("mac")).lower(): bool(
            _managed_squeezelite_processes({_safe_str(row.get("mac")).lower()})
        )
        for row in sessions
    }
    lms_ok = False
    lms_version = ""
    library_name = ""
    plugin_rows: List[Dict[str, Any]] = []
    if not _broker_light_mode():
        try:
            status = await lms.rpc("", ["serverstatus", 0, 1])
            result = status.get("result") or {}
            lms_version = _safe_str(result.get("version"))
            lms_ok = True
            library_response = await lms.rpc("", ["pref", "libraryname", "?"])
            library_name = _safe_str((library_response.get("result") or {}).get("_p2")).strip()
            plugin_rows = await _curated_lms_plugins()
        except Exception:
            pass

    checks: List[Dict[str, str]] = []
    if _broker_light_mode():
        checks.append({"level": "ok", "text": "Broker Light mode is active"})
    else:
        checks.append({"level": "ok" if lms_ok else "error", "text": "LMS is responding" if lms_ok else "LMS is not responding"})
        checks.append({
            "level": "ok" if _cometd_client_id else "error",
            "text": "CometD is connected" if _cometd_client_id else "CometD is disconnected",
        })
    macs = [_safe_str(row.get("mac")).lower() for row in sessions]
    checks.append({
        "level": "ok" if len(macs) == len(set(macs)) else "error",
        "text": "Player MAC addresses are unique" if len(macs) == len(set(macs)) else "Duplicate player MAC addresses detected",
    })
    available = {row["output"] for row in _available_alsa_outputs()}
    available.update(_available_alsa_pcm_names())
    missing_outputs = [
        _safe_str(row.get("output")) for row in sessions
        if _safe_str(row.get("output")) not in available
    ]
    checks.append({
        "level": "ok" if not missing_outputs else "error",
        "text": "All configured audio outputs are present" if not missing_outputs
        else "Missing audio outputs: " + ", ".join(missing_outputs),
    })
    stopped = [
        _safe_str(row.get("name")) for row in sessions
        if not running.get(_safe_str(row.get("mac")).lower(), False)
    ]
    checks.append({
        "level": "ok" if not stopped else "error",
        "text": "All configured players are running" if not stopped
        else "Stopped players: " + ", ".join(stopped),
    })
    if not _broker_light_mode():
        checks.append({
            "level": "ok" if _legal_terms_accepted() else "error",
            "text": "Required risk acceptance is saved" if _legal_terms_accepted() else "Required risk acceptance is missing",
        })
    license_info = _license_status()
    license_state = _safe_str(license_info.get("state")).strip().lower()
    if license_state == "licensed":
        license_text = "License state: licensed"
    elif license_state == "not_required":
        license_text = "License state: not required in Broker Light"
    elif license_state == "trial":
        license_text = "License state: trial ({:.1f} days remaining)".format(
            _safe_int(license_info.get("trial_seconds_remaining"), 0) / 86400.0
        )
    else:
        license_text = "License state: expired"
    checks.append({
        "level": "error" if license_state == "expired" else "ok",
        "text": license_text,
    })

    return {
        "hostname": _pcp_config_hostname(),
        "uptime": uptime,
        "temperature": temperature,
        "loadavg": loadavg,
        "memory": memory,
        "disk": disk,
        "lms_ok": lms_ok,
        "lms_version": lms_version,
        "library_name": library_name,
        "cometd": bool(_cometd_client_id),
        "rti_connections": len(_ws_clients),
        "players": [
            {
                "slot": row.get("slot"),
                "name": row.get("name"),
                "mac": row.get("mac"),
                "output": row.get("output"),
                "running": running.get(_safe_str(row.get("mac")).lower(), False),
            }
            for row in sessions
        ],
        "checks": checks,
        "plugins": plugin_rows,
        "network_mounts": _pcp_network_mount_statuses(),
        "rollbacks": _broker_rollback_archives(),
    }


async def setup_system_page(req: web.Request) -> web.Response:
    status = await _system_status_snapshot()
    identity_hostname = _default_unit_hostname() if _is_generic_hostname(status["hostname"]) else _safe_str(status["hostname"])
    player_rows = "".join(
        "<tr><td>{slot}</td><td>{name}</td><td><code>{mac}</code></td><td><code>{output}</code></td>"
        "<td style=\"color:{color};font-weight:bold;\">{state}</td></tr>".format(
            slot=_html_escape(row.get("slot")),
            name=_html_escape(row.get("name")),
            mac=_html_escape(row.get("mac")),
            output=_html_escape(row.get("output")),
            color="#18794e" if row.get("running") else "#b42318",
            state="Running" if row.get("running") else "Stopped",
        )
        for row in status["players"]
    ) or '<tr><td colspan="5">No configured players found.</td></tr>'
    check_rows = "".join(
        '<li style="margin:7px 0;color:{color};"><b>{mark}</b> {text}</li>'.format(
            color="#18794e" if row["level"] == "ok" else "#b42318",
            mark="PASS" if row["level"] == "ok" else "FAIL",
            text=_html_escape(row["text"]),
        )
        for row in status["checks"]
    )
    temp_text = "{} C".format(status["temperature"]) if status["temperature"] is not None else "Unavailable"
    disk_total = max(_safe_int(status["disk"].get("total"), 0), 1)
    disk_free = _safe_int(status["disk"].get("free"), 0)
    disk_text = "{:.1f} GB free of {:.1f} GB".format(disk_free / 1073741824.0, disk_total / 1073741824.0)
    loadavg = status["loadavg"]
    if loadavg.get("one") is None:
        load_text = "Unavailable"
    else:
        load_text = "{:.2f} / {:.2f} / {:.2f}".format(
            loadavg.get("one") or 0.0,
            loadavg.get("five") or 0.0,
            loadavg.get("fifteen") or 0.0,
        )
    mem_total = max(_safe_int(status["memory"].get("total"), 0), 1)
    mem_avail = _safe_int(status["memory"].get("available"), 0)
    mem_used = max(mem_total - mem_avail, 0)
    memory_text = "{:.0f}% used ({:.0f} MB free)".format(
        (mem_used / mem_total) * 100.0,
        mem_avail / 1048576.0,
    )
    mount_rows = "".join(
        '<div style="margin:7px 0;color:{color};"><b>{mark}</b> <code>{path}</code> &mdash; {state}{detail}</div>'.format(
            color="#18794e" if row.get("mounted") and row.get("readable") else "#b42318",
            mark="MOUNTED" if row.get("mounted") and row.get("readable") else "NOT MOUNTED",
            path=_html_escape(row.get("path")),
            state="mounted and readable" if row.get("mounted") and row.get("readable") else (
                "mounted but not readable" if row.get("mounted") else "configured in pCP but currently unavailable"
            ),
            detail=(" ({})".format(_html_escape(row.get("fstype")))) if row.get("fstype") else "",
        )
        for row in status.get("network_mounts", [])
    ) or '<div style="margin:7px 0;color:#596579;">No enabled pCP network mounts are configured.</div>'
    if _broker_light_mode():
        mode_status_rows = """
<tr><th>Hostname</th><td>__HOSTNAME__</td><th>Broker</th><td>v__VERSION__</td></tr>
<tr><th>Mode</th><td>Broker Light</td><th>CPU Temperature</th><td>__TEMPERATURE__</td></tr>
<tr><th>CPU Load</th><td>__CPU_LOAD__</td><th>Memory</th><td>__MEMORY__</td></tr>
<tr><th>Uptime</th><td>__UPTIME__ minutes</td><th>Storage</th><td>__DISK__</td></tr>
"""
        identity_section = """
<h3>System Identity</h3>
<div style="font-size:13px;color:#596579;line-height:1.45;">
Hostname is managed in Advanced Setup. Normal units should stay on the automatic <code>Lyrion####</code> identity.
</div>
"""
        storage_section = ""
    else:
        mode_status_rows = """
<tr><th>Hostname</th><td>__HOSTNAME__</td><th>Broker</th><td>v__VERSION__</td></tr>
<tr><th>LMS</th><td>__LMS_STATE__ __LMS_VERSION__</td><th>CometD</th><td>__COMETD__</td></tr>
<tr><th>RTI Connections</th><td>__RTI_CONNECTIONS__</td><th>CPU Temperature</th><td>__TEMPERATURE__</td></tr>
<tr><th>CPU Load</th><td>__CPU_LOAD__</td><th>Memory</th><td>__MEMORY__</td></tr>
<tr><th>Uptime</th><td>__UPTIME__ minutes</td><th>Storage</th><td>__DISK__</td></tr>
"""
        identity_section = """
<h3>LMS Identity</h3>
<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:end;">
<label>LMS Library Name
<input id="lmsLibraryName" type="text" maxlength="80" value="__LIBRARY_NAME__" placeholder="Uses hostname when blank">
</label>
<button id="applyIdentity" type="button">Save LMS Name</button>
</div>
<div id="identityStatus" style="margin-top:10px;color:#596579;">Hostname is managed in Advanced Setup.</div>
"""
        storage_section = """
<h3>Storage / Drives</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
<a href="__PCP_BASE__/cgi-bin/drives.cgi" target="_blank" rel="noopener"><button type="button">Open pCP Storage / Mounts</button></a>
<a href="__LMS_BASE__/Default/settings/index.html?activePage=BASIC_SETTINGS" target="_blank" rel="noopener"><button type="button">Open LMS Music Folder</button></a>
<a href="__LMS_BASE__/Default/settings/index.html" target="_blank" rel="noopener"><button type="button">Open LMS Rescan / Library Settings</button></a>
</div>
<div style="margin-top:10px;"><b>pCP Network Mount Status</b> <a href="/setup/system" style="font-size:12px;margin-left:8px;">Refresh</a>
__MOUNT_ROWS__
</div>
<div style="font-size:12px;color:#596579;margin-top:8px;max-width:900px;line-height:1.45;">
Use pCP/LMS for USB drives and network shares. For NAS music libraries, configure the SMB/CIFS mount in pCP,
then point LMS at the mounted folder and rescan. Samba server sharing is separate; it exposes this unit's files
to Windows/macOS clients and is not required just to play music from a NAS.
</div>
"""
    restart_lms_button = '' if _broker_light_mode() else '<button class="system-action" data-action="restart_lms">Restart LMS</button>'
    pcp_base = _same_host_http_base(req, 80)
    lms_ui_base = _safe_str(_public_lms_base()).rstrip("/") or _same_host_http_base(req, 9000)
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Lyrion Gadget System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell">
<h2>System Commissioning</h2>
<div class="page-nav"><a href="/setup/players">Local Players</a><a href="/setup">Setup</a>__WEB_NAV__<b>System</b><a href="/setup/advanced">Advanced</a></div>

<section class="quick-links">
<h3>Status</h3>
<table><tbody>
__STATUS_ROWS__
</tbody></table>

__IDENTITY_SECTION__

<h3>System Check</h3><ul style="list-style:none;padding:0;">__CHECK_ROWS__</ul>

<h3>Players</h3>
<table><thead><tr><th>Slot</th><th>Name</th><th>MAC</th><th>Output</th><th>Status</th></tr></thead>
<tbody>__PLAYER_ROWS__</tbody></table>

<h3>Service Controls</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;">
<button class="system-action" data-action="restart_broker">Restart Broker</button>
<button class="system-action" data-action="restart_players">Restart Players</button>
__RESTART_LMS_BUTTON__
<button class="system-action" data-action="reboot">Reboot Device</button>
</div>
<div id="systemActionStatus" style="margin-top:10px;color:#596579;"></div>

__STORAGE_SECTION__

<h3>Configuration Backup</h3>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
<a href="/api/system/backup"><button type="button">Save Config Backup</button></a>
<form id="restoreForm" style="padding:0;border:0;box-shadow:none;margin:0;" enctype="multipart/form-data">
<input id="restoreFile" type="file" accept=".tgz,.gz" required>
<button type="submit">Restore Configuration</button>
</form>
</div>
<div style="font-size:12px;color:#8a5a00;margin-top:8px;">Backups contain local credentials and license information. Store them securely.</div>
</section>
</main>
<script>
(function(){
  var statusBox=document.getElementById("systemActionStatus");
  var statusClearTimer=null;
  var pendingActionButton=null;
  var pendingActionName="";
  var pendingActionStartedAt=0;
  var waitingForReconnect=false;
  var sawBrokerDisconnect=false;
  var sawLmsDisconnect=false;
  var identityButton=document.getElementById("applyIdentity");
  var identityStatus=document.getElementById("identityStatus");
  function flashStatus(message,isError){
    if(statusClearTimer) window.clearTimeout(statusClearTimer);
    statusBox.textContent=message||"";
    statusBox.style.color=isError?"#b42318":"#596579";
    if(!isError&&message){
      statusClearTimer=window.setTimeout(function(){
        if(statusBox.textContent===message) statusBox.textContent="";
      },12000);
    }
  }
  function isNetworkDrop(error){
    var message=(error&&error.message?error.message:String(error||"")).toLowerCase();
    return message.indexOf("failed to fetch")>=0||
      message.indexOf("networkerror")>=0||
      message.indexOf("network error")>=0||
      message.indexOf("load failed")>=0;
  }
  function setWaitingForReconnect(message){
    if(statusClearTimer) window.clearTimeout(statusClearTimer);
    waitingForReconnect=true;
    statusBox.textContent=message||"Command sent. Waiting for broker to reconnect...";
    statusBox.style.color="#596579";
  }
  function setServiceButtonsDisabled(disabled){
    Array.from(document.querySelectorAll(".system-action")).forEach(function(button){
      button.disabled=!!disabled;
    });
  }
  function clearPendingActions(detail){
    detail=detail||{};
    if((pendingActionName==="reboot"||pendingActionName==="restart_broker")&&!sawBrokerDisconnect) return;
    if(pendingActionName==="restart_lms"){
      if(!sawLmsDisconnect&&Date.now()-pendingActionStartedAt<10000) return;
      if(sawLmsDisconnect&&!detail.lmsConnected) return;
    }
    setServiceButtonsDisabled(false);
    var completedAction=pendingActionName;
    pendingActionButton=null;
    pendingActionName="";
    sawBrokerDisconnect=false;
    sawLmsDisconnect=false;
    if(waitingForReconnect){
      waitingForReconnect=false;
      window.dispatchEvent(new CustomEvent("lyrion-force-lms-state",{detail:{clear:true}}));
      flashStatus(completedAction==="restart_lms"?"LMS is responding again.":"Broker is responding again.",false);
    }
  }
  window.addEventListener("lyrion-health",function(event){
    var detail=event.detail||{};
    if(detail.brokerReachable&&pendingActionName==="restart_lms"&&!detail.lmsConnected) sawLmsDisconnect=true;
    if(detail.brokerReachable) clearPendingActions(detail);
    else if(pendingActionName==="reboot"||pendingActionName==="restart_broker") sawBrokerDisconnect=true;
  });
  if(identityButton) identityButton.addEventListener("click",async function(){
    identityButton.disabled=true;identityStatus.textContent="Saving system identity...";
    try{
      var response=await fetch("/api/setup/system-identity",{
        method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          library_name:(document.getElementById("lmsLibraryName")||{}).value||""
        })
      });
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Identity update failed");
      identityStatus.innerHTML="";
      identityStatus.style.color="#18794e";identityStatus.style.fontWeight="bold";
      if(data.reboot_required){
        var text=document.createElement("span");
        text.textContent="Hostname saved. Reboot is required for pCP/network discovery to fully use it. ";
        var reboot=document.createElement("button");
        reboot.type="button";
        reboot.textContent="Reboot Now";
        window.addEventListener("lyrion-health",function(event){
          if(event.detail&&event.detail.brokerReachable) reboot.disabled=false;
        });
        reboot.addEventListener("click",async function(){
          if(!window.confirm("Reboot device now to finish hostname change?"))return;
          reboot.disabled=true;
          identityStatus.appendChild(document.createTextNode(" Reboot requested..."));
          try{
            await postAction("reboot");
            window.setTimeout(function(){
              var attempts=0;
              var timer=window.setInterval(async function(){
                attempts+=1;
                try{
                  var response=await fetch("/health?reboot="+Date.now(),{cache:"no-store"});
                  if(response.ok){
                    window.clearInterval(timer);
                    window.location.replace("/setup/system?rebooted="+Date.now());
                  }
                }catch(_){}
                if(attempts>120)window.clearInterval(timer);
              },2000);
            },8000);
          }
          catch(error){
            if(isNetworkDrop(error)){
              identityStatus.textContent="Reboot command sent. Waiting for broker to reconnect...";
              identityStatus.style.color="#596579";
            }else{
              identityStatus.textContent=error.message;identityStatus.style.color="#b42318";
            }
          }
        });
        identityStatus.appendChild(text);
        identityStatus.appendChild(reboot);
      }else{
        identityStatus.textContent="LMS library name saved.";
      }
    }catch(error){
      identityStatus.textContent=error.message;identityStatus.style.color="#b42318";
      identityStatus.style.fontWeight="bold";
    }finally{identityButton.disabled=false;}
  });
  async function postAction(action, extra) {
    var response=await fetch("/api/system/action",{
      method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},
      body:JSON.stringify(Object.assign({action:action},extra||{}))
    });
    var data=await response.json();
    if(!data.ok) throw new Error(data.error||"Action failed");
    return data;
  }
  async function waitForPlayersReady(){
    var deadline=Date.now()+30000;
    var lastText="";
    while(Date.now()<deadline){
      try{
        var response=await fetch("/api/system/players-status?ts="+Date.now(),{cache:"no-store"});
        var data=await response.json();
        if(data.ok){
          lastText=(data.running||0)+" of "+(data.configured||0)+" configured players running";
          flashStatus("Waiting for local players... "+lastText,false);
          if(data.ready) return data;
        }
      }catch(_){}
      await new Promise(function(resolve){window.setTimeout(resolve,1000);});
    }
    throw new Error("Timed out waiting for local players to restart. "+lastText);
  }
  Array.from(document.querySelectorAll(".system-action")).forEach(function(button){
    button.addEventListener("click",async function(){
      var action=button.getAttribute("data-action");
      if(!window.confirm("Run "+button.textContent+" now?")) return;
      setServiceButtonsDisabled(true); pendingActionButton=button; pendingActionName=action; pendingActionStartedAt=Date.now();
      flashStatus(button.textContent+" requested...",false);
      try{
        var data=await postAction(action);
        if(action==="reboot") setWaitingForReconnect(data.message||"Reboot command sent. Waiting for broker to disconnect...");
        else if(action==="restart_lms") setWaitingForReconnect(data.message||"LMS restart command sent. Waiting for LMS to reconnect...");
        else if(action==="restart_broker"){
          window.dispatchEvent(new CustomEvent("lyrion-force-lms-state",{detail:{connected:false,untilMs:45000}}));
          setWaitingForReconnect(data.message||"Broker restart command sent. Waiting for broker to disconnect...");
        }
        else if(action==="restart_players"){
          flashStatus((data.message||"Local players restarted.")+" Waiting for players to report running...",false);
          var playerStatus=await waitForPlayersReady();
          flashStatus("Local players ready: "+playerStatus.running+" of "+playerStatus.configured+" running.",false);
        }
        else flashStatus(data.message||"Action requested.",false);
      }
      catch(error){
        if(action==="reboot"||isNetworkDrop(error)) setWaitingForReconnect("Command sent. Waiting for broker to reconnect...");
        else flashStatus(error.message,true);
      }
      finally{
        if(action!=="reboot"&&!waitingForReconnect){
          setServiceButtonsDisabled(false); pendingActionButton=null; pendingActionName="";
        }
      }
    });
  });
  document.getElementById("restoreForm").addEventListener("submit",async function(event){
    event.preventDefault();
    if(!window.confirm("Restore this configuration and restart local players?")) return;
    var restoreForm=event.target;
    var restoreButton=restoreForm.querySelector("button[type=submit]");
    var restoreFile=document.getElementById("restoreFile");
    var form=new FormData();form.append("backup",restoreFile.files[0]);
    restoreButton.disabled=true;
    flashStatus("Restoring configuration...",false);
    try{
      var response=await fetch("/api/system/restore",{method:"POST",credentials:"same-origin",body:form});
      var data=await response.json();if(!data.ok)throw new Error(data.error||"Restore failed");
      flashStatus(data.message,false);
      restoreForm.reset();
      window.setTimeout(function(){window.location.reload();},2500);
    }catch(error){flashStatus(error.message,true);}
    finally{restoreButton.disabled=false;}
  });
}());
</script></body></html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "System commissioning"))
        .replace("__WEB_NAV__", _setup_web_nav_link(False))
        .replace("__STATUS_ROWS__", mode_status_rows)
        .replace("__IDENTITY_SECTION__", identity_section)
        .replace("__STORAGE_SECTION__", storage_section)
        .replace("__MOUNT_ROWS__", mount_rows)
        .replace("__HOSTNAME__", _html_escape(status["hostname"]))
        .replace("__IDENTITY_HOSTNAME__", _html_escape(identity_hostname))
        .replace("__LIBRARY_NAME__", _html_escape(status["library_name"]))
        .replace("__VERSION__", _html_escape(APP_VERSION))
        .replace("__LMS_STATE__", "Connected" if status["lms_ok"] else "Disconnected")
        .replace("__LMS_VERSION__", _html_escape(status["lms_version"]))
        .replace("__COMETD__", "Connected" if status["cometd"] else "Disconnected")
        .replace("__RTI_CONNECTIONS__", str(status["rti_connections"]))
        .replace("__TEMPERATURE__", temp_text)
        .replace("__CPU_LOAD__", _html_escape(load_text))
        .replace("__MEMORY__", _html_escape(memory_text))
        .replace("__UPTIME__", str(status["uptime"] // 60))
        .replace("__DISK__", disk_text)
        .replace("__PCP_BASE__", _html_escape(pcp_base))
        .replace("__LMS_BASE__", _html_escape(lms_ui_base))
        .replace("__RESTART_LMS_BUTTON__", restart_lms_button)
        .replace("__CHECK_ROWS__", check_rows)
        .replace("__PLAYER_ROWS__", player_rows)
    )
    return web.Response(text=html, content_type="text/html")


async def setup_lms_plugin_settings_page(req: web.Request) -> web.Response:
    raw_path = _safe_str(req.query.get("path")).strip()
    parts = urllib.parse.urlsplit(raw_path)
    path = parts.path or raw_path
    if not _is_lms_plugin_helper_path(path):
        raise web.HTTPBadRequest(text="Invalid LMS plugin settings path")
    target_path = urllib.parse.urlunsplit(("", "", path, parts.query, ""))
    is_auth_page = bool(re.search(r"/auth\.html$", path, flags=re.I))

    await lms.start()
    assert lms._session is not None
    public_lms = _public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")
    broker_base = _public_broker_base().rstrip("/")

    def _settings_wrapper_location(path_or_url: Any) -> str:
        value = _safe_str(path_or_url).strip()
        if not value:
            return ""
        loc_parts = urllib.parse.urlsplit(value)
        if loc_parts.scheme and loc_parts.netloc:
            resolved = value
        elif value.startswith("/"):
            resolved = value
        else:
            resolved = urllib.parse.urljoin(target_path, value)
        loc_parts = urllib.parse.urlsplit(resolved)
        loc_path = loc_parts.path or resolved
        loc_path_query = urllib.parse.urlunsplit(("", "", loc_path, loc_parts.query, ""))
        if _is_lms_plugin_helper_path(loc_path):
            return broker_base + "/setup/lms-plugin-settings?path=" + urllib.parse.quote(loc_path_query, safe="")
        if loc_parts.scheme and loc_parts.netloc:
            return resolved
        if resolved.startswith("/"):
            return public_lms + resolved
        return public_lms + "/" + resolved.lstrip("/")

    fetch_url = LMS_BASE.rstrip("/") + target_path
    if req.method == "POST":
        post_body = await req.read()
        headers = {}
        content_type = _safe_str(req.headers.get("Content-Type")).strip()
        if content_type:
            headers["Content-Type"] = content_type
        async with lms._session.post(fetch_url, data=post_body, headers=headers, allow_redirects=False) as response:
            if response.status in (301, 302, 303, 307, 308):
                location = _safe_str(response.headers.get("Location")).strip()
                if location:
                    raise web.HTTPFound(location=_settings_wrapper_location(location))
            body = await response.text()
            if response.status >= 400:
                raise web.HTTPBadGateway(text="LMS settings page returned HTTP {}".format(response.status))
    else:
        async with lms._session.get(fetch_url) as response:
            body = await response.text()
            if response.status != 200:
                raise web.HTTPBadGateway(text="LMS settings page returned HTTP {}".format(response.status))

    def _absolute_action(match: re.Match[str]) -> str:
        action = html_lib.unescape(match.group(2)).strip()
        parts = urllib.parse.urlsplit(action)
        if parts.scheme and parts.netloc:
            action_path = urllib.parse.urlunsplit(("", "", parts.path, parts.query, ""))
        elif action.startswith("/"):
            action_path = action
        else:
            action_path = urllib.parse.urljoin(target_path, action)
        action_parts = urllib.parse.urlsplit(action_path)
        if _is_lms_plugin_helper_path(action_parts.path):
            wrapped = broker_base + "/setup/lms-plugin-settings?path=" + urllib.parse.quote(action_path, safe="")
            return match.group(1) + _html_escape(wrapped) + match.group(3)
        if parts.scheme and parts.netloc:
            absolute = action
        elif action.startswith("/"):
            absolute = public_lms + action
        else:
            absolute = public_lms + "/" + action.lstrip("/")
        return match.group(1) + _html_escape(absolute) + match.group(3)

    body = re.sub(r'(<form\b[^>]*\baction=")([^"]*)(")', _absolute_action, body, count=1, flags=re.I | re.S)
    def _wrap_plugin_js_location(match: re.Match[str]) -> str:
        prefix = match.group(1)
        quote = match.group(2)
        location = html_lib.unescape(match.group(3)).strip()
        wrapped = _settings_wrapper_location(location)
        if wrapped.startswith(broker_base + "/setup/lms-plugin-settings?"):
            safe_wrapped = wrapped.replace("\\", "\\\\").replace(quote, "\\" + quote)
            return prefix + quote + safe_wrapped + quote
        return match.group(0)

    body = re.sub(
        r"(window\.location(?:\.href)?\s*=\s*)(['\"])([^'\"]+)(['\"])",
        _wrap_plugin_js_location,
        body,
        flags=re.I,
    )
    body = re.sub(
        r"(<form\b(?![^>]*\bid=)[^>]*>)",
        lambda match: match.group(1)[:-1] + ' id="settingsForm">',
        body,
        count=1,
        flags=re.I | re.S,
    )
    body = re.sub(
        r"(<head\b[^>]*>)",
        r'\1<base href="{}">'.format(_html_escape(public_lms.rstrip("/") + (path.rsplit("/", 1)[0] or "") + "/")),
        body,
        count=1,
        flags=re.I,
    )
    if is_auth_page:
        controls = """
<div style="position:sticky;bottom:0;z-index:9999;background:#f6f8fb;border-top:1px solid #ccd4dc;padding:10px;display:flex;gap:8px;align-items:center;box-shadow:0 -2px 8px rgba(0,0,0,.08);">
  <button type="button" onclick="window.close()">Close</button>
  <button type="button" onclick="window.location.href='__SETTINGS_URL__'">Back to Settings</button>
  <span style="color:#596579;font-size:12px;">Complete the TIDAL sign-in, then return here or close this window.</span>
</div>
"""
        controls = controls.replace("__SETTINGS_URL__", _html_escape(_settings_wrapper_location("settings.html")))
    else:
        controls = """
<div style="position:sticky;bottom:0;z-index:9999;background:#f6f8fb;border-top:1px solid #ccd4dc;padding:10px;display:flex;gap:8px;align-items:center;box-shadow:0 -2px 8px rgba(0,0,0,.08);">
  <button id="saveSettingsOnly" type="button" style="font-weight:bold;">Save Settings</button>
  <button type="button" onclick="window.close()">Close</button>
  <button id="saveRestartLms" type="button" style="font-weight:bold;margin-left:18px;">Save + Restart LMS</button>
  <span id="lyrionSettingsStatus" style="color:#596579;font-size:12px;">For BBC Sounds, "Place in the Radio menu" requires an LMS restart before Lyrion Gadget sees the new location.</span>
</div>
<iframe name="lyrionSettingsSaveTarget" style="display:none;width:0;height:0;border:0;"></iframe>
<script>
(function(){
  function wireForms(){
    var forms=document.getElementsByTagName("form");
    for(var i=0;i<forms.length;i++){
      if(!forms[i].id && i===0) forms[i].id="settingsForm";
    }
  }
  wireForms();
  window.setTimeout(wireForms,250);
  var restart=document.getElementById("saveRestartLms");
  var status=document.getElementById("lyrionSettingsStatus");
  var saveSubmitted=false;
  var restartFlow=false;
  function refreshSetupNow(){
    try{
      if(window.opener && !window.opener.closed){
        try{ window.opener.postMessage({type:"lyrion-settings-saved"}, "*"); }catch(_){}
        window.opener.location.reload();
        window.setTimeout(function(){ try{ if(window.opener && !window.opener.closed) window.opener.location.reload(); }catch(_){} },3500);
        return;
      }
    }catch(_){}
    window.location.href="__BROKER_BASE__/setup";
  }
  function watchNormalSave(){
    var frame=document.getElementsByName("lyrionSettingsSaveTarget")[0];
    var form=document.getElementById("settingsForm") || document.getElementsByTagName("form")[0];
    function submitToHidden(){
      if(!form){ if(status)status.textContent="No LMS settings form found."; return false; }
      form.target="lyrionSettingsSaveTarget";
      saveSubmitted=true;
      if(status)status.textContent="Saving LMS settings...";
      form.submit();
      return true;
    }
    var saveOnly=document.getElementById("saveSettingsOnly");
    if(saveOnly){
      saveOnly.addEventListener("click",function(){
        submitToHidden();
      });
    }
    if(frame){
      frame.addEventListener("load",function(){
        if(!saveSubmitted || restartFlow) return;
        saveSubmitted=false;
        try{ if(form && form.target==="lyrionSettingsSaveTarget") form.removeAttribute("target"); }catch(_){}
        if(status)status.textContent="Settings saved. You can close this window.";
      });
    }
    window.lyrionSettingsSubmitToHidden=submitToHidden;
  }
  function refreshSetupAfterReconnect(){
    var attempts=0;
    function done(){
      try{
        if(window.opener && !window.opener.closed){
          try{ window.opener.postMessage({type:"lyrion-settings-saved"}, "*"); }catch(_){}
          window.opener.location.reload();
          window.setTimeout(function(){ try{ if(window.opener && !window.opener.closed) window.opener.location.reload(); }catch(_){} },3500);
          window.close();
          return;
        }
      }catch(_){}
      window.location.href="__BROKER_BASE__/setup";
    }
    function poll(){
      attempts++;
      fetch("__BROKER_BASE__/health?lms_settings_refresh="+Date.now(),{cache:"no-store"})
        .then(function(response){return response.json();})
        .then(function(data){
          if(data && data.cometd && data.cometd.connected){
            if(status)status.textContent="LMS reconnected. Refreshing setup...";
            window.setTimeout(done,800);
            return;
          }
          if(attempts<90) window.setTimeout(poll,1000);
          else done();
        })
        .catch(function(){
          if(attempts<90) window.setTimeout(poll,1000);
          else done();
        });
    }
    window.setTimeout(poll,1500);
  }
  if(restart){
    restart.addEventListener("click",function(){
      var form=document.getElementById("settingsForm") || document.getElementsByTagName("form")[0];
      if(!form){ if(status)status.textContent="No LMS settings form found."; return; }
      if(!window.confirm("Save settings and restart LMS now? Use this after moving an app between Home and Radio.")) return;
      restart.disabled=true;
      restartFlow=true;
      if(!window.lyrionSettingsSubmitToHidden || !window.lyrionSettingsSubmitToHidden()) return;
      window.setTimeout(function(){
        if(status)status.textContent="Restarting LMS...";
        fetch("__BROKER_BASE__/api/system/action",{
          method:"POST",
          credentials:"same-origin",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify({action:"restart_lms"})
        }).then(function(response){return response.json();})
          .then(function(data){
            if(!data.ok) throw new Error(data.error || "Restart failed");
            if(status)status.textContent=(data.message || "LMS restart requested.") + " Waiting for LMS to reconnect...";
            refreshSetupAfterReconnect();
          })
          .catch(function(error){
            restart.disabled=false;
            if(status)status.textContent=String(error && error.message || error);
          });
      },900);
    });
  }
  watchNormalSave();
})();
</script>
"""
    controls = controls.replace("__BROKER_BASE__", _html_escape(broker_base))
    if re.search(r"</form>", body, flags=re.I):
        body = re.sub(r"</form>", controls + "</form>", body, count=1, flags=re.I)
    else:
        body += controls
    return web.Response(text=body, content_type="text/html")


async def setup_pandora_account_page(req: web.Request) -> web.Response:
    _load_setup_config()
    index = _safe_int(req.query.get("index"), -1)
    if index < 0 or index > 3:
        raise web.HTTPBadRequest(text="Invalid Pandora account index")
    account = _pandora_accounts_cache()[index]
    letter = chr(65 + index)
    html = """<!doctype html>
<html><head><meta charset="utf-8"><title>Pandora {letter} Settings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>__SETUP_STYLE__</style></head><body>
__BRAND_HEADER__
<main class="page-shell" style="max-width:720px;">
<h2>Pandora {letter}</h2>
<form id="pandoraAccountForm">
  <label>Name
    <input id="name" type="text" maxlength="80" value="{name}" placeholder="Pandora {letter}">
  </label>
  <label>Pandora username/email
    <input id="username" type="text" autocomplete="username" value="{username}">
  </label>
  <label>Pandora password
    <input id="password" type="password" autocomplete="current-password" value="{password}">
  </label>
  <div style="display:flex;gap:8px;align-items:center;margin-top:14px;">
    <button id="saveButton" type="submit" style="font-weight:bold;">Save Pandora {letter}</button>
    <button type="button" onclick="window.close()">Close</button>
  </div>
  <div id="saveStatus" style="margin-top:10px;color:#596579;"></div>
</form>
<div style="font-size:12px;color:#596579;margin-top:16px;">These credentials are stored locally in the broker setup file and used by the broker-backed Pandora {letter} LMS plugin.</div>
</main>
<script>
(function(){{
  var form=document.getElementById("pandoraAccountForm");
  var status=document.getElementById("saveStatus");
  var button=document.getElementById("saveButton");
  form.addEventListener("submit",async function(event){{
    event.preventDefault();
    button.disabled=true;status.textContent="Saving Pandora {letter}...";
    try{{
      var response=await fetch("/api/pandora/account", {{
        method:"POST",credentials:"same-origin",headers:{{"Content-Type":"application/json"}},
        body:JSON.stringify({{
          index:{index},
          name:document.getElementById("name").value,
          username:document.getElementById("username").value,
          password:document.getElementById("password").value
        }})
      }});
      var data=await response.json();
      if(!data.ok)throw new Error(data.error||"Save failed");
      status.textContent="Saved. You can close this window.";
      status.style.color="#18794e";status.style.fontWeight="bold";
      if(window.opener && !window.opener.closed) {{
        window.opener.location.reload();
      }}
    }}catch(error){{
      status.textContent=error.message;status.style.color="#b42318";status.style.fontWeight="bold";
      button.disabled=false;
    }}
  }});
}})();
</script></body></html>""".format(
        letter=letter,
        index=index,
        name=_html_escape(account.get("name") or "Pandora {}".format(letter)),
        username=_html_escape(account.get("username")),
        password=_html_escape(account.get("password")),
    )
    html = html.replace("__SETUP_STYLE__", _SETUP_STYLE).replace(
        "__BRAND_HEADER__", _setup_brand_header(APP_VERSION, "Pandora account settings")
    )
    return web.Response(text=html, content_type="text/html")


async def api_pandora_account(req: web.Request) -> web.Response:
    try:
        _load_setup_config()
        body = await req.json()
        index = _safe_int(body.get("index"), -1)
        if index < 0 or index > 3:
            raise ValueError("Invalid Pandora account index")
        accounts = _pandora_accounts_cache()
        existing = accounts[index]
        password = _safe_str(body.get("password") if "password" in body else existing.get("password"))
        accounts[index] = {
            "enabled": True,
            "name": _safe_str(body.get("name") or accounts[index].get("name") or "Pandora {}".format(chr(65 + index))).strip(),
            "username": _safe_str(body.get("username") if "username" in body else existing.get("username")).strip(),
            "password": password,
        }
        _setup_cache["pandora_accounts"] = accounts
        pandora_backend.invalidate()
        _save_setup_config()
        return web.json_response({"ok": True, "account": index})
    except Exception as error:
        dbg("Pandora account save failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _restart_all_local_players() -> None:
    rows = _pcp_player_sessions()
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _stop_managed_squeezelite(macs)
    _restart_pcp_main()
    _launch_extra_sessions(rows)
    if len(_wait_for_squeezelite_macs(macs, len(rows), timeout=15)) != len(rows):
        raise RuntimeError("Not all configured players restarted")


def _start_all_local_players() -> Dict[str, Any]:
    rows = _pcp_player_sessions()
    if not rows:
        raise RuntimeError("No configured local players found")
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _restart_pcp_main()
    _launch_extra_sessions(rows)
    running = _wait_for_squeezelite_macs(macs, len(rows), timeout=15)
    if len(running) != len(rows):
        raise RuntimeError("Only {} of {} configured players started".format(len(running), len(rows)))
    return {"players": len(rows)}


def _stop_all_local_players() -> Dict[str, Any]:
    rows = _pcp_player_sessions()
    if not rows:
        raise RuntimeError("No configured local players found")
    macs = {_safe_str(row.get("mac")).lower() for row in rows}
    _stop_managed_squeezelite(macs)
    remaining = _managed_squeezelite_processes(macs)
    if remaining:
        raise RuntimeError("{} configured player process(es) are still running".format(len(remaining)))
    return {"players": len(rows)}


def _schedule_broker_restart() -> None:
    start_script = os.path.join(os.path.dirname(SETUP_JSON_PATH), "start-lyrion-broker-pcp.sh")
    app_dir = os.path.dirname(SETUP_JSON_PATH)
    pid_file = os.path.join(app_dir, "logs", "lyrion-broker.pid")
    log_file = os.path.join(app_dir, "logs", "lyrion-broker-restart.log")
    command = (
        "pid={pid}; start={start}; pidfile={pidfile}; log={log}; "
        "sleep 1; "
        "kill -TERM $pid >/dev/null 2>&1 || true; "
        "for i in 1 2 3 4 5; do kill -0 $pid >/dev/null 2>&1 || break; sleep 1; done; "
        "kill -KILL $pid >/dev/null 2>&1 || true; "
        "rm -f $pidfile; "
        "sleep 1; "
        "$start >> $log 2>&1"
    ).format(
        pid=os.getpid(),
        start=shlex.quote(start_script),
        pidfile=shlex.quote(pid_file),
        log=shlex.quote(log_file),
    )
    subprocess.Popen(
        ["/bin/sh", "-c", command],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _restart_lms_service() -> str:
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors: List[str] = []
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        stop = subprocess.run(
            [script, "stop"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        if stop.returncode != 0:
            errors.append("{} stop: {}".format(script, _safe_str(stop.stdout).strip()[-300:] or "exit {}".format(stop.returncode)))
            continue
        stopped = _wait_lms_http_state(False, timeout=35)
        time.sleep(2.0)
        try:
            start = subprocess.run(
                [script, "start"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=45,
                check=False,
            )
        except subprocess.TimeoutExpired:
            if _wait_lms_http_state(True, timeout=15):
                return "LMS stop/start completed and LMS is responding"
            errors.append("{} start timed out and LMS did not come back".format(script))
            continue
        if start.returncode != 0:
            errors.append("{} start: {}".format(script, _safe_str(start.stdout).strip()[-300:] or "exit {}".format(start.returncode)))
            continue
        started = _wait_lms_http_state(True, timeout=70)
        if stopped and started:
            return "LMS stop/start completed and LMS is responding"
        if not stopped:
            errors.append("{} stop command ran, but LMS did not stop responding".format(script))
        if not started:
            errors.append("{} start command ran, but LMS did not come back".format(script))

    command_sets = (
        ("/bin/systemctl", "restart", "logitechmediaserver"),
        ("/usr/bin/systemctl", "restart", "logitechmediaserver"),
        ("/bin/systemctl", "restart", "lyrionmusicserver"),
        ("/usr/bin/systemctl", "restart", "lyrionmusicserver"),
    )
    for args in command_sets:
        if not os.path.exists(args[0]):
            continue
        result = subprocess.run(
            list(args),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        output = _safe_str(result.stdout).strip()
        if result.returncode == 0:
            return output or "service command completed"
        errors.append("{}: {}".format(" ".join(args), output[-300:] or "exit {}".format(result.returncode)))
    if errors:
        raise RuntimeError("LMS restart failed: " + " | ".join(errors[-3:]))
    raise RuntimeError("No local LMS restart command was found")


def _http_endpoint_up(url: str, timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            response.read(256)
            return response.status < 500
    except Exception:
        return False


def _wait_lms_http_state(want_up: bool, timeout: float, url: str = "") -> bool:
    target_url = url or LMS_BASE
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _http_endpoint_up(target_url, timeout=1.5) == want_up:
            return True
        time.sleep(1.0)
    return False


def _start_local_lms() -> str:
    try:
        _pcp_lms_action("Start")
        if _wait_lms_http_state(True, timeout=70, url=LOCAL_LMS_BASE):
            return "pCP LMS start completed and LMS is responding"
    except Exception as error:
        pcp_error = error
    else:
        pcp_error = RuntimeError("pCP Start was requested, but local LMS did not respond")
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors = [_safe_str(pcp_error)]
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        result = subprocess.run(
            [script, "start"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=45,
            check=False,
        )
        if result.returncode == 0 and _wait_lms_http_state(True, timeout=70, url=LOCAL_LMS_BASE):
            return "LMS start completed and LMS is responding"
        errors.append("{} start: {}".format(script, _safe_str(result.stdout).strip()[-300:] or "exit {}".format(result.returncode)))
    raise RuntimeError("LMS start failed: " + " | ".join(errors[-3:]))


def _stop_local_lms() -> str:
    try:
        _pcp_lms_action("Stop")
        if _wait_lms_http_state(False, timeout=35, url=LOCAL_LMS_BASE):
            return "pCP LMS stop completed"
    except Exception as error:
        pcp_error = error
    else:
        pcp_error = RuntimeError("pCP Stop was requested, but local LMS still responded")
    init_scripts = (
        "/usr/local/etc/init.d/slimserver",
        "/usr/local/etc/init.d/logitechmediaserver",
        "/etc/init.d/logitechmediaserver",
        "/etc/init.d/lyrionmusicserver",
        "/etc/init.d/slimserver",
    )
    errors = [_safe_str(pcp_error)]
    for script in init_scripts:
        if not os.path.exists(script):
            continue
        result = subprocess.run(
            [script, "stop"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=35,
            check=False,
        )
        if result.returncode == 0 and _wait_lms_http_state(False, timeout=35, url=LOCAL_LMS_BASE):
            return "LMS stop completed"
        errors.append("{} stop: {}".format(script, _safe_str(result.stdout).strip()[-300:] or "exit {}".format(result.returncode)))
    raise RuntimeError("LMS stop failed: " + " | ".join(errors[-3:]))


def _pcp_lms_action(action: str) -> str:
    url = "http://127.0.0.1/cgi-bin/lms.cgi?ACTION={}".format(
        urllib.parse.quote(action)
    )
    with urllib.request.urlopen(url, timeout=15) as response:
        body = response.read(4096)
        if response.status >= 400:
            raise RuntimeError("pCP LMS {} returned HTTP {}".format(action, response.status))
        return body.decode("utf-8", errors="replace")


def _restart_lms_via_pcp_stop_start() -> str:
    _pcp_lms_action("Stop")
    stopped = _wait_lms_http_state(False, timeout=35)
    if not stopped:
        raise RuntimeError("pCP Stop was requested, but LMS did not stop responding on {}".format(LMS_BASE))
    time.sleep(2.0)
    _pcp_lms_action("Start")
    started = _wait_lms_http_state(True, timeout=70)
    if not started:
        raise RuntimeError("pCP Start was requested, but LMS did not come back on {}".format(LMS_BASE))
    return "pCP Stop/Start completed and LMS is responding"


def _restore_broker_archive(name: str) -> None:
    backup_dir = os.path.join(_update_root_dir(), "backups")
    if not re.fullmatch(r"broker-[A-Za-z0-9_.-]+\.tgz", name):
        raise ValueError("Invalid rollback archive")
    path = os.path.abspath(os.path.join(backup_dir, name))
    if os.path.dirname(path) != os.path.abspath(backup_dir) or not os.path.isfile(path):
        raise ValueError("Rollback archive was not found")
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    allowed_roots = {
        "lyrion_broker.py", "pandora_backend.py", "requirements.txt",
        "start-lyrion-broker-pcp.sh", "pandora_plugins", "web_assets",
    }
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            clean = member.name.replace("\\", "/").lstrip("./")
            root = clean.split("/", 1)[0]
            if (
                not clean or root not in allowed_roots or ".." in clean.split("/")
                or member.issym() or member.islnk()
                or not (member.isfile() or member.isdir())
            ):
                raise RuntimeError("Unsafe rollback archive entry: {}".format(member.name))
        for member in members:
            clean = member.name.replace("\\", "/").lstrip("./")
            target = os.path.abspath(os.path.join(app_dir, clean))
            if os.path.commonpath((app_dir, target)) != app_dir:
                raise RuntimeError("Unsafe rollback path")
            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError("Could not read rollback entry")
            with source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
            os.chmod(target, member.mode & 0o777)


async def api_system_action(req: web.Request) -> web.Response:
    global _cometd_client_id, _cometd_connected, _cometd_response_channel
    try:
        body = await req.json()
        action = _safe_str(body.get("action")).strip().lower()
        if action == "restart_players":
            await asyncio.to_thread(_restart_all_local_players)
            return web.json_response({"ok": True, "message": "Local players restarted."})
        if action == "restart_lms":
            _cometd_client_id = ""
            _cometd_connected = False
            _cometd_response_channel = ""
            try:
                output = await asyncio.to_thread(_restart_lms_service)
                return web.json_response({
                    "ok": True,
                    "message": "LMS restart command completed. Broker will reconnect shortly. {}".format(output[-180:]),
                })
            except Exception as service_error:
                output = await asyncio.to_thread(_restart_lms_via_pcp_stop_start)
                return web.json_response({
                    "ok": True,
                    "message": "LMS service restart was unavailable ({}). {}. Broker will reconnect shortly.".format(
                        _safe_str(service_error),
                        output,
                    ),
                })
        if action == "restart_broker":
            _schedule_broker_restart()
            return web.json_response({"ok": True, "message": "Broker restart requested."})
        if action == "reboot":
            subprocess.Popen(
                ["/bin/sh", "-c", "sleep 2; /sbin/reboot"],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, start_new_session=True,
            )
            return web.json_response({"ok": True, "message": "Device reboot requested."})
        if action == "rollback_broker":
            archive = _safe_str(body.get("archive")).strip()
            await asyncio.to_thread(_backup_current_install)
            await asyncio.to_thread(_restore_broker_archive, archive)
            _schedule_broker_restart()
            return web.json_response({"ok": True, "message": "Rollback installed; broker is restarting."})
        raise ValueError("Unknown system action")
    except Exception as error:
        dbg("System action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


def _html_input_value(tag: str, name: str) -> str:
    match = re.search(
        r'\b' + re.escape(name) + r'\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))',
        tag,
        flags=re.I,
    )
    if not match:
        return ""
    return html_lib.unescape(next((group for group in match.groups() if group is not None), ""))


def _lms_plugin_checkbox_fields(page: str, target_plugin_id: str, enable_target: bool) -> List[Tuple[str, str]]:
    fields: List[Tuple[str, str]] = []
    seen: set[str] = set()
    target = _safe_str(target_plugin_id).strip()
    for tag in re.findall(r'<input\b[^>]*>', page, flags=re.I | re.S):
        input_type = _html_input_value(tag, "type").lower()
        name = _html_input_value(tag, "name").strip()
        input_id = _html_input_value(tag, "id").strip()
        if input_type != "checkbox" or not name or name != input_id:
            continue
        checked = bool(re.search(r"\bchecked\b", tag, flags=re.I))
        if name == target:
            checked = enable_target
        if not checked or name in seen:
            continue
        value = _html_input_value(tag, "value").strip() or name
        fields.append((name, value))
        seen.add(name)
    if enable_target and target and target not in seen:
        fields.append((target, target))
    return fields


def _lms_plugin_base_fields(
    page: str,
    *,
    force_unsupported: bool = False,
    extra_repo_urls: Optional[List[str]] = None,
) -> List[Tuple[str, str]]:
    rand_match = re.search(r'<input[^>]+name="rand"[^>]+value="([^"]+)"', page, flags=re.I)
    if rand_match is None:
        rand_match = re.search(r'<input[^>]+value="([^"]+)"[^>]+name="rand"', page, flags=re.I)
    if rand_match is None:
        raise RuntimeError("LMS plugin security token was not found")

    fields: List[Tuple[str, str]] = [
        ("saveSettings", "1"),
        ("rand", html_lib.unescape(rand_match.group(1))),
    ]
    repo_values: List[str] = []
    saw_repo_input = False
    for tag in re.findall(r'<input\b[^>]*>', page, flags=re.I | re.S):
        if _html_input_value(tag, "name") == "repos":
            saw_repo_input = True
            value = _html_input_value(tag, "value").strip()
            if value:
                repo_values.append(value)
    for value in re.findall(r'<textarea[^>]+name="repos"[^>]*>(.*?)</textarea>', page, flags=re.I | re.S):
        saw_repo_input = True
        clean = html_lib.unescape(re.sub(r"<[^>]+>", "", value)).strip()
        if clean:
            repo_values.append(clean)
    normalized_repos = _normalize_repo_values(repo_values)
    extra_repos = [_safe_str(repo_url).strip() for repo_url in (extra_repo_urls or []) if _safe_str(repo_url).strip()]
    if any(_repo_is_pandora_repository(repo_url) for repo_url in extra_repos):
        normalized_repos = [
            repo_url for repo_url in normalized_repos
            if not _repo_is_pandora_repository(repo_url)
        ]
    for clean_url in extra_repos:
        if clean_url and not _repo_values_contain(normalized_repos, clean_url):
            normalized_repos.append(clean_url)
    if normalized_repos:
        fields.append(("repos", "\n".join(normalized_repos)))
    elif saw_repo_input:
        fields.append(("repos", ""))

    auto_match = re.search(
        r'<select[^>]+name="auto"[^>]*>.*?<option[^>]+value="([^"]+)"[^>]*selected',
        page,
        flags=re.I | re.S,
    )
    if auto_match is None:
        auto_match = re.search(
            r'<select[^>]+name="auto"[^>]*>.*?<option[^>]+selected[^>]+value="([^"]+)"',
            page,
            flags=re.I | re.S,
        )
    fields.append(("auto", auto_match.group(1) if auto_match else "0"))
    unsupported = re.search(
        r'<input(?=[^>]+name="useUnsupported")[^>]*checked',
        page,
        flags=re.I | re.S,
    )
    if unsupported or force_unsupported:
        fields.append(("useUnsupported", "1"))
    return fields


async def _post_lms_plugin_page(fields: List[Tuple[str, str]]) -> None:
    await lms.start()
    assert lms._session is not None
    encoded = urllib.parse.urlencode(fields, doseq=True)
    url = LMS_BASE.rstrip("/") + "/Default/settings/server/plugins.html"
    async with lms._session.post(
        url,
        data=encoded,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    ) as response:
        await response.read()
        if response.status != 200:
            raise RuntimeError("LMS plugin manager returned HTTP {}".format(response.status))


async def _ensure_pandora_repository_configured() -> Dict[str, Any]:
    page = await _lms_plugin_manager_html()
    repository = _pandora_repository_url()
    repo_values: List[str] = []
    for tag in re.findall(r'<input\b[^>]*>', page, flags=re.I | re.S):
        if _html_input_value(tag, "name") == "repos":
            value = _html_input_value(tag, "value").strip()
            if value:
                repo_values.append(value)
    for value in re.findall(r'<textarea[^>]+name="repos"[^>]*>(.*?)</textarea>', page, flags=re.I | re.S):
        clean = html_lib.unescape(re.sub(r"<[^>]+>", "", value)).strip()
        if clean:
            repo_values.append(clean)
    current_repos = _normalize_repo_values(repo_values)
    pandora_repos = [repo_url for repo_url in current_repos if _repo_is_pandora_repository(repo_url)]
    # A cloned appliance or DHCP change can leave the previous broker address in
    # LMS.  Keep exactly one broker-owned Pandora repository: the URL currently
    # reachable from the selected LMS server.  _lms_plugin_base_fields preserves
    # every unrelated repository while replacing all older Pandora URLs.
    if _repo_values_contain(current_repos, repository) and len(pandora_repos) == 1:
        return {"ok": True, "changed": False, "repository": repository}
    fields = _lms_plugin_base_fields(page, extra_repo_urls=[repository])
    await _post_lms_plugin_page(fields)
    return {
        "ok": True,
        "changed": True,
        "repository": repository,
        "replaced_repository_count": len(pandora_repos),
    }


async def api_pandora_ensure_repository(_req: web.Request) -> web.Response:
    try:
        return web.json_response(await _ensure_pandora_repository_configured())
    except Exception as error:
        dbg("Pandora repository ensure failed: {}".format(_safe_str(error)))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_system_plugin(req: web.Request) -> web.Response:
    try:
        body = await req.json()
        plugin_id = _safe_str(body.get("plugin")).strip()
        enable = bool(body.get("enable"))
        curated_ids = {item[0] for item in CURATED_LMS_PLUGINS}
        if plugin_id not in curated_ids:
            raise ValueError("Plugin is not in the curated Lyrion Gadget list")

        page = await _lms_plugin_manager_html()
        catalog = _parse_lms_plugin_catalog(page)
        label = next((name for cur_id, name in CURATED_LMS_PLUGINS if cur_id == plugin_id), plugin_id)
        plugin = catalog.get(plugin_id) or _broker_owned_plugin_catalog_entry(plugin_id, label)
        if not isinstance(plugin, dict):
            if plugin_id == "ShairTunes2W":
                raise ValueError("ShairTunes2W is not available from LMS yet. Restart LMS or add the ShairTunes plugin repository, then refresh this page.")
            raise ValueError("Plugin is not available from the configured LMS repositories")
        action_type = _safe_str(plugin.get("action_type")).lower()
        if action_type not in ("manual", "install"):
            raise RuntimeError("LMS did not expose a safe management action for this plugin")
        current_state = _safe_str(plugin.get("state")).lower()
        if enable and current_state == "active":
            home_changed = False
            if _is_airplay_service_item(plugin_id, label):
                home_changed = False
            elif _plugin_placement_managed_by_lms(plugin_id):
                home_changed = _set_lms_managed_plugin_visible(plugin_id, label, True)
            else:
                home_target = bool(enable and _curated_plugin_home_default_enabled(plugin_id, label))
                home_changed = _set_curated_plugin_home_enabled(plugin_id, home_target, label)
            return web.json_response({
                "ok": True,
                "message": "{} is already active.".format(plugin_id),
                "home_menu_changed": home_changed,
            })
        if not enable and current_state != "active":
            if _is_airplay_service_item(plugin_id, label):
                home_changed = False
            elif _plugin_placement_managed_by_lms(plugin_id):
                home_changed = _set_lms_managed_plugin_visible(plugin_id, label, False)
            else:
                home_changed = _set_curated_plugin_home_enabled(plugin_id, False, label)
            return web.json_response({
                "ok": True,
                "message": "{} is already inactive.".format(plugin_id),
                "home_menu_changed": home_changed,
            })

        fields = _lms_plugin_base_fields(
            page,
            extra_repo_urls=[_pandora_repository_url()] if enable and _pandora_account_index(plugin_id) >= 0 else [],
        )
        fields.append(("{}:{}".format(action_type, plugin_id), ""))
        fields.extend(_lms_plugin_checkbox_fields(page, plugin_id, enable))

        await _post_lms_plugin_page(fields)
        home_changed = False
        if _is_airplay_service_item(plugin_id, label):
            home_changed = False
        elif _plugin_placement_managed_by_lms(plugin_id):
            home_changed = _set_lms_managed_plugin_visible(plugin_id, label, bool(enable))
        else:
            home_target = bool(enable and _curated_plugin_home_default_enabled(plugin_id, label))
            home_changed = _set_curated_plugin_home_enabled(plugin_id, home_target, label)
        return web.json_response({
            "ok": True,
            "message": "{} requested for {}. When LMS asks to restart, select Apply/Reboot and wait for the broker to reconnect before opening plugin settings.".format(
                "Install/enable" if enable else "Disable", plugin_id
            ),
            "restart_required": True,
            "home_menu_changed": home_changed,
        })
    except Exception as error:
        dbg("Curated plugin action failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def api_system_backup(req: web.Request) -> web.Response:
    output = io.BytesIO()
    app_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for source, arcname in (
            (SETUP_JSON_PATH, "broker_setup.json"),
            (PCP_CONFIG_PATH, "pcp.cfg"),
        ):
            if os.path.isfile(source):
                archive.add(source, arcname=arcname, recursive=False)
        for path in (
            "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
            "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
        ):
            if os.path.isfile(path):
                archive.add(path, arcname="SlimDiscovery.lua", recursive=False)
                break
    filename = "lyrion-gadget-config-{}-{}.tgz".format(
        _safe_str(_read_pcp_config().get("HOST") or "pcp"),
        int(time.time()),
    )
    return web.Response(
        body=output.getvalue(),
        content_type="application/gzip",
        headers={"Content-Disposition": 'attachment; filename="{}"'.format(filename)},
    )


def _restore_configuration_archive(data: bytes) -> None:
    current_dir = os.path.dirname(os.path.abspath(SETUP_JSON_PATH))
    backup_dir = os.path.join(current_dir, "backups")
    os.makedirs(backup_dir, exist_ok=True)
    stamp = int(time.time())
    if os.path.isfile(SETUP_JSON_PATH):
        shutil.copyfile(SETUP_JSON_PATH, os.path.join(backup_dir, "broker_setup.json.{}".format(stamp)))
    if os.path.isfile(PCP_CONFIG_PATH):
        shutil.copyfile(PCP_CONFIG_PATH, os.path.join(backup_dir, "pcp.cfg.{}".format(stamp)))

    files: Dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive.getmembers():
            clean = member.name.replace("\\", "/").lstrip("./")
            if clean not in ("broker_setup.json", "pcp.cfg", "SlimDiscovery.lua") or not member.isfile():
                raise RuntimeError("Unsupported configuration backup entry: {}".format(member.name))
            source = archive.extractfile(member)
            if source is not None:
                files[clean] = source.read()
    if "broker_setup.json" not in files or "pcp.cfg" not in files:
        raise RuntimeError("Backup must contain broker_setup.json and pcp.cfg")
    json.loads(files["broker_setup.json"].decode("utf-8"))
    files["pcp.cfg"].decode("utf-8")

    with open(SETUP_JSON_PATH + ".restore", "wb") as handle:
        handle.write(files["broker_setup.json"])
    os.replace(SETUP_JSON_PATH + ".restore", SETUP_JSON_PATH)
    with open(PCP_CONFIG_PATH + ".restore", "wb") as handle:
        handle.write(files["pcp.cfg"])
    os.replace(PCP_CONFIG_PATH + ".restore", PCP_CONFIG_PATH)
    if "SlimDiscovery.lua" in files:
        for path in (
            "/home/tc/.jivelite/userpath-vis/settings/SlimDiscovery.lua",
            "/home/tc/.jivelite/userpath/settings/SlimDiscovery.lua",
        ):
            if os.path.isfile(path):
                with open(path, "wb") as handle:
                    handle.write(files["SlimDiscovery.lua"])
                break
    subprocess.run(["/usr/bin/filetool.sh", "-b"], timeout=60, check=True)


async def api_system_restore(req: web.Request) -> web.Response:
    try:
        reader = await req.multipart()
        part = await reader.next()
        if part is None or part.name != "backup":
            raise ValueError("Configuration backup file is required")
        data = bytearray()
        while True:
            chunk = await part.read_chunk(65536)
            if not chunk:
                break
            data.extend(chunk)
            if len(data) > 5 * 1024 * 1024:
                raise ValueError("Configuration backup exceeds 5 MB")
        await asyncio.to_thread(_restore_configuration_archive, bytes(data))
        _load_setup_config()
        await asyncio.to_thread(_restart_all_local_players)
        return web.json_response({"ok": True, "message": "Configuration restored and local players restarted."})
    except Exception as error:
        dbg("Configuration restore failed: {}".format(error))
        return web.json_response({"ok": False, "error": _safe_str(error)}, status=400)


async def setup_advanced_page(_req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(_req):
        raise web.HTTPFound("/setup/advanced/login")
    advanced_level = _advanced_setup_level(_req)
    _load_setup_config()
    saved_public = _safe_str(_setup_cache.get("public_lms_base"))
    update_manifest_url = _safe_str(
        _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL
    )
    configured_hostname = _pcp_config_hostname()
    advanced_hostname = _default_unit_hostname() if _is_generic_hostname(configured_hostname) else configured_hostname
    pcp_base = _same_host_http_base(_req, 80)
    rollback_options = "".join(
        '<option value="{name}">{name}</option>'.format(name=_html_escape(row["name"]))
        for row in _broker_rollback_archives()
    )
    track_checked = " checked" if bool(_setup_cache.get("track_drilldown", False)) else ""
    hide_spotty_transfer_checked = " checked" if bool(_setup_cache.get("hide_spotty_transfer_playback", True)) else ""
    card_art_checked = " checked" if bool(_setup_cache.get("web_panel_card_art", False)) else ""
    broker_bg = _effective_broker_panel_color("bg", "#135093")
    broker_content_bg = _effective_broker_panel_color("content_bg", "#0e52a5")
    broker_accent = _effective_broker_panel_color("accent", "#ffffff")
    default_mode = _safe_panel_mode(_setup_cache.get("web_panel_default_mode"))
    mode_options = "".join(
        '<option value="{value}"{selected}>{label}</option>'.format(
            value=value,
            selected=" selected" if value == default_mode else "",
            label=label,
        )
        for value, label in (("control", "Control + Browse"), ("browse", "Browse Only"))
    )
    try:
        players = _rti_connected_players(await lms.get_players())
    except Exception:
        players = []
    broker_url_rows: List[str] = []
    base = "{}://{}:{}".format(_req.scheme, _req.host.split(":", 1)[0], LISTEN_PORT)
    for p in players:
        pid = _safe_str(p.get("playerid")).strip().lower()
        if not pid:
            continue
        name = _safe_str(p.get("name") or pid)
        control = "{}/panel/control?playerid={}".format(base, urllib.parse.quote(pid, safe=""))
        browse = "{}/panel/browse?playerid={}".format(base, urllib.parse.quote(pid, safe=""))
        broker_url_rows.append("""
        <tr>
          <td>{name}</td>
          <td><code>{pid}</code></td>
          <td><a href="{control}">{control}</a></td>
          <td><a href="{browse}">{browse}</a></td>
        </tr>
        """.format(
            name=_html_escape(name),
            pid=_html_escape(pid),
            control=_html_escape(control),
            browse=_html_escape(browse),
        ))
    if not broker_url_rows:
        broker_url_rows.append('<tr><td colspan="4" style="color:#666;">No connected players found.</td></tr>')
    if advanced_level < 2:
        advanced_settings_form = """
  <section class="quick-links">
    <h3>Advanced Level 2</h3>
    <div style="font-size:13px;color:#596579;">
      Enter the level 2 password to show broker webpage controls, playback behavior, Spotty menu cleanup,
      public LMS base, and broker control/browse URLs.
    </div>
  </section>
"""
    elif _broker_light_mode():
        advanced_settings_form = """
  <section class="quick-links">
    <h3>Broker Light Advanced</h3>
    <div style="font-size:13px;color:#596579;">
      Broker Light keeps advanced settings focused on identity, updates, rollback, and remote-player setup.
      Full broker-only browse controls are hidden on player-only units.
    </div>
  </section>
"""
    else:
        advanced_settings_form = """
  <form method="post" action="/api/setup/advanced">
    <h3>Broker Webpages</h3>
    <div style="font-size:12px;color:#666;margin-bottom:10px;">
      Material remains the recommended web object path. These controls tune the broker-served control and browse pages.
    </div>
    <label>Default broker page:
      <select name="web_panel_default_mode">__MODE_OPTIONS__</select>
    </label>
    <label style="display:block;margin-top:10px;">Broker background:
      <input type="color" name="web_panel_broker_bg" value="__BROKER_BG__">
      <code>__BROKER_BG__</code>
    </label>
    <label style="display:block;margin-top:10px;">Broker content:
      <input type="color" name="web_panel_broker_content_bg" value="__BROKER_CONTENT_BG__">
      <code>__BROKER_CONTENT_BG__</code>
    </label>
    <label style="display:block;margin-top:10px;">Broker accent:
      <input type="color" name="web_panel_broker_accent" value="__BROKER_ACCENT__">
      <code>__BROKER_ACCENT__</code>
    </label>
    <label style="display:block;margin-top:10px;"><input type="checkbox" name="web_panel_card_art" value="1"__CARD_ART__> Show blurred artwork behind broker thumbnail cards</label>

    <h3 style="margin-top:22px;">Broker Panel URLs</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">These URLs use the broker-served control and browse pages instead of Material Skin.</div>
    <table>
      <thead><tr><th>Player</th><th>MAC</th><th>Control URL</th><th>Browse URL</th></tr></thead>
      <tbody>__BROKER_URL_ROWS__</tbody>
    </table>

    <h3>Playable Track Behavior</h3>
    <label><input type="checkbox" name="track_drilldown"__TRACK_CHECKED__> Drill down when selecting playable tracks</label>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      When off, selecting a playable track makes it the target so the RTI driver's Select Action can apply.
    </div>

    <h3 style="margin-top:22px;">Spotty Menu</h3>
    <label><input type="checkbox" name="hide_spotty_transfer_playback"__HIDE_SPOTTY_TRANSFER_CHECKED__> Hide Transfer Playback row</label>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Hides Spotty's Transfer Playback menu item from RTI. Leave enabled unless you need Spotify Connect transfer controls in this project.
    </div>

    <h3 style="margin-top:22px;">Public LMS Base for Art/Icons</h3>
    <input type="text" name="public_lms_base" value="__SAVED_PUBLIC__" placeholder="http://lyriongadget.local:9000" style="width:420px;max-width:100%;padding:6px;box-sizing:border-box;">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      Optional. Use this when LMS_BASE is loopback or not reachable by RTI panels. Relative art and icon paths are rewritten against this base.
    </div>

    <h3 style="margin-top:22px;">Material Layer Repair</h3>
    <div style="font-size:12px;color:#666;margin-top:6px;">
      The broker installs/refreshes the Material layer during normal startup and Web Panel saves. Use this only as a repair button.
    </div>
    <button type="button" id="materialInstallBtn" style="margin-top:8px;padding:8px 14px;">Repair Material Layer</button>
    <span id="materialInstallStatus" style="margin-left:10px;color:#555;"></span>

    <div style="margin-top:18px;">
      <button type="submit" style="padding:8px 14px;">Save Advanced Settings</button>
    </div>
  </form>
"""
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Broker Advanced Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell">
  <h2>Lyrion Broker Advanced Setup</h2>
  <div class="page-nav"><a href="/setup/players">Local Players</a><a href="/setup">Setup</a>__WEB_NAV__<a href="/setup/system">System</a><b>Advanced</b><a href="/setup/advanced/logout">Logout</a></div>

  <section class="quick-links">
    <h3>Device Hostname</h3>
    <div style="font-size:13px;color:#596579;line-height:1.45;margin-bottom:10px;">
      Normal units should use the automatic <code>Lyrion####</code> identity from the unit MAC. Change this only for recovery or a special install.
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
      <label>Hostname
        <input id="advancedHostname" type="text" maxlength="26" pattern="[A-Za-z0-9-]+" value="__ADVANCED_HOSTNAME__">
      </label>
      <button id="saveAdvancedHostname" type="button" style="padding:8px 14px;">Save Hostname</button>
    </div>
    <div id="advancedHostnameStatus" style="margin-top:10px;color:#596579;">Default for this unit: <code>__DEFAULT_HOSTNAME__</code></div>
  </section>

  <section class="quick-links">
    <h3>pCP Advanced Interface</h3>
    <div style="font-size:13px;color:#596579;line-height:1.45;margin-bottom:10px;">
      The unit root page opens Lyrion Gadget. Use this link when you need the underlying piCorePlayer controls.
    </div>
    <a href="__PCP_BASE__/cgi-bin/about.cgi" target="_blank" rel="noopener"><button type="button">Open pCP Advanced</button></a>
  </section>

  __ADVANCED_SETTINGS_FORM__

  <section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:20px;">
    <h3>Broker Update</h3>
    <label for="updateManifestUrl">Update manifest URL</label>
    <input id="updateManifestUrl" type="url" value="__UPDATE_MANIFEST_URL__" placeholder="https://raw.githubusercontent.com/.../update.json"
           style="display:block;width:620px;max-width:100%;padding:7px;box-sizing:border-box;margin-top:6px;">
    <div style="font-size:12px;color:#666;margin-top:6px;">
      The default points to the public Lyrion Gadget GitHub release feed. Packages install only after their SHA-256 matches the manifest.
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">
      <button id="checkUpdate" type="button" style="padding:8px 14px;">Check for Updates</button>
      <button id="installUpdate" type="button" style="padding:8px 14px;" disabled>Download and Install</button>
    </div>
    <pre id="updateStatus" style="white-space:pre-wrap;background:#eef2f5;border:1px solid #ccd4dc;border-radius:6px;padding:10px;margin-top:12px;">Current broker version: __APP_VERSION__ | Advanced level: __ADVANCED_LEVEL__</pre>
  </section>

  <section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:20px;">
    <h3>Broker Rollback</h3>
    <div style="font-size:12px;color:#666;margin-bottom:8px;">
      Restore a broker package backup created before an update. Configuration backups stay on the System page.
    </div>
    <select id="rollbackArchive"><option value="">Select a previous broker backup</option>__ROLLBACK_OPTIONS__</select>
    <button id="rollbackButton" type="button" style="padding:8px 14px;">Roll Back Broker</button>
    <div id="rollbackStatus" style="margin-top:10px;color:#596579;"></div>
  </section>
  </main>
  <script>
  (function () {
    var checkButton = document.getElementById("checkUpdate");
    var installButton = document.getElementById("installUpdate");
    var statusBox = document.getElementById("updateStatus");
    var manifestInput = document.getElementById("updateManifestUrl");
    var rollbackButton = document.getElementById("rollbackButton");
    var rollbackStatus = document.getElementById("rollbackStatus");
    var hostnameButton = document.getElementById("saveAdvancedHostname");
    var hostnameStatus = document.getElementById("advancedHostnameStatus");
    var materialInstallButton = document.getElementById("materialInstallBtn");

    hostnameButton.addEventListener("click", async function () {
      hostnameButton.disabled = true;
      hostnameStatus.textContent = "Saving hostname...";
      hostnameStatus.style.color = "#596579";
      try {
        var response = await fetch("/api/setup/system-identity", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({hostname: document.getElementById("advancedHostname").value})
        });
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Hostname update failed");
        hostnameStatus.style.color = "#18794e";
        hostnameStatus.textContent = data.reboot_required
          ? "Hostname saved. Reboot the device for pCP/network discovery to fully use it."
          : "Hostname saved.";
      } catch (error) {
        hostnameStatus.style.color = "#b42318";
        hostnameStatus.textContent = error.message;
      } finally {
        hostnameButton.disabled = false;
      }
    });

    async function saveManifestUrl() {
      var body = {
        update_manifest_url: manifestInput.value.trim()
      };
      var response = await fetch("/api/setup/advanced", {
        method: "POST",
        credentials: "same-origin",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(body)
      });
      if (!response.ok) throw new Error("Could not save update URL");
    }

    checkButton.addEventListener("click", async function () {
      installButton.disabled = true;
      statusBox.textContent = "Checking for updates...";
      try {
        await saveManifestUrl();
        var response = await fetch("/api/update/check", {credentials: "same-origin"});
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Update check failed");
        statusBox.textContent =
          "Installed: " + data.current_version + "\\n" +
          "Available: " + data.version + "\\n" +
          (data.notes ? "\\n" + data.notes : "") +
          (data.available ? "\\n\\nUpdate is ready to install." : "\\n\\nNo newer update is available.");
        installButton.disabled = !data.available;
      } catch (error) {
        statusBox.textContent = "Update check failed: " + error.message;
      }
    });

    installButton.addEventListener("click", async function () {
      if (!window.confirm("Install this broker update now? Playback control will briefly disconnect.")) return;
      checkButton.disabled = true;
      installButton.disabled = true;
      statusBox.textContent = "Downloading and verifying update...";
      try {
        var response = await fetch("/api/update/install", {
          method: "POST",
          credentials: "same-origin"
        });
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Install failed");
        statusBox.textContent = data.message + "\\nWaiting for broker " + data.target_version + "...";
        var attempts = 0;
        var timer = window.setInterval(async function () {
          attempts += 1;
          try {
            var health = await fetch("/health?update=" + Date.now(), {cache: "no-store"});
            var result = await health.json();
            if (result.ver === data.target_version) {
              window.clearInterval(timer);
              statusBox.textContent = "Update complete. Broker version " + result.ver + " is running.";
              window.setTimeout(function () {
                window.location.replace("/setup/advanced?updated=" + Date.now());
              }, 500);
            }
          } catch (_) {}
          if (attempts > 90) {
            window.clearInterval(timer);
            statusBox.textContent += "\\nRestart is taking longer than expected. Refresh this page in a minute.";
          }
        }, 2000);
      } catch (error) {
        statusBox.textContent = "Install failed: " + error.message;
        checkButton.disabled = false;
      }
    });

    rollbackButton.addEventListener("click", async function () {
      var archive = document.getElementById("rollbackArchive").value;
      if (!archive) {
        rollbackStatus.textContent = "Select a rollback archive.";
        return;
      }
      if (!window.confirm("Replace the running broker with " + archive + "?")) return;
      rollbackButton.disabled = true;
      rollbackStatus.textContent = "Installing rollback...";
      try {
        var response = await fetch("/api/system/action", {
          method: "POST",
          credentials: "same-origin",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({action: "rollback_broker", archive: archive})
        });
        var data = await response.json();
        if (!data.ok) throw new Error(data.error || "Rollback failed");
        rollbackStatus.textContent = data.message || "Rollback installed; broker is restarting.";
      } catch (error) {
        rollbackStatus.textContent = error.message;
        rollbackButton.disabled = false;
      }
    });

    if (materialInstallButton) {
      materialInstallButton.addEventListener("click", async function () {
        var status = document.getElementById("materialInstallStatus");
        materialInstallButton.disabled = true;
        status.textContent = "Repairing...";
        try {
          var response = await fetch("/api/setup/material-skin", {method: "POST", credentials: "same-origin"});
          var data = await response.json();
          if (!response.ok || !data.ok) throw new Error(data.error || ("HTTP " + response.status));
          status.textContent = "Installed to " + data.path;
        } catch (error) {
          status.textContent = error.message;
        } finally {
          materialInstallButton.disabled = false;
        }
      });
    }
  }());
  </script>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION))
        .replace("__WEB_NAV__", _setup_web_nav_link(False))
        .replace("__ADVANCED_SETTINGS_FORM__", advanced_settings_form)
        .replace("__APP_VERSION__", _html_escape(APP_VERSION))
        .replace("__ADVANCED_LEVEL__", str(advanced_level))
        .replace("__ADVANCED_HOSTNAME__", _html_escape(advanced_hostname))
        .replace("__DEFAULT_HOSTNAME__", _html_escape(_default_unit_hostname()))
        .replace("__PCP_BASE__", _html_escape(pcp_base))
        .replace("__TRACK_CHECKED__", track_checked)
        .replace("__HIDE_SPOTTY_TRANSFER_CHECKED__", hide_spotty_transfer_checked)
        .replace("__SAVED_PUBLIC__", _html_escape(saved_public))
        .replace("__MODE_OPTIONS__", mode_options)
        .replace("__BROKER_BG__", _html_escape(broker_bg))
        .replace("__BROKER_CONTENT_BG__", _html_escape(broker_content_bg))
        .replace("__BROKER_ACCENT__", _html_escape(broker_accent))
        .replace("__CARD_ART__", card_art_checked)
        .replace("__BROKER_URL_ROWS__", "".join(broker_url_rows))
        .replace("__UPDATE_MANIFEST_URL__", _html_escape(update_manifest_url))
        .replace("__ROLLBACK_OPTIONS__", rollback_options)
    )
    return web.Response(text=html, content_type="text/html")


def _advanced_auth_token(level: int = 1) -> str:
    level = 2 if int(level or 1) >= 2 else 1
    password = ADVANCED_SETUP_PASSWORD_LEVEL2 if level >= 2 else ADVANCED_SETUP_PASSWORD
    return hashlib.sha256(
        ("lyrion-advanced-setup:{}:{}".format(level, password)).encode("utf-8")
    ).hexdigest()


def _advanced_setup_level(req: web.Request) -> int:
    supplied = _safe_str(req.cookies.get(ADVANCED_AUTH_COOKIE))
    if supplied and hmac.compare_digest(supplied, _advanced_auth_token(2)):
        return 2
    if supplied and hmac.compare_digest(supplied, _advanced_auth_token(1)):
        return 1
    return 0


def _advanced_setup_authorized(req: web.Request, min_level: int = 1) -> bool:
    return _advanced_setup_level(req) >= int(min_level or 1)


def _safe_setup_next(value: Any) -> str:
    text = _safe_str(value).strip()
    if not text.startswith("/"):
        return "/setup"
    if text.startswith("//"):
        return "/setup"
    if re.search(r"[\r\n]", text):
        return "/setup"
    return text


def _setup_auth_required(path: str) -> bool:
    if path in ("/setup/advanced/login", "/setup/advanced/logout"):
        return False
    if path == "/api/setup/session":
        return False
    if path.startswith("/setup/assets/"):
        return False
    if path == "/":
        return True
    if path.startswith("/setup"):
        return True
    if path.startswith("/api/setup"):
        return True
    if path.startswith("/api/update"):
        return True
    if path in (
        "/api/lms_root",
        "/api/mymusic_menu",
        "/api/radio_menu",
        "/api/system/action",
        "/api/system/plugin",
        "/api/system/backup",
        "/api/system/restore",
        "/api/pandora/account",
        "/api/pandora/ensure-repository",
    ):
        return True
    return False


@web.middleware
async def setup_auth_middleware(req: web.Request, handler: Any) -> web.StreamResponse:
    if _setup_auth_required(req.path) and not _advanced_setup_authorized(req):
        if req.path.startswith("/api/") or req.method not in ("GET", "HEAD"):
            target = _safe_setup_next(str(req.rel_url))
            return web.json_response(
                {
                    "ok": False,
                    "auth_required": True,
                    "error": "Setup session expired. Sign in again to continue.",
                    "login_url": "/setup/advanced/login?next={}".format(
                        urllib.parse.quote(target, safe="")
                    ),
                },
                status=401,
            )
        target = urllib.parse.quote(_safe_setup_next(str(req.rel_url)), safe="")
        raise web.HTTPFound("/setup/advanced/login?next={}".format(target))
    return await handler(req)


async def api_setup_session(req: web.Request) -> web.Response:
    level = _advanced_setup_level(req)
    return web.json_response(
        {
            "ok": level > 0,
            "logged_in": level > 0,
            "level": level,
            "login_url": "/setup/advanced/login?next={}".format(
                urllib.parse.quote(_safe_setup_next(str(req.query.get("next") or req.rel_url)), safe="")
            ),
        },
        status=200 if level > 0 else 401,
    )


async def setup_advanced_login_page(req: web.Request) -> web.Response:
    if _advanced_setup_authorized(req):
        raise web.HTTPFound(_safe_setup_next(req.query.get("next")) if req.query.get("next") else "/setup")
    error = "Incorrect password." if _safe_str(req.query.get("error")) else ""
    next_path = _safe_setup_next(req.query.get("next"))
    form_action = "/setup/advanced/login?next={}".format(urllib.parse.quote(next_path, safe=""))
    lms_ui_base = _safe_str(_public_lms_base()).rstrip("/") or _same_host_http_base(req, 9000)
    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lyrion Gadget Setup Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>__SETUP_STYLE__</style>
</head>
<body>
  __BRAND_HEADER__
  <main class="page-shell" style="max-width:560px;">
  <h2>Lyrion Gadget Setup</h2>
  <div style="font-size:13px;color:#596579;margin-bottom:14px;">Enter the installer password to configure this unit.</div>
  <form method="post" action="__FORM_ACTION__">
    <input type="hidden" name="next" value="__NEXT_PATH__">
    <label for="password" style="display:block;margin-bottom:6px;">Password</label>
    <input id="password" name="password" type="password" autofocus required
           style="width:100%;max-width:360px;padding:8px;box-sizing:border-box;">
    <div style="color:#b42318;margin-top:8px;">__ERROR__</div>
    <div style="margin-top:14px;">
      <button type="submit" style="padding:8px 14px;">Open Setup</button>
    </div>
  </form>
  <section style="margin-top:28px;border-top:1px solid #ccd4dc;padding-top:16px;">
    <h3 style="margin:0 0 10px;">Quick Links</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="__LMS_BASE__/" target="_blank" rel="noopener"><button type="button">LMS Web UI</button></a>
      <a href="/health" target="_blank" rel="noopener"><button type="button">Broker Health</button></a>
    </div>
  </section>
  </main>
</body>
</html>"""
    html = (html
        .replace("__SETUP_STYLE__", _SETUP_STYLE)
        .replace("__BRAND_HEADER__", _setup_brand_header(APP_VERSION, show_reboot_banner=False))
        .replace("__FORM_ACTION__", _html_escape(form_action))
        .replace("__NEXT_PATH__", _html_escape(next_path))
        .replace("__LMS_BASE__", _html_escape(lms_ui_base))
        .replace("__ERROR__", _html_escape(error))
    )
    return web.Response(text=html, content_type="text/html")


async def setup_advanced_login_post(req: web.Request) -> web.Response:
    form = await req.post()
    supplied = _safe_str(form.get("password"))
    next_path = _safe_setup_next(form.get("next") or req.query.get("next"))
    auth_level = 0
    if hmac.compare_digest(supplied, ADVANCED_SETUP_PASSWORD_LEVEL2):
        auth_level = 2
    elif hmac.compare_digest(supplied, ADVANCED_SETUP_PASSWORD):
        auth_level = 1
    if auth_level <= 0:
        raise web.HTTPFound(
            "/setup/advanced/login?error=1&next={}".format(
                urllib.parse.quote(next_path, safe="")
            )
        )
    response = web.HTTPFound(next_path)
    response.set_cookie(
        ADVANCED_AUTH_COOKIE,
        _advanced_auth_token(auth_level),
        max_age=ADVANCED_AUTH_MAX_AGE,
        httponly=True,
        samesite="Strict",
        path="/",
    )
    raise response


async def setup_advanced_logout(_req: web.Request) -> web.Response:
    response = web.HTTPFound("/setup")
    response.del_cookie(ADVANCED_AUTH_COOKIE, path="/")
    raise response


async def api_setup_advanced_post(req: web.Request) -> web.Response:
    if not _advanced_setup_authorized(req):
        if "application/json" in _safe_str(req.headers.get("content-type")).lower():
            return web.json_response({"ok": False, "error": "advanced authentication required"}, status=401)
        raise web.HTTPFound("/setup/advanced/login")
    _load_setup_config()
    ctype = _safe_str(req.headers.get("content-type")).lower()
    if "application/json" in ctype:
        try:
            body = await req.json()
        except Exception:
            body = {}
        if isinstance(body, dict):
            if "track_drilldown" in body:
                _setup_cache["track_drilldown"] = bool(body.get("track_drilldown"))
            if "broker_mode" in body:
                broker_mode = _safe_str(body.get("broker_mode")).strip().lower()
                if broker_mode in ("full", "light"):
                    _setup_cache["broker_mode"] = broker_mode
            if "hide_spotty_transfer_playback" in body:
                _setup_cache["hide_spotty_transfer_playback"] = bool(body.get("hide_spotty_transfer_playback"))
            if "public_lms_base" in body:
                _setup_cache["public_lms_base"] = _safe_str(body.get("public_lms_base")).strip()
            if "update_manifest_url" in body:
                _setup_cache["update_manifest_url"] = _safe_str(body.get("update_manifest_url")).strip()
            if _advanced_setup_authorized(req, 2):
                if "web_panel_broker_bg" in body or "broker_bg" in body:
                    _setup_cache["web_panel_broker_bg"] = _safe_optional_panel_color(body.get("web_panel_broker_bg", body.get("broker_bg")))
                if "web_panel_broker_content_bg" in body or "broker_content_bg" in body:
                    _setup_cache["web_panel_broker_content_bg"] = _safe_optional_panel_color(body.get("web_panel_broker_content_bg", body.get("broker_content_bg")))
                if "web_panel_broker_accent" in body or "broker_accent" in body:
                    _setup_cache["web_panel_broker_accent"] = _safe_optional_panel_color(body.get("web_panel_broker_accent", body.get("broker_accent")))
                if "web_panel_default_mode" in body or "default_mode" in body:
                    _setup_cache["web_panel_default_mode"] = _safe_panel_mode(body.get("web_panel_default_mode", body.get("default_mode")))
                if "web_panel_card_art" in body or "card_art" in body:
                    card_art_raw = body.get("web_panel_card_art", body.get("card_art", False))
                    _setup_cache["web_panel_card_art"] = _safe_str(card_art_raw).strip().lower() in ("1", "true", "yes", "on")
    else:
        form = await req.post()
        broker_mode = _safe_str(form.get("broker_mode")).strip().lower()
        if broker_mode in ("full", "light"):
            _setup_cache["broker_mode"] = broker_mode
        _setup_cache["track_drilldown"] = form.get("track_drilldown") is not None
        _setup_cache["hide_spotty_transfer_playback"] = form.get("hide_spotty_transfer_playback") is not None
        _setup_cache["public_lms_base"] = _safe_str(form.get("public_lms_base")).strip()
        if "update_manifest_url" in form:
            _setup_cache["update_manifest_url"] = _safe_str(form.get("update_manifest_url")).strip()
        if _advanced_setup_authorized(req, 2):
            if "web_panel_broker_bg" in form:
                _setup_cache["web_panel_broker_bg"] = _safe_optional_panel_color(form.get("web_panel_broker_bg"))
            if "web_panel_broker_content_bg" in form:
                _setup_cache["web_panel_broker_content_bg"] = _safe_optional_panel_color(form.get("web_panel_broker_content_bg"))
            if "web_panel_broker_accent" in form:
                _setup_cache["web_panel_broker_accent"] = _safe_optional_panel_color(form.get("web_panel_broker_accent"))
            if "web_panel_default_mode" in form:
                _setup_cache["web_panel_default_mode"] = _safe_panel_mode(form.get("web_panel_default_mode"))
            if "web_panel_default_mode" in form or "web_panel_card_art" in form:
                _setup_cache["web_panel_card_art"] = form.get("web_panel_card_art") is not None
    _save_setup_config()
    _load_setup_config()
    if "application/json" not in ctype:
        raise web.HTTPFound("/setup/advanced")
    return await api_setup_get(req)


async def api_setup_get(_req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(_req)
    sources_in_use = await _sources_in_use(pid)
    return web.json_response({
        "ok": True,
        "ver": APP_VERSION,
        "effective_lms_base": LMS_BASE,
        "setup_json_path": SETUP_JSON_PATH,
        "saved_lms_base": _safe_str(_setup_cache.get("lms_base")),
        "broker_mode": _broker_mode(),
        "saved_public_lms_base": _safe_str(_setup_cache.get("public_lms_base")),
        "update_manifest_url": _safe_str(
            _setup_cache.get("update_manifest_url") or DEFAULT_UPDATE_MANIFEST_URL
        ),
        "effective_public_lms_base": _public_lms_base(),
        "home_menu": _home_menu_cache,
        "sources_in_use": sources_in_use,
        "track_drilldown": bool(_setup_cache.get("track_drilldown", False)),
        "hide_spotty_transfer_playback": bool(_setup_cache.get("hide_spotty_transfer_playback", True)),
        "mymusic_menu": _mymusic_menu_cache(),
        "radio_menu": _radio_menu_cache(),
        "iheart_region": _iheart_region_setting(),
        "iheart_skip_intro_when_filtered": _iheart_skip_intro_when_filtered(),
        "web_panel": {
            "enabled": bool(_setup_cache.get("web_panel_enabled", True)),
            "bg": _safe_panel_color(_setup_cache.get("web_panel_bg"), "#135093"),
            "content_bg": _safe_panel_color(_setup_cache.get("web_panel_content_bg"), "#0e52a5"),
            "accent": _safe_panel_color(_setup_cache.get("web_panel_accent"), "#ffffff"),
            "broker_bg": _effective_broker_panel_color("bg", "#135093"),
            "broker_content_bg": _effective_broker_panel_color("content_bg", "#0e52a5"),
            "broker_accent": _effective_broker_panel_color("accent", "#ffffff"),
            "material_bg": _effective_material_panel_color("bg", "#135093"),
            "material_content_bg": _effective_material_panel_color("content_bg", "#0e52a5"),
            "material_accent": _effective_material_panel_color("accent", "#ffffff"),
            "default_mode": _safe_panel_mode(_setup_cache.get("web_panel_default_mode")),
            "card_art": bool(_setup_cache.get("web_panel_card_art", False)),
            "material_mode": _safe_material_mode(_setup_cache.get("web_panel_material_mode")),
        },
        "license": _license_status(),
        "legal": {
            "accepted": _legal_terms_accepted(),
            "terms_version": LEGAL_TERMS_VERSION,
            "accepted_at": _safe_int(_setup_cache.get("legal_accepted_at"), 0),
        },
        "pandora_accounts": [
            {
                "enabled": row["enabled"],
                "name": row["name"],
                "username": row["username"],
                "password_configured": bool(row["password"]),
            }
            for row in _pandora_accounts_cache()
        ],
    })


async def api_rti_config_get(req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(req)
    return web.json_response({
        "ok": True,
        "ver": APP_VERSION,
        "broker_id": BROKER_ID or _compute_broker_id(),
        "broker_mode": _broker_mode(),
        "lms_base": LMS_BASE,
        "sources_in_use": await _sources_in_use(pid),
    })


async def api_setup_web_post(req: web.Request) -> web.Response:
    _load_setup_config()
    ctype = _safe_str(req.headers.get("content-type")).lower()
    if "application/json" in ctype:
        try:
            body = await req.json()
        except Exception:
            body = {}
        if not isinstance(body, dict):
            body = {}
        _setup_cache["web_panel_enabled"] = bool(body.get("web_panel_enabled", body.get("enabled", True)))
        _setup_cache["web_panel_bg"] = _safe_panel_color(body.get("web_panel_bg", body.get("bg")), "#135093")
        _setup_cache["web_panel_content_bg"] = _safe_panel_color(body.get("web_panel_content_bg", body.get("content_bg")), "#0e52a5")
        _setup_cache["web_panel_accent"] = _safe_panel_color(body.get("web_panel_accent", body.get("accent")), "#ffffff")
        if "web_panel_broker_bg" in body or "broker_bg" in body:
            _setup_cache["web_panel_broker_bg"] = _safe_optional_panel_color(body.get("web_panel_broker_bg", body.get("broker_bg")))
        if "web_panel_broker_content_bg" in body or "broker_content_bg" in body:
            _setup_cache["web_panel_broker_content_bg"] = _safe_optional_panel_color(body.get("web_panel_broker_content_bg", body.get("broker_content_bg")))
        if "web_panel_broker_accent" in body or "broker_accent" in body:
            _setup_cache["web_panel_broker_accent"] = _safe_optional_panel_color(body.get("web_panel_broker_accent", body.get("broker_accent")))
        if "web_panel_material_bg" in body or "material_bg" in body:
            _setup_cache["web_panel_material_bg"] = _safe_optional_panel_color(body.get("web_panel_material_bg", body.get("material_bg")))
        if "web_panel_material_content_bg" in body or "material_content_bg" in body:
            _setup_cache["web_panel_material_content_bg"] = _safe_optional_panel_color(body.get("web_panel_material_content_bg", body.get("material_content_bg")))
        if "web_panel_material_accent" in body or "material_accent" in body:
            _setup_cache["web_panel_material_accent"] = _safe_optional_panel_color(body.get("web_panel_material_accent", body.get("material_accent")))
        if "web_panel_default_mode" in body or "default_mode" in body:
            _setup_cache["web_panel_default_mode"] = _safe_panel_mode(body.get("web_panel_default_mode", body.get("default_mode")))
        if "web_panel_material_mode" in body or "material_mode" in body:
            _setup_cache["web_panel_material_mode"] = _safe_material_mode(body.get("web_panel_material_mode", body.get("material_mode")))
        if "web_panel_card_art" in body or "card_art" in body:
            card_art_raw = body.get("web_panel_card_art", body.get("card_art", False))
            _setup_cache["web_panel_card_art"] = _safe_str(card_art_raw).strip().lower() in ("1", "true", "yes", "on")
    else:
        form = await req.post()
        _setup_cache["web_panel_enabled"] = form.get("web_panel_enabled") is not None
        _setup_cache["web_panel_bg"] = _safe_panel_color(form.get("web_panel_bg") or _setup_cache.get("web_panel_bg"), "#135093")
        _setup_cache["web_panel_content_bg"] = _safe_panel_color(form.get("web_panel_content_bg") or _setup_cache.get("web_panel_content_bg"), "#0e52a5")
        _setup_cache["web_panel_accent"] = _safe_panel_color(form.get("web_panel_accent") or _setup_cache.get("web_panel_accent"), "#ffffff")
        if "web_panel_broker_bg" in form:
            _setup_cache["web_panel_broker_bg"] = _safe_optional_panel_color(form.get("web_panel_broker_bg"))
        if "web_panel_broker_content_bg" in form:
            _setup_cache["web_panel_broker_content_bg"] = _safe_optional_panel_color(form.get("web_panel_broker_content_bg"))
        if "web_panel_broker_accent" in form:
            _setup_cache["web_panel_broker_accent"] = _safe_optional_panel_color(form.get("web_panel_broker_accent"))
        if "web_panel_material_bg" in form:
            _setup_cache["web_panel_material_bg"] = _safe_optional_panel_color(form.get("web_panel_material_bg"))
        if "web_panel_material_content_bg" in form:
            _setup_cache["web_panel_material_content_bg"] = _safe_optional_panel_color(form.get("web_panel_material_content_bg"))
        if "web_panel_material_accent" in form:
            _setup_cache["web_panel_material_accent"] = _safe_optional_panel_color(form.get("web_panel_material_accent"))
        if "web_panel_default_mode" in form:
            _setup_cache["web_panel_default_mode"] = _safe_panel_mode(form.get("web_panel_default_mode"))
        if "web_panel_material_mode" in form:
            _setup_cache["web_panel_material_mode"] = _safe_material_mode(form.get("web_panel_material_mode"))
        if "web_panel_default_mode" in form or "web_panel_card_art" in form:
            _setup_cache["web_panel_card_art"] = form.get("web_panel_card_art") is not None
    _save_setup_config()
    _load_setup_config()
    try:
        if not _broker_light_mode():
            await asyncio.to_thread(_install_material_custom_layer)
    except Exception as e:
        dbg(f"Material custom layer install skipped after web settings save: {e}")
    if "application/json" in ctype:
        return await api_setup_get(req)
    raise web.HTTPFound("/setup/web")


async def api_setup_material_skin(req: web.Request) -> web.Response:
    try:
        path = await asyncio.to_thread(_install_material_custom_layer)
        return web.json_response({"ok": True, "path": path})
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e)}, status=500)


async def api_mymusic_menu(req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(req)
    if not pid:
        return web.json_response({
            "ok": False,
            "playerid": "",
            "error": "No connected LMS player is available. Provision/start at least one local player first, then load the My Music tree.",
        }, status=409)
    try:
        items = await _discover_mymusic_menu_merged(pid)
        return web.json_response({"ok": True, "playerid": pid, "items": items})
    except Exception as e:
        return web.json_response({"ok": False, "playerid": pid, "error": _safe_str(e)}, status=500)


async def api_radio_menu(req: web.Request) -> web.Response:
    _load_setup_config()
    pid = await _pick_setup_playerid(req)
    if not pid:
        return web.json_response({
            "ok": False,
            "playerid": "",
            "error": "No connected LMS player is available. Provision/start at least one local player first, then load the Radio tree.",
        }, status=409)
    try:
        items = await _discover_radio_menu_merged(pid)
        return web.json_response({"ok": True, "playerid": pid, "items": items})
    except Exception as e:
        return web.json_response({"ok": False, "playerid": pid, "error": _safe_str(e)}, status=500)


async def api_setup_post(req: web.Request) -> web.Response:
    _load_setup_config()

    # accept either HTML form or JSON
    lms_base = ""
    public_lms_base = _safe_str(_setup_cache.get("public_lms_base"))
    home_menu = None
    mymusic_menu = None
    radio_menu = None
    iheart_region = ""
    iheart_skip_intro_when_filtered = _iheart_skip_intro_when_filtered()
    license_key = _safe_str(_setup_cache.get("license_key")).strip()
    legal_accept = _legal_terms_accepted()
    pandora_accounts = None

    ctype = _safe_str(req.headers.get("content-type")).lower()
    if "application/json" in ctype:
        try:
            body = await req.json()
        except Exception:
            body = {}
        if isinstance(body, dict):
            lms_base = _safe_str(body.get("lms_base"))
            if "public_lms_base" in body:
                public_lms_base = _safe_str(body.get("public_lms_base"))
            home_menu = body.get("home_menu")
            mymusic_menu = body.get("mymusic_menu")
            radio_menu = body.get("radio_menu")
            iheart_region = _safe_str(body.get("iheart_region"))
            if "iheart_skip_intro_when_filtered" in body:
                iheart_skip_intro_when_filtered = bool(body.get("iheart_skip_intro_when_filtered"))
            if "license_key" in body:
                license_key = _safe_str(body.get("license_key")).strip()
            if "legal_accept" in body:
                legal_accept = bool(body.get("legal_accept"))
            pandora_accounts = body.get("pandora_accounts")
            if "track_drilldown" in body:
                _setup_cache["track_drilldown"] = bool(body.get("track_drilldown"))
    else:
        form = await req.post()
        lms_base = _safe_str(form.get("lms_base"))
        if form.get("public_lms_base") is not None:
            public_lms_base = _safe_str(form.get("public_lms_base"))
        iheart_region = _safe_str(form.get("iheart_region"))
        iheart_skip_intro_when_filtered = form.get("iheart_skip_intro_when_filtered") is not None
        license_key = _safe_str(form.get("license_key")).strip()
        legal_accept = form.get("legal_accept") is not None
        if any(form.get(f"pandora_name_{index}") is not None for index in range(4)):
            pandora_accounts = [
                {
                    "enabled": form.get(f"pandora_enabled_{index}") is not None,
                    "name": _safe_str(form.get(f"pandora_name_{index}")),
                    "username": _safe_str(form.get(f"pandora_username_{index}")),
                    "password": _safe_str(form.get(f"pandora_password_{index}")),
                }
                for index in range(4)
            ]

        hm_raw = _safe_str(form.get("home_menu_json")).strip()
        if hm_raw:
            try:
                home_menu = json.loads(hm_raw)
            except Exception:
                home_menu = None
        mm_raw = _safe_str(form.get("mymusic_menu_json")).strip()
        if mm_raw:
            try:
                mymusic_menu = json.loads(mm_raw)
            except Exception:
                mymusic_menu = None
        rm_raw = _safe_str(form.get("radio_menu_json")).strip()
        if rm_raw:
            try:
                radio_menu = json.loads(rm_raw)
            except Exception:
                radio_menu = None

    if isinstance(home_menu, list) and home_menu:
        clean_hm: List[Dict[str, Any]] = []
        seen_hm: Set[str] = set()
        for row in home_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key")).strip()
            if not key or key in seen_hm:
                continue
            if _is_airplay_service_item(key, row.get("source_label") or row.get("label")):
                continue
            seen_hm.add(key)
            clean_hm.append({
                "key": key,
                "label": _safe_str(row.get("label") or row.get("source_label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
                "type": _safe_str(row.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core",
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "icon": (
                    _pyrrha_classic_icon_url()
                    if _is_pyrrha_home_item(key, row.get("source_label") or row.get("label") or key)
                    else _safe_str(row.get("icon") or _core_home_icon(key))
                ),
            })
        _setup_cache["home_menu"] = _normalize_unique_menu_orders(clean_hm)
    if isinstance(mymusic_menu, list):
        clean_mm: List[Dict[str, Any]] = []
        seen_mm: Set[str] = set()
        for row in mymusic_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key") or row.get("id")).strip()
            if not key or key in seen_mm:
                continue
            seen_mm.add(key)
            clean_mm.append({
                "key": key,
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "alias": _safe_str(row.get("alias") or row.get("source_label") or row.get("label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
            })
        _setup_cache["mymusic_menu"] = clean_mm
    if isinstance(radio_menu, list):
        clean_rm: List[Dict[str, Any]] = []
        seen_rm: Set[str] = set()
        for row in radio_menu:
            if not isinstance(row, dict):
                continue
            key = _safe_str(row.get("key") or row.get("id")).strip()
            if not key or key in seen_rm:
                continue
            seen_rm.add(key)
            clean_rm.append({
                "key": key,
                "source_label": _safe_str(row.get("source_label") or row.get("label") or key),
                "alias": _safe_str(row.get("alias") or row.get("source_label") or row.get("label") or key),
                "enabled": bool(row.get("enabled", True)),
                "order": _safe_int(row.get("order"), 100),
                "icon": _safe_str(row.get("icon") or ""),
            })
        _setup_cache["radio_menu"] = clean_rm

    # Persist values from the web UI. Saved values override env hints.
    _setup_cache["lms_base"] = lms_base.strip()
    _setup_cache["public_lms_base"] = public_lms_base.strip()
    _setup_cache["iheart_region"] = _iheart_region_setting(iheart_region)
    _setup_cache["iheart_skip_intro_when_filtered"] = bool(iheart_skip_intro_when_filtered)
    _setup_cache["license_key"] = license_key
    if legal_accept:
        if not _legal_terms_accepted():
            _setup_cache["legal_accepted_at"] = int(time.time())
        _setup_cache["legal_accepted"] = True
        _setup_cache["legal_terms_version"] = LEGAL_TERMS_VERSION
    else:
        _setup_cache["legal_accepted"] = False
        _setup_cache["legal_accepted_at"] = 0
        _setup_cache["legal_terms_version"] = ""
    if isinstance(pandora_accounts, list):
        clean_pandora_accounts: List[Dict[str, Any]] = []
        current_accounts = _pandora_accounts_cache()
        for index in range(4):
            row = pandora_accounts[index] if index < len(pandora_accounts) and isinstance(pandora_accounts[index], dict) else {}
            current = current_accounts[index]
            clean_pandora_accounts.append({
                "enabled": bool(row.get("enabled", False)),
                "name": _safe_str(row.get("name") or current.get("name") or f"Pandora {chr(65 + index)}").strip(),
                "username": _safe_str(row.get("username") if "username" in row else current.get("username")).strip(),
                "password": _safe_str(row.get("password") if "password" in row else current.get("password")),
            })
        if clean_pandora_accounts != current_accounts:
            pandora_backend.invalidate()
        _setup_cache["pandora_accounts"] = clean_pandora_accounts

    _save_setup_config()
    _load_setup_config()

    # Apply new LMS base live immediately
    new_live_base = _safe_str(_setup_cache.get("lms_base")).strip()
    if not new_live_base:
        new_live_base = LOCAL_LMS_BASE
    await _apply_lms_base(new_live_base)

    # If browser, redirect back to /setup
    if "text/html" in ctype or "application/x-www-form-urlencoded" in ctype:
        raise web.HTTPFound("/setup")

    return await api_setup_get(req)


async def api_lms_root(req: web.Request) -> web.Response:
    """Preview LMS root menu. Uses a player context if provided."""
    pid = _safe_str(await _pick_setup_playerid(req)).strip().lower()
    try:
        if not pid:
            raise RuntimeError("No connected LMS player is available for menu preview")
        r = await lms.rpc(pid, ["menu", 0, 200, "direct:1"])
        return web.json_response({"ok": True, "playerid": pid, "result": r.get("result") or {}})
    except Exception as e:
        return web.json_response({"ok": False, "error": _safe_str(e), "playerid": pid}, status=500)




# ---------------- Menu/Browse engine (action-driven from real Lyrion top menu) ----------------

_ws_nav: Dict[int, List[Dict[str, Any]]] = {}

_APP_KEY_ALIASES = {
    "spotty": ["spotty", "spotify"],
    "pyrrha": ["pyrrha", "pandora"],
    "bbcsounds": ["bbcsounds", "bbc sounds", "bbc"],
    "sounds": ["sounds", "sounds & effects"],
    "iheart": ["iheart", "iheartradio", "iheart radio"],
    "podcast": ["podcast", "podcasts"],
}

_GROUP_TITLE = {
    "myMusic": "My Music",
    "radios": "Radio",
    "randomplay": "Random Mix",
}


def _norm_key(s: Any) -> str:
    s = _safe_str(s).lower()
    return "".join(ch for ch in s if ch.isalnum())


def _b64u_enc(obj: Dict[str, Any]) -> str:
    raw = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_dec(s: str) -> Dict[str, Any]:
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return json.loads(base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8"))


def _extract_menu_items(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(result, dict):
        return []
    for k in ("item_loop", "loop_loop", "playlists_loop", "items"):
        v = result.get(k)
        if isinstance(v, list):
            items = [i for i in v if isinstance(i, dict)]
            _learn_pandora_station_urls(items)
            return items
    return []


def _pandora_url_key(value: Any) -> str:
    url = _clean_text(value)
    if not url:
        return ""
    if not url.lower().startswith(("fr_pandora", "frpandora", "pyr", "pyrrha")):
        return ""
    return url.split("?", 1)[0].strip().lower()


def _learn_pandora_station_urls(items: List[Dict[str, Any]]) -> None:
    try:
        for it in items:
            if not isinstance(it, dict):
                continue
            bags = [it]
            for bag_name in ("presetParams", "params", "playControlParams"):
                bag = it.get(bag_name)
                if isinstance(bag, dict):
                    bags.append(bag)
            for bag in bags:
                url = _pandora_url_key(
                    bag.get("favorites_url")
                    or bag.get("url")
                    or bag.get("touchToPlay")
                )
                if not url:
                    continue
                station = _valid_station_label(
                    bag.get("favorites_title")
                    or it.get("text")
                    or it.get("title")
                    or it.get("name")
                )
                if station:
                    _pandora_station_by_url[url] = station
                    art = _normalize_icon_url(
                        _safe_str(
                            it.get("icon")
                            or it.get("image")
                            or it.get("artwork_url")
                            or bag.get("icon")
                        )
                    )
                    if art:
                        _pandora_station_art_by_url[url] = art
                        _pandora_station_art_by_label[_norm_key(station)] = art
    except Exception:
        pass


def _pick_label(it: Dict[str, Any]) -> str:
    return _safe_str(it.get("text") or it.get("title") or it.get("name") or it.get("label") or it.get("id") or "")




def _dbg_row_art(label: str, item_id: str, art: str, it: Dict[str, Any]) -> None:
    try:
        win = it.get("window") or {}
        dbg("ROW ART label=%s id=%s art=%s raw_icon=%s raw_icon_id=%s raw_preset_icon=%s raw_artwork=%s raw_win_icon_id=%s raw_coverid=%s raw_artwork_track_id=%s" % (
            _safe_str(label),
            _safe_str(item_id),
            _safe_str(art),
            _safe_str(it.get("icon")),
            _safe_str(it.get("icon-id")),
            _safe_str((it.get("presetParams") or {}).get("icon")) if isinstance(it.get("presetParams"), dict) else "",
            _safe_str(it.get("artwork_url")),
            _safe_str(win.get("icon-id")) if isinstance(win, dict) else "",
            _safe_str(it.get("coverid") or it.get("cover_id") or it.get("coverart") or it.get("artwork_track_id")),
            _safe_str(it.get("artwork_track_id"))
        ))
    except Exception:
        pass


def _track_album_art_url(it: Dict[str, Any]) -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    if not isinstance(it, dict):
        return ""

    def _clean_music_id(v: Any) -> str:
        s = _safe_str(v).strip()
        if not s:
            return ""
        if ":" in s or "/" in s or "?" in s or "&" in s:
            return ""
        return s

    def _walk(obj: Any, depth: int = 0) -> str:
        if depth > 5:
            return ""
        if isinstance(obj, dict):
            # Explicit art first.
            for k in ("artwork_url", "art", "icon", "icon-id", "image", "icon_url"):
                v = _safe_str(obj.get(k)).strip()
                if not v:
                    continue
                art = _normalize_art_url(v) if ("art" in k or k == "artwork_url") else _normalize_icon_url(v)
                cid = _extract_cover_id_from_pathish(art)
                if cid:
                    return f"{base}/music/{cid}/cover_200x200_o"
                if art.startswith((_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"), "/music/")) or "/music/" in art:
                    return art if art.startswith("http") else ((_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/")) + art)
            # Then ID-style fields.
            for k in ("coverid", "cover_id", "artwork_track_id", "album_id", "track_id", "id"):
                v = _clean_music_id(obj.get(k))
                if v:
                    return f"{base}/music/{v}/cover_200x200_o"
            # Some rows only expose coverart=1 with an id in the same bag.
            coverart = _safe_str(obj.get("coverart")).strip().lower()
            if coverart in ("1", "true"):
                for k in ("album_id", "id", "track_id"):
                    v = _clean_music_id(obj.get(k))
                    if v:
                        return f"{base}/music/{v}/cover_200x200_o"
            # Recurse through common nested bags first, then any remaining dict/list values.
            for k in ("window", "params", "commonParams", "playControlParams", "presetParams", "itemParams"):
                if k in obj:
                    got = _walk(obj.get(k), depth + 1)
                    if got:
                        return got
            for _, val in obj.items():
                if isinstance(val, (dict, list)):
                    got = _walk(val, depth + 1)
                    if got:
                        return got
        elif isinstance(obj, list):
            for val in obj:
                got = _walk(val, depth + 1)
                if got:
                    return got
        return ""

    return _walk(it)


def _local_cover_art_url(it: Dict[str, Any]) -> str:
    base = (_public_lms_base().rstrip("/") or LMS_BASE.rstrip("/"))
    coverid = _safe_str(it.get("coverid") or it.get("cover_id") or "").strip()
    if coverid:
        return f"{base}/music/{coverid}/cover_200x200_o"
    atid = _safe_str(it.get("artwork_track_id") or "").strip()
    if atid:
        return f"{base}/music/{atid}/cover_200x200_o"
    albumid = _safe_str(it.get("album_id") or "").strip()
    if albumid:
        return f"{base}/music/{albumid}/cover_200x200_o"
    # Some local-library title/album rows only expose coverart=1 plus a numeric id.
    # In that case LMS can still serve cover art from /music/<id>/cover_200x200_o.
    if _safe_str(it.get("coverart")).strip() in ("1", "true", "True"):
        tid = _safe_str(it.get("id") or "").strip()
        if tid:
            return f"{base}/music/{tid}/cover_200x200_o"
    return ""

def _pick_art(it: Dict[str, Any]) -> str:
    win = it.get("window") or {}
    if isinstance(win, dict):
        # Prefer a real icon path over icon-id tokens. LMS browse rows often expose
        # usable local art as music/<id>/cover in icon/icon-id fields.
        v = _safe_str(win.get("icon"))
        if v:
            return _normalize_icon_url(v)
        v = _safe_str(win.get("icon-id"))
        if v:
            return _normalize_icon_url(v)

    # Prefer artwork first for stream/web items
    for k in ("artwork_url", "art"):
        v = _safe_str(it.get(k))
        if v:
            return _normalize_art_url(v)

    # For browse rows, prefer icon before icon-id. icon-id is often just a token,
    # while icon can be a usable LMS-local path like music/<id>/cover.
    for k in ("image", "icon", "icon_url", "icon-id"):
        v = _safe_str(it.get(k))
        if v:
            return _normalize_icon_url(v)

    # Last resort for local library rows that only expose cover identifiers
    v = _local_cover_art_url(it)
    if v:
        return v
    return ""


def _action_fallback_art(label: str, row_type: str = "node") -> str:
    lab = _norm_key(label)
    if not lab:
        return ""
    if "addtoend" in lab or ("add" in lab and "end" in lab):
        return _normalize_icon_url("/html/images/playlists.png")
    if "playnext" in lab or ("play" in lab and "next" in lab):
        return _normalize_icon_url("/html/images/newmusic.png")
    if "playallsongs" in lab or ("play" in lab and "all" in lab and "song" in lab):
        return _normalize_icon_url("/html/images/albums.png")
    if "playthissong" in lab or "playthisstation" in lab or (lab.startswith("play") and "song" in lab):
        return _normalize_icon_url("/html/images/browselibrary.png")
    return ""

def _mymusic_fallback_art(it: Dict[str, Any], label: str) -> str:
    iid = _safe_str(it.get("id"))
    node = _safe_str(it.get("node"))
    lab = _norm_key(label)
    iidn = _norm_key(iid)
    if node != "myMusic" and iid not in ("randomplay",):
        return ""
    # Use known-good LMS-local icons where possible.
    if iid == "randomplay" or "randommix" in lab:
        return _normalize_icon_url("/html/images/browselibrary.png")
    if iid == "myMusicNewMusic" or "newmusic" in iidn or ("newmusic" in lab):
        return _normalize_icon_url("/html/images/newmusic.png")
    if iid == "myMusicMusicFolder" or "musicfolder" in iidn or ("musicfolder" in lab):
        return _normalize_icon_url("/html/images/musicfolder.png")
    if iid == "myMusicAlbums" or "album" in lab:
        return _normalize_icon_url("/html/images/albums.png")
    if iid == "myMusicPlaylists" or "playlist" in lab:
        return _normalize_icon_url("/html/images/playlists.png")
    if iid == "myMusicGenres" or "genre" in lab:
        return _normalize_icon_url("/html/images/genres.png")
    if iid == "myMusicYears" or "year" in lab:
        return _normalize_icon_url("/html/images/browselibrary.png")
    if iid == "myMusicSearch" or lab == "search":
        return _normalize_icon_url("/html/images/search.png")
    return ""

def _track_drilldown_enabled() -> bool:
    try:
        return bool(_setup_cache.get("track_drilldown", False))
    except Exception:
        return False


async def _top_menu_raw(pid: str) -> Dict[str, Any]:
    r = await lms.rpc(pid, ["menu", 0, 100, "direct:1"])
    return (r.get("result") or {})


def _home_enabled_lookup() -> Dict[str, Dict[str, Any]]:
    _load_setup_config()
    out: Dict[str, Dict[str, Any]] = {}
    for row in _home_menu_cache:
        if not row.get("enabled"):
            continue
        key = _norm_key(row.get("key"))
        if key:
            out[key] = row
        lbl = _norm_key(row.get("label"))
        if lbl:
            out[lbl] = row
    return out


def _top_find_home_item(top_items: List[Dict[str, Any]], text: str) -> Optional[Dict[str, Any]]:
    want = _norm_key(text)
    for it in top_items:
        if _norm_key(_pick_label(it)) == want:
            return it
    return None




def _top_find_item_by_alias(top_items: List[Dict[str, Any]], aliases: List[str], node: str = "") -> Optional[Dict[str, Any]]:
    wants = [_norm_key(a) for a in aliases if _norm_key(a)]
    for it in top_items:
        if node and _safe_str(it.get("node")) != node:
            continue
        lab = _norm_key(_pick_label(it))
        iid = _norm_key(it.get("id"))
        if lab in wants or iid in wants:
            return it
    return None

def _mymusic_menu_lookup() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in _mymusic_menu_cache():
        key = _safe_str(row.get("key")).strip()
        if key:
            out[key] = row
    return out


def _apply_mymusic_menu_config(raw_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cfg = _mymusic_menu_lookup()
    if not cfg:
        return raw_items
    out: List[Tuple[int, str, Dict[str, Any]]] = []
    fallback_order = 1000
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        key = _safe_str(it.get("id")).strip()
        if not key:
            continue
        rowcfg = cfg.get(key)
        if not rowcfg:
            label = _pick_label(it)
            if not _mymusic_menu_default_enabled(key, label):
                continue
            out.append((_safe_int(it.get("weight"), fallback_order), _safe_str(label or key), dict(it)))
            fallback_order += 10
            continue
        if not bool(rowcfg.get("enabled", True)):
            continue
        row = dict(it)
        alias = _safe_str(rowcfg.get("alias")).strip()
        if alias:
            row["text"] = alias
        order = _safe_int(rowcfg.get("order"), _safe_int(it.get("weight"), 100))
        out.append((order, _safe_str(row.get("text") or row.get("id")), row))
    out.sort(key=lambda t: (t[0], t[1]))
    return [t[2] for t in out]


def _apply_radio_menu_config(raw_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    merged_rows = _merge_radio_menu_with_discovered(raw_items)
    saved_lookup = _menu_row_saved_lookup(merged_rows)
    if not saved_lookup:
        return raw_items
    out: List[Tuple[int, str, Dict[str, Any]]] = []
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        rowcfg = _menu_saved_row_for_item(saved_lookup, it)
        if not rowcfg or not bool(rowcfg.get("enabled", True)):
            continue
        row = dict(it)
        alias = _safe_str(rowcfg.get("alias")).strip()
        if alias:
            row["text"] = alias
            row["label"] = alias
            row["title"] = alias
        order = _safe_int(rowcfg.get("order"), _safe_int(it.get("weight"), 100))
        row["weight"] = order
        out.append((order, _safe_str(row.get("text") or row.get("id")), row))
    out.sort(key=lambda t: (t[0], t[1]))
    return [t[2] for t in out]


def _app_key_from_item(it: Dict[str, Any]) -> str:
    n = _norm_key(_pick_label(it))
    for key, aliases in _APP_KEY_ALIASES.items():
        if n == key:
            return key
        for a in aliases:
            if n == _norm_key(a):
                return key
    return n


def _canon_app_key(s: Any) -> str:
    n = _norm_key(s)
    for key, aliases in _APP_KEY_ALIASES.items():
        if n == key:
            return key
        for a in aliases:
            if n == _norm_key(a):
                return key
    return n


def _rootapp_menu_name(row_key: Any) -> str:
    key = _safe_str(row_key).strip()
    n = _norm_key(key)
    if "frpandora0" in n:
        return "fr_pandora_0"
    if "frpandora1" in n:
        return "fr_pandora_1"
    if "frpandora2" in n:
        return "fr_pandora_2"
    if "frpandora3" in n:
        return "fr_pandora_3"
    if "bbcsounds" in n:
        return "bbcsounds"
    if "qobuz" in n:
        return "qobuz"
    if "tidal" in n:
        return "tidal"
    if "spotty" in n or "spotify" in n:
        return "spotty"
    if "pyrrha" in n:
        return "pyrrha"
    if "podcast" in n:
        return "podcasts"
    if "iheart" in n:
        return "opmliheartradio"
    return ""



def _pandora_menu_name(value: Any) -> str:
    name = _safe_str(value).strip().lower()
    prefix = "fr_pandora_"
    suffix = name[len(prefix):] if name.startswith(prefix) else ""
    return name if suffix.isdigit() else ""


def _pandora_station_action(actions: Any) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(actions, dict):
            return None
        for key in ("play", "go", "add", "add-hold", "do"):
            act = actions.get(key)
            if not isinstance(act, dict):
                continue
            cmd = act.get("cmd")
            if not isinstance(cmd, list) or len(cmd) < 3:
                continue
            lower = [_safe_str(x).strip().lower() for x in cmd]
            if not lower[0].startswith("fr_pandora_"):
                continue
            if lower[1] != "playlist" or lower[2] != "play":
                continue
            params = act.get("params") if isinstance(act.get("params"), dict) else {}
            menu_name = _pandora_menu_name(params.get("menu"))
            if not menu_name or menu_name != lower[0]:
                continue
            if not _safe_str(params.get("item_id")).strip():
                continue
            return act
        return None
    except Exception:
        return None

def _is_pandora_station_context_row(label: Any, actions: Any) -> bool:
    if _norm_key(label) == "playthisstation":
        return False
    return _pandora_station_action(actions) is not None


def _is_pandora_station_actions(actions: Any) -> bool:
    return _pandora_station_action(actions) is not None


def _is_pandora_navigation_actions(actions: Any) -> bool:
    try:
        if not isinstance(actions, dict):
            return False
        for key in ("go", "do"):
            act = actions.get(key)
            if not isinstance(act, dict):
                continue
            cmd = act.get("cmd")
            if not isinstance(cmd, list) or len(cmd) < 2:
                continue
            lower = [_safe_str(x).strip().lower() for x in cmd]
            if lower[0].startswith("fr_pandora_") and lower[1] == "items":
                return True
        return False
    except Exception:
        return False


def _is_pandora_action_family(actions: Any) -> bool:
    try:
        if not isinstance(actions, dict):
            return False
        for act in actions.values():
            if not isinstance(act, dict):
                continue
            cmd = act.get("cmd")
            if isinstance(cmd, list) and cmd:
                if _safe_str(cmd[0]).strip().lower().startswith("fr_pandora_"):
                    return True
            params = act.get("params") if isinstance(act.get("params"), dict) else {}
            menu = _safe_str(params.get("menu")).strip().lower()
            if menu.startswith("fr_pandora_"):
                return True
        return False
    except Exception:
        return False


def _pandora_action_item_id(actions: Any) -> str:
    if not isinstance(actions, dict):
        return ""
    for act in actions.values():
        if not isinstance(act, dict):
            continue
        cmd = act.get("cmd")
        params = act.get("params") if isinstance(act.get("params"), dict) else {}
        if isinstance(cmd, list) and cmd and _safe_str(cmd[0]).strip().lower().startswith("fr_pandora_"):
            item_id = _safe_str(params.get("item_id")).strip()
            if item_id:
                return item_id
    return ""


def _is_pandora_genre_item_id(item_id: Any) -> bool:
    return _safe_str(item_id).strip().startswith("2.")


def _is_pyrrha_station_actions(actions: Any) -> bool:
    try:
        if not isinstance(actions, dict):
            return False
        play = actions.get("play")
        if not isinstance(play, dict):
            return False
        cmd = play.get("cmd")
        if not isinstance(cmd, list) or len(cmd) < 3:
            return False
        lower = [_safe_str(x).strip().lower() for x in cmd]
        if lower[0] != "pyrrha":
            return False
        if lower[1] != "playlist" or lower[2] != "play":
            return False
        params = play.get("params") if isinstance(play.get("params"), dict) else {}
        if _safe_str(params.get("menu")).strip().lower() != "pyrrha":
            return False
        return _safe_str(params.get("touchToPlaySingle")).strip() in ("1", "true", "True")
    except Exception:
        return False

def _valid_station_label(value: Any) -> str:
    lines = _clean_text(value).splitlines()
    station = lines[0].strip() if lines else ""
    if not station:
        return ""
    if _norm_key(station) in (
        "playthisstation", "play", "yourstations", "stations", "pandora",
        "pyrrha", "delete", "renamestation", "addmoremusic",
        "genrestations", "genres", "createanewstation", "createnewstation",
        "createstation", "account", "accountinuse",
    ):
        return ""
    return station

def _remember_pandora_station(pid: str, station: Any) -> str:
    name = _valid_station_label(station)
    if name and pid:
        _pandora_station_unknown_playerids.discard(pid.lower())
        _pandora_station_by_playerid[pid] = name
        _pandora_station_by_playerid[pid.lower()] = name
        _np_station_by_playerid[pid] = name
        _np_station_by_playerid[pid.lower()] = name
    return name

def _clear_pandora_station(pid: str) -> None:
    if not pid:
        return
    for key in (pid, pid.lower()):
        _pandora_station_by_playerid.pop(key, None)
        _np_station_by_playerid.pop(key, None)
    _pandora_station_unknown_playerids.add(pid.lower())


def _pandora_station_payload(spec: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(spec, dict):
            return None
        acts = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
        if not _is_pandora_station_actions(acts):
            return None
        label = _safe_str(spec.get("label") or "Pandora Station").strip() or "Pandora Station"
        items: List[Dict[str, Any]] = []
        order = [
            ("play", "Play Now"),
            ("add-hold", "Play Next"),
            ("add", "Add to End"),
        ]
        for key, row_label in order:
            act = acts.get(key)
            if not isinstance(act, dict):
                continue
            row_spec = {"kind": "actions", "actions": {key: act}}
            items.append({
                "id": "act:" + _b64u_enc(row_spec),
                "label": row_label,
                "type": "action",
                "can_open": False,
                "no_icon": True,
            })
        if not items:
            return None
        return {
            "node": "act",
            "title": label,
            "offset": 0,
            "limit": len(items),
            "total": len(items),
            "items": items,
            "nav": {"can_back": True, "can_home": True},
        }
    except Exception:
        return None


def _row_action_params(it: Dict[str, Any], key: str) -> Dict[str, Any]:
    acts = it.get("actions") or {}
    act = acts.get(key) if isinstance(acts, dict) else None
    return act.get("params") if isinstance(act, dict) and isinstance(act.get("params"), dict) else {}


def _row_track_id_from_item(it: Dict[str, Any]) -> str:
    for k in ("track_id", "artwork_track_id"):
        v = _safe_str(it.get(k)).strip()
        if v:
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        for k in ("track_id", "artwork_track_id"):
            v = _safe_str(bag.get(k)).strip()
            if v:
                return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        for k in ("track_id", "artwork_track_id"):
            v = _safe_str(params.get(k)).strip()
            if v:
                return v
    return ""


def _row_album_id_from_item(it: Dict[str, Any]) -> str:
    for k in ("album_id",):
        v = _safe_str(it.get(k)).strip()
        if v:
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        v = _safe_str(bag.get("album_id")).strip()
        if v:
            return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        v = _safe_str(params.get("album_id")).strip()
        if v:
            return v
    return ""


def _row_playlist_id_from_item(it: Dict[str, Any]) -> str:
    for k in ("playlist_id", "playlistid"):
        v = _safe_str(it.get(k)).strip()
        if v:
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        for k in ("playlist_id", "playlistid"):
            v = _safe_str(bag.get(k)).strip()
            if v:
                return v
    for key in ("go", "play", "add-hold", "add", "more"):
        params = _row_action_params(it, key)
        for k in ("playlist_id", "playlistid"):
            v = _safe_str(params.get(k)).strip()
            if v:
                return v
    return ""


def _row_playlist_item_index_from_item(it: Dict[str, Any]) -> str:
    for k in ("playlist_item_index", "playlist_index", "index"):
        v = _safe_str(it.get(k)).strip()
        if v != "":
            return v
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        for k in ("playlist_item_index", "playlist_index", "index"):
            v = _safe_str(bag.get(k)).strip()
            if v != "":
                return v
    return ""


def _row_menu_id_from_item(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return ""
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        v = _safe_str(bag.get("menu")).strip()
        if v:
            return v
    for key in ("add-hold", "play", "add", "go"):
        params = _row_action_params(it, key)
        v = _safe_str(params.get("menu")).strip()
        if v:
            return v
    return ""


def _row_can_add_favorite(it: Dict[str, Any], row_type: str, track_id: str, album_id: str) -> bool:
    if not isinstance(it, dict):
        return False

    # Some plugins expose an explicit favorites URL or favorites action; trust that.
    try:
        fav_url = _safe_str(((it.get("presetParams") or {}).get("favorites_url"))).strip() if isinstance(it.get("presetParams"), dict) else ""
    except Exception:
        fav_url = ""
    if fav_url:
        return True

    acts = it.get("actions") if isinstance(it.get("actions"), dict) else {}
    if isinstance(acts, dict):
        for k in acts.keys():
            lk = _safe_str(k).strip().lower()
            if lk in ("favorite", "favorites", "addfavorite", "add_favorite", "savefavorite", "save_favorite"):
                return True

    # Broker should do the heavy lifting here: real LMS track/album ids are favorite-capable.
    # This covers My Music album rows even when the raw item/node shape is thin or menu context
    # is not obvious by the time RTI selects the target.
    if track_id or album_id:
        return True

    return False


def _track_row_needs_meta(row: Dict[str, Any]) -> bool:
    return (
        row.get("type") == "track" and (
            not _safe_str(row.get("artist")).strip() or
            not _safe_str(row.get("album")).strip() or
            not _safe_str(row.get("genre")).strip() or
            row.get("duration") in (None, "", 0, "0")
        )
    )


async def _enrich_track_rows(raw_items: List[Dict[str, Any]], rows: List[Dict[str, Any]]) -> None:
    if not raw_items or not rows:
        return
    count = min(len(raw_items), len(rows))
    for idx in range(count):
        row = rows[idx]
        if not isinstance(row, dict) or not _track_row_needs_meta(row):
            continue
        raw = raw_items[idx] if isinstance(raw_items[idx], dict) else {}
        track_id = _row_track_id_from_item(raw) or _safe_str(row.get("track_id")).strip()
        album_id = _row_album_id_from_item(raw) or _safe_str(row.get("album_id")).strip()
        if track_id:
            row["track_id"] = track_id
        if album_id:
            row["album_id"] = album_id
        if not track_id:
            continue
        try:
            meta = await lms.track_metadata(track_id)
        except Exception as e:
            dbg("TRACK META fetch failed track_id=%s err=%s" % (track_id, _safe_str(e)))
            continue
        if not isinstance(meta, dict) or not meta:
            continue
        if not _safe_str(row.get("artist")) and _safe_str(meta.get("artist")):
            row["artist"] = _safe_str(meta.get("artist"))
        if not _safe_str(row.get("album")) and _safe_str(meta.get("album")):
            row["album"] = _safe_str(meta.get("album"))
        if not _safe_str(row.get("genre")) and _safe_str(meta.get("genre")):
            row["genre"] = _safe_str(meta.get("genre"))
        if row.get("duration") in (None, "", 0, "0") and meta.get("duration") not in (None, ""):
            row["duration"] = meta.get("duration")
        if not _safe_str(row.get("label")) and _safe_str(meta.get("title")):
            row["label"] = _safe_str(meta.get("title"))
        if not _safe_str(row.get("art")) and _safe_str(meta.get("art")):
            row["art"] = _safe_str(meta.get("art"))
        dbg("TRACK META merge idx=%s track_id=%s artist=%s album=%s genre=%s duration=%s" % (idx, track_id, _safe_str(row.get("artist")), _safe_str(row.get("album")), _safe_str(row.get("genre")), _safe_str(row.get("duration"))))


def _dbg_broker_menu_rows(title: str, offset: int, raw_items: List[Dict[str, Any]], rows: List[Dict[str, Any]]) -> None:
    try:
        dbg("BROKER_PAGE title=%s offset=%s raw_items=%s rows=%s" % (
            _safe_str(title), _safe_int(offset), len(raw_items or []), len(rows or [])
        ))
        count = min(3, len(raw_items or []), len(rows or []))
        for idx in range(count):
            raw = raw_items[idx] if isinstance(raw_items[idx], dict) else {}
            row = rows[idx] if isinstance(rows[idx], dict) else {}
            dbg("BROKER_RAW idx=%s name=%s type=%s node=%s id=%s track_id=%s album_id=%s artist=%s album=%s genre=%s duration=%s art=%s" % (
                idx,
                _safe_str(raw.get("text") or raw.get("title") or raw.get("name") or raw.get("label")),
                _safe_str(raw.get("type")),
                _safe_str(raw.get("node")),
                _safe_str(raw.get("id")),
                _row_track_id_from_item(raw),
                _row_album_id_from_item(raw),
                _safe_str(raw.get("artist")),
                _safe_str(raw.get("album")),
                _safe_str(raw.get("genre")),
                _safe_str(raw.get("duration")),
                _safe_str(raw.get("artwork_url") or raw.get("icon") or raw.get("icon-id"))
            ))
            dbg("BROKER_ROW idx=%s label=%s type=%s id=%s track_id=%s album_id=%s artist=%s album=%s genre=%s duration=%s art=%s can_open=%s" % (
                idx,
                _safe_str(row.get("label")),
                _safe_str(row.get("type")),
                _safe_str(row.get("id")),
                _safe_str(row.get("track_id")),
                _safe_str(row.get("album_id")),
                _safe_str(row.get("artist")),
                _safe_str(row.get("album")),
                _safe_str(row.get("genre")),
                _safe_str(row.get("duration")),
                _safe_str(row.get("art")),
                _safe_str(row.get("can_open"))
            ))
    except Exception as e:
        dbg("BROKER_LOG_ERR %s" % _safe_str(e))


def _is_qobuz_track_item(it: Dict[str, Any]) -> bool:
    if not isinstance(it, dict):
        return False
    params = it.get("params") if isinstance(it.get("params"), dict) else {}
    preset = it.get("presetParams") if isinstance(it.get("presetParams"), dict) else {}
    touch = _safe_str(params.get("touchToPlay")).strip()
    item_id = _safe_str(params.get("item_id")).strip()
    fav_url = _safe_str(preset.get("favorites_url")).strip().lower()
    fav_type = _safe_str(preset.get("favorites_type")).strip().lower()
    return bool(touch or item_id) and fav_url.startswith("qobuz://") and fav_type in ("", "audio")


def _tidal_track_info(it: Dict[str, Any]) -> Optional[Dict[str, str]]:
    if not isinstance(it, dict):
        return None
    params = it.get("params") if isinstance(it.get("params"), dict) else {}
    preset = it.get("presetParams") if isinstance(it.get("presetParams"), dict) else {}
    fav_url = _safe_str(preset.get("favorites_url")).strip()
    fav_type = _safe_str(preset.get("favorites_type")).strip().lower()
    touch = _safe_str(params.get("touchToPlay") or params.get("item_id")).strip()
    if not touch or not fav_url.lower().startswith("tidal://") or fav_type not in ("", "audio"):
        return None
    title = _clean_text(_pick_label(it)).splitlines()[0].strip()
    fav_title = _safe_str(preset.get("favorites_title")).strip()
    if not title and fav_title:
        title = fav_title.split(" - ", 1)[0].strip()
    return {"url": fav_url, "title": title or fav_url}


def _is_bbc_sounds_item(it: Dict[str, Any]) -> bool:
    if not isinstance(it, dict):
        return False
    if it.get("_broker_bbc_sounds"):
        return True
    hay = _norm_key(json.dumps({
        "cmd": it.get("cmd"),
        "params": it.get("params"),
        "url": it.get("url"),
        "playlist": it.get("playlist"),
        "passthrough": it.get("passthrough"),
        "items": it.get("items"),
        "actions": it.get("actions"),
        "presetParams": it.get("presetParams"),
    }, ensure_ascii=False, default=str))
    return (
        "bbcsounds" in hay
        or "sounds://" in hay
        or "bbc.co.uk/sounds" in hay
        or "sounds.files.bbci.co.uk" in hay
        or "rms.api.bbc.co.uk" in hay
    )


def _bbc_embedded_items(it: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(it, dict) or not _is_bbc_sounds_item(it):
        return []
    raw = it.get("items")
    if not isinstance(raw, list):
        return []
    out: List[Dict[str, Any]] = []
    for row in raw:
        if not isinstance(row, dict) or not _pick_label(row).strip():
            continue
        tagged = copy.deepcopy(row)
        tagged["_broker_bbc_sounds"] = True
        out.append(tagged)
    return out


def _bbc_audio_url(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict) or not _is_bbc_sounds_item(it):
        return ""
    if _safe_str(it.get("type")).strip().lower() != "audio":
        return ""
    url = _safe_str(it.get("url")).strip()
    return url if url.startswith("sounds://") else ""


def _bbc_audio_actions(url: str) -> Dict[str, Any]:
    return {
        "play": {"cmd": ["playlist", "play", url]},
        "add": {"cmd": ["playlist", "add", url]},
        "add-hold": {"cmd": ["playlist", "insert", url]},
    }


def _bbc_row_id(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict) or not _is_bbc_sounds_item(it):
        return ""
    broker_row_id = _safe_str(it.get("_broker_bbc_item_id")).strip()
    if broker_row_id:
        return broker_row_id
    row_id = _safe_str(it.get("id")).strip()
    if row_id:
        return row_id
    actions = it.get("actions") if isinstance(it.get("actions"), dict) else {}
    play_control = actions.get("playControl") if isinstance(actions.get("playControl"), dict) else {}
    params = play_control.get("params") if isinstance(play_control.get("params"), dict) else {}
    parent_id = _safe_str(params.get("item_id")).strip()
    idx = _safe_str(params.get("_index")).strip()
    if parent_id and idx.isdigit():
        return f"{parent_id}.{idx}"
    return ""


def _bbc_row_has_items(it: Dict[str, Any]) -> bool:
    return _safe_int(it.get("hasitems"), 0) == 1 or _safe_str(it.get("hasitems")).strip().lower() in ("true", "yes")


def _bbc_row_is_audio(it: Dict[str, Any]) -> bool:
    return (
        _safe_int(it.get("isaudio"), 0) == 1
        or _safe_str(it.get("isaudio")).strip().lower() in ("true", "yes")
        or _safe_str(it.get("type")).strip().lower() == "audio"
    )


def _bbc_item_actions(item_id: str) -> Dict[str, Any]:
    return {
        "play": {"cmd": ["bbcsounds", "playlist", "play"], "params": {"item_id": item_id}},
        "add": {"cmd": ["bbcsounds", "playlist", "add"], "params": {"item_id": item_id}},
        "add-hold": {"cmd": ["bbcsounds", "playlist", "insert"], "params": {"item_id": item_id}},
    }


def _bbc_browse_action(actions: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(actions, dict):
        return None
    go = actions.get("go") if isinstance(actions.get("go"), dict) else None
    if not isinstance(go, dict):
        return None
    cmd = go.get("cmd") if isinstance(go.get("cmd"), list) else []
    if len(cmd) < 2:
        return None
    if _safe_str(cmd[0]).strip().lower() != "bbcsounds":
        return None
    if _safe_str(cmd[1]).strip().lower() != "items":
        return None
    params = go.get("params") if isinstance(go.get("params"), dict) else {}
    if not _safe_str(params.get("item_id")).strip():
        return None
    return go


def _row_from_action_item(it: Dict[str, Any], default_type: str = "node") -> Dict[str, Any]:
    label = _pick_label(it)
    direct_id = _safe_str(it.get("id")).strip()
    if direct_id.startswith("cmd:"):
        row: Dict[str, Any] = {
            "id": direct_id,
            "label": label or direct_id.split(":", 1)[1].title(),
            "type": "node",
            "can_open": True,
        }
        art = _pick_art(it) or _mymusic_fallback_art(it, row["label"]) or _action_fallback_art(row["label"], "node")
        if art:
            row["art"] = art
        return row
    row_type = default_type
    actions = it.get("actions") or {}
    is_qobuz_track = _is_qobuz_track_item(it)
    if is_qobuz_track and isinstance(actions, dict) and isinstance(actions.get("go"), dict):
        # Qobuz track rows expose page-level go through base.actions, but
        # row taps should target the song via play/add/insert, not drill.
        actions = dict(actions)
        actions.pop("go", None)
        it["actions"] = actions
    is_tidal_playable = _is_tidal_action_spec(actions if isinstance(actions, dict) else {})

    item_kind = _safe_str(it.get("type")).lower()
    source_node = _safe_str(it.get("node")).lower()
    row_item_id = _safe_str((it.get("params") or {}).get("item_id")).strip() if isinstance(it.get("params"), dict) else ""
    row_ctx = _safe_str((it.get("params") or {}).get("isContextMenu")).strip() if isinstance(it.get("params"), dict) else ""
    row_pc = _safe_str((it.get("playControlParams") or {}).get("xmlbrowserPlayControl")).strip() if isinstance(it.get("playControlParams"), dict) else ""
    row_touch = _safe_str((it.get("params") or {}).get("touchToPlay")).strip() if isinstance(it.get("params"), dict) else ""
    row_style = _safe_str(it.get("style")).lower()
    row_fav_url = _safe_str(((it.get("presetParams") or {}).get("favorites_url"))).strip() if isinstance(it.get("presetParams"), dict) else ""
    tidal_track = _tidal_track_info(it)
    bbc_embedded_items = _bbc_embedded_items(it)
    bbc_audio_url = _bbc_audio_url(it)
    bbc_browse_action = _bbc_browse_action(actions)
    bbc_browse_params = bbc_browse_action.get("params") if isinstance(bbc_browse_action, dict) and isinstance(bbc_browse_action.get("params"), dict) else {}
    bbc_item_id = _bbc_row_id(it) or _safe_str(bbc_browse_params.get("item_id")).strip()
    bbc_is_audio = bool(bbc_item_id and _bbc_row_is_audio(it))
    bbc_has_items = bool(bbc_item_id and (_bbc_row_has_items(it) or not bbc_is_audio))
    label_key = _norm_key(label)
    bbc_is_play_row = bbc_is_audio and label_key.startswith("play")
    can_search = _safe_str(it.get("can_search") or it.get("canSearch")).strip().lower() in ("1", "true", "yes")
    action_menus: Set[str] = set()
    for action in actions.values() if isinstance(actions, dict) else []:
        params = action.get("params") if isinstance(action, dict) and isinstance(action.get("params"), dict) else {}
        menu_name = _safe_str(params.get("menu")).strip().lower()
        if menu_name:
            action_menus.add(menu_name)
    is_spotty_search_container = (
        label_key == "search" and
        any("spotty" in menu_name or "spotify" in menu_name for menu_name in action_menus)
    )
    is_qobuz_search_container = (
        label_key == "search" and
        any("qobuz" in menu_name for menu_name in action_menus)
    )
    if label_key in (
        "createanewstation", "createnewstation", "createstation", "newstation", "addstation",
        "renamestation",
        "addmoremusictothisstation", "addmoremusic"
    ):
        can_search = True
    elif label_key == "search" and not is_spotty_search_container and not is_qobuz_search_container:
        can_search = True
    for bag_name in ("params", "commonParams", "playControlParams", "itemParams", "presetParams"):
        bag = it.get(bag_name) if isinstance(it.get(bag_name), dict) else {}
        mode = _safe_str(bag.get("mode")).strip().lower()
        tagged = _safe_str(
            bag.get("search") or bag.get("query") or bag.get("term") or
            bag.get("station") or bag.get("station_name") or bag.get("stationname")
        ).strip().upper()
        if tagged == "__TAGGEDINPUT__":
            can_search = True
            break
    if not can_search and isinstance(actions, dict):
        for act in actions.values():
            params = act.get("params") if isinstance(act, dict) and isinstance(act.get("params"), dict) else {}
            mode = _safe_str(params.get("mode")).strip().lower()
            tagged = _safe_str(
                params.get("search") or params.get("query") or params.get("term") or
                params.get("station") or params.get("station_name") or params.get("stationname")
            ).strip().upper()
            if tagged == "__TAGGEDINPUT__":
                can_search = True
                break
    is_spotty_touch_track = (
        row_item_id != "" and
        row_touch != "" and
        row_ctx in ("1", "true", "True") and
        row_style == "itemplay" and
        row_fav_url.startswith("spotify:track:")
    )
    is_spotty_playcontrol_track = (
        _safe_str(it.get("goAction")).lower() == "playcontrol" and
        row_item_id != "" and
        row_ctx in ("1", "true", "True") and
        row_pc != "" and
        row_fav_url.startswith("spotify:track:")
    )

    go_action_play = (_safe_str(it.get("goAction")).lower() == "play" and
                      item_kind in ("audio", "track", "song", "playlist"))
    if (bbc_embedded_items or bbc_has_items or bbc_browse_action) and not (bbc_audio_url or bbc_is_audio):
        go_action_play = False
    # Spotty track rows should target/select only on tap; UI Play handles playback.
    # Keep Pandora, Pyrrha, randomplay and all other sources on their existing behavior.
    if is_spotty_touch_track or is_spotty_playcontrol_track:
        go_action_play = False
    has_playable_actions = isinstance(actions, dict) and (
        isinstance(actions.get("play"), dict) or
        isinstance(actions.get("add"), dict) or
        isinstance(actions.get("add-hold"), dict)
    )
    is_podcast_episode = bool(it.get("_broker_podcast_episode")) or _is_podcast_episode_actions(actions)
    if is_podcast_episode:
        has_playable_actions = True
    podcast_go = actions.get("go") if isinstance(actions.get("go"), dict) else {}
    podcast_go_cmd = podcast_go.get("cmd") if isinstance(podcast_go.get("cmd"), list) else []
    is_podcast_browse_node = (
        not is_podcast_episode
        and len(podcast_go_cmd) >= 2
        and _safe_str(podcast_go_cmd[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(podcast_go_cmd[1]).strip().lower() == "items"
    )
    # Treat only true track/song/audio rows as playable-first when track drilldown is off.
    # Albums often expose play/add actions too, but should still drill to the track list.
    looks_like_track = (
        item_kind in ("audio", "track", "song") or
        (it.get("duration") is not None) or
        bool(_safe_str(it.get("track"))) or
        is_qobuz_track or
        bool(tidal_track) or
        (is_tidal_playable and item_kind in ("audio", "track", "song")) or
        is_spotty_touch_track or
        is_spotty_playcontrol_track or
        is_podcast_episode
    )
    track_drill = _track_drilldown_enabled()

    if is_spotty_touch_track or is_spotty_playcontrol_track:
        row_type = "track"
    elif go_action_play or (has_playable_actions and looks_like_track):
        row_type = "track"
    elif it.get("isANode"):
        row_type = "node"

    art = _pick_art(it)
    if not art and row_type == "track":
        art = _track_album_art_url(it)
    if not art and isinstance(it.get("presetParams"), dict):
        art = _normalize_icon_url(_safe_str((it.get("presetParams") or {}).get("icon")))
    if not art:
        art = _mymusic_fallback_art(it, label)
    if not art and row_type != "track":
        art = _action_fallback_art(label, row_type)
    if not art and row_type != "track":
        art = _broker_list_art_url("0")
    if it.get("no_icon"):
        art = ""

    item_id = ""
    node_name = _safe_str(it.get("id"))
    can_open = False

    if is_spotty_touch_track or is_spotty_playcontrol_track:
        item_id = "sptrack:" + row_item_id
        row_type = "track"
        can_open = False
    elif is_qobuz_track and row_item_id:
        item_id = "qobuztrack:" + row_item_id
        row_type = "track"
        can_open = False
    elif tidal_track:
        item_id = "tidaltrack:" + _b64u_enc(tidal_track)
        row_type = "track"
        can_open = False
    elif bbc_is_audio:
        item_id = "act:" + _b64u_enc({
            "kind": "bbc_audio",
            "label": label,
            "actions": _bbc_item_actions(bbc_item_id),
        })
        row_type = "track"
        can_open = bbc_is_play_row
        has_playable_actions = True
    elif bbc_browse_action and not bbc_is_audio:
        item_id = "act:" + _b64u_enc({
            "kind": "bbc_go",
            "label": label,
            "action": copy.deepcopy(bbc_browse_action),
            "play_item_id": bbc_item_id,
            "force_title": True,
        })
        row_type = "node"
        can_open = True
    elif bbc_has_items and not bbc_is_audio:
        item_id = "act:" + _b64u_enc({
            "kind": "bbc_go",
            "label": label,
            "action": {"cmd": ["bbcsounds", "items"], "params": {"item_id": bbc_item_id}},
            "play_item_id": bbc_item_id,
            "force_title": True,
        })
        row_type = "node"
        can_open = True
    elif bbc_embedded_items and not bbc_audio_url:
        item_id = "act:" + _b64u_enc({
            "kind": "bbc_items",
            "label": label,
            "items": copy.deepcopy(bbc_embedded_items),
        })
        row_type = "node"
        can_open = True
    elif bbc_audio_url:
        item_id = "act:" + _b64u_enc({
            "kind": "bbc_audio",
            "label": label,
            "actions": _bbc_audio_actions(bbc_audio_url),
        })
        row_type = "track"
        can_open = label_key == "play"
        has_playable_actions = True
    elif it.get("isANode") and node_name and not (row_type == "track" and not track_drill):
        item_id = "group:" + node_name
        row_type = "node"
        can_open = True
    elif isinstance(actions, dict) and actions:
        is_pandora_station = _is_pandora_station_context_row(label, actions)
        if is_pandora_station:
            action_spec: Dict[str, Any] = {"kind": "pandora_station", "label": label, "actions": actions}
            for meta_key in ("presetParams", "commonParams", "params", "playControlParams"):
                if isinstance(it.get(meta_key), dict):
                    action_spec[meta_key] = copy.deepcopy(it.get(meta_key))
            for meta_key in ("icon", "image", "artwork_url"):
                if it.get(meta_key):
                    action_spec[meta_key] = _safe_str(it.get(meta_key))
            item_id = "act:" + _b64u_enc(action_spec)
            row_type = "node"
            can_open = True
            dbg("PANDORA STATION ROW label=%s can_open=1" % _safe_str(label))
        else:
            action_spec: Dict[str, Any] = {"kind": "actions", "label": label, "actions": actions}
            if "checkbox" in it:
                action_spec["checkbox"] = _safe_int(it.get("checkbox"), 0)
            if it.get("nextWindow") is not None:
                action_spec["nextWindow"] = _safe_str(it.get("nextWindow"))
            item_id = "act:" + _b64u_enc(action_spec)
        if is_spotty_touch_track or is_spotty_playcontrol_track:
            item_id = "sptrack:" + row_item_id
            row_type = "track"
            can_open = False
        elif is_qobuz_track and row_item_id:
            item_id = "qobuztrack:" + row_item_id
            row_type = "track"
            can_open = False
        elif tidal_track:
            item_id = "tidaltrack:" + _b64u_enc(tidal_track)
            row_type = "track"
            can_open = False
        elif is_pandora_station:
            row_type = "node"
            can_open = True
        elif is_podcast_browse_node:
            row_type = "node"
            can_open = True
        elif has_playable_actions and looks_like_track and not track_drill:
            row_type = "track"
            can_open = False
        elif isinstance(actions.get("go"), dict):
            row_type = "node"
            can_open = True
        elif isinstance(actions.get("on"), dict) or isinstance(actions.get("off"), dict):
            row_type = "node"
            can_open = True
        elif has_playable_actions and (looks_like_track or not isinstance(actions.get("go"), dict)):
            row_type = "track"
        elif isinstance(actions.get("do"), dict):
            row_type = "action"
    elif go_action_play:
        cmd = it.get("cmd") if isinstance(it.get("cmd"), list) else []
        params = it.get("params") if isinstance(it.get("params"), dict) else {}
        if cmd and _is_bbc_sounds_item(it):
            item_id = "act:" + _b64u_enc({"kind": "goaction_play", "label": label, "actions": {"play": {"cmd": cmd, "params": params}}})
        else:
            dbg("NOOP RAW ITEM " + json.dumps(it, ensure_ascii=False))
            item_id = "noop:" + _norm_key(label)
    else:
        dbg("NOOP RAW ITEM " + json.dumps(it, ensure_ascii=False))
        item_id = "noop:" + _norm_key(label)

    display_label = label
    if "checkbox" in it:
        display_label = ("[x] " if _safe_int(it.get("checkbox"), 0) else "[ ] ") + label
    row = {"id": item_id, "label": display_label, "type": row_type, "can_open": can_open}
    if bbc_is_play_row:
        row["retain_target"] = True
    if _is_pandora_action_family(actions) and not _is_pandora_station_actions(actions):
        row["target_art"] = _pandora_classic_icon_url("", "")
    if (
        row_type == "node"
        and not _is_pandora_station_actions(actions)
        and _is_pandora_action_family(actions)
    ):
        row["retain_target"] = True
    if "checkbox" in it:
        row["checkbox"] = _safe_int(it.get("checkbox"), 0)
    if can_search:
        row["can_search"] = True
        row["can_open"] = True
        row["type"] = "node"
    if art:
        row["art"] = art
    _dbg_row_art(label, item_id, art, it)
    if _safe_str(it.get("artist")):
        row["artist"] = _safe_str(it.get("artist"))
    if _safe_str(it.get("album")):
        row["album"] = _safe_str(it.get("album"))
    if _safe_str(it.get("genre")):
        row["genre"] = _safe_str(it.get("genre"))
    if it.get("duration") is not None:
        row["duration"] = it.get("duration")
    track_id = _row_track_id_from_item(it)
    if track_id:
        row["track_id"] = track_id
    album_id = _row_album_id_from_item(it)
    if album_id:
        row["album_id"] = album_id
    playlist_id = _row_playlist_id_from_item(it)
    playlist_item_index = _row_playlist_item_index_from_item(it)
    if playlist_id and playlist_item_index == "" and not track_id and row_type == "node":
        row["can_rename_playlist"] = True
        row["can_delete_playlist"] = True
    if playlist_id:
        row["playlist_id"] = playlist_id
    if playlist_item_index != "":
        row["playlist_item_index"] = playlist_item_index
    is_playlist_entry = bool(playlist_id and playlist_item_index != "")
    if row_type != "playlist" and not is_playlist_entry and _row_can_add_favorite(it, row_type, track_id, album_id):
        row["canAddFavorite"] = True
    if row_type != "playlist" and playlist_id and playlist_item_index != "":
        row["can_remove_playlist_item"] = True
    if has_playable_actions or go_action_play or row_type in ("track", "radio", "station"):
        row["canPlayLoad"] = True
    if has_playable_actions or row_type in ("track", "album", "playlist", "radio", "station"):
        row["canPlayAdd"] = True
        row["canPlayInsert"] = True
    try:
        dbg("ALBUM ROW DEBUG label=%s type=%s album_id=%s track_id=%s canAddFavorite=%s node=%s raw_id=%s raw_keys=%s" % (
            _safe_str(row.get("label")),
            _safe_str(row.get("type")),
            _safe_str(row.get("album_id")),
            _safe_str(row.get("track_id")),
            _safe_str(row.get("canAddFavorite")),
            _safe_str(it.get("node")),
            _safe_str(it.get("id")),
            ",".join(sorted(list(it.keys()))) if isinstance(it, dict) else ""
        ))
    except Exception:
        pass
    return row

def _payload(node: str, title: str, items: List[Dict[str, Any]], can_back: bool, source: str = "", page_kind: str = "", context_name: str = "", context_source: str = "") -> Dict[str, Any]:
    return {
        "node": node,
        "title": title,
        "source": source,
        "page_kind": page_kind,
        "context_name": context_name,
        "context_source": context_source,
        "offset": 0,
        "limit": len(items),
        "total": len(items),
        "items": items,
        "nav": {"can_back": can_back, "can_home": node != "home"},
    }


async def _playlists_payload_direct(pid: str, offset: int = 0, limit: int = 100) -> Dict[str, Any]:
    rr = await lms.cmd(pid, "playlists", [offset, limit])
    res = rr.get("result") if isinstance(rr, dict) else {}
    raw_playlists = _extract_menu_items(res if isinstance(res, dict) else {})
    rows = []
    for raw in raw_playlists:
        if not isinstance(raw, dict):
            continue
        playlist_id = _first_nonempty(raw, "playlist_id", "playlistid", "id")
        label = _first_nonempty(raw, "playlist", "title", "name", "text")
        if not playlist_id or not label:
            continue
        row = {
            "id": f"playlist:{playlist_id}",
            "label": label,
            "type": "playlist",
            "can_open": True,
            "can_rename_playlist": True,
            "can_delete_playlist": True,
        }
        art = _pick_art(raw) or _mymusic_fallback_art({"id": "myMusicPlaylists", "node": "myMusic"}, "Playlists")
        if art:
            row["art"] = art
            row["target_art"] = art
        rows.append(row)
    if not rows:
        rows.append({
            "id": "noop:empty-playlists",
            "label": "Empty",
            "type": "node",
            "can_open": False,
            "art": _mymusic_fallback_art({"id": "myMusicPlaylists", "node": "myMusic"}, "Playlists"),
        })
    return _payload("cmd:playlists", "Playlists", rows, True, "My Music", "section", "Playlists", "My Music")


def _favorite_row_from_lms_item(it: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(it, dict):
        return None
    label = _clean_text(it.get("name") or it.get("title") or it.get("text"))
    if not label:
        return None
    url = _safe_str(it.get("url")).strip()
    art = _normalize_icon_url(_safe_str(it.get("image") or it.get("icon")).strip())
    row_type = "track"
    item_id = ""
    can_open = False
    fav_id = _safe_str(it.get("id")).strip()
    fav_delete_id = fav_id.split(".", 1)[1] if "." in fav_id else fav_id

    low_url = url.lower()
    if fav_id:
        item_id = "favitem:" + _b64u_enc({
            "id": fav_id,
            "delete_id": fav_delete_id,
            "url": url,
            "title": label,
        })
        if low_url.startswith("db:album.id="):
            row_type = "album"
        elif low_url.startswith("db:playlist.id="):
            row_type = "playlist"
        elif low_url.startswith("db:contributor.id="):
            row_type = "artist"
        elif "pandora" in low_url or low_url.startswith("frpandora"):
            row_type = "station"
        else:
            row_type = "track"
        if row_type == "station":
            art = (
                _pandora_station_art_by_url.get(_pandora_url_key(url))
                or _pandora_station_art_by_label.get(_norm_key(label))
                or art
            )
    elif low_url.startswith("db:track.id="):
        val = url.split("=", 1)[1].strip()
        item_id = "title:" + val
        row_type = "track"
    elif low_url.startswith("db:album.id="):
        val = url.split("=", 1)[1].strip()
        item_id = "album:" + val
        row_type = "album"
    elif low_url.startswith("db:playlist.id="):
        val = url.split("=", 1)[1].strip()
        item_id = "playlist:" + val
        row_type = "playlist"
    elif low_url.startswith("db:contributor.id="):
        val = url.split("=", 1)[1].strip()
        item_id = "artist:" + val
        row_type = "artist"

    if not item_id:
        return None

    row: Dict[str, Any] = {
        "id": item_id,
        "label": label,
        "type": row_type,
        "can_open": can_open,
        "canPlayLoad": True,
        "canPlayAdd": True,
        "canPlayInsert": True,
        "canRemoveFavorite": True,
    }
    if art:
        row["art"] = art
    if row_type == "album" and item_id.startswith("album:"):
        row["album_id"] = item_id.split(":", 1)[1]
    return row


async def _prime_pandora_favorite_art(pid: str, raw_items: List[Dict[str, Any]]) -> None:
    menus: Set[str] = set()
    for it in raw_items if isinstance(raw_items, list) else []:
        if not isinstance(it, dict):
            continue
        url = _safe_str(it.get("url")).strip().lower()
        if url.startswith("frpandora0://"):
            menus.add("fr_pandora_0")
        elif url.startswith("frpandora1://"):
            menus.add("fr_pandora_1")
        elif url.startswith("frpandora2://"):
            menus.add("fr_pandora_2")
        elif url.startswith("frpandora3://"):
            menus.add("fr_pandora_3")
    for menu in sorted(menus):
        try:
            res = await lms.rpc(pid or "", [menu, "items", "0", "200", f"menu:{menu}", "item_id:0"])
            payload = (res.get("result") or {}) if isinstance(res, dict) else {}
            _extract_menu_items(payload)
        except Exception as e:
            dbg(f"PANDORA favorite art prime failed menu={menu}: {type(e).__name__}: {_safe_str(e)}")


async def _favorites_payload_direct(pid: str = "", offset: int = 0, limit: int = 100) -> Dict[str, Any]:
    offset = max(0, _safe_int(offset, 0))
    limit = _safe_int(limit, 100)
    if limit <= 0:
        limit = 100
    res = await lms.rpc("", ["favorites", "items", str(offset), str(limit), "want_url:1"])
    payload = (res.get("result") or {}) if isinstance(res, dict) else {}
    raw_items = payload.get("loop_loop") if isinstance(payload.get("loop_loop"), list) else []
    await _prime_pandora_favorite_art(pid, raw_items)
    rows = [row for row in (_favorite_row_from_lms_item(it) for it in raw_items) if isinstance(row, dict)]
    total = _safe_int(payload.get("count"), len(rows))
    title = _configured_source_label("favorites") or _safe_str(payload.get("title") or "Favorites")
    return {
        "node": "root:favorites",
        "title": title,
        "source": title,
        "page_kind": "track_list" if rows else "container",
        "context_name": title,
        "context_source": title,
        "offset": offset,
        "limit": limit,
        "total": total,
        "items": rows,
        "nav": {"can_back": True, "can_home": True},
    }




def _infer_page_kind(rows: List[Dict[str, Any]]) -> str:
    if not isinstance(rows, list) or not rows:
        return "container"
    has_trackish = False
    actionish = 0
    for r in rows:
        if not isinstance(r, dict):
            continue
        if _safe_str(r.get("type")).lower() == "track" or _safe_str(r.get("track_id")).strip() or _safe_str(r.get("album_id")).strip() or _safe_int(r.get("duration"), 0) > 0:
            has_trackish = True
        if r.get("can_open"):
            return "container"
        if _safe_str(r.get("id")).startswith("act:") or r.get("canPlayLoad") or r.get("canPlayAdd") or r.get("canPlayInsert"):
            actionish += 1
    if has_trackish:
        return "track_list"
    if actionish > 0:
        return "action_page"
    return "container"

def _home_payload_from_top(top: Dict[str, Any], home_rows: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    items = _extract_menu_items(top)
    rows: List[Dict[str, Any]] = []
    home_art_version = f"home-{APP_VERSION}"
    menu_rows = home_rows if isinstance(home_rows, list) else _home_menu_cache
    for rowcfg in sorted(menu_rows, key=lambda r: (_safe_int(r.get("order"),100), _safe_str(r.get("label")))):
        if not rowcfg.get("enabled"):
            continue
        key = _safe_str(rowcfg.get("key")).strip().lower()
        label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or key)
        kind = _safe_str(rowcfg.get("type") or ("core" if key in ("mymusic","radio","favorites") else "app")) or "core"
        if kind == "core":
            if key == "mymusic":
                it = _top_find_home_item(items, "My Music") or {}
                row = {"id": "root:mymusic", "label": label or "My Music", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/html/images/musicfolder.png")
                if art: row["art"] = _broker_rounded_list_art_url(art, home_art_version)
                rows.append(row)
            elif key == "radio":
                it = _top_find_home_item(items, "Radio") or {}
                row = {"id": "root:radio", "label": label or "Radio", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/plugins/TuneIn/html/images/radio.png")
                if art: row["art"] = _broker_rounded_list_art_url(art, home_art_version)
                rows.append(row)
            elif key == "favorites":
                it = _top_find_home_item(items, "Favorites") or {}
                row = {"id": "root:favorites", "label": label or "Favorites", "type": "node", "can_open": True}
                art = _pick_art(it) or _normalize_icon_url("/html/images/favorites.png")
                if art: row["art"] = _broker_rounded_list_art_url(art, home_art_version)
                rows.append(row)
            continue
        want = _norm_key(rowcfg.get("source_label") or rowcfg.get("label") or "")
        picked = None
        for it in items:
            if _safe_int(it.get("isApp"), 0) != 1:
                continue
            if _norm_key(_pick_label(it)) == want:
                picked = it
                break
        if picked is None:
            continue
        root_id = "rootapp:" + _safe_str(rowcfg.get("key"))
        r = {"id": root_id, "label": label or _pick_label(picked), "type": "node", "can_open": True}
        if _is_pyrrha_home_item(rowcfg.get("key"), rowcfg.get("source_label") or rowcfg.get("label") or label):
            art = _pyrrha_classic_icon_url()
        else:
            art = _pick_art(picked) or _safe_str(rowcfg.get("icon") or "")
        if art:
            r["art"] = _broker_rounded_list_art_url(art, home_art_version)
        rows.append(r)
    return _payload("home", _safe_str(_setup_cache.get("home_title") or "Home"), rows, False, "", "home", "", "")


def _group_payload_from_top(top: Dict[str, Any], node_name: str, title: str, source: str = "") -> Dict[str, Any]:
    raw_group: List[Dict[str, Any]] = []
    for it in _extract_menu_items(top):
        if _safe_str(it.get("node")) == node_name:
            raw_group.append(it)
    if node_name == "myMusic" and not any("playlist" in _norm_key(it.get("id")) or "playlist" in _norm_key(_pick_label(it)) for it in raw_group):
        raw_group.append({
            "id": "cmd:playlists",
            "text": "Playlists",
            "node": "myMusic",
            "weight": 80,
        })
    if node_name == "randomplay":
        raw_group = [
            it for it in raw_group
            if _safe_str(it.get("id")).strip().lower() != "randomchooselibrary"
            and _norm_key(_pick_label(it)) != "uselibraryview"
        ]
    if node_name == "myMusic":
        raw_group = _apply_mymusic_menu_config(raw_group)
    elif node_name == "radios":
        raw_group = _apply_radio_menu_config(raw_group)
    items = [_row_from_action_item(it) for it in raw_group]
    if node_name == "radios":
        radio_art_version = f"radio-{APP_VERSION}"
        for row in items:
            art = _safe_str(row.get("art")).strip()
            if art:
                row["art"] = _broker_rounded_list_art_url(art, radio_art_version)
    source = _clean_text(source or title)
    return _payload(f"group:{node_name}", title, items, True, source, "section", title, source)


def _action_to_rpc_args(action: Dict[str, Any], offset: int = 0, limit: int = 60, search: str = "") -> List[Any]:
    cmd = action.get("cmd") or []
    if not isinstance(cmd, list):
        cmd = [cmd]
    args: List[Any] = list(cmd)
    lower = [_safe_str(x).lower() for x in args]
    if any(x == "items" for x in lower):
        args.extend([str(offset), str(limit)])
    elif lower and lower[0] == "randomplaygenrelist" and len(args) == 1:
        # Without a range LMS returns only the count, not the genre rows.
        args.extend(["0", "200"])
    params = action.get("params") or {}
    if (
        isinstance(params, dict)
        and len(lower) >= 3
        and _safe_str(args[0]).strip().lower().startswith("fr_pandora_")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() in ("play", "add")
    ):
        params = dict(params)
        for k in ("isContextMenu", "useContextMenu", "nextWindow"):
            params.pop(k, None)
    search = _safe_str(search).strip()
    search_added = False
    station_added = False
    if isinstance(params, dict):
        for k, v in params.items():
            lk = _safe_str(k).lower()
            if lk in ("player", "playerid", "player_id"):
                continue
            if search and lk in ("search", "searchterm", "query", "q", "term", "station", "stationname", "station_name"):
                args.append(f"{k}:{search}")
                search_added = True
                if lk in ("station", "stationname", "station_name"):
                    station_added = True
                continue
            if v is None or v == "":
                continue
            args.append(f"{k}:{v}")
    if search and not search_added:
        args.append(f"search:{search}")
    if search and args and _safe_str(args[0]).lower().startswith("fr_pandora") and not station_added:
        args.append(f"station:{search}")
    return args


def _menu_action_track_override_args(acts: Dict[str, Any], pcmd: str) -> Optional[List[Any]]:
    if not isinstance(acts, dict):
        return None

    add_hold = acts.get("add-hold") if isinstance(acts.get("add-hold"), dict) else None
    ah_params = add_hold.get("params") if isinstance(add_hold, dict) and isinstance(add_hold.get("params"), dict) else {}
    track_id = _safe_str(ah_params.get("track_id")).strip()
    if not track_id:
        return None

    play = acts.get("play") if isinstance(acts.get("play"), dict) else None
    play_params = play.get("params") if isinstance(play, dict) and isinstance(play.get("params"), dict) else {}
    add = acts.get("add") if isinstance(acts.get("add"), dict) else None
    add_params = add.get("params") if isinstance(add, dict) and isinstance(add.get("params"), dict) else {}

    # Track rows coming from LMS album drilldown often expose:
    #   play      -> album-level playlistcontrol load
    #   add       -> album-level playlistcontrol add
    #   add-hold  -> track-level playlistcontrol insert
    # For RTI target mode we want the selected track, not the whole album.
    # When add-hold gives us a concrete track_id, prefer that for load/add too.
    args: List[Any] = ["playlistcontrol", pcmd, f"track_id:{track_id}"]

    src_params = ah_params
    if pcmd == "cmd:load" and play_params:
        src_params = play_params
    elif pcmd == "cmd:add" and add_params:
        src_params = add_params

    for key in ("menu", "sort"):
        val = src_params.get(key)
        if val is None or val == "":
            val = ah_params.get(key)
        if val is not None and val != "":
            args.append(f"{key}:{val}")
    return args


def _qobuz_action_args(acts: Dict[str, Any], pcmd: str) -> Optional[List[Any]]:
    if not isinstance(acts, dict):
        return None

    if pcmd == "cmd:insert":
        key = "add-hold"
        verb = "insert"
    elif pcmd == "cmd:add":
        key = "add"
        verb = "add"
    else:
        key = "play"
        verb = "play"

    act = acts.get(key) if isinstance(acts.get(key), dict) else None
    if not isinstance(act, dict):
        return None
    cmd = act.get("cmd") if isinstance(act.get("cmd"), list) else []
    if len(cmd) < 3:
        return None
    if _safe_str(cmd[0]).strip().lower() != "qobuz":
        return None
    if _safe_str(cmd[1]).strip().lower() != "playlist":
        return None

    params = act.get("params") if isinstance(act.get("params"), dict) else {}
    if _safe_str(params.get("menu")).strip().lower() != "qobuz":
        return None

    item_id = _safe_str(params.get("item_id") or params.get("touchToPlay")).strip()
    args: List[Any] = ["qobuz", "playlist", verb, "menu:qobuz"]
    if item_id:
        args.extend(["isContextMenu:1", f"item_id:{item_id}"])
    return args


def _is_qobuz_action_spec(acts: Dict[str, Any]) -> bool:
    return _qobuz_action_args(acts, "cmd:load") is not None


def _tidal_action_args(acts: Dict[str, Any], pcmd: str) -> Optional[List[Any]]:
    if not isinstance(acts, dict):
        return None

    if pcmd == "cmd:insert":
        key = "add-hold"
    elif pcmd == "cmd:add":
        key = "add"
    else:
        key = "play"

    act = acts.get(key) if isinstance(acts.get(key), dict) else None
    if not isinstance(act, dict):
        return None
    cmd = act.get("cmd") if isinstance(act.get("cmd"), list) else []
    if len(cmd) < 3:
        return None
    if _safe_str(cmd[0]).strip().lower() != "tidal_browse":
        return None
    if _safe_str(cmd[1]).strip().lower() != "playlist":
        return None

    return _action_to_rpc_args(act, 0, 60)


def _is_tidal_action_spec(acts: Dict[str, Any]) -> bool:
    return _tidal_action_args(acts, "cmd:load") is not None


def _bbc_action_args(acts: Dict[str, Any], pcmd: str) -> Optional[List[Any]]:
    if not isinstance(acts, dict):
        return None
    if pcmd == "cmd:insert":
        key = "add-hold"
    elif pcmd == "cmd:add":
        key = "add"
    else:
        key = "play"
    act = acts.get(key) if isinstance(acts.get(key), dict) else None
    if not isinstance(act, dict):
        return None
    cmd = act.get("cmd") if isinstance(act.get("cmd"), list) else []
    if not cmd:
        return None
    if _safe_str(cmd[0]).strip().lower() not in ("bbcsounds", "playlist"):
        return None
    return _action_to_rpc_args(act, 0, 60)


def _pandora_contextmenu_action_from_spec(spec: Dict[str, Any], allow_play_this_station: bool = False) -> Optional[Dict[str, Any]]:
    try:
        if not isinstance(spec, dict):
            return None
        if not allow_play_this_station and _norm_key(spec.get("label")) == "playthisstation":
            return None
        acts = spec.get("actions") or {}
        if not isinstance(acts, dict) or not acts:
            return None
        sample = _pandora_station_action(acts)
        if not isinstance(sample, dict):
            return None
        cmd = sample.get("cmd") or []
        if not isinstance(cmd, list):
            cmd = [cmd]
        lower = [_safe_str(x).lower() for x in cmd]
        if len(lower) < 3:
            return None
        menu_name = _pandora_menu_name(lower[0])
        if not menu_name:
            return None
        if lower[1] != "playlist" or lower[2] != "play":
            return None
        params = sample.get("params") or {}
        if not isinstance(params, dict):
            return None
        if _pandora_menu_name(params.get("menu")) != menu_name:
            return None
        if not _safe_str(params.get("item_id")):
            return None
        ctx_params = dict(params)
        parent_id = _pandora_station_parent_item_id(ctx_params.get("item_id"))
        current_id = _safe_str(ctx_params.get("item_id")).strip()
        if parent_id and parent_id != current_id:
            ctx_params["item_id"] = parent_id
            dbg("PANDORA CONTEXT parent item_id=%s from=%s" % (parent_id, current_id))
        for k in ("touchToPlay", "touchToPlaySingle", "nextWindow", "player", "playerid", "player_id"):
            ctx_params.pop(k, None)
        ctx_params["isContextMenu"] = 1
        if "useContextMenu" not in ctx_params:
            ctx_params["useContextMenu"] = 1
        dbg("PANDORA CONTEXT OPEN item_id=" + _safe_str(ctx_params.get("item_id")))
        # Pandora's station "play" action starts playback even with
        # isContextMenu set. Ask the plugin's XML-browser endpoint for the
        # context menu instead, using the same station item_id.
        return {"cmd": [cmd[0], "items"], "params": ctx_params}
    except Exception as e:
        dbg("PANDORA CONTEXT helper error: " + _safe_str(e))
        return None

def _pandora_station_parent_item_id(item_id: Any) -> str:
    s = _safe_str(item_id).strip()
    if not s:
        return ""
    parts = [p for p in s.split(".") if p != ""]
    if len(parts) >= 3:
        return ".".join(parts[:2])
    return s

def _spec_label_for_favorite(spec: Dict[str, Any]) -> str:
    if not isinstance(spec, dict):
        return ""
    v = _safe_str(spec.get("label") or spec.get("title") or spec.get("name")).strip()
    if "\n" in v:
        v = v.split("\n", 1)[0].strip()
    return v

def _favorite_args_from_ids(title: str, track_id: str = "", album_id: str = "", artist_id: str = "", playlist_id: str = "") -> Optional[List[Any]]:
    title = _safe_str(title).strip()
    if track_id:
        return ["favorites", "add", f"url:db:track.id={track_id}", f"title:{title or track_id}"]
    if album_id:
        return ["favorites", "add", f"url:db:album.id={album_id}", f"title:{title or album_id}"]
    if artist_id:
        return ["favorites", "add", f"url:db:contributor.id={artist_id}", f"title:{title or artist_id}"]
    if playlist_id:
        return ["favorites", "add", f"url:db:playlist.id={playlist_id}", f"title:{title or playlist_id}"]
    return None

def _spec_favorite_args(spec: Dict[str, Any]) -> Optional[List[Any]]:
    if not isinstance(spec, dict):
        return None

    title = _spec_label_for_favorite(spec)

    # Exact favorite action from LMS/plugin, if present.
    acts = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
    for k in ("favorite", "favorites", "addfavorite", "add_favorite", "savefavorite", "save_favorite"):
        act = acts.get(k)
        if isinstance(act, dict):
            args = _action_to_rpc_args(act, 0, 60)
            if isinstance(args, list) and args:
                return args

    # Explicit favorite URL from plugin rows. LMS favorites add accepts icon,
    # but only if the row metadata survives the RTI round trip.
    for bucket in (spec, spec.get("presetParams"), spec.get("commonParams"), spec.get("params"), spec.get("playControlParams")):
        if isinstance(bucket, dict):
            fav_url = _safe_str(bucket.get("favorites_url")).strip()
            if fav_url:
                fav_title = _safe_str(bucket.get("favorites_title")).strip() or title or fav_url
                args = ["favorites", "add", f"url:{fav_url}", f"title:{fav_title}"]
                fav_icon = _normalize_icon_url(
                    _safe_str(
                        bucket.get("icon")
                        or bucket.get("image")
                        or bucket.get("artwork_url")
                        or spec.get("icon")
                        or spec.get("image")
                        or spec.get("artwork_url")
                    )
                )
                if fav_icon:
                    args.append(f"icon:{fav_icon}")
                fav_type = _safe_str(bucket.get("favorites_type") or bucket.get("type")).strip()
                if fav_type:
                    args.append(f"type:{fav_type}")
                return args

    # Fall back to ids found in any common action params.
    track_id = album_id = artist_id = playlist_id = ""
    for k in ("add-hold", "play", "add", "go", "do"):
        act = acts.get(k)
        if not isinstance(act, dict):
            continue
        params = act.get("params") if isinstance(act.get("params"), dict) else {}
        track_id = track_id or _safe_str(params.get("track_id")).strip()
        album_id = album_id or _safe_str(params.get("album_id")).strip()
        artist_id = artist_id or _safe_str(params.get("artist_id")).strip()
        playlist_id = playlist_id or _safe_str(params.get("playlist_id")).strip()

    return _favorite_args_from_ids(title, track_id, album_id, artist_id, playlist_id)


def _favorite_args_with_title(args: List[Any], title: Any) -> List[Any]:
    clean_title = _valid_station_label(title) or _clean_text(title).splitlines()[0].strip()
    if not clean_title:
        return args
    out = list(args)
    replaced = False
    for idx, value in enumerate(out):
        if _safe_str(value).lower().startswith("title:"):
            out[idx] = f"title:{clean_title}"
            replaced = True
    if not replaced:
        out.append(f"title:{clean_title}")
    return out


def _favorite_title_from_nav(ws: web.WebSocketResponse, spec: Dict[str, Any]) -> str:
    favorite_title = _valid_station_label(spec.get("label")) if isinstance(spec, dict) else ""
    if favorite_title:
        return favorite_title
    for frame in reversed(_ws_nav.get(id(ws)) or []):
        favorite_title = _valid_station_label(frame.get("selected_label"))
        if favorite_title:
            return favorite_title
        payload = frame.get("payload") if isinstance(frame, dict) else {}
        if not isinstance(payload, dict):
            continue
        favorite_title = _valid_station_label(
            payload.get("context_name") or payload.get("title")
        )
        if favorite_title:
            return favorite_title
    return ""


def _pandora_station_from_current_nav(ws: web.WebSocketResponse, spec: Dict[str, Any]) -> str:
    if isinstance(spec, dict):
        label = _valid_station_label(spec.get("label"))
        if label:
            return label
        for key in ("context_name", "title", "name"):
            label = _valid_station_label(spec.get(key))
            if label:
                return label
    for frame in reversed(_ws_nav.get(id(ws)) or []):
        if not isinstance(frame, dict):
            continue
        label = _valid_station_label(frame.get("selected_label"))
        if label:
            return label
        payload = frame.get("payload") if isinstance(frame.get("payload"), dict) else {}
        for key in ("context_name", "title"):
            label = _valid_station_label(payload.get(key))
            if label:
                return label
    return ""


async def _context_favorite_args(pid: str, spec: Dict[str, Any], title: Any = "") -> Optional[List[Any]]:
    if not isinstance(spec, dict):
        return None
    ctx = _pandora_contextmenu_action_from_spec(spec, allow_play_this_station=True)
    if not isinstance(ctx, dict):
        return None
    try:
        rr = await lms.rpc(pid, _action_to_rpc_args(ctx, 0, 60))
        result = rr.get("result") if isinstance(rr, dict) else {}
        items = _extract_menu_items(result if isinstance(result, dict) else {})
        for it in items:
            if not isinstance(it, dict):
                continue
            args = _spec_favorite_args(it)
            if args:
                return _favorite_args_with_title(args, title)
            label_key = _norm_key(_pick_label(it))
            if "favorite" not in label_key:
                continue
            acts = it.get("actions") if isinstance(it.get("actions"), dict) else {}
            for key in ("favorite", "favorites", "addfavorite", "add_favorite", "savefavorite", "save_favorite", "go", "do", "play"):
                act = acts.get(key) if isinstance(acts, dict) else None
                if isinstance(act, dict):
                    args = _action_to_rpc_args(act, 0, 60)
                    if args:
                        return _favorite_args_with_title(args, title)
    except Exception as e:
        dbg("CONTEXT FAVORITE helper error: " + _safe_str(e))
    return None



def _find_top_action_item(top_items: List[Dict[str, Any]], menu: str = "", mode: str = "", node: str = "", item_id: str = "") -> Optional[Dict[str, Any]]:
    want_menu = _safe_str(menu)
    want_mode = _safe_str(mode)
    want_node = _safe_str(node)
    want_id = _safe_str(item_id)
    for it in top_items:
        if want_node and _safe_str(it.get("node")) != want_node:
            continue
        if want_id and _safe_str(it.get("id")) == want_id:
            return it
        acts = it.get("actions") or {}
        go = acts.get("go") if isinstance(acts, dict) else None
        params = go.get("params") if isinstance(go, dict) else None
        if isinstance(params, dict):
            if want_menu and _safe_str(params.get("menu")) == want_menu:
                if not want_mode or _safe_str(params.get("mode")) == want_mode:
                    return it
            if want_mode and _safe_str(params.get("mode")) == want_mode and (not want_menu or _safe_str(params.get("menu")) == want_menu):
                return it
    return None




def _base_action_for_item(base_action: Dict[str, Any], it: Dict[str, Any]) -> Dict[str, Any]:
    spec = copy.deepcopy(base_action)
    params = dict(spec.get("params") or {})
    items_params = _safe_str(spec.get("itemsParams"))
    bucket: Dict[str, Any] = {}
    if items_params == "params":
        bucket = dict(it.get("params") or {})
    elif items_params == "commonParams":
        bucket = dict(it.get("commonParams") or {})
    elif items_params == "presetParams":
        bucket = dict(it.get("presetParams") or {})
    elif items_params == "playControlParams":
        bucket = dict(it.get("playControlParams") or {})
    for rk, rv in bucket.items():
        if rv is not None and rv != "":
            params[rk] = rv
    spec["params"] = params
    return spec


def _merge_base_actions_into_raw_items(raw_items: List[Dict[str, Any]], base_actions: Dict[str, Any]) -> None:
    for it in raw_items:
        if not isinstance(it, dict):
            continue
        row_params = it.get("params") if isinstance(it.get("params"), dict) else {}
        if (not isinstance(it.get("actions"), dict)) and isinstance(it.get("addAction"), str):
            ak = _safe_str(it.get("addAction"))
            if isinstance(base_actions.get(ak), dict):
                it["actions"] = {ak: dict(base_actions.get(ak) or {})}
        # For many LMS plugin rows (eg Pyrrha/Pandora-style itemplay/audio), actions are not inline.
        # Instead the row advertises goAction/play and the parent result provides base.actions with
        # itemsParams:"params". Synthesize row actions from base.actions + row params so we call the
        # plugin's own command path rather than forcing playlistcontrol item_id loads.
        if not isinstance(it.get("actions"), dict):
            synth = {}
            ga = _safe_str(it.get("goAction")).strip()
            for bk in (ga, "play", "add", "add-hold", "go"):
                if not bk:
                    continue
                bv = base_actions.get(bk)
                if not isinstance(bv, dict):
                    continue
                synth[bk] = _base_action_for_item(bv, it)
            if synth:
                it["actions"] = synth
        elif isinstance(it.get("actions"), dict) and isinstance(base_actions, dict):
            for bk, bv in base_actions.items():
                if bk not in it["actions"] and isinstance(bv, dict):
                    it["actions"][bk] = _base_action_for_item(bv, it)


def _fill_tagged_search_inputs(obj: Any, search: str) -> None:
    s = _safe_str(search).strip()
    if not s:
        return
    try:
        if isinstance(obj, dict):
            for k, v in list(obj.items()):
                if isinstance(v, str) and v.strip().upper() == "__TAGGEDINPUT__":
                    obj[k] = s
                elif isinstance(v, (dict, list)):
                    _fill_tagged_search_inputs(v, s)
        elif isinstance(obj, list):
            for v in obj:
                if isinstance(v, (dict, list)):
                    _fill_tagged_search_inputs(v, s)
    except Exception:
        pass

def _search_bucket_from_item(it: Dict[str, Any]) -> str:
    if not isinstance(it, dict):
        return ""
    acts = it.get("actions") if isinstance(it.get("actions"), dict) else {}
    go = acts.get("go") if isinstance(acts.get("go"), dict) else None
    params = go.get("params") if isinstance(go, dict) and isinstance(go.get("params"), dict) else {}
    bucket = _safe_str(params.get("cachesearch")).strip().upper()
    if bucket:
        return bucket
    lab = _norm_key(_pick_label(it))
    if "artist" in lab:
        return "ARTISTS"
    if "album" in lab:
        return "ALBUMS"
    if "song" in lab or "track" in lab:
        return "SONGS"
    if "work" in lab:
        return "WORKS"
    return ""

def _search_bucket_suffix(bucket: str) -> str:
    b = _safe_str(bucket).strip().upper()
    if b.startswith("ARTIST"):
        return "Artist"
    if b.startswith("ALBUM"):
        return "Album"
    if b.startswith("SONG") or b.startswith("TRACK"):
        return "Song"
    if b.startswith("WORK"):
        return "Work"
    if b.startswith("PLAYLIST"):
        return "Playlist"
    return ""

def _looks_like_search_bucket_page(items: List[Dict[str, Any]], search: str) -> bool:
    if not search or not isinstance(items, list) or not items:
        return False
    found = 0
    for it in items:
        if _search_bucket_from_item(it):
            found += 1
    return found >= max(2, min(3, len(items)))

async def _flatten_mymusic_search_results(pid: str, raw_items: List[Dict[str, Any]], search: str, limit: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    order = {"ARTISTS": 0, "ALBUMS": 1, "SONGS": 2, "TRACKS": 2, "WORKS": 3, "PLAYLISTS": 4}
    buckets = sorted(
        [it for it in raw_items if isinstance(it, dict) and _search_bucket_from_item(it)],
        key=lambda it: order.get(_search_bucket_from_item(it), 99)
    )
    per_bucket = max(3, min(12, _safe_int(limit, 20)))
    for bucket_item in buckets:
        bucket = _search_bucket_from_item(bucket_item)
        suffix = _search_bucket_suffix(bucket)
        acts = bucket_item.get("actions") if isinstance(bucket_item.get("actions"), dict) else {}
        go = acts.get("go") if isinstance(acts.get("go"), dict) else None
        if not isinstance(go, dict):
            continue
        action = copy.deepcopy(go)
        _fill_tagged_search_inputs(action, search)
        try:
            rr = await lms.rpc(pid, _action_to_rpc_args(action, 0, per_bucket, ""))
            sub_res = rr.get("result") or {}
            sub_items = _extract_menu_items(sub_res)
            base_actions = (sub_res.get("base") or {}).get("actions") or {}
            _merge_base_actions_into_raw_items(sub_items, base_actions)
        except Exception as e:
            dbg("SEARCH FLATTEN bucket=%s failed: %s" % (bucket, _safe_str(e)))
            continue
        for raw in sub_items:
            if not isinstance(raw, dict):
                continue
            row = _row_from_action_item(raw)
            label = _safe_str(row.get("label")).strip()
            if suffix and label and f"({suffix})" not in label:
                row["label"] = f"{label} ({suffix})"
            sig = _safe_str(row.get("id") or row.get("label"))
            if not sig or sig in seen:
                continue
            seen.add(sig)
            out.append(row)
            if len(out) >= _safe_int(limit, 20):
                return out
    return out


def _first_nonempty(d: Dict[str, Any], *keys: str) -> str:
    if not isinstance(d, dict):
        return ""
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            return _safe_str(v).strip()
    return ""


async def _direct_mymusic_search_results(search: str, limit: int = 60) -> List[Dict[str, Any]]:
    term = _safe_str(search).strip()
    if not term:
        return []
    max_items = max(5, min(_safe_int(limit, 20), 40))

    async def quick_rpc(args: List[Any]) -> Dict[str, Any]:
        try:
            return await asyncio.wait_for(lms.rpc("", args), timeout=2.0)
        except Exception as e:
            dbg("SEARCH DIRECT failed args=%s err=%s" % (_safe_str(args), _safe_str(e)))
            return {}

    per_group = max(6, min(16, max_items))
    artist_r, album_r, title_r = await asyncio.gather(
        quick_rpc(["artists", 0, per_group, f"search:{term}"]),
        quick_rpc(["albums", 0, per_group, f"search:{term}"]),
        quick_rpc(["titles", 0, per_group, f"search:{term}", "tags:aldt"]),
    )

    rows: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    def add_row(row: Dict[str, Any]) -> None:
        if len(rows) >= max_items:
            return
        sig = _safe_str(row.get("id") or row.get("label")).strip()
        if not sig or sig in seen:
            return
        seen.add(sig)
        rows.append(row)

    def leaf_row(row_id: str, label: str, suffix: str, raw: Dict[str, Any]) -> Dict[str, Any]:
        text = _safe_str(label).strip()
        if suffix and text and f"({suffix})" not in text:
            text = f"{text} ({suffix})"
        row: Dict[str, Any] = {
            "id": row_id,
            "label": text,
            "type": "track",
            "can_open": False,
        }
        artist = _first_nonempty(raw, "artist", "artistname", "contributor")
        album = _first_nonempty(raw, "album", "albumtitle")
        duration = _first_nonempty(raw, "duration", "secs", "seconds")
        track_id = _first_nonempty(raw, "track_id", "trackid", "id") if row_id.startswith("title:") else ""
        album_id = _first_nonempty(raw, "album_id", "albumid", "id") if row_id.startswith("album:") else _first_nonempty(raw, "album_id", "albumid")
        if artist:
            row["artist"] = artist
        if album:
            row["album"] = album
        if duration:
            row["duration"] = duration
        if track_id:
            row["track_id"] = track_id
        if album_id:
            row["album_id"] = album_id
        art = _pick_art(raw) or _track_album_art_url(raw) or _local_cover_art_url(raw)
        if art:
            row["art"] = art
        return row

    artist_res = (artist_r.get("result") or {}) if isinstance(artist_r, dict) else {}
    for raw in artist_res.get("artists_loop") or artist_res.get("contributors_loop") or []:
        if not isinstance(raw, dict):
            continue
        aid = _first_nonempty(raw, "artist_id", "contributor_id", "id")
        name = _first_nonempty(raw, "artist", "artistname", "contributor", "name")
        if aid and name:
            add_row(leaf_row(f"artist:{aid}", name, "Artist", raw))

    album_res = (album_r.get("result") or {}) if isinstance(album_r, dict) else {}
    for raw in album_res.get("albums_loop") or []:
        if not isinstance(raw, dict):
            continue
        aid = _first_nonempty(raw, "album_id", "albumid", "id")
        name = _first_nonempty(raw, "album", "albumtitle", "title", "name")
        if aid and name:
            add_row(leaf_row(f"album:{aid}", name, "Album", raw))

    title_res = (title_r.get("result") or {}) if isinstance(title_r, dict) else {}
    for raw in title_res.get("titles_loop") or title_res.get("tracks_loop") or []:
        if not isinstance(raw, dict):
            continue
        tid = _first_nonempty(raw, "track_id", "trackid", "id")
        name = _first_nonempty(raw, "title", "track", "name")
        if tid and name:
            add_row(leaf_row(f"title:{tid}", name, "Song", raw))

    dbg("SEARCH DIRECT term=%s rows=%s" % (term, len(rows)))
    return rows



def _library_title_from_action(action: Dict[str, Any], title_hint: str = "") -> str:
    t = _safe_str(title_hint).strip()
    if t and t.lower() not in ("library", "browse", "music library"):
        return t
    params = action.get("params") if isinstance(action, dict) and isinstance(action.get("params"), dict) else {}
    mode = _safe_str(params.get("mode")).strip().lower()
    if mode == "albums":
        return "Albums"
    if mode == "artists":
        return "Artists"
    if mode == "genres":
        return "Genres"
    if mode == "playlists":
        return "Playlists"
    if mode == "years":
        return "Years"
    if mode == "search":
        return "Search"
    cmd = action.get("cmd") if isinstance(action, dict) else []
    if isinstance(cmd, list) and len(cmd) >= 2 and _safe_str(cmd[0]).lower() == "browselibrary" and _safe_str(cmd[1]).lower() == "items":
        return "My Music"
    menu = _safe_str(params.get("menu")).strip()
    if menu == "1":
        return "My Music"
    return t or "Library"


async def _action_result_payload(pid: str, spec: Dict[str, Any], title_hint: str = "", offset: int = 0, limit: int = 60, source_hint: str = "", search: str = "") -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    if _safe_str(spec.get("kind")).strip().lower() == "bbc_items":
        raw_items = [
            row for row in (spec.get("items") if isinstance(spec.get("items"), list) else [])
            if isinstance(row, dict) and _pick_label(row).strip()
        ]
        items = [_row_from_action_item(row) for row in raw_items]
        await _enrich_track_rows(raw_items, items)
        title = _safe_str(spec.get("label") or title_hint or "BBC Sounds").strip() or "BBC Sounds"
        source = _safe_str(source_hint).strip() or "BBC Sounds"
        return ({
            "node": "act",
            "title": title,
            "source": source,
            "page_kind": _infer_page_kind(items),
            "context_name": title,
            "context_source": source,
            "offset": 0,
            "limit": len(items),
            "total": len(items),
            "items": items,
            "nav": {"can_back": True, "can_home": True},
        }, None)

    action = spec.get("action") or {}
    if not action:
        pandora_ctx = _pandora_contextmenu_action_from_spec(spec)
        if isinstance(pandora_ctx, dict):
            action = pandora_ctx
        else:
            acts = spec.get("actions") or {}
            if isinstance(acts, dict):
                if isinstance(acts.get("go"), dict):
                    action = acts.get("go")
                elif isinstance(acts.get("do"), dict):
                    action = acts.get("do")
                elif isinstance(acts.get("play"), dict):
                    action = acts.get("play")
                elif isinstance(acts.get("on"), dict) or isinstance(acts.get("off"), dict):
                    action = acts.get("off") if _safe_int(spec.get("checkbox"), 0) else acts.get("on")
    if not isinstance(action, dict) or not action:
        return (None, {"t": "err", "ok": False, "error": "unsupported_item"})
    search = _safe_str(search).strip()
    args = _action_to_rpc_args(action, offset, limit, search)
    is_iheart_station_play = (
        len(args) >= 3
        and _safe_str(args[0]).strip().lower() in ("iheartradio", "fr_iheartradio")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() == "play"
    )
    if is_iheart_station_play:
        await lms.rpc(pid, ["playlist", "clear"])
        _np_source_by_playerid[pid] = _configured_source_label("iheart") or "iHeartRadio"
        station_name = _clean_text(spec.get("label") or title_hint).splitlines()[0].strip()
        if station_name and not _is_internal_label(station_name):
            _np_station_by_playerid[pid] = station_name
            _np_station_by_playerid[pid.lower()] = station_name
    r = await lms.rpc(pid, args)
    r = await _verify_random_mix_start(pid, args, r)
    if (
        len(args) >= 3
        and _safe_str(args[0]).strip().lower() in ("podcast", "podcasts")
        and _safe_str(args[1]).strip().lower() == "playlist"
        and _safe_str(args[2]).strip().lower() == "play"
    ):
        _schedule_podcast_selection_refresh(pid, _safe_str(spec.get("label") or title_hint))
    if len(args) >= 2 and _safe_str(args[0]).strip().lower() == "randomplay":
        randomplay_mode = _safe_str(args[1]).strip().lower()
        if randomplay_mode == "disable":
            await lms.rpc(pid, ["stop"])
        else:
            _random_mix_queue_players.add(pid.lower())
    if is_iheart_station_play:
        asyncio.create_task(_collapse_iheart_queue_later(pid))
    res = (r.get("result") or {})
    raw_items = _extract_menu_items(res)
    replace_current_menu = False
    spec_label_key = _norm_key(spec.get("label"))
    action_params = action.get("params") if isinstance(action.get("params"), dict) else {}
    action_cmd = action.get("cmd") if isinstance(action.get("cmd"), list) else []
    is_bbc_action = bool(action_cmd and _safe_str(action_cmd[0]).strip().lower() == "bbcsounds")
    randomplay_command = _safe_str(action_cmd[0]).strip().lower() if action_cmd else ""
    if randomplay_command in ("randomplaychoosegenre", "randomplaygenreselectall"):
        refresh = await lms.rpc(pid, ["randomplaygenrelist", "0", "200"])
        refresh_res = refresh.get("result") or {}
        refresh_items = _extract_menu_items(refresh_res)
        if refresh_items:
            res = refresh_res
            raw_items = refresh_items
            replace_current_menu = True
            title_hint = "Choose Genres"
    action_menu_name = _pandora_menu_name(action_params.get("menu"))
    action_cmd_name = _pandora_menu_name(action_cmd[0]) if action_cmd else ""
    pandora_action_menu = action_menu_name if action_menu_name and action_menu_name == action_cmd_name else ""
    pandora_action_item_id = _safe_str(action_params.get("item_id")).strip()
    if (
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[0]).strip().lower() in ("iheartradio", "fr_iheartradio") and
        _safe_str(action_cmd[1]).strip().lower() == "items"
    ):
        if (
            _iheart_region_setting()
            and _iheart_skip_intro_when_filtered()
            and _norm_key(title_hint or spec.get("label")) in ("iheartradio", "iheart", "radio")
        ):
            selected_region = _iheart_region_setting()
            genre_item = _iheart_genre_follow_item(raw_items, selected_region)
            if not genre_item:
                genre_item = next((
                    item for item in raw_items
                    if isinstance(item, dict)
                    and _norm_key(_pick_label(item)) in ("genre", "genres")
                    and isinstance((item.get("actions") or {}).get("go"), dict)
                ), None)
            if genre_item:
                genre_action = (genre_item.get("actions") or {}).get("go")
                genre_args = _action_to_rpc_args(genre_action, 0, limit, "")
                genre_response = await lms.rpc(pid, genre_args)
                genre_res = genre_response.get("result") or {}
                genre_items = _extract_menu_items(genre_res)
                if genre_items:
                    follow_item = None
                    if _norm_key(_pick_label(genre_item)) in ("genre", "genres"):
                        follow_item = _iheart_genre_follow_item(genre_items, selected_region)
                    if follow_item:
                        follow_action = (follow_item.get("actions") or {}).get("go")
                        follow_args = _action_to_rpc_args(follow_action, 0, limit, "")
                        follow_response = await lms.rpc(pid, follow_args)
                        follow_res = follow_response.get("result") or {}
                        follow_items = _extract_menu_items(follow_res)
                        if follow_items:
                            genre_res = follow_res
                            genre_items = follow_items
                            genre_item = follow_item
                    res = genre_res
                    raw_items = genre_items
                    replace_current_menu = True
                    title_hint = _pick_label(genre_item) or "Genres"
                    dbg("IHEART skip intro opened Genres rows=%s" % len(raw_items))
        unfiltered_count = len(raw_items)
        raw_items = _filter_iheart_region_items(raw_items)
        if len(raw_items) != unfiltered_count:
            res["count"] = len(raw_items)
            dbg("IHEART REGION filter=%s rows=%s->%s" % (
                _iheart_region_setting(), unfiltered_count, len(raw_items)
            ))
    if action_cmd and _safe_str(action_cmd[0]).strip().lower() in ("spotty", "spotify"):
        unfiltered_count = len(raw_items)
        raw_items = _filter_spotty_menu_items(raw_items)
        if len(raw_items) != unfiltered_count:
            res["count"] = len(raw_items)
            dbg("SPOTTY filter transfer playback rows=%s->%s" % (unfiltered_count, len(raw_items)))
    if (
        search and
        "renamestation" in spec_label_key and
        bool(pandora_action_menu) and
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[1]).strip().lower() == "items"
    ):
        parent_station_id = _pandora_station_parent_item_id(action_params.get("item_id"))
        if parent_station_id:
            try:
                refresh = await lms.rpc(pid, [
                    pandora_action_menu, "items", 0, limit,
                    f"menu:{pandora_action_menu}",
                    f"item_id:{parent_station_id}",
                    "isContextMenu:1",
                    "useContextMenu:1",
                ])
                refresh_res = refresh.get("result") or {}
                refresh_items = _extract_menu_items(refresh_res)
                if refresh_items:
                    res = refresh_res
                    raw_items = refresh_items
                    replace_current_menu = True
                    dbg("PANDORA RENAME refresh station item_id=%s title=%s" % (parent_station_id, search))
            except Exception as e:
                dbg("PANDORA RENAME refresh failed item_id=%s err=%s" % (parent_station_id, _safe_str(e)))
    if (
        not raw_items and
        _safe_str(action.get("nextWindow")).strip().lower() == "parent" and
        bool(pandora_action_menu) and
        _safe_str(action_params.get("item_id")).strip() and
        len(action_cmd) >= 2 and
        _safe_str(action_cmd[1]).strip().lower() == "items" and
        ("stationwillbedeleted" in spec_label_key or "areyousure" in spec_label_key)
    ):
        return ({
            "node": "act",
            "title": "Station deleted",
            "source": _safe_str(source_hint).strip(),
            "page_kind": "message",
            "context_name": _safe_str(title_hint or spec.get("label") or "").strip(),
            "context_source": _safe_str(source_hint).strip(),
            "offset": 0,
            "limit": 0,
            "total": 0,
            "items": [],
            "nav": {"can_back": True, "can_home": True},
        }, None)
    if raw_items:
        base_actions = (res.get("base") or {}).get("actions") or {}
        fast_page: List[Dict[str, Any]] = list(raw_items)
        podcast_page_key = _norm_key(title_hint or spec.get("label"))
        parent_actions = spec.get("actions") if isinstance(spec.get("actions"), dict) else {}
        parent_play = parent_actions.get("play") if isinstance(parent_actions.get("play"), dict) else {}
        parent_play_cmd = parent_play.get("cmd") if isinstance(parent_play.get("cmd"), list) else []
        parent_go = parent_actions.get("go") if isinstance(parent_actions.get("go"), dict) else {}
        is_podcast_feed_page = (
            not parent_go
            and len(parent_play_cmd) >= 3
            and _safe_str(parent_play_cmd[0]).strip().lower() in ("podcast", "podcasts")
            and _safe_str(parent_play_cmd[1]).strip().lower() == "playlist"
            and _safe_str(parent_play_cmd[2]).strip().lower() == "play"
        )
        if (
            podcast_page_key == "recentlyplayed"
            or podcast_page_key.startswith("newepisodes")
            or is_podcast_feed_page
        ):
            for raw in fast_page:
                if isinstance(raw, dict):
                    raw["_broker_podcast_episode"] = True
        if search:
            _fill_tagged_search_inputs(fast_page, search)
        if search and offset == 0 and _looks_like_search_bucket_page(fast_page, search):
            direct_rows = await _direct_mymusic_search_results(search, limit)
            if direct_rows:
                dbg("SEARCH DIRECT page term=%s replacing bucket menu rows=%s" % (search, len(direct_rows)))
                return ({
                    "node": "act",
                    "title": f"Search for {search}",
                    "source": _safe_str(source_hint).strip(),
                    "page_kind": "track_list",
                    "context_name": search,
                    "context_source": _safe_str(source_hint).strip(),
                    "offset": 0,
                    "limit": len(direct_rows),
                    "total": len(direct_rows),
                    "items": direct_rows,
                    "nav": {"can_back": True, "can_home": True},
                    "_replace_current_menu": replace_current_menu,
                }, None)
        pandora_station_context_page = (
            _safe_str(spec.get("kind")).lower() == "pandora_station" or
            (
                bool(pandora_action_menu) and
                _safe_str(action_params.get("isContextMenu")).strip() in ("1", "true", "True") and
                _safe_str(action_params.get("item_id")).strip()
            )
        )
        if pandora_station_context_page:
            for raw in fast_page:
                if isinstance(raw, dict):
                    raw["no_icon"] = True
        _merge_base_actions_into_raw_items(fast_page, base_actions)
        if is_bbc_action:
            bbc_parent_id = _safe_str(action_params.get("item_id")).strip()
            page_offset = _safe_int(offset, 0)
            for idx, raw in enumerate(fast_page):
                if isinstance(raw, dict):
                    raw["_broker_bbc_sounds"] = True
                    if bbc_parent_id:
                        raw["_broker_bbc_item_id"] = f"{bbc_parent_id}.{page_offset + idx}"
                    row_id = _bbc_row_id(raw)
                    if row_id:
                        row_is_audio = _bbc_row_is_audio(raw)
                        if row_is_audio:
                            raw["actions"] = _bbc_item_actions(row_id)
                        else:
                            raw["actions"] = {
                                "go": {
                                    "cmd": ["bbcsounds", "items"],
                                    "params": {"item_id": row_id},
                                }
                            }
        visible_raw_items = [it for it in fast_page if isinstance(it, dict) and _pick_label(it).strip()]
        if len(visible_raw_items) != len(fast_page):
            dbg("MENU blank-label rows filtered title=%s rows=%s->%s" % (
                _safe_str(title_hint or spec.get("label") or ""),
                len(fast_page),
                len(visible_raw_items),
            ))
        items = [_row_from_action_item(it) for it in visible_raw_items]
        action_mode = _safe_str(action_params.get("mode")).strip().lower()
        action_playlist_id = _safe_str(action_params.get("playlist_id") or action_params.get("playlistid")).strip()
        if action_mode == "playlisttracks" and action_playlist_id:
            for row_idx, row in enumerate(items):
                if not isinstance(row, dict):
                    continue
                row["playlist_id"] = action_playlist_id
                row["playlist_item_index"] = str(_safe_int(offset, 0) + row_idx)
                row["can_remove_playlist_item"] = True
                row.pop("canAddFavorite", None)
        await _enrich_track_rows(visible_raw_items, items)
        raw_title = _safe_str((res.get("window") or {}).get("text") or res.get("title") or "")
        source = _safe_str(source_hint).strip()
        context_name = _safe_str(search or title_hint or spec.get("label") or "").strip()
        context_source = source
        page_kind = _infer_page_kind(items)
        force_title = bool(spec.get("force_title"))
        title = raw_title if raw_title and raw_title.lower() not in ("library", "browse", "music library") else _library_title_from_action(action, context_name)
        if search:
            title = search
        elif force_title and context_name:
            title = context_name
        elif page_kind == "track_list" and context_name:
            title = context_name
        elif raw_title.lower() in ("your stations", "stations") and context_name:
            title = context_name
        elif not title and context_name:
            title = context_name
        if not source:
            source = ""
        if title == "My Music":
            _dbg_broker_menu_rows(title, offset, fast_page, items)
        total = max(_safe_int(res.get("count"), len(items)), len(items))
        if is_podcast_feed_page:
            total = min(total, 200)
        payload = {
            "node": "act",
            "title": title,
            "source": source,
            "page_kind": page_kind,
            "context_name": context_name,
            "context_source": context_source,
            "offset": offset,
            "limit": len(items),
            "total": total,
            "items": items,
            "nav": {"can_back": True, "can_home": True},
            "_replace_current_menu": replace_current_menu,
        }
        return (payload, None)
    if pandora_action_menu and _is_pandora_genre_item_id(pandora_action_item_id):
        _np_source_by_playerid[pid] = "Pandora"
        _clear_pandora_station(pid)
    return (None, {"t": "ack", "ok": True, "req": {"t": "menu_select", "spec": spec}, "result": res, "playerid": pid})


async def _fresh_podcast_play_args(
    pid: str, stack: List[Dict[str, Any]], expected_title: str
) -> Optional[List[Any]]:
    if not stack or not expected_title:
        return None
    parent_item = _safe_str(stack[-1].get("item"))
    if not parent_item.startswith("act:"):
        return None
    try:
        parent_spec = _b64u_dec(parent_item.split(":", 1)[1])
        refreshed, _ = await _action_result_payload(
            pid, parent_spec, _safe_str(parent_spec.get("label")), 0, 200, "Podcasts"
        )
        rows = refreshed.get("items") if isinstance(refreshed, dict) else None
        if not isinstance(rows, list):
            return None
        wanted = _norm_key(expected_title)
        for row in rows:
            if not isinstance(row, dict) or _norm_key(row.get("label")) != wanted:
                continue
            fresh_id = _safe_str(row.get("id"))
            if not fresh_id.startswith("act:"):
                continue
            fresh_spec = _b64u_dec(fresh_id.split(":", 1)[1])
            fresh_actions = fresh_spec.get("actions") or {}
            play = fresh_actions.get("play") if isinstance(fresh_actions.get("play"), dict) else {}
            cmd = play.get("cmd") if isinstance(play.get("cmd"), list) else []
            if (
                len(cmd) >= 3
                and _safe_str(cmd[0]).strip().lower() in ("podcast", "podcasts")
                and _safe_str(cmd[1]).strip().lower() == "playlist"
                and _safe_str(cmd[2]).strip().lower() == "play"
            ):
                dbg(f"PODCAST PLAY rebound title={expected_title}")
                return _action_to_rpc_args(play, 0, 60)
    except Exception as e:
        dbg(f"PODCAST PLAY rebind failed: {type(e).__name__}: {_safe_str(e)}")
    return None


async def ws_rti(req: web.Request) -> web.StreamResponse:
    _load_setup_config()
    if _broker_light_mode():
        return web.json_response({
            "ok": False,
            "error": "broker_light_mode",
            "message": "RTI websocket is disabled in Broker Light mode.",
            "setup_url": "/setup/advanced",
        }, status=403)
    if not _legal_terms_accepted():
        return web.json_response({
            "ok": False,
            "error": "legal_terms_not_accepted",
            "terms_version": LEGAL_TERMS_VERSION,
            "setup_url": "/setup",
        }, status=403)
    license_info = _license_status()
    # RTI XP's WebSocket support is fragile around extensions/control frames.
    # Keep this endpoint as plain as possible: no heartbeat pings, no compression.
    ws = web.WebSocketResponse(compress=False)
    await ws.prepare(req)

    peer = req.remote or "?"
    ws_client_kind = _safe_str(req.query.get("client")).strip().lower()
    ws_panel_slot = _safe_str(req.query.get("slot") or req.query.get("panel_slot") or "main").strip().lower() or "main"
    panel_ws_key = ""
    if ws_client_kind == "panel":
        panel_ws_key = f"{peer}|{ws_panel_slot}"
        old_panel_ws = _panel_ws_by_key.get(panel_ws_key)
        if old_panel_ws is not None and old_panel_ws is not ws and not old_panel_ws.closed:
            try:
                await old_panel_ws.close(code=4001, message=b"panel superseded")
            except Exception:
                pass
        _panel_ws_by_key[panel_ws_key] = ws
    connect_ts = time.time()
    _rti_ws_diag["connects"] = _safe_int(_rti_ws_diag.get("connects"), 0) + 1
    _rti_ws_diag["active"] = len(_ws_clients) + 1
    _rti_ws_diag["last_peer"] = peer
    _rti_ws_diag["last_connect_ts"] = connect_ts
    _rti_ws_diag["last_error"] = ""
    dbg(f"WS client connected from {peer}")
    disconnect_counted = False

    def mark_disconnected() -> None:
        nonlocal disconnect_counted
        if disconnect_counted:
            return
        disconnect_counted = True
        _ws_clients.discard(ws)
        if panel_ws_key and _panel_ws_by_key.get(panel_ws_key) is ws:
            _panel_ws_by_key.pop(panel_ws_key, None)
        _rti_ws_diag["disconnects"] = _safe_int(_rti_ws_diag.get("disconnects"), 0) + 1
        _rti_ws_diag["active"] = len(_ws_clients)
        _rti_ws_diag["last_disconnect_ts"] = time.time()
        _rti_ws_diag["last_disconnect_after_secs"] = round(max(0.0, time.time() - connect_ts), 3)

    queue_send_pending: Dict[str, Any] = {}
    queue_send_tasks: Dict[str, asyncio.Task] = {}

    async def send_now(obj: Any) -> None:
        msg = _rti_json_dumps(obj) + "\n"
        try:
            await ws.send_str(msg)
            _rti_ws_diag["last_send_ts"] = time.time()
            _rti_ws_diag["last_send_type"] = _safe_str(obj.get("t") if isinstance(obj, dict) else "")
            _rti_ws_diag["last_send_bytes"] = len(msg.encode("utf-8", errors="ignore"))
        except Exception as e:
            _rti_ws_diag["last_error"] = f"send:{type(e).__name__}:{_safe_str(e)}"
            raise

    async def flush_queue_send_later(key: str) -> None:
        try:
            await asyncio.sleep(RTI_QUEUE_COALESCE_SECS)
            obj = queue_send_pending.pop(key, None)
            if obj is not None and not ws.closed:
                await send_now(obj)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            _rti_ws_diag["last_error"] = f"queue_send:{type(e).__name__}:{_safe_str(e)}"
        finally:
            queue_send_tasks.pop(key, None)

    async def send(obj: Any) -> None:
        if isinstance(obj, dict) and _safe_str(obj.get("t")) in ("menu", "favorites") and isinstance(obj.get("items"), list):
            before_obj = obj
            compact_obj = _rti_trim_ws_payload(obj)
            try:
                before_bytes = len(_json_dumps(before_obj).encode("utf-8", errors="ignore")) + 1
                after_bytes = len(_json_dumps(compact_obj).encode("utf-8", errors="ignore")) + 1
                item_count, id_total, id_max = _rti_menu_payload_stats(compact_obj)
                saved = before_bytes - after_bytes
                if saved >= 512 or after_bytes >= 25000 or id_max >= 1500:
                    dbg(
                        "RTI MENU PAYLOAD type=%s items=%s bytes=%s saved=%s id_total=%s id_max=%s title=%s"
                        % (
                            _safe_str(compact_obj.get("t")),
                            item_count,
                            after_bytes,
                            saved,
                            id_total,
                            id_max,
                            _safe_str(compact_obj.get("title")),
                        )
                    )
            except Exception:
                pass
            obj = compact_obj
        elif isinstance(obj, dict):
            obj = _rti_trim_ws_payload(obj)
        if _should_coalesce_queue_ws(obj):
            key = _queue_ws_key(obj)
            if key:
                queue_send_pending[key] = obj
                task = queue_send_tasks.get(key)
                if task is None or task.done():
                    queue_send_tasks[key] = asyncio.create_task(flush_queue_send_later(key))
                return
        await send_now(obj)

    if RTI_WS_FIRST_SEND_DELAY_SECS:
        await asyncio.sleep(RTI_WS_FIRST_SEND_DELAY_SECS)

    if ws.closed:
        mark_disconnected()
        return ws

    # Say hello first (does not affect push schema)
    if (not LYRION_VERSION) or (not BROKER_ID):
        await _refresh_server_meta()
    try:
        hello_license = license_info
        await send({
            "t": "hello",
            "ok": True,
            "app": "lyrion_broker",
            "ver": APP_VERSION,
            "lyrion_ver": LYRION_VERSION,
            "broker_id": BROKER_ID,
            "license_state": _safe_str(hello_license.get("state")),
            "license_trial_days_remaining": round(
                _safe_int(hello_license.get("trial_seconds_remaining"), 0) / 86400.0,
                2,
            ),
        })
    except Exception:
        mark_disconnected()
        return ws
    if not license_info.get("valid"):
        try:
            await send({"t": "err", "ok": False, "error": "license_expired", "license": license_info})
            await ws.close(code=4003, message=b"license expired")
        except Exception:
            pass
        mark_disconnected()
        return ws

    # IMPORTANT: do NOT add this WS to the broadcast set until after we send the full-batch.
    # That guarantees the client receives FULL snapshots first, with no deltas interleaved,
    # and avoids any 'syncing suppression' state that could wedge push.
    connected_players: List[Tuple[str, str, str]] = []
    try:
        # Always rebuild this map from the active LMS. A prior LMS target can leave
        # valid-looking but stale player/status caches behind.
        players = await lms.get_players()
        _reset_player_identity_maps()
        for p in players:
            if _safe_int(p.get("connected"), 0) != 1:
                continue
            pid0 = _safe_str(p.get("playerid")).strip().lower()
            pname0 = _safe_str(p.get("name")).strip()
            if not pid0 or not pname0:
                continue
            _remember_player_identity(pid0, pname0)
            connected_players.append((pname0.lower(), pid0, pname0))

        items = connected_players
        items.sort()

        for _k, pid, pname in items:
            snap: Dict[str, Any] = {}
            try:
                st = await lms.status(pid)
                if isinstance(st, dict) and st:
                    st.setdefault("sync_master", "")
                    st.setdefault("sync_slaves", "")
                    _normalize_art_fields(st)
                    _enrich_status_payload(st, pid)
                    _rewrite_status_art_for_broker(st, pid)
                    _normalize_player_display_fields(pid, st)
                    snap = st
                    _last_status_by_key[pid] = dict(st)
            except Exception as e:
                dbg(f"WS initial status failed playerid={pid}: {_safe_str(e)}")

            if isinstance(snap, dict) and snap:
                await send({
                    "t": "push",
                    "src": "cometd",
                    "channel": _cometd_response_channel or "/slim/_/response",
                    "playerid": pid,
                    "player_name": pname,
                    "full": True,
                    "complete": True,
                    "payload": _rti_status_payload(snap)
                })
            await _send_sync_list(send, pid)

            await asyncio.sleep(0.35)  # stagger to avoid CPU spikes

    except Exception as e:
        dbg(f"WS full-batch error: {_safe_str(e)}")

    # Now enable normal broadcast deltas for this client
    _ws_clients.add(ws)

    # Renew subscriptions after the snapshot. This repairs a stale subscription
    # set after changing LMS targets without introducing any periodic polling.
    if _cometd_client_id:
        for _k, pid, _pname in connected_players:
            try:
                await cometd_status_subscribe(pid)
            except Exception as e:
                dbg(f"WS connect CometD resubscribe failed for {pid}: {_safe_str(e)}")

    try:
        async for msg in ws:
            if not _license_status().get("valid"):
                await send({"t": "err", "ok": False, "error": "license_expired"})
                await ws.close(code=4003, message=b"license expired")
                break
            if msg.type != WSMsgType.TEXT:
                continue
            raw = msg.data.strip()
            if not raw:
                continue
            for line in raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    reqj = json.loads(line)
                except Exception:
                    await send({"t": "err", "ok": False, "error": "bad_json"})
                    continue

                t = _safe_str(reqj.get("t"))
                if t == "get_players":
                    players = await lms.get_players()
                    await send({"t": "players", "players": players, "default_player": pick_default_player(players)})

                elif t == "get_status":
                    pid = _safe_str(reqj.get("playerid")) or _safe_str(reqj.get("player"))
                    if not pid:
                        await send({"t": "err", "ok": False, "error": "missing_player"})
                        continue
                    st = await fresh_status_for_push(pid)
                    await send({"t": "status", "playerid": pid, "status": st})

                elif t == "cmd":
                    # Accept both the new schema (playerid/name) and legacy aliases (player/cmd/command).
                    pid = _safe_str(reqj.get("playerid") or reqj.get("playerId") or reqj.get("player_id") or reqj.get("player"))
                    name = _safe_str(reqj.get("name") or reqj.get("cmd") or reqj.get("command"))
                    args = reqj.get("args") or reqj.get("argv") or []
                    if isinstance(args, str):
                        args = [args]
                    if not isinstance(args, list):
                        args = []
                    # Optional human label for logs/UI (identity is always pid/MAC)
                    pname = _safe_str(reqj.get("player_name") or reqj.get("playerName"))
                    if not pname and pid:
                        pname = _playerid_to_name.get(pid.lower(), "")
                    dbg(f"WS CMD playerid={pid} player_name={pname} name={name} args={args}")
                    if not pid or not name:
                        await send({"t": "err", "ok": False, "error": "missing_player_or_name"})
                        continue
                    
                    if name == "queue_fetch":
                        try:
                            st = await full_queue_status_for_push(pid, 200)
                            await send({"t": "queue", "ok": True,
                                        "playerid": pid, "player_name": pname,
                                        "payload": st})
                        except Exception as e:
                            await send({"t": "queue", "ok": False,
                                        "playerid": pid, "player_name": pname,
                                        "error": _safe_str(e)})
                        continue


                    if name in ("sync_list_get", "sync_list_refresh", "sync_list_toggle", "sync_list_apply", "sync_list_sync_all", "sync_list_unsync_all"):
                        view = _safe_str(reqj.get("view") or reqj.get("deviceid") or "")
                        try:
                            payload = await _apply_sync_list_command(pid, name, args)
                            payload["view"] = view
                            await send({"t": "ack", "ok": True,
                                        "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args, "view": view},
                                        "result": {"sync_list": True}})
                            await send(payload)
                            if name not in ("sync_list_get", "sync_list_refresh", "sync_list_apply"):
                                schedule_sync_status_refresh()
                        except Exception as e:
                            await send({"t": "err", "ok": False, "error": _safe_str(e),
                                        "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args, "view": view}})
                        continue

                    try:
                        res = await lms.cmd(pid, name, args)
                        cmd_result = res.get("result") or {}
                        await send({"t": "ack", "ok": True,
                                    "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args, "view": _safe_str(reqj.get("view") or reqj.get("deviceid") or "")},
                                    "result": cmd_result})

                        if name in ("sync", "unsync", "sync_toggle", "sync_all"):
                            schedule_sync_status_refresh()
                        if name in ("play", "pause", "stop", "next", "prev", "queue_goto", "goto"):
                            schedule_transport_command_verify(pid, pname, name)

                        if name in ("repeat", "shuffle") and cmd_result:
                            mode_key = f"playlist {name}"
                            mode_val = cmd_result.get(mode_key, cmd_result.get(f"playlist_{name}", cmd_result.get(name)))
                            if mode_val is not None:
                                _last_status_by_key.setdefault(pid, {})[mode_key] = mode_val
                                _last_status_by_key[pid][f"playlist_{name}"] = mode_val
                                _last_status_by_key[pid][name] = mode_val
                                await send({
                                    "t": "push",
                                    "src": "broker",
                                    "channel": _cometd_response_channel or "/slim/_/response",
                                    "playerid": pid,
                                    "player_name": pname,
                                    "full": False,
                                    "complete": False,
                                    "payload": {mode_key: mode_val, f"playlist_{name}": mode_val, name: mode_val}
                                })

                        # Normal live updates come from CometD. This fallback is only for troubleshooting.
                        try:
                            await cometd_status_subscribe(pid)
                        except Exception as e:
                            dbg(f"WS CMD CometD resubscribe failed for {pid}: {_safe_str(e)}")

                        if FORCE_STATUS_AFTER_COMMAND or name in ("repeat", "shuffle"):
                            try:
                                await asyncio.sleep(0.35)
                                prev_status = dict(_last_status_by_key.get(pid) or {})
                                st2 = await fresh_status_for_push(pid)
                                if isinstance(st2, dict) and st2:
                                    payload = _diff(prev_status, st2) if prev_status else st2
                                    if not payload:
                                        continue
                                    await send({
                                        "t": "push",
                                        "src": "broker",
                                        "channel": _cometd_response_channel or "/slim/_/response",
                                        "playerid": pid,
                                        "player_name": pname,
                                        "full": not bool(prev_status),
                                        "complete": not bool(prev_status),
                                        "payload": payload
                                    })
                            except Exception:
                                pass
                    except Exception as e:
                        await send({"t": "err", "ok": False, "error": _safe_str(e),
                                    "req": {"t": t, "playerid": pid, "player_name": pname, "name": name, "args": args}})

                elif t == "cometd_subscribe_status":
                    pid = _safe_str(reqj.get("playerid")) or _safe_str(reqj.get("player"))
                    if pid:
                        await cometd_status_subscribe(pid)
                        await send({"t": "ack", "ok": True, "req": {"t": t, "playerid": pid}})
                    else:
                        await send({"t": "err", "ok": False, "error": "missing_player"})

                elif t in ("favorites_list", "favorite_list"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        offset = _safe_int(reqj.get("offset"), 0)
                        limit = _safe_int(reqj.get("limit"), 100)
                        pl = await _favorites_payload_direct(pid, offset, limit)
                        await send({"t": "favorites", "ok": True, **pl})
                    except Exception as e:
                        await send({"t": "favorites", "ok": False, "error": f"favorites_exception:{type(e).__name__}", "items": [], "total": 0})
                    continue

                elif t in ("menu_home", "browse_home"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        top = await _top_menu_raw(pid)
                        home_rows = await _merge_home_menu_with_live_apps(pid)
                        pl = _home_payload_from_top(top, home_rows)
                        _ws_nav[id(ws)] = [{"payload": pl}]
                        await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                    except Exception as e:
                        await send({"t": "err", "ok": False, "error": f"menu_home_exception:{type(e).__name__}"})
                    continue

                elif t in ("menu_nav", "browse_nav"):
                    cmd = _safe_str(reqj.get("cmd") or reqj.get("nav") or "")
                    stack = _ws_nav.get(id(ws)) or []
                    if cmd == "back" and stack:
                        cur_pl = stack[-1].get("payload") or {}
                        if _safe_str(cur_pl.get("title")).strip().lower() == "station deleted":
                            for si in range(len(stack) - 2, -1, -1):
                                frame = stack[si]
                                frame_pl = frame.get("payload") or {}
                                if _safe_str(frame_pl.get("title")).strip().lower() != "your stations":
                                    continue
                                refresh_item = _safe_str(frame.get("item"))
                                refresh_pid = _safe_str(frame.get("pid") or reqj.get("playerid") or reqj.get("player"))
                                refreshed = None
                                if refresh_item.startswith("act:"):
                                    try:
                                        refresh_spec = _b64u_dec(refresh_item.split(":", 1)[1])
                                        refreshed, _ = await _action_result_payload(
                                            refresh_pid,
                                            refresh_spec,
                                            _safe_str(frame_pl.get("title") or "Your Stations"),
                                            0,
                                            _safe_int(frame.get("limit"), 60),
                                            _safe_str(frame_pl.get("source") or "Pandora")
                                        )
                                    except Exception as e:
                                        dbg("PANDORA DELETE BACK refresh failed: " + _safe_str(e))
                                if isinstance(refreshed, dict):
                                    nav = dict(refreshed.get("nav") or {})
                                    nav["can_back"] = si > 0
                                    nav["can_home"] = True
                                    refreshed["nav"] = nav
                                    stack = stack[:si] + [{"payload": refreshed, "item": refresh_item, "pid": refresh_pid, "offset": 0, "limit": _safe_int(frame.get("limit"), 60)}]
                                else:
                                    stack = stack[:si + 1]
                                _ws_nav[id(ws)] = stack
                                pl = dict(stack[-1].get("payload") or {})
                                nav = dict(pl.get("nav") or {})
                                nav["can_back"] = len(stack) > 1
                                nav["can_home"] = pl.get("node") != "home"
                                pl["nav"] = nav
                                await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                                break
                            else:
                                if len(stack) > 1:
                                    stack.pop()
                                _ws_nav[id(ws)] = stack
                                if stack:
                                    pl = dict(stack[-1].get("payload") or {})
                                    nav = dict(pl.get("nav") or {})
                                    nav["can_back"] = len(stack) > 1
                                    nav["can_home"] = pl.get("node") != "home"
                                    pl["nav"] = nav
                                    await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                                else:
                                    await send({"t": "err", "ok": False, "error": "nav_empty"})
                            continue
                    if cmd == "back" and len(stack) > 1:
                        stack.pop()
                        _ws_nav[id(ws)] = stack
                    if stack:
                        pl = dict(stack[-1].get("payload") or {})
                        nav = dict(pl.get("nav") or {})
                        nav["can_back"] = len(stack) > 1
                        nav["can_home"] = pl.get("node") != "home"
                        pl["nav"] = nav
                        await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                    else:
                        await send({"t": "err", "ok": False, "error": "nav_empty"})
                    continue

                elif t in ("menu_list", "browse_list"):
                    stack = _ws_nav.get(id(ws)) or []
                    if stack:
                        pl = dict(stack[-1].get("payload") or {})
                        nav = dict(pl.get("nav") or {})
                        nav["can_back"] = len(stack) > 1
                        nav["can_home"] = pl.get("node") != "home"
                        pl["nav"] = nav
                        await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                    else:
                        await send({"t": "err", "ok": False, "error": "menu_empty"})
                    continue

                elif t in ("menu_select", "browse_select"):
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        item = _safe_str(reqj.get("item_id") or reqj.get("id") or reqj.get("item")) or ""
                        offset = _safe_int(reqj.get("offset"), 0)
                        limit = _safe_int(reqj.get("limit"), 60)
                        search = _safe_str(reqj.get("search") or reqj.get("query") or reqj.get("term")).strip()
                        stack = _ws_nav.get(id(ws)) or []
                        if not item:
                            await send({"t": "err", "ok": False, "error": "missing_item"})
                            continue
                        top = await _top_menu_raw(pid)
                        raw_items = _extract_menu_items(top)
                        pl = None
                        ack = None

                        if item == "root:mymusic":
                            label = _configured_source_label("mymusic") or "My Music"
                            pl = _group_payload_from_top(top, "myMusic", label, label)
                        elif item == "root:radio":
                            label = _configured_source_label("radio") or "Radio"
                            pl = _group_payload_from_top(top, "radios", label, label)
                        elif item == "root:favorites":
                            pl = await _favorites_payload_direct(pid, offset, limit)
                        elif item.startswith("rootapp:"):
                            row_key = item.split(":", 1)[1]
                            app = None
                            want = ""
                            display_label = ""
                            source_label = ""
                            home_rows = await _merge_home_menu_with_live_apps(pid)
                            for rowcfg in home_rows:
                                if _safe_str(rowcfg.get("key")) == row_key:
                                    want = _norm_key(rowcfg.get("source_label") or rowcfg.get("label") or row_key)
                                    display_label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or row_key)
                                    source_label = _safe_str(rowcfg.get("label") or rowcfg.get("source_label") or row_key)
                                    break
                            for it in raw_items:
                                if _safe_int(it.get("isApp"), 0) != 1:
                                    continue
                                if _canonical_home_app_key(_safe_str(it.get("id") or ""), _pick_label(it)) == row_key:
                                    app = it
                                    break
                                if _norm_key(_pick_label(it)) == want:
                                    app = it
                                    break
                            if app and isinstance((app.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(
                                    pid,
                                    {"kind": "go", "label": (display_label or _pick_label(app)), "force_title": True, "action": (app.get("actions") or {}).get("go")},
                                    display_label or _pick_label(app),
                                    offset,
                                    limit,
                                    source_label or _pick_label(app)
                                )
                            elif app:
                                menu_name = _rootapp_menu_name(row_key)
                                if menu_name:
                                    pl, ack = await _action_result_payload(
                                        pid,
                                        {
                                            "kind": "go",
                                            "label": (display_label or _pick_label(app)),
                                            "force_title": True,
                                            "action": {
                                                "cmd": [menu_name, "items"],
                                                "params": {"menu": menu_name, "item_id": "0"},
                                            },
                                        },
                                        display_label or _pick_label(app),
                                        offset,
                                        limit,
                                        source_label or _pick_label(app)
                                    )
                        elif item.startswith("root:"):
                            root_key = item.split(":", 1)[1]
                            app = None
                            for it in raw_items:
                                if _safe_int(it.get("isApp"), 0) == 1 and _app_key_from_item(it) == root_key:
                                    app = it
                                    break
                            # support iHeart as direct custom path if ever called
                            if app is None and root_key == "iheart":
                                app = _top_find_item_by_alias(raw_items, ["iHeartRadio", "iHeart", "opmliheartradio"], "radios")
                            if app and isinstance((app.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(pid, {"kind": "go", "label": (display_label or _pick_label(app)), "action": (app.get("actions") or {}).get("go")}, _pick_label(app), offset, limit)
                        elif item.startswith("group:"):
                            grp = item.split(":", 1)[1]
                            title = _GROUP_TITLE.get(grp, _pick_label({"text": grp}))
                            pl = _group_payload_from_top(top, grp, title)
                        elif item.startswith("act:"):
                            spec = _b64u_dec(item.split(":", 1)[1])
                            parent_pl = (stack[-1].get("payload") or {}) if stack else {}
                            parent_title_hint = _safe_str(spec.get("label") or parent_pl.get("title") or "Library")
                            parent_source_hint = _safe_str(parent_pl.get("source") or "")
                            if _safe_str(spec.get("kind")).lower() == "pandora_station":
                                _remember_pandora_station(pid, spec.get("label"))
                            if (
                                _norm_key(spec.get("label")) == "playthisstation"
                                and (
                                    _is_pandora_station_actions(spec.get("actions"))
                                    or _is_pyrrha_station_actions(spec.get("actions"))
                                )
                            ):
                                for station_candidate in (
                                    spec.get("context_name"),
                                    parent_pl.get("context_name"),
                                    parent_pl.get("title"),
                                ):
                                    station_name = _remember_pandora_station(pid, station_candidate)
                                    if station_name:
                                        break
                            if not parent_source_hint and _safe_str(parent_pl.get("title")) in ("My Music", "Pandora", "Spotty", "Radio", "Favorites"):
                                parent_source_hint = _safe_str(parent_pl.get("title"))
                            pl, ack = await _action_result_payload(pid, spec, parent_title_hint, offset, limit, parent_source_hint, search)
                        elif item.startswith("cmd:"):
                            cmd_name = item.split(":", 1)[1].strip().lower()
                            picked = None
                            title_hint = "Library"
                            if cmd_name == "artists":
                                picked = _find_top_action_item(raw_items, mode="artists", node="myMusic")
                                title_hint = "Artists"
                            elif cmd_name == "albums":
                                picked = _find_top_action_item(raw_items, mode="albums", node="myMusic")
                                title_hint = "Albums"
                            elif cmd_name == "genres":
                                picked = _find_top_action_item(raw_items, mode="genres", node="myMusic")
                                title_hint = "Genres"
                            elif cmd_name == "playlists":
                                picked = _find_top_action_item(raw_items, mode="playlists", node="myMusic")
                                title_hint = "Playlists"
                            elif cmd_name == "years":
                                picked = _find_top_action_item(raw_items, mode="years", node="myMusic")
                                title_hint = "Years"
                            elif cmd_name == "search":
                                picked = _find_top_action_item(raw_items, mode="search", node="myMusic")
                                title_hint = "Search"
                            elif cmd_name == "favorites":
                                picked = _find_top_action_item(raw_items, menu="favorites") or _top_find_home_item(raw_items, "Favorites")
                                title_hint = "Favorites"
                            if cmd_name == "playlists":
                                pl = await _playlists_payload_direct(pid, offset, limit)
                            elif picked and isinstance((picked.get("actions") or {}).get("go"), dict):
                                pl, ack = await _action_result_payload(pid, {"kind": "go", "label": title_hint, "action": (picked.get("actions") or {}).get("go")}, title_hint, offset, limit, "My Music")
                            else:
                                await send({"t": "err", "ok": False, "error": f"unknown_cmd:{cmd_name}"})
                                continue
                        elif item.startswith("playlist:"):
                            playlist_id = item.split(":", 1)[1].strip()
                            if not playlist_id:
                                await send({"t": "err", "ok": False, "error": "playlist_id_missing"})
                                continue
                            pl, ack = await _action_result_payload(
                                pid,
                                {
                                    "kind": "go",
                                    "label": "Playlist",
                                    "action": {
                                        "cmd": ["browselibrary", "items"],
                                        "params": {
                                            "mode": "playlistTracks",
                                            "playlist_id": playlist_id,
                                            "menu": "1",
                                        },
                                    },
                                },
                                "Playlist",
                                offset,
                                limit,
                                "My Music",
                            )
                            if isinstance(pl, dict):
                                playlist_icon = _mymusic_fallback_art({"id": "myMusicPlaylists", "node": "myMusic"}, "Playlists")
                                pl["page_action"] = {
                                    "id": item,
                                    "label": _safe_str(pl.get("title") or "Playlist"),
                                    "type": "playlist",
                                    "art": playlist_icon,
                                    "target_art": playlist_icon,
                                    "playlist_id": playlist_id,
                                    "can_rename_playlist": True,
                                    "can_delete_playlist": True,
                                }
                        elif item.startswith("sptrack:"):
                            ack = {"t": "ack", "ok": True, "req": {"t": "menu_select", "item_id": item}, "result": {}}
                        elif item.startswith("noop:"):
                            ack = {"t": "ack", "ok": True, "req": {"t": "menu_select", "item_id": item}, "result": {}}
                        else:
                            await send({"t": "err", "ok": False, "error": "unknown_menu_item"})
                            continue

                        if pl is not None:
                            selected_label = ""
                            if item.startswith("act:"):
                                try:
                                    selected_spec = _b64u_dec(item.split(":", 1)[1])
                                    selected_label = _safe_str(selected_spec.get("label"))
                                    if _safe_str(selected_spec.get("kind")).lower() == "pandora_station":
                                        _remember_pandora_station(
                                            pid,
                                            pl.get("context_name") or pl.get("title") or selected_spec.get("label")
                                        )
                                except Exception:
                                    pass
                            replace_current_menu = bool(pl.pop("_replace_current_menu", False))
                            nav = dict(pl.get("nav") or {})
                            nav["can_back"] = len(stack) >= 1
                            nav["can_home"] = True
                            pl["nav"] = nav
                            # Paging requests (offset > 0) must not create new navigation history entries
                            # and must not replace the canonical current payload on the nav stack.
                            # Keep stack[-1] pointing at the logical location's first page so Back returns
                            # to the parent level instead of peeling paging chunks one at a time.
                            if replace_current_menu and stack:
                                stack[-1] = {"payload": pl, "item": item, "pid": pid, "offset": offset, "limit": limit, "selected_label": selected_label}
                            elif offset <= 0:
                                stack.append({"payload": pl, "item": item, "pid": pid, "offset": offset, "limit": limit, "selected_label": selected_label})
                            _ws_nav[id(ws)] = stack
                            await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                        elif ack is not None:
                            await send(ack)
                            if FORCE_STATUS_AFTER_COMMAND:
                                try:
                                    st2 = await lms.status(pid)
                                    if isinstance(st2, dict) and st2:
                                        _normalize_art_fields(st2)
                                        _enrich_status_payload(st2, pid)
                                        _rewrite_status_art_for_broker(st2, pid)
                                        _normalize_player_display_fields(pid, st2)
                                        await send({
                                            "t": "push",
                                            "src": "broker",
                                            "channel": _cometd_response_channel or "/slim/_/response",
                                            "playerid": pid,
                                            "player_name": _playerid_to_name.get(pid.lower(), ""),
                                            "full": False,
                                            "complete": False,
                                            "payload": st2
                                        })
                                except Exception:
                                    pass
                        else:
                            await send({"t": "err", "ok": False, "error": "menu_select_empty"})
                        continue

                    except Exception as e:
                        tb_lines = traceback.format_exc().strip().splitlines()
                        frame = ""
                        for line in reversed(tb_lines):
                            if "lyrion_broker.py" in line:
                                frame = line.strip()
                                break
                        tb = frame or (tb_lines[-1] if tb_lines else "")
                        dbg(f"menu_select exception {type(e).__name__}: {_safe_str(e)} trace={tb}")
                        await send({"t": "err", "ok": False, "error": f"menu_select_exception:{type(e).__name__}:{_safe_str(e)}:{tb}"})
                        continue

                elif t in ("menu_action", "browse_action"):

                    # Perform an action on a broker browse item (play/add) without changing transport behavior.
                    try:
                        pid = _safe_str(reqj.get("playerid") or reqj.get("player")) or ""
                        item = _safe_str(reqj.get("item_id") or reqj.get("id") or reqj.get("item")) or ""
                        action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                        view = _safe_str(reqj.get("view") or reqj.get("view_id") or "")
                        req_playlist_id = _safe_str(reqj.get("playlist_id") or reqj.get("playlistid")).strip()
                        req_playlist_item_index = _safe_str(
                            reqj.get("playlist_item_index")
                            if reqj.get("playlist_item_index") is not None
                            else reqj.get("playlist_index")
                        ).strip()
                        replace_and_play = False
                        play_now_keep_queue = False
                        add_favorite = False
                        remove_favorite = False
                        playlist_delete = False
                        playlist_rename = False
                        playlist_remove_entry = False
                        if action in ("play", "now", "replay"):
                            # User model: Play should start now but preserve the rest of the queue.
                            # Do that as ADD + move appended rows after current, not LOAD/INSERT.
                            pcmd = "cmd:add"
                            play_now_keep_queue = True
                        elif action in ("load", "replaceandplay", "replace_and_play", "replace-play", "replaceplay", "wipeandplay", "wipe_and_play", "replace", "clearandplay", "clear_and_play"):
                            pcmd = "cmd:load"
                            replace_and_play = True
                        elif action in ("add", "enqueue", "queue"):
                            pcmd = "cmd:add"
                        elif action in ("playnext", "next", "insert"):
                            pcmd = "cmd:insert"
                        elif action == "favorites_add":
                            pcmd = ""
                            add_favorite = True
                        elif action == "favorites_remove":
                            pcmd = ""
                            remove_favorite = True
                        elif action in ("playlist_delete", "delete_playlist"):
                            pcmd = ""
                            playlist_delete = True
                        elif action in ("playlist_rename", "rename_playlist"):
                            pcmd = ""
                            playlist_rename = True
                        elif action in ("playlist_remove_entry", "remove_playlist_entry"):
                            pcmd = ""
                            playlist_remove_entry = True
                        else:
                            await send({"t": "err", "ok": False, "error": "bad_action"})
                            continue

                        if not pid or not item:
                            await send({"t": "err", "ok": False, "error": "missing_player_or_item"})
                            continue

                        # item_id formats emitted by broker: act:<payload>, sptrack:<id>, title:<id>, album:<id>, artist:<id>, playlist:<id>
                        kind = ""
                        val = ""
                        if ":" in item:
                            kind, val = item.split(":", 1)
                            kind = kind.strip().lower()
                            val = val.strip()
                        else:
                            kind = item.strip().lower()
                            val = ""

                        if (playlist_delete or playlist_rename) and not req_playlist_id and kind == "act" and val:
                            try:
                                req_playlist_id = _row_playlist_id_from_item(_b64u_dec(val))
                            except Exception:
                                req_playlist_id = ""

                        before_count = -1
                        before_index = -1
                        random_mix_was_active = _random_mix_active(
                            _last_status_by_key.get(pid) or _last_status_by_key.get(pid.lower()) or {}
                        ) or pid.lower() in _random_mix_queue_players
                        if play_now_keep_queue:
                            try:
                                before = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                before_payload = (before.get("result") or {}) if isinstance(before, dict) else {}
                                if isinstance(before_payload, dict) and before_payload:
                                    _normalize_art_fields(before_payload)
                                    _enrich_status_payload(before_payload, pid)
                                    _normalize_player_display_fields(pid, before_payload)
                                    _last_status_by_key[pid] = dict(before_payload)
                                before_count = _safe_int(before_payload.get("playlist_tracks"), -1)
                                before_index = _safe_int(before_payload.get("playlist_cur_index"), -1)
                                random_mix_was_active = random_mix_was_active or _random_mix_active(before_payload)
                            except Exception:
                                before_count = -1
                                before_index = -1

                            # If the queue is empty, let LMS do a normal album load.  The add/move
                            # preserve path is only needed when there is an existing queue to keep.
                            if before_count <= 0:
                                _random_mix_queue_players.discard(pid.lower())
                                pcmd = "cmd:load"
                                play_now_keep_queue = False

                        args = None
                        if playlist_rename and req_playlist_id:
                            new_name = _safe_str(reqj.get("name") or reqj.get("newname")).strip()
                            if not new_name:
                                await send({"t": "err", "ok": False, "error": "playlist_name_missing"})
                                continue
                            args = ["playlists", "rename", f"playlist_id:{req_playlist_id}", f"newname:{new_name}"]
                        elif playlist_delete and req_playlist_id:
                            args = ["playlists", "delete", f"playlist_id:{req_playlist_id}"]
                        elif playlist_remove_entry:
                            if req_playlist_id and req_playlist_item_index != "":
                                args = [
                                    "playlists",
                                    "edit",
                                    f"playlist_id:{req_playlist_id}",
                                    "cmd:delete",
                                    f"index:{req_playlist_item_index}",
                                ]
                            else:
                                await send({"t": "err", "ok": False, "error": "playlist_entry_missing"})
                                continue
                        elif kind == "act" and val:
                            spec = _b64u_dec(val)
                            spec_kind = _safe_str(spec.get("kind")).strip().lower()
                            acts = spec.get("actions") or {}
                            if spec_kind == "bbc_go" and action in ("play", "now", "replay", "load", "replaceandplay", "replace_and_play", "replace-play", "replaceplay", "wipeandplay", "wipe_and_play", "replace", "clearandplay", "clear_and_play", "add", "enqueue", "queue", "playnext", "next", "insert"):
                                play_item_id = _safe_str(spec.get("play_item_id")).strip()
                                if not play_item_id:
                                    browse_action = spec.get("action") if isinstance(spec.get("action"), dict) else _bbc_browse_action(acts)
                                    browse_params = browse_action.get("params") if isinstance(browse_action, dict) and isinstance(browse_action.get("params"), dict) else {}
                                    play_item_id = _safe_str(browse_params.get("item_id")).strip()
                                if play_item_id:
                                    acts = _bbc_item_actions(play_item_id)
                                    spec_kind = "bbc_audio"
                            bbc_browse_action = _bbc_browse_action(acts)
                            if (
                                (spec_kind == "bbc_go" or bbc_browse_action)
                                and action in ("play", "now", "replay", "load", "replaceandplay", "replace_and_play", "replace-play", "replaceplay", "wipeandplay", "wipe_and_play", "replace", "clearandplay", "clear_and_play", "add", "enqueue", "queue", "playnext", "next", "insert")
                            ):
                                if spec_kind != "bbc_go" and bbc_browse_action:
                                    spec = {
                                        "kind": "bbc_go",
                                        "label": spec.get("label"),
                                        "action": bbc_browse_action,
                                        "force_title": True,
                                    }
                                pl, ack = await _action_result_payload(
                                    pid,
                                    spec,
                                    _safe_str(spec.get("label") or "BBC Sounds"),
                                    0,
                                    60,
                                    "BBC Sounds",
                                    "",
                                )
                                if pl is not None:
                                    stack = _ws_nav.get(id(ws)) or []
                                    nav = dict(pl.get("nav") or {})
                                    nav["can_back"] = len(stack) >= 1
                                    nav["can_home"] = True
                                    pl["nav"] = nav
                                    stack.append({"payload": pl, "item": item, "pid": pid, "offset": 0, "limit": 60})
                                    _ws_nav[id(ws)] = stack
                                    await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                                elif ack is not None:
                                    await send(ack)
                                else:
                                    await send({"t": "err", "ok": False, "error": "bbc_open_item_first"})
                                continue
                            is_qobuz_actions = _is_qobuz_action_spec(acts)
                            is_tidal_actions = _is_tidal_action_spec(acts)
                            if spec_kind == "bbc_audio" and action in ("play", "now", "replay"):
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                            if is_qobuz_actions and action in ("play", "now", "replay"):
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                            if is_tidal_actions and action in ("play", "now", "replay"):
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                            random_genre_actions = [
                                candidate for candidate in (acts.get("on"), acts.get("off"))
                                if isinstance(candidate, dict)
                                and isinstance(candidate.get("cmd"), list)
                                and candidate.get("cmd")
                                and _safe_str(candidate.get("cmd")[0]).strip().lower() == "randomplaychoosegenre"
                            ]
                            station_play = acts.get("play") if isinstance(acts.get("play"), dict) else {}
                            station_cmd = station_play.get("cmd") if isinstance(station_play.get("cmd"), list) else []
                            is_podcast_episode = (
                                action in ("play", "now", "replay")
                                and len(station_cmd) >= 3
                                and _safe_str(station_cmd[0]).strip().lower() in ("podcast", "podcasts")
                                and _safe_str(station_cmd[1]).strip().lower() == "playlist"
                                and _safe_str(station_cmd[2]).strip().lower() == "play"
                            )
                            if is_podcast_episode:
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                            station_head = (
                                _safe_str(station_cmd[0]).strip().lower()
                                if station_cmd else ""
                            )
                            nav_stack = _ws_nav.get(id(ws)) or []
                            in_radio_context = any(
                                _norm_key((frame.get("payload") or {}).get("source")) == "radio"
                                or _norm_key((frame.get("payload") or {}).get("context_source")) == "radio"
                                or _safe_str(frame.get("item")).strip().lower() == "root:radio"
                                for frame in nav_stack
                                if isinstance(frame, dict)
                            )
                            is_radio_context_station = (
                                action in ("play", "now", "replay")
                                and in_radio_context
                                and len(station_cmd) >= 3
                                and _safe_str(station_cmd[1]).strip().lower() == "playlist"
                                and _safe_str(station_cmd[2]).strip().lower() == "play"
                                and station_head not in (
                                    "podcast", "podcasts", "spotty", "spotify",
                                    "iheartradio", "fr_iheartradio",
                                )
                                and "pandora" not in station_head
                                and "pyrrha" not in station_head
                            )
                            if is_radio_context_station:
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                                _np_source_by_playerid[pid] = "Radio"
                                station_name = _clean_text(spec.get("label")).splitlines()[0].strip()
                                if station_name:
                                    _np_station_by_playerid[pid] = station_name
                            play_action_names = (
                                "play", "now", "replay", "load",
                                "replaceandplay", "replace_and_play", "replace-play",
                                "replaceplay", "wipeandplay", "wipe_and_play",
                                "replace", "clearandplay", "clear_and_play",
                            )
                            is_pandora_play_action = (
                                action in play_action_names
                                and _is_pandora_action_family(acts)
                            )
                            is_pandora_genre_action = _is_pandora_genre_item_id(
                                _pandora_action_item_id(acts)
                            )
                            if is_pandora_play_action:
                                _np_source_by_playerid[pid] = "Pandora"
                                _clear_pandora_station(pid)
                            if (
                                action in play_action_names
                                and (
                                    _safe_str(spec.get("kind")).lower() == "pandora_station"
                                    or _is_pandora_station_actions(acts)
                                    or _is_pyrrha_station_actions(acts)
                                )
                            ):
                                pcmd = "cmd:load"
                                play_now_keep_queue = False
                                replace_and_play = True
                                if not is_pandora_genre_action:
                                    remembered = _remember_pandora_station(
                                        pid,
                                        _pandora_station_from_current_nav(ws, spec)
                                    )
                            if add_favorite:
                                favorite_title = _favorite_title_from_nav(ws, spec)
                                args = _spec_favorite_args(spec)
                                if args is None:
                                    args = await _context_favorite_args(pid, spec, favorite_title)
                                elif favorite_title and (
                                    _safe_str(spec.get("kind")).lower() == "pandora_station"
                                    or _is_pandora_station_actions(acts)
                                    or _is_pyrrha_station_actions(acts)
                                ):
                                    args = _favorite_args_with_title(args, favorite_title)
                                if args is None:
                                    await send({"t": "err", "ok": False, "error": "favorite_unsupported"})
                                    continue
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                if action in ("play", "now", "replay") and random_genre_actions:
                                    # Genre rows configure Random Mix. RTI Play Now on
                                    # one starts a Song Mix using the enabled genres.
                                    args = ["randomplay", "tracks"]
                                    play_now_keep_queue = False
                                else:
                                    args = _bbc_action_args(acts, pcmd)
                                    if args is None:
                                        args = _qobuz_action_args(acts, pcmd)
                                    if args is None:
                                        args = _tidal_action_args(acts, pcmd)
                                    if args is None:
                                        args = _menu_action_track_override_args(acts, pcmd)
                                pick = None
                                if args is None:
                                    if pcmd == "cmd:load" and isinstance(acts.get("play"), dict):
                                        pick = acts.get("play")
                                    elif pcmd == "cmd:add" and isinstance(acts.get("add"), dict):
                                        pick = acts.get("add")
                                    elif pcmd == "cmd:add" and isinstance(acts.get("add-hold"), dict):
                                        pick = acts.get("add-hold")
                                    elif pcmd == "cmd:insert" and isinstance(acts.get("add-hold"), dict):
                                        pick = acts.get("add-hold")
                                    elif isinstance(acts.get("go"), dict):
                                        pick = acts.get("go")
                                    elif isinstance(acts.get("do"), dict):
                                        pick = acts.get("do")
                                    elif isinstance(spec.get("action"), dict):
                                        pick = spec.get("action")
                                    if not isinstance(pick, dict):
                                        await send({"t": "err", "ok": False, "error": "unsupported_item"})
                                        continue
                                    args = _action_to_rpc_args(pick, 0, 60)
                                if is_podcast_episode:
                                    fresh_args = await _fresh_podcast_play_args(
                                        pid, _ws_nav.get(id(ws)) or [], _safe_str(spec.get("label"))
                                    )
                                    if fresh_args:
                                        args = fresh_args
                        elif kind == "sptrack" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:spotify://track:{val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif pcmd == "cmd:load":
                                args = ["spotty", "playlist", "play", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                            elif pcmd == "cmd:add":
                                req_action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                                if req_action in ("playnext", "next", "insert"):
                                    args = ["spotty", "playlist", "insert", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                                else:
                                    args = ["spotty", "playlist", "add", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                        elif kind == "qobuztrack" and val:
                            req_action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                            if add_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_add_unsupported"})
                                continue
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif pcmd == "cmd:load" or req_action in ("play", "now", "replay"):
                                args = ["qobuz", "playlist", "play", "menu:qobuz", "isContextMenu:1", f"item_id:{val}"]
                                play_now_keep_queue = False
                                replace_and_play = True
                            elif pcmd == "cmd:insert":
                                args = ["qobuz", "playlist", "insert", "menu:qobuz", "isContextMenu:1", f"item_id:{val}"]
                            elif pcmd == "cmd:add":
                                if req_action in ("playnext", "next", "insert"):
                                    args = ["qobuz", "playlist", "insert", "menu:qobuz", "isContextMenu:1", f"item_id:{val}"]
                                else:
                                    args = ["qobuz", "playlist", "add", "menu:qobuz", "isContextMenu:1", f"item_id:{val}"]
                        elif kind == "tidaltrack" and val:
                            req_action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                            try:
                                info = _b64u_dec(val)
                            except Exception:
                                info = {}
                            url = _safe_str(info.get("url")).strip() if isinstance(info, dict) else ""
                            title = _safe_str(info.get("title")).strip() if isinstance(info, dict) else ""
                            if not url:
                                await send({"t": "err", "ok": False, "error": "tidal_track_missing_url"})
                                continue
                            if add_favorite:
                                args = ["favorites", "add", f"url:{url}", f"title:{title or url}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif pcmd == "cmd:load" or req_action in ("play", "now", "replay"):
                                args = ["playlist", "play", url, title or url]
                                play_now_keep_queue = False
                                replace_and_play = True
                            elif pcmd == "cmd:insert" or req_action in ("playnext", "next", "insert"):
                                args = ["playlist", "insert", url, title or url]
                            else:
                                args = ["playlist", "add", url, title or url]
                        elif kind == "favurl" and val:
                            req_action = _safe_str(reqj.get("action") or reqj.get("cmd") or "play").lower().strip()
                            try:
                                info = _b64u_dec(val)
                            except Exception:
                                info = {}
                            url = _safe_str(info.get("url")).strip() if isinstance(info, dict) else ""
                            title = _safe_str(info.get("title")).strip() if isinstance(info, dict) else ""
                            if not url:
                                await send({"t": "err", "ok": False, "error": "favorite_url_missing"})
                                continue
                            if add_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_already_saved"})
                                continue
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif pcmd == "cmd:insert" or req_action in ("playnext", "next", "insert"):
                                args = ["playlist", "insert", url, title or url]
                            elif pcmd == "cmd:add" and req_action not in ("play", "now", "replay"):
                                args = ["playlist", "add", url, title or url]
                            else:
                                args = ["playlist", "play", url, title or url]
                                play_now_keep_queue = False
                                replace_and_play = True
                            if "pandora" in url.lower() or url.lower().startswith("frpandora"):
                                _np_source_by_playerid[pid] = "Pandora"
                                station_name = _valid_station_label(title)
                                if station_name:
                                    _remember_pandora_station(pid, station_name)
                        elif kind == "favitem" and val:
                            try:
                                info = _b64u_dec(val)
                            except Exception:
                                info = {}
                            fav_id = _safe_str(info.get("id")).strip() if isinstance(info, dict) else ""
                            fav_delete_id = _safe_str(info.get("delete_id")).strip() if isinstance(info, dict) else ""
                            fav_url = _safe_str(info.get("url")).strip() if isinstance(info, dict) else ""
                            title = _safe_str(info.get("title")).strip() if isinstance(info, dict) else ""
                            if not fav_id:
                                await send({"t": "err", "ok": False, "error": "favorite_id_missing"})
                                continue
                            if add_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_action_unsupported"})
                                continue
                            if remove_favorite:
                                delete_id = fav_delete_id or (fav_id.split(".", 1)[1] if "." in fav_id else fav_id)
                                args = ["favorites", "delete", f"item_id:{delete_id}"]
                            elif pcmd == "cmd:add" and action not in ("play", "now", "replay"):
                                args = ["favorites", "playlist", "add", f"item_id:{fav_id}"]
                            else:
                                args = ["favorites", "playlist", "play", f"item_id:{fav_id}"]
                                play_now_keep_queue = False
                                replace_and_play = True
                            if "pandora" in fav_url.lower() or fav_url.lower().startswith("frpandora"):
                                _np_source_by_playerid[pid] = "Pandora"
                                station_name = _valid_station_label(title)
                                if station_name:
                                    _remember_pandora_station(pid, station_name)
                        elif kind == "title" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:track.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"track_id:{val}"]
                        elif kind == "album" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:album.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"album_id:{val}"]
                        elif kind == "playlist" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:playlist.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            elif playlist_delete:
                                args = ["playlists", "delete", f"playlist_id:{val}"]
                            elif playlist_rename:
                                new_name = _safe_str(reqj.get("name") or reqj.get("newname")).strip()
                                if not new_name:
                                    await send({"t": "err", "ok": False, "error": "playlist_name_missing"})
                                    continue
                                args = ["playlists", "rename", f"playlist_id:{val}", f"newname:{new_name}"]
                            elif playlist_remove_entry:
                                await send({"t": "err", "ok": False, "error": "playlist_entry_missing"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"playlist_id:{val}"]
                        elif kind == "artist" and val:
                            if add_favorite:
                                args = ["favorites", "add", f"url:db:contributor.id={val}", f"title:{val}"]
                            elif remove_favorite:
                                await send({"t": "err", "ok": False, "error": "favorite_remove_unsupported"})
                                continue
                            else:
                                args = ["playlistcontrol", pcmd, f"artist_id:{val}"]
                        else:
                            await send({"t": "err", "ok": False, "error": "unsupported_item"})
                            continue

                        if play_now_keep_queue:
                            active_provider = _current_player_provider(pid, before_payload if isinstance(before_payload, dict) else None)
                            target_provider = _provider_from_action_args(args)
                            leaving_random_mix = (
                                random_mix_was_active
                                and target_provider in ("mymusic", "spotify")
                            )
                            provider_switch = bool(active_provider and target_provider and active_provider != target_provider)
                            if leaving_random_mix or provider_switch:
                                dbg(f"PLAY NOW source switch: active={active_provider} target={target_provider}; using load/clear")
                                play_now_keep_queue = False
                                replace_and_play = True
                                if target_provider == "spotify" and kind == "sptrack" and val:
                                    args = ["spotty", "playlist", "play", "menu:spotty", "isContextMenu:1", f"item_id:{val}"]
                                elif target_provider == "spotify" and kind == "act" and isinstance(acts.get("play"), dict):
                                    args = _action_to_rpc_args(acts.get("play"), 0, 60)
                                elif target_provider == "mymusic" and kind in ("title", "album", "playlist", "artist") and val:
                                    id_key = "track_id" if kind == "title" else f"{kind}_id"
                                    args = ["playlistcontrol", "cmd:load", f"{id_key}:{val}"]
                                elif leaving_random_mix and target_provider == "mymusic" and kind == "act" and isinstance(acts.get("play"), dict):
                                    args = _action_to_rpc_args(acts.get("play"), 0, 60)
                                elif isinstance(args, list) and args and _safe_str(args[0]).strip().lower() == "playlistcontrol":
                                    args = ["playlistcontrol"] + [("cmd:load" if _safe_str(x).strip().lower().startswith("cmd:") else x) for x in args[1:]]

                        if play_now_keep_queue:
                            if before_count < 0 or before_index < 0:
                                try:
                                    before = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                    before_payload = (before.get("result") or {}) if isinstance(before, dict) else {}
                                    before_count = _safe_int(before_payload.get("playlist_tracks"), -1)
                                    before_index = _safe_int(before_payload.get("playlist_cur_index"), -1)
                                except Exception:
                                    before_count = -1
                                    before_index = -1

                        if replace_and_play:
                            if random_mix_was_active:
                                try:
                                    await lms.rpc(pid, ["randomplay", "disable"])
                                    await asyncio.sleep(0.15)
                                except Exception:
                                    pass
                            try:
                                await lms.rpc(pid, ["playlist", "clear"])
                            except Exception:
                                pass
                        res = await lms.rpc(pid, args)
                        res = await _verify_random_mix_start(pid, args, res)
                        if (
                            isinstance(args, list)
                            and len(args) >= 3
                            and _safe_str(args[0]).strip().lower() in ("podcast", "podcasts")
                            and _safe_str(args[1]).strip().lower() == "playlist"
                            and _safe_str(args[2]).strip().lower() == "play"
                        ):
                            _schedule_podcast_selection_refresh(
                                pid, _safe_str(spec.get("label")) if kind == "act" else ""
                            )
                        if (
                            isinstance(args, list)
                            and len(args) >= 2
                            and _safe_str(args[0]).strip().lower() == "randomplay"
                        ):
                            randomplay_mode = _safe_str(args[1]).strip().lower()
                            if randomplay_mode == "disable":
                                await lms.rpc(pid, ["stop"])
                            else:
                                _random_mix_queue_players.add(pid.lower())
                        if replace_and_play:
                            _random_mix_queue_players.discard(pid.lower())
                        is_podcast_play = (
                            isinstance(args, list)
                            and len(args) >= 3
                            and _safe_str(args[0]).strip().lower() == "podcast"
                            and _safe_str(args[1]).strip().lower() == "playlist"
                            and _safe_str(args[2]).strip().lower() == "play"
                        )
                        if is_podcast_play:
                            await lms.rpc(pid, ["play"])

                        # "Play" should preserve queue but start the inserted selection immediately.
                        # Append first, then move newly appended rows directly after the current item.
                        if play_now_keep_queue:
                            try:
                                after = await lms.rpc(pid, ["status", 0, 1, f"tags:{STATUS_TAGS}"])
                                after_payload = (after.get("result") or {}) if isinstance(after, dict) else {}
                                after_count = _safe_int(after_payload.get("playlist_tracks"), -1)
                                insert_at = 0 if before_count <= 0 else before_index + 1
                                added = after_count - before_count
                                if before_count >= 0 and before_index >= 0 and added > 0:
                                    if insert_at < 0:
                                        insert_at = 0
                                    dbg(f"PLAY NOW preserve queue: before_count={before_count} before_index={before_index} added={added} insert_at={insert_at}")
                                    for n in range(added):
                                        await lms.rpc(pid, ["playlist", "move", str(before_count + n), str(insert_at + n)])
                                    await lms.rpc(pid, ["playlist", "index", str(insert_at)])
                                else:
                                    dbg(f"PLAY NOW preserve queue fallback: before_count={before_count} after_count={after_count} before_index={before_index}")
                                    await lms.rpc(pid, ["playlist", "index", "+1"])
                            except Exception as e:
                                dbg(f"PLAY NOW preserve queue failed: {type(e).__name__}: {_safe_str(e)}")

                        await send({"t": "ack", "ok": True, "req": {"t": t, "playerid": pid, "item_id": item, "action": action}, "result": (res.get("result") if isinstance(res, dict) else res) or {}})
                        if (
                            _provider_from_action_args(args) == "pandora"
                            and action in (
                                "play", "now", "replay", "load",
                                "replaceandplay", "replace_and_play", "replace-play",
                                "replaceplay", "wipeandplay", "wipe_and_play",
                                "replace", "clearandplay", "clear_and_play",
                            )
                        ):
                            schedule_pandora_status_refresh(
                                pid,
                                _playerid_to_name.get(pid.lower(), ""),
                            )
                        if replace_and_play or play_now_keep_queue:
                            try:
                                await asyncio.sleep(0.35)
                                stq = await full_queue_status_for_push(pid, 200)
                                await send({
                                    "t": "queue",
                                    "ok": True,
                                    "playerid": pid,
                                    "player_name": _playerid_to_name.get(pid.lower(), ""),
                                    "payload": stq,
                                })
                                qsig = _queue_refresh_signature(stq, pid)
                                if qsig:
                                    _last_queue_refresh_sig_by_playerid[pid] = qsig
                            except Exception as e:
                                dbg(f"post-action queue refresh failed: {type(e).__name__}: {_safe_str(e)}")
                        if remove_favorite:
                            try:
                                refreshed = await _favorites_payload_direct(pid, 0, 100)
                                await send({"t": "favorites", "ok": True, **refreshed})
                                await send({"t": "menu", "ok": True, **refreshed, "view": view})
                            except Exception as e:
                                dbg(f"favorite remove refresh failed: {type(e).__name__}: {_safe_str(e)}")
                        if playlist_delete or playlist_rename:
                            try:
                                stack = _ws_nav.get(id(ws)) or []
                                playlist_frame_index = -1
                                playlist_frame = {}
                                for si in range(len(stack) - 1, -1, -1):
                                    frame = stack[si] if isinstance(stack[si], dict) else {}
                                    frame_pl = frame.get("payload") if isinstance(frame.get("payload"), dict) else {}
                                    if (
                                        _safe_str(frame.get("item")).strip().lower() == "cmd:playlists"
                                        or _safe_str(frame_pl.get("node")).strip().lower() == "cmd:playlists"
                                        or _safe_str(frame_pl.get("title")).strip().lower() == "playlists"
                                    ):
                                        playlist_frame_index = si
                                        playlist_frame = frame
                                        break
                                refreshed = None
                                refresh_item = _safe_str(playlist_frame.get("item")).strip()
                                refresh_limit = _safe_int(playlist_frame.get("limit"), 100)
                                if refresh_item.startswith("act:"):
                                    try:
                                        refresh_spec = _b64u_dec(refresh_item.split(":", 1)[1])
                                        refreshed, _ = await _action_result_payload(
                                            pid,
                                            refresh_spec,
                                            "Playlists",
                                            0,
                                            refresh_limit,
                                            "My Music",
                                        )
                                    except Exception as e:
                                        dbg(f"playlist action refresh failed: {type(e).__name__}: {_safe_str(e)}")
                                if not isinstance(refreshed, dict):
                                    refreshed = await _playlists_payload_direct(pid, 0, 100)
                                nav = dict(refreshed.get("nav") or {})
                                nav["can_back"] = playlist_frame_index > 0
                                nav["can_home"] = True
                                refreshed["nav"] = nav
                                new_frame = {
                                    "payload": refreshed,
                                    "item": refresh_item or "cmd:playlists",
                                    "pid": pid,
                                    "offset": 0,
                                    "limit": refresh_limit,
                                    "selected_label": "",
                                }
                                if playlist_frame_index >= 0:
                                    stack = stack[:playlist_frame_index] + [new_frame]
                                elif stack:
                                    stack.append(new_frame)
                                else:
                                    stack = [new_frame]
                                _ws_nav[id(ws)] = stack
                                await send({"t": "menu", "ok": True, **refreshed, "view": view})
                            except Exception as e:
                                dbg(f"playlist refresh failed: {type(e).__name__}: {_safe_str(e)}")
                        if FORCE_STATUS_AFTER_COMMAND:
                            try:
                                st2 = await lms.status(pid)
                                if isinstance(st2, dict) and st2:
                                    _normalize_art_fields(st2)
                                    _enrich_status_payload(st2, pid)
                                    _rewrite_status_art_for_broker(st2, pid)
                                    await send({
                                        "t": "push",
                                        "src": "broker",
                                        "channel": _cometd_response_channel or "/slim/_/response",
                                        "playerid": pid,
                                        "player_name": _playerid_to_name.get(pid.lower(), ""),
                                        "full": False,
                                        "complete": False,
                                        "payload": st2
                                    })
                            except Exception:
                                pass
                    except Exception as e:
                        tb = traceback.format_exc().strip().splitlines()[-1]
                        dbg(f"menu_action exception {type(e).__name__}: {_safe_str(e)} trace={tb}")
                        await send({"t": "err", "ok": False, "error": f"menu_action_exception:{type(e).__name__}:{_safe_str(e)}"})
                        continue
                elif t in ("menu_nav", "browse_nav"):
                    cmdn = _safe_str(reqj.get("cmd") or reqj.get("nav") or "")
                    stack = _ws_nav.get(id(ws)) or [{"kind": "home", "title": "Home"}]
                    if cmdn == "home":
                        _ws_nav[id(ws)] = [{"kind": "home", "title": "Home"}]
                        pl = _home_list_payload()
                        await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                    elif cmdn == "back":
                        if len(stack) > 1:
                            stack.pop()
                        _ws_nav[id(ws)] = stack
                        cur = stack[-1] if stack else {"kind": "home", "title": "Home"}
                        if _safe_str(cur.get("kind")) == "home":
                            pl = _home_list_payload()
                            await send({"t": "menu", "ok": True, **pl, "view": _safe_str(reqj.get("view") or reqj.get("view_id") or "")})
                        elif _safe_str(cur.get("kind")) == "mymusic":
                            await send({
                                "t": "menu", "ok": True,
                                "node": "root:mymusic",
                                "title": "My Music",
                                "offset": 0,
                                "limit": 4,
                                "total": 4,
                                "items": [
                                    {"id": "cmd:artists", "label": "Artists", "type": "node"},
                                    {"id": "cmd:albums", "label": "Albums", "type": "node"},
                                    {"id": "cmd:genres", "label": "Genres", "type": "node"},
                                    {"id": "cmd:playlists", "label": "Playlists", "type": "node"},
                                ],
                                "nav": {"can_back": len(stack) > 1, "can_home": True},
                            })
                        else:
                            # Client can call menu_list to refresh current node
                            await send({"t": "ack", "ok": True, "req": {"t": t, "cmd": cmdn}})
                    else:
                        await send({"t": "err", "ok": False, "error": "bad_nav_cmd"})


                else:
                    await send({"t": "ack", "ok": True, "req": {"t": t}})

    finally:
        for task in list(queue_send_tasks.values()):
            task.cancel()
        queue_send_tasks.clear()
        queue_send_pending.clear()
        mark_disconnected()
        dbg(f"WS client disconnected from {peer}")
    return ws


async def on_startup(app: web.Application) -> None:
    dbg(f"Starting Lyrion Broker v{APP_VERSION}")
    _load_setup_config()
    try:
        if _ensure_pcp_root_redirect():
            dbg("pCP root page now routes to Lyrion Gadget setup")
    except Exception as e:
        dbg("pCP root redirect startup repair skipped: {}".format(_safe_str(e)))
    if _clear_hostname_reboot_pending_if_booted():
        _save_setup_config()
        dbg("Hostname reboot marker cleared after completed OS reboot")
    try:
        if _ensure_default_unit_hostname():
            dbg("Default Lyrion hostname applied: {}".format(_default_unit_hostname()))
    except Exception as e:
        dbg("Default hostname repair skipped: {}".format(_safe_str(e)))
    previous_update = _read_update_status()
    if (
        _safe_str(previous_update.get("state")) == "installing"
        and _safe_str(previous_update.get("target_version")) == APP_VERSION
    ):
        _write_update_status(
            "complete",
            f"Broker {APP_VERSION} installed successfully",
            target_version=APP_VERSION,
            backup_path=_safe_str(previous_update.get("backup_path")),
    )
    _ensure_license_trial_started()
    try:
        if _installed_pandora_plugin_needs_repair() and _repair_installed_pandora_plugin_icons():
            dbg("Installed Pandora plugin icons repaired")
    except Exception as e:
        dbg("Installed Pandora icon repair skipped: {}".format(_safe_str(e)))
    local_server_target_repaired = False
    try:
        local_server_target_repaired = _repair_full_local_player_server_target()
    except Exception as e:
        dbg("Local player server target repair skipped: {}".format(_safe_str(e)))
    dac8x_repaired = False
    try:
        dac8x_outputs = [
            _safe_str(row.get("output"))
            for row in _pcp_player_sessions()
            if _safe_str(row.get("output")).startswith("dac8x_")
        ]
        if dac8x_outputs and _ensure_dac8x_asound_config(dac8x_outputs):
            dac8x_repaired = True
            dbg("DAC8x ALSA config repaired on startup")
    except Exception as e:
        dbg("DAC8x ALSA startup repair skipped: {}".format(_safe_str(e)))
    threading.Thread(target=_discovery_udp_thread, daemon=True).start()
    dbg(f"Listen {LISTEN_HOST}:{LISTEN_PORT}")
    dbg(f"LMS {LMS_BASE}")
    dbg(f"Periodic rescan every {RESCAN_SECS}s (0 disables periodic)")
    await lms.start()
    await _refresh_server_meta()
    if not _broker_light_mode():
        try:
            playlist_pref = await lms.rpc("", ["pref", "playlistdir", "?"])
            configured_playlist_dir = _safe_str((playlist_pref.get("result") or {}).get("_p2")).strip()
            if not configured_playlist_dir:
                configured_playlist_dir = await lms.ensure_playlist_dir()
                dbg("Default LMS playlist folder configured: {}".format(configured_playlist_dir))
        except Exception as e:
            dbg("Default LMS playlist folder setup skipped: {}".format(_safe_str(e)))
    if local_server_target_repaired or dac8x_repaired:
        try:
            await asyncio.to_thread(_restart_all_local_players)
            if local_server_target_repaired:
                dbg("Local players restarted after server target repair")
            if dac8x_repaired:
                dbg("DAC8x players restarted after ALSA repair")
        except Exception as e:
            dbg("Player restart after startup repair failed: {}".format(_safe_str(e)))
    app["cometd_task"] = asyncio.create_task(cometd_loop(app))
    app["friendly_name_task"] = asyncio.create_task(_restore_friendly_player_names())
    app["mixer_normalize_task"] = asyncio.create_task(_normalize_mixer_levels_after_startup())
    app["material_layer_task"] = asyncio.create_task(_refresh_material_custom_layer_after_startup())
    app["pandora_repo_task"] = asyncio.create_task(_ensure_pandora_repository_after_startup())
    app["first_run_update_task"] = asyncio.create_task(_first_run_auto_update_after_startup())


async def on_cleanup(app: web.Application) -> None:
    first_run_update_task = app.get("first_run_update_task")
    if first_run_update_task:
        first_run_update_task.cancel()
    material_task = app.get("material_layer_task")
    if material_task:
        material_task.cancel()
    pandora_repo_task = app.get("pandora_repo_task")
    if pandora_repo_task:
        pandora_repo_task.cancel()
    mixer_task = app.get("mixer_normalize_task")
    if mixer_task:
        mixer_task.cancel()
        try:
            await mixer_task
        except Exception:
            pass
    friendly_task = app.get("friendly_name_task")
    if friendly_task:
        friendly_task.cancel()
        try:
            await friendly_task
        except Exception:
            pass
    task = app.get("cometd_task")
    if task:
        task.cancel()
        try:
            await task
        except Exception:
            pass
    await lms.close()
    global _cometd_session, _lms_proxy_session
    if _cometd_session and not _cometd_session.closed:
        await _cometd_session.close()
    if _lms_proxy_session and not _lms_proxy_session.closed:
        await _lms_proxy_session.close()


def build_app() -> web.Application:
    app = web.Application(middlewares=[setup_auth_middleware])
    app.add_routes([
        web.get("/", root_page),
        web.get("/health", health),
        web.get("/api/players", api_players),
        web.get("/api/system/players-status", api_system_players_status),
        web.get("/api/pandora/v1", api_pandora_v1),
        web.get("/api/pandora/repository.xml", api_pandora_repository),
        web.get("/api/pandora/plugins/Pandora-{letter}.zip", api_pandora_plugin_zip),
        web.post("/api/pandora/ensure-repository", api_pandora_ensure_repository),
        web.get("/rti", ws_rti),
        web.get("/art/main", art_main),
        web.get("/art/list", art_list),
        web.get("/art/source", art_source),
        web.get("/panel/assets/{filename}", panel_asset),
        web.get("/panel/material", material_panel_page),
        web.get("/panel", panel_page),
        web.get("/panel/{mode}", panel_page),
        web.get("/api/panel/state", api_panel_state),
        web.post("/api/panel/control", api_panel_control),
        web.route("*", "/jsonrpc.js", lms_proxy),
        web.route("*", "/cometd", lms_proxy),
        web.route("*", "/material", lms_proxy),
        web.route("*", "/material/{tail:.*}", lms_proxy),
        web.route("*", "/music/{tail:.*}", lms_proxy),
        web.route("*", "/imageproxy/{tail:.*}", lms_proxy),
        web.route("*", "/contributor/{tail:.*}", lms_proxy),
        web.route("*", "/plugins/{tail:.*}", lms_proxy),

        # Setup UI (does not affect RTI WS protocol)
        web.get("/setup", setup_page),
        web.get("/setup/players", setup_players_page),
        web.get("/setup/web", setup_web_page),
        web.get("/setup/system", setup_system_page),
        web.get("/setup/lms-plugin-settings", setup_lms_plugin_settings_page),
        web.post("/setup/lms-plugin-settings", setup_lms_plugin_settings_page),
        web.get("/setup/pandora-account", setup_pandora_account_page),
        web.get("/setup/assets/{filename}", setup_asset),
        web.get("/setup/advanced", setup_advanced_page),
        web.get("/setup/advanced/login", setup_advanced_login_page),
        web.post("/setup/advanced/login", setup_advanced_login_post),
        web.get("/setup/advanced/logout", setup_advanced_logout),
        web.get("/api/rti/config", api_rti_config_get),
        web.get("/api/setup/session", api_setup_session),
        web.get("/api/setup", api_setup_get),
        web.post("/api/setup", api_setup_post),
        web.post("/api/setup/web", api_setup_web_post),
        web.post("/api/setup/material-skin", api_setup_material_skin),
        web.post("/api/setup/mode", api_setup_mode),
        web.get("/api/setup/lms-discovery", api_setup_lms_discovery),
        web.post("/api/setup/advanced", api_setup_advanced_post),
        web.post("/api/setup/system-identity", api_setup_system_identity),
        web.post("/api/setup/players/apply", api_setup_players_apply),
        web.post("/api/setup/players/fixed-volume", api_setup_players_fixed_volume),
        web.post("/api/setup/players/action", api_setup_players_action),
        web.post("/api/setup/players/test-output", api_setup_players_test_output),
        web.post("/api/system/action", api_system_action),
        web.post("/api/system/plugin", api_system_plugin),
        web.post("/api/pandora/account", api_pandora_account),
        web.get("/api/system/backup", api_system_backup),
        web.post("/api/system/restore", api_system_restore),
        web.get("/api/update/peek", api_update_peek),
        web.get("/api/update/check", api_update_check),
        web.get("/api/update/status", api_update_status),
        web.post("/api/update/install", api_update_install),
        web.get("/api/lms_root", api_lms_root),
        web.get("/api/mymusic_menu", api_mymusic_menu),
        web.get("/api/radio_menu", api_radio_menu),
    ])
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app


def _get_listen_ip_for_peer(peer_ip: str) -> str:
    try:
        t = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        t.connect((peer_ip, 9))
        ip = t.getsockname()[0]
        t.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _discovery_status_snapshot() -> Dict[str, Any]:
    try:
        rows = _pcp_player_sessions()
        macs = {
            _safe_str(row.get("mac")).strip().lower()
            for row in rows
            if _safe_str(row.get("mac")).strip()
        }
        running_macs = _running_squeezelite_macs(macs) if macs else set()
        return {
            "configured_players": len(rows),
            "running_players": len(running_macs),
            "local_player_limit": _local_player_limit(),
        }
    except Exception:
        return {
            "configured_players": 0,
            "running_players": 0,
            "local_player_limit": _local_player_limit(),
        }


def _discovery_reply(addr: Tuple[str, int], commissioning: bool) -> bytes:
    unit_name = _pcp_config_hostname() or _default_unit_hostname()
    payload: Dict[str, Any] = {
        "t": "gadget_announce" if commissioning else "broker_announce",
        "ip": _get_listen_ip_for_peer(addr[0]),
        "port": LISTEN_PORT,
        "name": DISCOVERY_NAME or BROKER_ID or unit_name or "Lyrion Gadget",
        "broker_id": BROKER_ID,
        "hostname": unit_name,
        "version": APP_VERSION,
        "mode": _broker_mode(),
        "pi_model": _raspberry_pi_model(),
    }
    if commissioning:
        payload["lms_base"] = LMS_BASE
        payload.update(_discovery_status_snapshot())
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _discovery_udp_thread(listen_host: str = "0.0.0.0") -> None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((listen_host, DISCOVERY_UDP_PORT))
        dbg(f"UDP discovery listening {listen_host}:{DISCOVERY_UDP_PORT}")
    except Exception as e:
        dbg(f"UDP discovery disabled (bind failed): {e}")
        return

    while True:
        try:
            data, addr = s.recvfrom(1024)
        except Exception:
            continue
        try:
            commissioning = data == COMMISSION_DISCOVERY_MAGIC
            rti_discovery = data == DISCOVERY_MAGIC
            if not commissioning and not rti_discovery:
                continue
            if rti_discovery and _broker_light_mode():
                continue
            s.sendto(_discovery_reply(addr, commissioning=commissioning), addr)
        except Exception:
            continue


def main() -> None:
    web.run_app(build_app(), host=LISTEN_HOST, port=LISTEN_PORT)


if __name__ == "__main__":
    main()





