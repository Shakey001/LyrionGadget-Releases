#!/bin/sh
# Install this project's custom Lyrion Python broker on piCorePlayer.
# Run from the pi_broker folder after copying it to the pCP host.

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

if [ -n "${TCE_DIR:-}" ]; then
  PERSIST_DIR="$TCE_DIR"
elif [ -e /etc/sysconfig/tcedir ]; then
  PERSIST_DIR="$(readlink -f /etc/sysconfig/tcedir 2>/dev/null || true)"
else
  PERSIST_DIR=""
fi

if [ -z "$PERSIST_DIR" ]; then
  PERSIST_DIR="/mnt/mmcblk0p2/tce"
fi

APP_DIR="${APP_DIR:-$PERSIST_DIR/lyriongadget}"
PLAYLIST_DIR="${PLAYLIST_DIR:-$PERSIST_DIR/slimserver/Playlists}"
BOOTLOCAL="${BOOTLOCAL:-/opt/bootlocal.sh}"
BOOTSYNC="${BOOTSYNC:-/opt/bootsync.sh}"
FILETOOL_LIST="${FILETOOL_LIST:-/opt/.filetool.lst}"
START_SCRIPT="$APP_DIR/start-lyrion-broker-pcp.sh"
WATCH_SCRIPT="$APP_DIR/watch-lyrion-broker-pcp.sh"
LAUNCH_SCRIPT="$APP_DIR/launch-lyrion-broker-pcp.sh"
ENV_FILE="$APP_DIR/lyrion-broker.env"
PCP_CONFIG="${PCP_CONFIG:-/usr/local/etc/pcp/pcp.cfg}"
PI_MODEL="$(tr -d '\000' < /proc/device-tree/model 2>/dev/null || true)"
PI_MAJOR=0
BOOT_DELAY=45
case "$PI_MODEL" in
  *"Raspberry Pi 3"*) PI_MAJOR=3; BOOT_DELAY=25 ;;
  *"Raspberry Pi 4"*) PI_MAJOR=4; BOOT_DELAY=20 ;;
  *"Raspberry Pi 5"*) PI_MAJOR=5; BOOT_DELAY=10 ;;
esac

install_pcp_root_redirect() {
  target="/var/www/index.html"
  mkdir -p /var/www
  if [ -L "$target" ]; then
    rm -f "$target"
  fi
  cat > "$target" <<'EOF'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="cache-control" content="no-store, no-cache, must-revalidate, max-age=0">
  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="expires" content="0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lyrion Gadget</title>
  <script>
    (function () {
      var host = window.location.hostname || window.location.host.split(":")[0];
      window.location.replace(window.location.protocol + "//" + host + ":9099/setup");
    }());
  </script>
</head>
<body style="font-family:Arial,sans-serif;margin:32px;line-height:1.45;">
  <h1>Lyrion Gadget</h1>
  <p>Opening Lyrion Gadget setup...</p>
  <p><a href="#" onclick="this.href=location.protocol+'//'+location.hostname+':9099/setup'">Open Lyrion Gadget setup</a></p>
</body>
</html>
EOF
  if [ -f "$FILETOOL_LIST" ]; then
    grep -qxF "var/www/index.html" "$FILETOOL_LIST" || echo "var/www/index.html" >> "$FILETOOL_LIST"
  fi
}

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 was not found."
  echo "Install a Python 3 extension from the piCorePlayer Extensions page, reboot if requested, then rerun this installer."
  exit 1
fi

mkdir -p "$APP_DIR" "$PLAYLIST_DIR"
cp "$SCRIPT_DIR/lyrion_broker.py" "$APP_DIR/lyrion_broker.py"
cp "$SCRIPT_DIR/pandora_backend.py" "$APP_DIR/pandora_backend.py"
cp "$SCRIPT_DIR/requirements.txt" "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/pandora_plugins"
cp "$SCRIPT_DIR"/pandora_plugins/*.zip "$APP_DIR/pandora_plugins/"
mkdir -p "$APP_DIR/web_assets"
cp "$SCRIPT_DIR"/web_assets/* "$APP_DIR/web_assets/"
cp "$SCRIPT_DIR/start-lyrion-broker-pcp.sh" "$START_SCRIPT"
chmod +x "$START_SCRIPT"
cp "$SCRIPT_DIR/watch-lyrion-broker-pcp.sh" "$WATCH_SCRIPT"
chmod +x "$WATCH_SCRIPT"
cp "$SCRIPT_DIR/launch-lyrion-broker-pcp.sh" "$LAUNCH_SCRIPT"
chmod +x "$LAUNCH_SCRIPT"
if [ -f "$SCRIPT_DIR/repair-picoreplayer.sh" ]; then
  cp "$SCRIPT_DIR/repair-picoreplayer.sh" "$APP_DIR/repair-picoreplayer.sh"
  chmod +x "$APP_DIR/repair-picoreplayer.sh"
fi

if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
LMS_BASE=http://127.0.0.1:9000
BROKER_HOST=0.0.0.0
BROKER_PORT=9099
BROKER_DIFF=1
STATUS_SUBSCRIBE_SECS=300
RESCAN_SECS=0
FORCE_STATUS_AFTER_COMMAND=0
RTI_WS_FIRST_SEND_DELAY_SECS=0.75
BROKER_SETUP_JSON=$APP_DIR/broker_setup.json
EOF
fi

if grep -q '^BROKER_DIFF=' "$ENV_FILE"; then
  sed -i 's/^BROKER_DIFF=.*/BROKER_DIFF=1/' "$ENV_FILE"
else
  printf '\nBROKER_DIFF=1\n' >> "$ENV_FILE"
fi

if grep -q '^STATUS_SUBSCRIBE_SECS=' "$ENV_FILE"; then
  sed -i 's/^STATUS_SUBSCRIBE_SECS=.*/STATUS_SUBSCRIBE_SECS=300/' "$ENV_FILE"
else
  printf '\nSTATUS_SUBSCRIBE_SECS=300\n' >> "$ENV_FILE"
fi

if grep -q '^RTI_WS_FIRST_SEND_DELAY_SECS=' "$ENV_FILE"; then
  sed -i 's/^RTI_WS_FIRST_SEND_DELAY_SECS=.*/RTI_WS_FIRST_SEND_DELAY_SECS=0.75/' "$ENV_FILE"
else
  printf '\nRTI_WS_FIRST_SEND_DELAY_SECS=0.75\n' >> "$ENV_FILE"
fi

if [ ! -x "$APP_DIR/.venv/bin/python" ]; then
  if ! python3 -m venv "$APP_DIR/.venv"; then
    echo "Could not create the Python virtual environment at $APP_DIR/.venv."
    echo "Make sure the piCorePlayer Python 3 package includes venv/ensurepip support, then rerun this installer."
    exit 1
  fi
fi

"$APP_DIR/.venv/bin/python" -m pip install --upgrade pip
"$APP_DIR/.venv/bin/python" -m pip install -r "$APP_DIR/requirements.txt"

BOOT_LINE="( sleep $BOOT_DELAY; $LAUNCH_SCRIPT >/dev/null 2>&1 ) &"
if [ -f "$BOOTLOCAL" ]; then
  sed -i "\|$START_SCRIPT|d" "$BOOTLOCAL"
  sed -i "\|$WATCH_SCRIPT|d" "$BOOTLOCAL"
  sed -i "\|$LAUNCH_SCRIPT|d" "$BOOTLOCAL"
fi

if [ -f "$BOOTSYNC" ]; then
  sed -i "\|$START_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|$WATCH_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|$LAUNCH_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|lyrion-bootsync.log|d" "$BOOTSYNC"
else
  printf '#!/bin/sh\n' > "$BOOTSYNC"
  chmod +x "$BOOTSYNC"
fi

cat >> "$BOOTSYNC" <<EOF

# Start Lyrion RTI Broker after pCP boot settles
(
  sleep $BOOT_DELAY
  mkdir -p $APP_DIR/logs
  echo "\$(date) bootsync starting Lyrion broker" >> $APP_DIR/logs/lyrion-bootsync.log
  $LAUNCH_SCRIPT >> $APP_DIR/logs/lyrion-bootsync.log 2>&1
) &
EOF

if [ -f "$FILETOOL_LIST" ]; then
  grep -qxF "opt/bootlocal.sh" "$FILETOOL_LIST" || echo "opt/bootlocal.sh" >> "$FILETOOL_LIST"
  grep -qxF "opt/bootsync.sh" "$FILETOOL_LIST" || echo "opt/bootsync.sh" >> "$FILETOOL_LIST"
  grep -qxF "opt/.filetool.lst" "$FILETOOL_LIST" || echo "opt/.filetool.lst" >> "$FILETOOL_LIST"
fi

install_pcp_root_redirect

if [ -f "$PCP_CONFIG" ] && command -v python3 >/dev/null 2>&1; then
  for slot in 1 2 3 4 5; do
    if grep -q "^USER_COMMAND_${slot}=" "$PCP_CONFIG"; then
      current_cmd="$(grep "^USER_COMMAND_${slot}=" "$PCP_CONFIG" | head -1 | sed 's/^USER_COMMAND_[0-9]="//;s/"$//')"
      if echo "$current_cmd" | grep -qi 'lyrion-broker-pcp'; then
        sed -i "s|^USER_COMMAND_${slot}=.*|USER_COMMAND_${slot}=\"\"|" "$PCP_CONFIG"
      fi
    fi
  done
fi

if [ -f "$PCP_CONFIG" ] && command -v python3 >/dev/null 2>&1; then
  DEFAULT_HOST="$(python3 - <<'PY'
import os, re
mac = ""
for name in sorted(os.listdir("/sys/class/net")):
    if name == "lo":
        continue
    try:
        value = open(f"/sys/class/net/{name}/address", "r", encoding="utf-8").read().strip()
    except Exception:
        continue
    if re.fullmatch(r"[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}", value) and value != "00:00:00:00:00:00":
        mac = value
        break
tail = "".join(mac.split(":"))[-4:].upper() if mac else "0000"
print("Lyrion" + tail)
PY
)"
  CURRENT_HOST="$(grep '^HOST=' "$PCP_CONFIG" 2>/dev/null | head -1 | sed 's/^HOST="//;s/"$//')"
  case "$(printf '%s' "$CURRENT_HOST" | tr '[:upper:]' '[:lower:]')" in
    ""|"pcp"|"picoreplayer"|"raspberrypi"|"localhost")
      if grep -q '^HOST=' "$PCP_CONFIG"; then
        sed -i "s|^HOST=.*|HOST=\"$DEFAULT_HOST\"|" "$PCP_CONFIG"
      else
        printf '\nHOST="%s"\n' "$DEFAULT_HOST" >> "$PCP_CONFIG"
      fi
      ;;
  esac
fi

if command -v filetool.sh >/dev/null 2>&1; then
  filetool.sh -b
fi

"$START_SCRIPT"
if ! ps | grep '[w]atch-lyrion-broker-pcp.sh' >/dev/null 2>&1; then
  "$LAUNCH_SCRIPT"
fi

IP_ADDR="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ -z "$IP_ADDR" ]; then
  IP_ADDR="<picoreplayer-ip>"
fi

echo "Installed Lyrion Broker to $APP_DIR"
echo "Health: http://$IP_ADDR:9099/health"
echo "Setup:  http://$IP_ADDR:9099/setup"
