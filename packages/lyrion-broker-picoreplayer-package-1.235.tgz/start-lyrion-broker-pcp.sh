#!/bin/sh
# piCorePlayer/Tiny Core startup wrapper for the Lyrion RTI Broker.

set -eu

APP_DIR="${APP_DIR:-/mnt/mmcblk0p2/tce/lyriongadget}"
PERSIST_DIR="${PERSIST_DIR:-$(dirname "$APP_DIR")}"
PLAYLIST_DIR="${PLAYLIST_DIR:-$PERSIST_DIR/slimserver/Playlists}"
ENV_FILE="${ENV_FILE:-$APP_DIR/lyrion-broker.env}"
LOG_DIR="${LOG_DIR:-$APP_DIR/logs}"
PID_FILE="${PID_FILE:-$LOG_DIR/lyrion-broker.pid}"

if [ -f "$ENV_FILE" ]; then
  # shellcheck disable=SC1090
  . "$ENV_FILE"
fi

mkdir -p "$LOG_DIR"
mkdir -p "$PLAYLIST_DIR"

PYTHON_BIN="${PYTHON_BIN:-$APP_DIR/.venv/bin/python}"
if [ ! -x "$PYTHON_BIN" ]; then
  PYTHON_BIN="${PYTHON_BIN_FALLBACK:-python3}"
fi

export LMS_BASE="${LMS_BASE:-http://127.0.0.1:9000}"
export BROKER_HOST="${BROKER_HOST:-0.0.0.0}"
export BROKER_PORT="${BROKER_PORT:-9099}"
export BROKER_DIFF="${BROKER_DIFF:-1}"
export STATUS_SUBSCRIBE_SECS="${STATUS_SUBSCRIBE_SECS:-300}"
export RESCAN_SECS="${RESCAN_SECS:-0}"
export FORCE_STATUS_AFTER_COMMAND="${FORCE_STATUS_AFTER_COMMAND:-0}"
export RTI_WS_FIRST_SEND_DELAY_SECS="${RTI_WS_FIRST_SEND_DELAY_SECS:-0.75}"
export BROKER_SETUP_JSON="${BROKER_SETUP_JSON:-$APP_DIR/broker_setup.json}"

HEALTH_URL="${BROKER_HEALTH_URL:-http://127.0.0.1:$BROKER_PORT/health}"
STARTUP_WAIT_SECS="${BROKER_STARTUP_WAIT_SECS:-90}"
STARTUP_RETRIES="${BROKER_STARTUP_RETRIES:-2}"

log_start() {
  printf '%s start-wrapper: %s\n' "$(date)" "$*" >> "$LOG_DIR/lyrion-broker.log"
}

is_broker_pid() {
  pid="$1"
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  [ -r "/proc/$pid/cmdline" ] || return 1
  tr '\000' '\n' < "/proc/$pid/cmdline" | grep -Fqx "$APP_DIR/lyrion_broker.py"
}

health_ok() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time 2 "$HEALTH_URL" >/dev/null 2>&1
    return $?
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -T 2 -O /dev/null "$HEALTH_URL" >/dev/null 2>&1
    return $?
  fi
  return 1
}

wait_for_health() {
  deadline=$(( $(date +%s) + STARTUP_WAIT_SECS ))
  while [ "$(date +%s)" -lt "$deadline" ]; do
    if health_ok; then
      return 0
    fi
    sleep 2
  done
  return 1
}

stop_broker_pid() {
  pid="$1"
  [ -n "$pid" ] || return 0
  kill "$pid" 2>/dev/null || true
  sleep 2
  kill -9 "$pid" 2>/dev/null || true
}

if [ -f "$PID_FILE" ]; then
  old_pid="$(cat "$PID_FILE" 2>/dev/null || true)"
  if is_broker_pid "$old_pid"; then
    if health_ok || wait_for_health; then
      exit 0
    fi
    log_start "broker pid $old_pid exists but health did not answer; restarting it"
    stop_broker_pid "$old_pid"
  fi
  rm -f "$PID_FILE"
fi

attempt=1
while [ "$attempt" -le "$STARTUP_RETRIES" ]; do
  cd "$APP_DIR"
  log_start "launch attempt $attempt using $PYTHON_BIN"
  if command -v setsid >/dev/null 2>&1; then
    setsid "$PYTHON_BIN" "$APP_DIR/lyrion_broker.py" </dev/null >> "$LOG_DIR/lyrion-broker.log" 2>&1 &
  else
    nohup "$PYTHON_BIN" "$APP_DIR/lyrion_broker.py" </dev/null >> "$LOG_DIR/lyrion-broker.log" 2>&1 &
  fi
  new_pid="$!"
  echo "$new_pid" > "$PID_FILE"

  if wait_for_health; then
    log_start "broker healthy on $HEALTH_URL pid $new_pid"
    exit 0
  fi

  if is_broker_pid "$new_pid"; then
    log_start "broker pid $new_pid did not become healthy; killing and retrying"
    stop_broker_pid "$new_pid"
  else
    log_start "broker process $new_pid exited before health answered"
  fi
  rm -f "$PID_FILE"
  attempt=$((attempt + 1))
  sleep 3
done

log_start "broker failed to become healthy after $STARTUP_RETRIES attempts"
exit 1
