#!/bin/sh
# Install this project's custom Lyrion Python broker on piCorePlayer.
# Run from the pi_broker folder after copying it to the pCP host.

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

if [ -n "${TCE_DIR:-}" ]; then
  PERSIST_DIR="$TCE_DIR"
elif [ -e /etc/sysconfig/tcedir ]; then
  PERSIST_DIR="$(readlink -f /etc/sysconfig/tcedir 2>/dev/null || true)"
else
  PERSIST_DIR=""
fi

if [ -z "$PERSIST_DIR" ]; then
  PERSIST_DIR="/mnt/mmcblk0p2/tce"
fi

APP_DIR="${APP_DIR:-$PERSIST_DIR/lyriongadget}"
BOOTLOCAL="${BOOTLOCAL:-/opt/bootlocal.sh}"
FILETOOL_LIST="${FILETOOL_LIST:-/opt/.filetool.lst}"
START_SCRIPT="$APP_DIR/start-lyrion-broker-pcp.sh"
ENV_FILE="$APP_DIR/lyrion-broker.env"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 was not found."
  echo "Install a Python 3 extension from the piCorePlayer Extensions page, reboot if requested, then rerun this installer."
  exit 1
fi

mkdir -p "$APP_DIR"
cp "$SCRIPT_DIR/lyrion_broker.py" "$APP_DIR/lyrion_broker.py"
cp "$SCRIPT_DIR/pandora_backend.py" "$APP_DIR/pandora_backend.py"
cp "$SCRIPT_DIR/requirements.txt" "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/pandora_plugins"
cp "$SCRIPT_DIR"/pandora_plugins/*.zip "$APP_DIR/pandora_plugins/"
mkdir -p "$APP_DIR/web_assets"
cp "$SCRIPT_DIR"/web_assets/*.png "$APP_DIR/web_assets/"
cp "$SCRIPT_DIR/start-lyrion-broker-pcp.sh" "$START_SCRIPT"
chmod +x "$START_SCRIPT"
if [ -f "$SCRIPT_DIR/repair-picoreplayer.sh" ]; then
  cp "$SCRIPT_DIR/repair-picoreplayer.sh" "$APP_DIR/repair-picoreplayer.sh"
  chmod +x "$APP_DIR/repair-picoreplayer.sh"
fi

if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
LMS_BASE=http://127.0.0.1:9000
BROKER_HOST=0.0.0.0
BROKER_PORT=9099
BROKER_DIFF=1
STATUS_SUBSCRIBE_SECS=300
RESCAN_SECS=0
FORCE_STATUS_AFTER_COMMAND=0
RTI_WS_FIRST_SEND_DELAY_SECS=0.75
BROKER_SETUP_JSON=$APP_DIR/broker_setup.json
EOF
fi

if grep -q '^BROKER_DIFF=' "$ENV_FILE"; then
  sed -i 's/^BROKER_DIFF=.*/BROKER_DIFF=1/' "$ENV_FILE"
else
  printf '\nBROKER_DIFF=1\n' >> "$ENV_FILE"
fi

if grep -q '^STATUS_SUBSCRIBE_SECS=' "$ENV_FILE"; then
  sed -i 's/^STATUS_SUBSCRIBE_SECS=.*/STATUS_SUBSCRIBE_SECS=300/' "$ENV_FILE"
else
  printf '\nSTATUS_SUBSCRIBE_SECS=300\n' >> "$ENV_FILE"
fi

if grep -q '^RTI_WS_FIRST_SEND_DELAY_SECS=' "$ENV_FILE"; then
  sed -i 's/^RTI_WS_FIRST_SEND_DELAY_SECS=.*/RTI_WS_FIRST_SEND_DELAY_SECS=0.75/' "$ENV_FILE"
else
  printf '\nRTI_WS_FIRST_SEND_DELAY_SECS=0.75\n' >> "$ENV_FILE"
fi

if [ ! -x "$APP_DIR/.venv/bin/python" ]; then
  if ! python3 -m venv "$APP_DIR/.venv"; then
    echo "Could not create the Python virtual environment at $APP_DIR/.venv."
    echo "Make sure the piCorePlayer Python 3 package includes venv/ensurepip support, then rerun this installer."
    exit 1
  fi
fi

"$APP_DIR/.venv/bin/python" -m pip install --upgrade pip
"$APP_DIR/.venv/bin/python" -m pip install -r "$APP_DIR/requirements.txt"

BOOT_LINE="( sleep 20; $START_SCRIPT ) &"
if [ -f "$BOOTLOCAL" ]; then
  sed -i "\|$START_SCRIPT|d" "$BOOTLOCAL"
  if ! grep -qxF "$BOOT_LINE" "$BOOTLOCAL"; then
    printf '\n# Start Lyrion RTI Broker\n%s\n' "$BOOT_LINE" >> "$BOOTLOCAL"
  fi
else
  printf '#!/bin/sh\n# Start Lyrion RTI Broker\n%s\n' "$BOOT_LINE" > "$BOOTLOCAL"
  chmod +x "$BOOTLOCAL"
fi

if [ -f "$FILETOOL_LIST" ]; then
  grep -qxF "opt/bootlocal.sh" "$FILETOOL_LIST" || echo "opt/bootlocal.sh" >> "$FILETOOL_LIST"
  grep -qxF "opt/.filetool.lst" "$FILETOOL_LIST" || echo "opt/.filetool.lst" >> "$FILETOOL_LIST"
fi

if command -v filetool.sh >/dev/null 2>&1; then
  filetool.sh -b
fi

"$START_SCRIPT"

IP_ADDR="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ -z "$IP_ADDR" ]; then
  IP_ADDR="<picoreplayer-ip>"
fi

echo "Installed Lyrion Broker to $APP_DIR"
echo "Health: http://$IP_ADDR:9099/health"
echo "Setup:  http://$IP_ADDR:9099/setup"
