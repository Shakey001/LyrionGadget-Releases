#!/bin/sh
# Short pCP user-command launcher for the Lyrion watchdog.

set -u

APP_DIR="${APP_DIR:-/mnt/mmcblk0p2/tce/lyriongadget}"
LOG_DIR="${LOG_DIR:-$APP_DIR/logs}"
WATCH_SCRIPT="${WATCH_SCRIPT:-$APP_DIR/watch-lyrion-broker-pcp.sh}"

mkdir -p "$LOG_DIR"

rotate_log() {
  log_file="$1"
  max_bytes="${2:-10485760}"
  [ -f "$log_file" ] || return 0
  log_bytes="$(wc -c < "$log_file" 2>/dev/null || echo 0)"
  [ "$log_bytes" -gt "$max_bytes" ] || return 0
  rm -f "$log_file.3"
  [ ! -f "$log_file.2" ] || mv "$log_file.2" "$log_file.3"
  [ ! -f "$log_file.1" ] || mv "$log_file.1" "$log_file.2"
  mv "$log_file" "$log_file.1"
}

if ps | grep '[w]atch-lyrion-broker-pcp.sh' >/dev/null 2>&1; then
  exit 0
fi

rotate_log "$LOG_DIR/lyrion-watchdog.log"

printf '%s launcher: starting watchdog\n' "$(date)" >> "$LOG_DIR/lyrion-watchdog.log"
if command -v setsid >/dev/null 2>&1; then
  setsid "$WATCH_SCRIPT" </dev/null >> "$LOG_DIR/lyrion-watchdog.log" 2>&1 &
else
  nohup "$WATCH_SCRIPT" </dev/null >> "$LOG_DIR/lyrion-watchdog.log" 2>&1 &
fi
exit 0
