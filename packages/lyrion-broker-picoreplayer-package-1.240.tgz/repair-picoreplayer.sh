#!/bin/sh
# One-shot repair/update helper for piCorePlayer.

set -u

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

if [ -n "${TCE_DIR:-}" ]; then
  PERSIST_DIR="$TCE_DIR"
elif [ -e /etc/sysconfig/tcedir ]; then
  PERSIST_DIR="$(readlink -f /etc/sysconfig/tcedir 2>/dev/null || true)"
else
  PERSIST_DIR=""
fi

if [ -z "$PERSIST_DIR" ]; then
  PERSIST_DIR="/mnt/mmcblk0p2/tce"
fi

APP_DIR="${APP_DIR:-$PERSIST_DIR/lyriongadget}"
PLAYLIST_DIR="${PLAYLIST_DIR:-$PERSIST_DIR/slimserver/Playlists}"
BOOTLOCAL="${BOOTLOCAL:-/opt/bootlocal.sh}"
BOOTSYNC="${BOOTSYNC:-/opt/bootsync.sh}"
FILETOOL_LIST="${FILETOOL_LIST:-/opt/.filetool.lst}"
ENV_FILE="$APP_DIR/lyrion-broker.env"
LOG_DIR="$APP_DIR/logs"
START_SCRIPT="$APP_DIR/start-lyrion-broker-pcp.sh"
WATCH_SCRIPT="$APP_DIR/watch-lyrion-broker-pcp.sh"
LAUNCH_SCRIPT="$APP_DIR/launch-lyrion-broker-pcp.sh"
PCP_CONFIG="${PCP_CONFIG:-/usr/local/etc/pcp/pcp.cfg}"
PI_MODEL="$(tr -d '\000' < /proc/device-tree/model 2>/dev/null || true)"
PI_MAJOR=0
BOOT_DELAY=45
case "$PI_MODEL" in
  *"Raspberry Pi 3"*) PI_MAJOR=3; BOOT_DELAY=25 ;;
  *"Raspberry Pi 4"*) PI_MAJOR=4; BOOT_DELAY=20 ;;
  *"Raspberry Pi 5"*) PI_MAJOR=5; BOOT_DELAY=10 ;;
esac

install_pcp_root_redirect() {
  target="/var/www/index.html"
  mkdir -p /var/www
  if [ -L "$target" ]; then
    rm -f "$target"
  fi
  cat > "$target" <<'EOF'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="cache-control" content="no-store, no-cache, must-revalidate, max-age=0">
  <meta http-equiv="pragma" content="no-cache">
  <meta http-equiv="expires" content="0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lyrion Gadget</title>
  <script>
    (function () {
      var host = window.location.hostname || window.location.host.split(":")[0];
      window.location.replace(window.location.protocol + "//" + host + ":9099/setup");
    }());
  </script>
</head>
<body style="font-family:Arial,sans-serif;margin:32px;line-height:1.45;">
  <h1>Lyrion Gadget</h1>
  <p>Opening Lyrion Gadget setup...</p>
  <p><a href="#" onclick="this.href=location.protocol+'//'+location.hostname+':9099/setup'">Open Lyrion Gadget setup</a></p>
</body>
</html>
EOF
  if [ -f "$FILETOOL_LIST" ]; then
    grep -qxF "var/www/index.html" "$FILETOOL_LIST" || echo "var/www/index.html" >> "$FILETOOL_LIST"
  fi
}

if command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
else
  SUDO=""
fi

echo "Repairing Lyrion Broker at $APP_DIR"

mkdir -p "$APP_DIR" "$LOG_DIR" "$PLAYLIST_DIR"
if id tc >/dev/null 2>&1; then
  chown tc:staff "$PLAYLIST_DIR"
  chmod 0775 "$PLAYLIST_DIR"
fi
cp "$SCRIPT_DIR/lyrion_broker.py" "$APP_DIR/lyrion_broker.py"
cp "$SCRIPT_DIR/pandora_backend.py" "$APP_DIR/pandora_backend.py"
cp "$SCRIPT_DIR/requirements.txt" "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/pandora_plugins"
cp "$SCRIPT_DIR"/pandora_plugins/*.zip "$APP_DIR/pandora_plugins/"
mkdir -p "$APP_DIR/web_assets"
cp "$SCRIPT_DIR"/web_assets/* "$APP_DIR/web_assets/"
cp "$SCRIPT_DIR/start-lyrion-broker-pcp.sh" "$START_SCRIPT"
chmod +x "$START_SCRIPT"
cp "$SCRIPT_DIR/watch-lyrion-broker-pcp.sh" "$WATCH_SCRIPT"
chmod +x "$WATCH_SCRIPT"
cp "$SCRIPT_DIR/launch-lyrion-broker-pcp.sh" "$LAUNCH_SCRIPT"
chmod +x "$LAUNCH_SCRIPT"

if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
LMS_BASE=http://127.0.0.1:9000
BROKER_HOST=0.0.0.0
BROKER_PORT=9099
BROKER_DIFF=1
STATUS_SUBSCRIBE_SECS=300
RESCAN_SECS=0
FORCE_STATUS_AFTER_COMMAND=0
RTI_WS_FIRST_SEND_DELAY_SECS=0.75
BROKER_SETUP_JSON=$APP_DIR/broker_setup.json
EOF
fi

set_env() {
  key="$1"
  val="$2"
  if grep -q "^$key=" "$ENV_FILE"; then
    sed -i "s|^$key=.*|$key=$val|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$key" "$val" >> "$ENV_FILE"
  fi
}

set_env BROKER_DIFF 1
set_env STATUS_SUBSCRIBE_SECS 300
set_env FORCE_STATUS_AFTER_COMMAND 0
set_env RTI_WS_FIRST_SEND_DELAY_SECS 0.75
set_env BROKER_SETUP_JSON "$APP_DIR/broker_setup.json"

if [ -x "$APP_DIR/.venv/bin/python" ]; then
  echo "Installing broker Python requirements..."
  "$APP_DIR/.venv/bin/python" -m pip install -r "$APP_DIR/requirements.txt"
fi

BOOT_LINE="( sleep $BOOT_DELAY; $LAUNCH_SCRIPT >/dev/null 2>&1 ) &"
if [ -f "$BOOTLOCAL" ]; then
  sed -i "\|$START_SCRIPT|d" "$BOOTLOCAL"
  sed -i "\|$WATCH_SCRIPT|d" "$BOOTLOCAL"
  sed -i "\|$LAUNCH_SCRIPT|d" "$BOOTLOCAL"
fi

if [ -f "$BOOTSYNC" ]; then
  sed -i "\|$START_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|$WATCH_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|$LAUNCH_SCRIPT|d" "$BOOTSYNC"
  sed -i "\|lyrion-bootsync.log|d" "$BOOTSYNC"
else
  printf '#!/bin/sh\n' > "$BOOTSYNC"
  chmod +x "$BOOTSYNC"
fi

cat >> "$BOOTSYNC" <<EOF

# Start Lyrion RTI Broker after pCP boot settles
(
  sleep $BOOT_DELAY
  mkdir -p $APP_DIR/logs
  echo "\$(date) bootsync starting Lyrion broker" >> $APP_DIR/logs/lyrion-bootsync.log
  $LAUNCH_SCRIPT >> $APP_DIR/logs/lyrion-bootsync.log 2>&1
) &
EOF

if [ -f "$FILETOOL_LIST" ]; then
  grep -qxF "opt/bootlocal.sh" "$FILETOOL_LIST" || echo "opt/bootlocal.sh" >> "$FILETOOL_LIST"
  grep -qxF "opt/bootsync.sh" "$FILETOOL_LIST" || echo "opt/bootsync.sh" >> "$FILETOOL_LIST"
  grep -qxF "opt/.filetool.lst" "$FILETOOL_LIST" || echo "opt/.filetool.lst" >> "$FILETOOL_LIST"
fi

install_pcp_root_redirect

if [ -f "$PCP_CONFIG" ] && command -v python3 >/dev/null 2>&1; then
  for slot in 1 2 3 4 5; do
    if grep -q "^USER_COMMAND_${slot}=" "$PCP_CONFIG"; then
      current_cmd="$(grep "^USER_COMMAND_${slot}=" "$PCP_CONFIG" | head -1 | sed 's/^USER_COMMAND_[0-9]="//;s/"$//')"
      if echo "$current_cmd" | grep -qi 'lyrion-broker-pcp'; then
        sed -i "s|^USER_COMMAND_${slot}=.*|USER_COMMAND_${slot}=\"\"|" "$PCP_CONFIG"
      fi
    fi
  done
fi

if [ -f "$PCP_CONFIG" ] && command -v python3 >/dev/null 2>&1; then
  DEFAULT_HOST="$(python3 - <<'PY'
import os, re
mac = ""
for name in sorted(os.listdir("/sys/class/net")):
    if name == "lo":
        continue
    try:
        value = open(f"/sys/class/net/{name}/address", "r", encoding="utf-8").read().strip()
    except Exception:
        continue
    if re.fullmatch(r"[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}", value) and value != "00:00:00:00:00:00":
        mac = value
        break
tail = "".join(mac.split(":"))[-4:].upper() if mac else "0000"
print("Lyrion" + tail)
PY
)"
  CURRENT_HOST="$(grep '^HOST=' "$PCP_CONFIG" 2>/dev/null | head -1 | sed 's/^HOST="//;s/"$//')"
  case "$(printf '%s' "$CURRENT_HOST" | tr '[:upper:]' '[:lower:]')" in
    ""|"pcp"|"picoreplayer"|"raspberrypi"|"localhost")
      if grep -q '^HOST=' "$PCP_CONFIG"; then
        sed -i "s|^HOST=.*|HOST=\"$DEFAULT_HOST\"|" "$PCP_CONFIG"
      else
        printf '\nHOST="%s"\n' "$DEFAULT_HOST" >> "$PCP_CONFIG"
      fi
      ;;
  esac
fi

echo "Stopping old broker processes..."
ps | grep '[l]yrion_broker.py' | awk '{print $1}' | while read pid; do
  [ -n "$pid" ] || continue
  $SUDO kill "$pid" 2>/dev/null || true
done
sleep 1
ps | grep '[l]yrion_broker.py' | awk '{print $1}' | while read pid; do
  [ -n "$pid" ] || continue
  $SUDO kill -9 "$pid" 2>/dev/null || true
done

rm -f "$LOG_DIR/lyrion-broker.pid" /tmp/lyrion-broker.pid 2>/dev/null || true

echo "Starting broker..."
"$START_SCRIPT"
if ! ps | grep '[w]atch-lyrion-broker-pcp.sh' >/dev/null 2>&1; then
  "$LAUNCH_SCRIPT"
fi
sleep 2

echo "Running processes:"
ps | grep '[l]yrion_broker.py' || true

echo "Health:"
if command -v curl >/dev/null 2>&1; then
  curl -s http://127.0.0.1:9099/health || true
  echo
else
  echo "curl not found"
fi

echo "Env:"
grep -E 'BROKER_DIFF|STATUS_SUBSCRIBE_SECS|FORCE_STATUS|RTI_WS_FIRST_SEND_DELAY_SECS|LMS_BASE|BROKER_PORT' "$ENV_FILE" || true

echo "Recent log:"
tail -40 "$LOG_DIR/lyrion-broker.log" 2>/dev/null || true

if command -v filetool.sh >/dev/null 2>&1; then
  echo "Saving Tiny Core backup..."
  filetool.sh -b
fi
