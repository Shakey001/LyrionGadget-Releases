const $ = (selector) => document.querySelector(selector);
let snapshot;
let formDirty = false;

function setDirty(value) {
  formDirty = value;
  $("#save").disabled = !value;
  if (value) $("#saveState").textContent = "Unsaved changes";
  else $("#saveState").textContent = "Ready to configure";
}

function escapeHtml(value) {
  const node = document.createElement("div");
  node.textContent = value;
  return node.innerHTML;
}

async function load(forceFormRefresh = false) {
  try {
    const response = await fetch("/api/status", {cache: "no-store", signal: AbortSignal.timeout(2500)});
    snapshot = await response.json();
    $("#host").textContent = snapshot.hostname;
    $("#arch").textContent = snapshot.architecture;
    $("#playerMac").textContent = snapshot.playerMac;
    $("#serverDot").classList.toggle("online", snapshot.serverOnline);
    $("#overall").textContent = snapshot.running ? "Player running" : snapshot.serverOnline ? "Player stopped" : "Setup needed";
    $("#overall").classList.toggle("online", snapshot.running);
    $("#overall").style.borderColor = "";
    $("#overall").style.background = "";
    $("#overall").style.color = "";

    if (!formDirty || forceFormRefresh) {
      $("#server").value = snapshot.server;
      $("#playerName").value = snapshot.playerName;
      $("#alsaParams").value = snapshot.alsaParams || "200:4:32:0";
      $("#extendedRates").checked = !!snapshot.extendedRates;
      $("#fixedVolume").checked = snapshot.fixedVolume;
      const select = $("#output");
      select.innerHTML = "";
      const labels = {analog: "Analog line output", spdif: "S/PDIF digital output"};
      snapshot.outputs.forEach((row) => {
        const option = document.createElement("option");
        option.value = row.key;
        option.textContent = `${labels[row.key]} — ${row.label}`;
        option.selected = row.key === snapshot.output;
        select.append(option);
      });
      setDirty(false);
    }
    $("#state").textContent = snapshot.running ? "● Running" : "○ Stopped";
    $("#state").classList.toggle("running", snapshot.running);
    $("#audioFormat").textContent = snapshot.extendedRates ? "Extended to 192 kHz" : "Native stream rate";
    $("#events").innerHTML = (snapshot.events.length ? snapshot.events : ["No events yet."])
      .map((event) => `<div>${escapeHtml(event)}</div>`).join("");
  } catch (_error) {
    $("#overall").textContent = "Device offline";
    $("#overall").classList.remove("online");
    $("#overall").style.borderColor = "#991b1b";
    $("#overall").style.background = "#450a0a";
    $("#overall").style.color = "#fca5a5";
    $("#serverDot").classList.remove("online");
  }
}

async function save() {
  const button = $("#save");
  button.disabled = true;
  $("#saveState").textContent = "Applying settings…";
  try {
    const response = await fetch("/api/config", {
      method: "POST",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({
        server: $("#server").value,
        playerName: $("#playerName").value,
        output: $("#output").value,
        alsaParams: $("#alsaParams").value,
        extendedRates: $("#extendedRates").checked,
        fixedVolume: $("#fixedVolume").checked,
      }),
    });
    if (!response.ok) throw new Error(await response.text());
    setDirty(false);
    $("#saveState").textContent = "Settings applied";
    setTimeout(() => load(true), 700);
  } catch (error) {
    $("#saveState").textContent = error.message;
  } finally {
    button.disabled = !formDirty;
  }
}

function chooseGadget() {
  const selected = $("#gadgetResults").value;
  if (!selected) return;
  $("#server").value = selected;
  setDirty(true);
  const label = $("#gadgetResults").selectedOptions[0].textContent;
  $("#discoverState").textContent = `${label} selected. Click Save Player Settings.`;
}

async function discover() {
  const button = $("#discover");
  const picker = $("#gadgetResults");
  button.disabled = true;
  $("#gadgetPickerWrap").hidden = true;
  $("#discoverState").textContent = "Searching network…";
  try {
    const response = await fetch("/api/discover", {cache: "no-store"});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Discovery failed");
    const gadgets = result.gadgets || [];
    if (!gadgets.length) {
      $("#discoverState").textContent = "No Lyrion Gadget found. Existing address was not changed.";
    } else if (gadgets.length === 1) {
      $("#server").value = gadgets[0].server;
      setDirty(true);
      $("#discoverState").textContent = `Found ${gadgets[0].name} at ${gadgets[0].server}. Click Save Player Settings.`;
    } else {
      picker.innerHTML = '<option value="">Select a Lyrion Gadget…</option>';
      gadgets.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
      gadgets.forEach((gadget) => {
        const option = document.createElement("option");
        option.value = gadget.server;
        option.textContent = `${gadget.name} — ${gadget.server}${gadget.version ? ` — v${gadget.version}` : ""}`;
        picker.append(option);
      });
      $("#gadgetPickerWrap").hidden = false;
      $("#discoverState").textContent = `${gadgets.length} Lyrion Gadgets found. Select this player's server.`;
    }
  } catch (error) {
    $("#discoverState").textContent = error.message;
  } finally {
    button.disabled = false;
  }
}

$("#save").addEventListener("click", save);
$("#refresh").addEventListener("click", () => load(true));
$("#discover").addEventListener("click", discover);
$("#gadgetResults").addEventListener("change", chooseGadget);
$("#server").addEventListener("input", () => setDirty(true));
$("#playerName").addEventListener("input", () => setDirty(true));
$("#output").addEventListener("change", () => setDirty(true));
$("#alsaParams").addEventListener("input", () => setDirty(true));
$("#extendedRates").addEventListener("change", () => setDirty(true));
$("#fixedVolume").addEventListener("change", () => setDirty(true));
load();
setInterval(() => load(false), 3000);
