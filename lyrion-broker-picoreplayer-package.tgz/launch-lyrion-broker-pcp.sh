#!/bin/sh
# Short pCP user-command launcher for the Lyrion watchdog.

set -u

APP_DIR="${APP_DIR:-/mnt/mmcblk0p2/tce/lyriongadget}"
LOG_DIR="${LOG_DIR:-$APP_DIR/logs}"
WATCH_SCRIPT="${WATCH_SCRIPT:-$APP_DIR/watch-lyrion-broker-pcp.sh}"

mkdir -p "$LOG_DIR"

if ps | grep '[w]atch-lyrion-broker-pcp.sh' >/dev/null 2>&1; then
  exit 0
fi

printf '%s launcher: starting watchdog\n' "$(date)" >> "$LOG_DIR/lyrion-watchdog.log"
if command -v setsid >/dev/null 2>&1; then
  setsid "$WATCH_SCRIPT" </dev/null >> "$LOG_DIR/lyrion-watchdog.log" 2>&1 &
else
  nohup "$WATCH_SCRIPT" </dev/null >> "$LOG_DIR/lyrion-watchdog.log" 2>&1 &
fi
exit 0
