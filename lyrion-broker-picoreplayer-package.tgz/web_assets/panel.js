(function () {
  "use strict";

  var cfg = window.LYRION_PANEL || {};
  var playerid = (cfg.playerid || "").toLowerCase();
  var mode = cfg.mode || "browse";
  var ws = null;
  var wsSerial = 0;
  var reconnectTimer = 0;
  var connected = false;
  var currentItems = [];
  var knownPlayers = [];
  var currentTitle = "Home";
  var nowState = {};
  var pendingSearch = "";
  var volumeTimer = 0;
  var statusTimer = 0;
  var progressTimer = 0;
  var shuttingDown = false;
  var activeView = "browse";
  var browseLayout = "list";
  var touchStartX = 0;
  var touchStartY = 0;
  var pointerStartX = 0;
  var pointerStartY = 0;
  var progressBase = { pos: 0, dur: 0, ts: 0, playing: false };
  var capabilityState = {};
  var actionSheetRow = null;
  var pendingContextActionRow = null;
  var currentContextActionRow = null;

  function $(id) { return document.getElementById(id); }

  function send(obj) {
    if (shuttingDown) return;
    if (!ws || ws.readyState !== 1) return;
    ws.send(JSON.stringify(obj) + "\n");
  }

  function api(path, opts) {
    if (shuttingDown) {
      return Promise.reject(new Error("Panel closing"));
    }
    opts = opts || {};
    return fetch(path, opts).then(function (res) {
      return res.json().then(function (body) {
        if (!res.ok || body.ok === false) throw new Error(body.error || ("HTTP " + res.status));
        return body;
      });
    });
  }

  function text(v) {
    if (v === null || v === undefined) return "";
    return String(v);
  }

  function first() {
    for (var i = 0; i < arguments.length; i++) {
      var v = text(arguments[i]).trim();
      if (v) return v;
    }
    return "";
  }

  function samePlayer(pid) {
    return text(pid).toLowerCase() === playerid;
  }

  function hexToRgb(value) {
    var raw = text(value).trim();
    var m = raw.match(/^#?([0-9a-f]{6})$/i);
    if (!m) return "183, 255, 138";
    var hex = m[1];
    return [
      parseInt(hex.slice(0, 2), 16),
      parseInt(hex.slice(2, 4), 16),
      parseInt(hex.slice(4, 6), 16)
    ].join(", ");
  }

  function setPlayer(pid) {
    pid = text(pid).toLowerCase();
    if (!pid || playerid) return false;
    playerid = pid;
    cfg.playerid = pid;
    setText("npSub", pid);
    return true;
  }

  function ensurePlayer(pid) {
    pid = text(pid).toLowerCase();
    if (!pid) return false;
    playerid = pid;
    cfg.playerid = pid;
    setText("npSub", pid);
    return true;
  }

  function setStatus(label, ok) {
    var el = $("status");
    var logo = $("statusLogo");
    if (el) {
      el.textContent = ok ? "" : label;
      el.className = "status " + (ok ? "ok hidden" : "err");
    }
    if (logo) logo.className = "status-logo " + (ok ? "ok" : "err");
  }

  function setActive(id, active) {
    var el = $(id);
    if (!el) return;
    var base = el.className.replace(/\s+active\b/g, "");
    el.className = base + (active ? " active" : "");
  }

  function boolish(value) {
    if (value === true || value === 1) return true;
    if (value === false || value === 0) return false;
    var s = text(value).toLowerCase();
    if (s === "1" || s === "true" || s === "yes") return true;
    if (s === "0" || s === "false" || s === "no") return false;
    return null;
  }

  function setButtonEnabled(id, available) {
    var el = $(id);
    if (!el) return;
    if (available === null || available === undefined) {
      el.disabled = false;
    } else {
      el.disabled = !available;
    }
  }

  function readBoolCap(payload, keys) {
    for (var i = 0; i < keys.length; i++) {
      if (payload && Object.prototype.hasOwnProperty.call(payload, keys[i])) {
        return boolish(payload[keys[i]]);
      }
    }
    return null;
  }

  function derivePrevAvailable(payload) {
    var tracks = parseInt(first(payload.playlist_tracks, payload.playlistTracks, payload["playlist tracks"], nowState.playlist_tracks), 10);
    var idx = parseInt(first(payload.playlist_cur_index, payload.playlistIndex, payload["playlist index"], nowState.playlist_cur_index), 10);
    if (!isNaN(tracks) && tracks > 1 && !isNaN(idx)) return idx > 0;
    return null;
  }

  function deriveNextAvailable(payload) {
    var tracks = parseInt(first(payload.playlist_tracks, payload.playlistTracks, payload["playlist tracks"], nowState.playlist_tracks), 10);
    var idx = parseInt(first(payload.playlist_cur_index, payload.playlistIndex, payload["playlist index"], nowState.playlist_cur_index), 10);
    if (!isNaN(tracks) && tracks > 1 && !isNaN(idx)) return idx < tracks - 1;
    return null;
  }

  function iconSvg(name) {
    var icons = {
      prev: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h2v14H7z"></path><path d="M19 5v14L9 12z"></path></svg>',
      next: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5h2v14h-2z"></path><path d="M5 5v14l10-7z"></path></svg>',
      play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"></path></svg>',
      pause: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h4v14H7zM13 5h4v14h-4z"></path></svg>',
      queue: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h11v2H4zM4 11h11v2H4zM4 16h7v2H4z"></path><path d="M17 10v8l5-4z"></path></svg>',
      playnext: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5v14l8-7z"></path><path d="M14 5h2v14h-2z"></path><path d="M18 7h2v3h3v2h-3v3h-2v-3h-3v-2h3z"></path></svg>',
      sync: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9.5a3.5 3.5 0 1 1 3.2-4.9 5 5 0 0 0-1.5 9.6A3.5 3.5 0 0 1 6 9.5z"></path><path d="M14 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"></path><path d="M5 18.5C5 16.6 8.5 15 12 15s7 1.6 7 3.5V21H5z"></path></svg>',
      grid: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"></path></svg>',
      list: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16v2H4zM4 11h16v2H4zM4 16h16v2H4z"></path></svg>',
      back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11v2H7.8l5.6 5.6L12 20 4 12l8-8 1.4 1.4L7.8 11z"></path></svg>',
      home: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11l9-8 9 8-1.4 1.5L18 11.1V21h-5v-6h-2v6H6v-9.9l-1.6 1.4z"></path></svg>',
      add: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"></path></svg>',
      edit: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 17.3V20h2.7L17.9 8.8l-2.7-2.7z"></path><path d="M19.7 7 17 4.3l1.2-1.2a1.4 1.4 0 0 1 2 0l.7.7a1.4 1.4 0 0 1 0 2z"></path></svg>',
      trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4h8l1 2h4v2H3V6h4z"></path><path d="M6 10h12l-1 11H7z"></path></svg>',
      close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z"></path></svg>',
      search: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.5 4a6.5 6.5 0 0 1 5.1 10.5l4.4 4.4-1.4 1.4-4.4-4.4A6.5 6.5 0 1 1 10.5 4zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9z"></path></svg>',
      browse: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v3H4zM4 10.5h16v3H4zM4 16h16v3H4z"></path></svg>',
      now: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm0 2v12h14V6z"></path><path d="M8 15l2.7-3.2 2.1 2.5 1.7-2.1L18 16H6z"></path></svg>',
      info: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 10h2v8h-2zM11 6h2v2h-2z"></path><path d="M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20zm0 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16z"></path></svg>',
      thumbUp: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 10h4v11H2zM8 21h8.8a3 3 0 0 0 2.9-2.3l1.2-5A3 3 0 0 0 18 10h-4.2l.7-3.4A2.9 2.9 0 0 0 11.7 3h-.4L8 9z"></path></svg>',
      thumbDown: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 3h4v11H2zM8 3h8.8a3 3 0 0 1 2.9 2.3l1.2 5A3 3 0 0 1 18 14h-4.2l.7 3.4a2.9 2.9 0 0 1-2.8 3.6h-.4L8 15z"></path></svg>'
    };
    return icons[name] || "";
  }

  function setTransportIcon(id, value) {
    var el = $(id);
    if (el) el.innerHTML = iconSvg(value);
  }

  function updateTransportState(payload) {
    var isPlaying = text(payload.mode).toLowerCase() === "play";
    var playAvailable = isPlaying ? readBoolCap(payload, ["can_pause", "canPause"]) : readBoolCap(payload, ["can_play", "canPlay"]);
    var prevAvailable = readBoolCap(payload, ["can_prev", "can_previous", "canPrev", "canPrevious"]);
    var nextAvailable = readBoolCap(payload, ["can_next", "canNext"]);
    if (prevAvailable === null) prevAvailable = derivePrevAvailable(payload);
    if (nextAvailable === null) nextAvailable = deriveNextAvailable(payload);
    if (playAvailable !== null) capabilityState.play = playAvailable;
    if (prevAvailable !== null) capabilityState.prev = prevAvailable;
    if (nextAvailable !== null) capabilityState.next = nextAvailable;
    if (playAvailable === null && capabilityState.play !== undefined) playAvailable = capabilityState.play;
    if (prevAvailable === null && capabilityState.prev !== undefined) prevAvailable = capabilityState.prev;
    if (nextAvailable === null && capabilityState.next !== undefined) nextAvailable = capabilityState.next;
    if (playAvailable === null) playAvailable = true;
    if (prevAvailable === null) prevAvailable = false;
    if (nextAvailable === null) nextAvailable = true;
    var playIcon = isPlaying ? "pause" : "play";
    setTransportIcon("playPause", playIcon);
    setTransportIcon("coverPlayPause", playIcon);
    ["playPause", "coverPlayPause"].forEach(function (id) { setButtonEnabled(id, playAvailable); });
    ["prev", "coverPrev"].forEach(function (id) { setButtonEnabled(id, prevAvailable); });
    ["next", "coverNext"].forEach(function (id) { setButtonEnabled(id, nextAvailable); });
  }

  function drawProgress(pos, dur) {
    var pct = dur > 0 ? Math.max(0, Math.min(100, (pos / dur) * 100)) : 0;
    var bar = $("progressBar");
    if (bar) bar.style.width = pct + "%";
    var coverBar = $("coverProgressBar");
    if (coverBar) coverBar.style.width = pct + "%";
    var value = dur > 0 ? (fmtTime(pos) + " / " + fmtTime(dur)) : "";
    var label = $("timeLabel");
    if (label) label.textContent = value;
    var coverLabel = $("coverTimeLabel");
    if (coverLabel) coverLabel.textContent = value;
  }

  function updateProgress(payload) {
    var pos = Number(first(payload.time, payload.position, payload["playlist time"], 0)) || 0;
    var dur = Number(first(payload.duration, payload.remoteMeta && payload.remoteMeta.duration, 0)) || 0;
    progressBase = {
      pos: pos,
      dur: dur,
      ts: Date.now(),
      playing: text(payload.mode).toLowerCase() === "play"
    };
    drawProgress(pos, dur);
  }

  function tickProgress() {
    if (!progressBase.playing || progressBase.dur <= 0) return;
    var pos = progressBase.pos + ((Date.now() - progressBase.ts) / 1000);
    drawProgress(Math.min(pos, progressBase.dur), progressBase.dur);
  }

  function loadBrowseLayout() {
    try {
      var saved = window.localStorage && window.localStorage.getItem("lyrionPanelBrowseLayout");
      browseLayout = saved === "grid" ? "grid" : "list";
    } catch (e) {
      browseLayout = "list";
    }
    applyBrowseLayout();
  }

  function saveBrowseLayout() {
    try {
      if (window.localStorage) window.localStorage.setItem("lyrionPanelBrowseLayout", browseLayout);
    } catch (e) {}
  }

  function applyBrowseLayout() {
    var list = $("list");
    if (list) list.className = "list" + (browseLayout === "grid" ? " grid" : "");
    var toggle = $("layoutToggle");
    if (toggle) {
      toggle.innerHTML = iconSvg(browseLayout === "grid" ? "list" : "grid");
      toggle.title = browseLayout === "grid" ? "Show list" : "Show thumbnails";
      toggle.setAttribute("aria-label", toggle.title);
    }
  }

  function toggleBrowseLayout() {
    browseLayout = browseLayout === "grid" ? "list" : "grid";
    saveBrowseLayout();
    applyBrowseLayout();
  }

  function setBrowseLayout(value, persist) {
    browseLayout = value === "grid" ? "grid" : "list";
    if (persist) saveBrowseLayout();
    applyBrowseLayout();
  }

  function setView(name) {
    if (name === "queue") {
      setQueueDrawer(true);
      refreshState(true);
      return;
    }
    if (name === "now") {
      setCover(true);
      return;
    }
    activeView = name || "browse";
    ["browse", "queue", "details"].forEach(function (view) {
      var el = $(view + "View");
      if (el) el.className = "view" + (view === activeView ? " active" : "");
    });
    var tabs = document.querySelectorAll(".panel-tabs .tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].className = "tab" + (tabs[i].getAttribute("data-view") === activeView ? " active" : "");
    }
    setActive("detailsToggle", activeView === "details");
  }

  function setQueueDrawer(open) {
    var drawer = $("queueDrawer");
    if (drawer) drawer.className = "queue-drawer" + (open ? " open" : "");
    setActive("queueToggle", open);
  }

  function setSyncDrawer(open) {
    var drawer = $("syncDrawer");
    if (drawer) drawer.className = "queue-drawer sync-drawer" + (open ? " open" : "");
    setActive("syncToggle", open);
    if (open) renderSyncList();
  }

  function setCover(open) {
    var overlay = $("coverOverlay");
    if (overlay) overlay.className = "cover-overlay" + (open ? " open" : "");
    setActive("nowToggle", open);
    var nowToggle = $("nowToggle");
    if (nowToggle) nowToggle.innerHTML = iconSvg(open ? "close" : "now");
  }

  function isOpen(id) {
    var el = $(id);
    return !!(el && el.className.indexOf(" open") >= 0);
  }

  function toggleQueueDrawer() {
    var open = !isOpen("queueDrawer");
    setQueueDrawer(open);
    if (open) refreshState(true);
  }

  function toggleSyncDrawer() {
    var open = !isOpen("syncDrawer");
    setSyncDrawer(open);
    if (open) refreshState(false);
  }

  function toggleCover() {
    setCover(!isOpen("coverOverlay"));
  }

  function toggleDetails() {
    setView(activeView === "details" ? "browse" : "details");
  }

  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return m + ":" + (s < 10 ? "0" : "") + s;
  }

  function fmtDuration(value) {
    var raw = first(value);
    if (!raw) return "";
    if (raw.indexOf(":") >= 0) return raw;
    return fmtTime(raw);
  }

  function imageUrl(row) {
    return first(row && row.artwork_url, row && row.art, row && row.icon, cfg.defaultArt);
  }

  function isDefaultArt(url) {
    var u = text(url).toLowerCase();
    return !u || u.indexOf("/music/0/cover") >= 0 || u.indexOf("id=0") >= 0;
  }

  function sourceBadgeUrl(payload) {
    var hay = [
      first(payload.np_source, payload.source),
      first(payload.np_path, payload.path, payload.url),
      payload.remoteMeta && first(payload.remoteMeta.source, payload.remoteMeta.url)
    ].join(" ").toLowerCase();
    if (hay.indexOf("spotty") >= 0 || hay.indexOf("spotify") >= 0) return "/panel/assets/badge-spotify.svg";
    if (hay.indexOf("pandora") >= 0 || hay.indexOf("pyrrha") >= 0 || hay.indexOf("fr_pandora") >= 0) return "/panel/assets/badge-pandora.svg";
    return "";
  }

  function currentQueueRow(payload) {
    if (!payload || !Array.isArray(payload.playlist_loop)) return null;
    var idx = parseInt(first(payload.playlist_cur_index, payload["playlist index"], 0), 10) || 0;
    for (var i = 0; i < payload.playlist_loop.length; i++) {
      var row = payload.playlist_loop[i] || {};
      var rowIdx = parseInt(first(row["playlist index"], row.playlist_index, i), 10);
      if (rowIdx === idx) return row;
    }
    return payload.playlist_loop[idx] || payload.playlist_loop[0] || null;
  }

  function normalizeNow(payload) {
    payload = payload || {};
    var out = {};
    Object.keys(payload).forEach(function (key) { out[key] = payload[key]; });
    var row = currentQueueRow(payload);
    if (row) {
      if (!first(out.current_title, out.title, out.remote_title)) out.current_title = first(row.title, row.name);
      if (!first(out.artist, out.trackartist)) out.artist = first(row.artist, row.trackartist);
      if (!first(out.album)) out.album = first(row.album);
      if (!first(out.genre)) out.genre = first(row.genre);
      if (!first(out.duration)) out.duration = first(row.duration);
      if (!first(out.artwork_url, out.artwork_url2)) out.artwork_url = first(row.artwork_url, row.art, row.icon);
      out.remoteMeta = out.remoteMeta || {};
      if (!first(out.remoteMeta.title)) out.remoteMeta.title = first(row.title, row.name);
      if (!first(out.remoteMeta.artist)) out.remoteMeta.artist = first(row.artist, row.trackartist);
      if (!first(out.remoteMeta.album)) out.remoteMeta.album = first(row.album);
      if (!first(out.remoteMeta.artwork_url)) out.remoteMeta.artwork_url = first(row.artwork_url, row.art, row.icon);
    }
    return out;
  }

  function mergeNow(payload) {
    payload = normalizeNow(payload);
    Object.keys(payload).forEach(function (key) {
      var value = payload[key];
      if (value === undefined || value === null) return;
      if (typeof value === "string" && value === "" && key !== "np_station" && key !== "np_path") return;
      nowState[key] = value;
    });
    return nowState;
  }

  function updateNow(payload) {
    if (!payload) return;
    payload = mergeNow(payload);
    var title = first(payload.current_title, payload.title, payload.remote_title, payload.remoteMeta && payload.remoteMeta.title, payload.station, payload.station_name);
    if (!title && text(payload.mode).toLowerCase() === "stop") title = "Stopped";
    if (!title) title = "Loading...";
    var artist = first(payload.artist, payload.trackartist, payload.remoteMeta && payload.remoteMeta.artist);
    var album = first(payload.album, payload.remoteMeta && payload.remoteMeta.album);
    var source = first(payload.np_source, payload.source);
    var station = first(payload.np_station, payload.station, payload.station_name);
    var path = first(payload.np_path, payload.path, payload.url);
    var streamish = /radio|pandora|pyrrha|iheart|tunein|airplay|podcast/i.test(source + " " + path);
    var subParts = streamish ? [station, artist, album] : [artist, album, station];
    var seenParts = {};
    var sub = subParts.filter(function (value) {
      value = text(value);
      if (!value || seenParts[value]) return false;
      seenParts[value] = true;
      return true;
    }).join(" | ");
    var art = first(payload.artwork_url2, payload.artwork_url, payload.remoteMeta && payload.remoteMeta.artwork_url2, payload.remoteMeta && payload.remoteMeta.artwork_url, cfg.defaultArt);
    var vol = first(payload["mixer volume"], payload.mixer_volume, payload.volume);
    var fixed = payload.fixed_volume === true || payload.can_volume === false;
    var canRatePositive = boolish(first(payload.canRatePositive, payload.can_rate_positive, payload.canThumbsUp, payload.remoteMeta && payload.remoteMeta.canRatePositive, payload.remoteMeta && payload.remoteMeta.canThumbsUp));
    var canRateNegative = boolish(first(payload.canRateNegative, payload.can_rate_negative, payload.canThumbsDown, payload.remoteMeta && payload.remoteMeta.canRateNegative, payload.remoteMeta && payload.remoteMeta.canThumbsDown));

    setText("npTitle", title);
    var fallbackSource = /^my music$/i.test(source) ? "" : source;
    setText("npSub", sub || fallbackSource || "");
    setText("bigTitle", title);
    setText("bigMeta", sub || fallbackSource || "");
    setText("coverTitle", title);
    setText("coverMeta", sub || fallbackSource || "");
    var noArt = isDefaultArt(art);
    var img = $("art");
    if (img) img.className = "art" + (noArt ? " no-art" : "");
    if (img && art && img.src !== art) img.src = art;
    var coverImg = $("coverArt");
    if (coverImg) coverImg.className = "cover-art" + (noArt ? " no-art" : "");
    if (coverImg && art && coverImg.src !== art) coverImg.src = art;
    var badge = $("coverBadge");
    if (badge) {
      var badgeUrl = sourceBadgeUrl(payload);
      badge.className = "cover-badge" + (badgeUrl ? "" : " hidden");
      if (badgeUrl && badge.src !== badgeUrl) badge.src = badgeUrl;
    }
    if (art) {
      document.documentElement.style.setProperty("--now-art", "url('" + text(art).replace(/'/g, "%27") + "')");
    }
    var nowWrap = document.querySelector(".now");
    var volWrap = document.querySelector(".volume");
    var slider = $("volume");
    var label = $("volumeLabel");
    if (nowWrap) nowWrap.className = "now" + (fixed ? " fixed-volume" : "");
    if (volWrap) volWrap.className = "volume" + (fixed ? " hidden" : "");
    if (vol !== "") {
      if (slider) {
        if (document.activeElement !== slider) slider.value = parseInt(vol, 10) || 0;
        slider.disabled = !!fixed;
      }
      if (label) label.textContent = fixed ? "Fixed" : ((parseInt(vol, 10) || 0) + "%");
    } else if (label && fixed) {
      label.textContent = "Fixed";
    }
    updateTransportState(payload);
    setButtonEnabled("thumbUp", canRatePositive === true);
    setButtonEnabled("thumbDown", canRateNegative === true);
    ["thumbUp", "thumbDown"].forEach(function (id) {
      var el = $(id);
      if (el) el.className = "icon-btn footer-action rating-action" + ((id === "thumbUp" ? canRatePositive : canRateNegative) === true ? "" : " hidden");
    });
    updateProgress(payload);
    if (Array.isArray(payload.playlist_loop)) renderQueue(payload);
    renderDetails(payload);
  }

  function setText(id, value) {
    var el = $(id);
    if (el) el.textContent = value;
  }

  function rowTitle(row) {
    return first(row.label, row.title, row.name, row.text, "Item");
  }

  function rowSubtitle(row) {
    var sub = first(row.artist, row.album, row.type, row.source, "");
    return /^(node|folder|category)$/i.test(sub) ? "" : sub;
  }

  function rowTrackNumber(row, fallback) {
    var raw = first(row.tracknum, row.track_num, row.trackNumber, row.track, row.index, row["playlist index"], row.playlist_index);
    var n = parseInt(raw, 10);
    if (!isNaN(n) && n > 0 && n < 1000) return String(n);
    if (fallback !== undefined && fallback !== null) return String(fallback + 1);
    return "";
  }

  function isLikelyTrackRow(row) {
    var type = first(row && row.type).toLowerCase();
    var id = first(row && row.id).toLowerCase();
    return type === "track" || type === "song" || !!(row && (row.track_id || row.duration)) || id.indexOf("title:") === 0 || id.indexOf("sptrack:") === 0;
  }

  function rowActionIcon(row) {
    var label = rowTitle(row).toLowerCase();
    var id = first(row && row.id).toLowerCase();
    var hay = label + " " + id;
    if (id === "randomplay" || hay.indexOf("randomplay") >= 0 || (hay.indexOf("random") >= 0 && hay.indexOf("mix") >= 0)) return "";
    if (hay.indexOf("delete") >= 0 || hay.indexOf("remove") >= 0) return "trash";
    if (hay.indexOf("rename") >= 0 || hay.indexOf("edit") >= 0) return "edit";
    if (hay.indexOf("add") >= 0 || hay.indexOf("append") >= 0 || hay.indexOf("play later") >= 0) return "add";
    if (/^(play|play all|play this|play now|load)(\b|$)/.test(label) || hay.indexOf("play all") >= 0) return "play";
    return "";
  }

  function canOpen(row) {
    var id = first(row.id);
    return !!(row.can_open || row.hasitems || row.hasItems || id.indexOf("root:") === 0 || id.indexOf("rootapp:") === 0 || id.indexOf("cmd:") === 0);
  }

  function canPlay(row) {
    return !!(row.canPlayLoad || row.canPlayAdd || row.canPlayInsert || first(row.id).indexOf("act:") === 0 || first(row.id).indexOf("sptrack:") === 0 || first(row.id).indexOf("title:") === 0 || first(row.id).indexOf("album:") === 0 || first(row.id).indexOf("playlist:") === 0);
  }

  function showPlayAction(row) {
    var id = first(row && row.id).toLowerCase();
    var label = rowTitle(row).toLowerCase();
    var type = first(row && row.type).toLowerCase();
    if (!canPlay(row)) return false;
    if (id.indexOf("album:") === 0 || id.indexOf("playlist:") === 0 || id.indexOf("title:") === 0 || id.indexOf("sptrack:") === 0) return true;
    if (row && (row.album_id || row.playlist_id || type === "album" || type === "playlist")) return true;
    if (/^(play|play all|play this|play now|load)(\b|$)/.test(label) || label.indexOf("play all") >= 0) return true;
    return false;
  }

  function renderMenu(msg) {
    currentItems = Array.isArray(msg.items) ? msg.items : [];
    currentTitle = first(msg.title, "Home");
    var atHome = /^home$/i.test(currentTitle);
    currentContextActionRow = atHome ? null : pendingContextActionRow;
    pendingContextActionRow = null;
    setText("crumb", atHome ? "" : currentTitle);
    var back = $("back");
    if (back) back.className = "icon-only" + (atHome ? " hidden" : "");
    var list = $("list");
    if (!list) return;
    applyBrowseLayout();
    var contextualTrackList = !!currentContextActionRow && currentItems.some(isLikelyTrackRow);
    if (contextualTrackList) {
      setBrowseLayout("list", false);
      list.className += " album-track-list";
    }
    list.innerHTML = "";
    if (!currentItems.length) {
      list.appendChild(message("No items."));
      return;
    }
    renderContextActions(list);
    currentItems.forEach(function (row, rowIndex) {
      var item = document.createElement("div");
      item.className = "row";
      if (contextualTrackList && isLikelyTrackRow(row)) item.className += " track-row";
      var hasPlayAction = showPlayAction(row);
      if (hasPlayAction) item.className += " playable-row";
      item.dataset.id = first(row.id);

      var artUrl = imageUrl(row);
      if (isDefaultArt(artUrl)) item.className += " no-art";
      item.style.setProperty("--row-art", "url('" + text(artUrl).replace(/'/g, "%27") + "')");
      var actionIcon = rowActionIcon(row);
      if (actionIcon) {
        item.className += " action-row";
        var ico = document.createElement("div");
        ico.className = "row-icon";
        ico.innerHTML = iconSvg(actionIcon);
        item.appendChild(ico);
      } else if (contextualTrackList && isLikelyTrackRow(row)) {
        var num = document.createElement("div");
        num.className = "row-icon track-number";
        num.textContent = rowTrackNumber(row, rowIndex);
        item.appendChild(num);
      } else {
        var img = document.createElement("img");
        img.alt = "";
        img.src = artUrl;
        item.appendChild(img);
      }

      var body = document.createElement("div");
      var title = document.createElement("div");
      title.className = "row-title";
      title.textContent = rowTitle(row);
      var sub = document.createElement("div");
      sub.className = "row-sub";
      var subtitle = rowSubtitle(row);
      sub.textContent = subtitle;
      if (!subtitle) sub.className = "row-sub empty";
      body.appendChild(title);
      body.appendChild(sub);
      item.appendChild(body);

      var action = document.createElement("button");
      action.className = "row-action";
      if (!hasPlayAction) action.className += " hidden";
      action.title = hasPlayAction ? "Actions" : "Open";
      action.setAttribute("aria-label", action.title);
      action.innerHTML = iconSvg(hasPlayAction ? "play" : "browse");
      action.onclick = function (ev) {
        ev.stopPropagation();
        if (hasPlayAction) openActionSheet(row);
        else playRow(row);
      };
      item.appendChild(action);

      if (contextualTrackList && isLikelyTrackRow(row)) {
        var dur = first(row.duration, row.time);
        var duration = document.createElement("div");
        duration.className = "track-duration" + (dur ? "" : " empty");
        duration.textContent = fmtDuration(dur);
        item.insertBefore(duration, action);
      }

      item.onclick = function () { openRow(row); };
      list.appendChild(item);
    });
  }

  function renderContextActions(list) {
    if (!list || !currentContextActionRow || !showPlayAction(currentContextActionRow)) return;
    var box = document.createElement("div");
    box.className = "context-actions context-hero";
    var art = document.createElement("img");
    art.className = "context-art";
    art.alt = "";
    art.src = imageUrl(currentContextActionRow);
    box.appendChild(art);
    var labelWrap = document.createElement("div");
    labelWrap.className = "context-copy";
    var kicker = document.createElement("div");
    kicker.className = "context-kicker";
    kicker.textContent = currentTitle || "Selection";
    var label = document.createElement("div");
    label.className = "context-action-title";
    label.textContent = rowTitle(currentContextActionRow);
    var sub = document.createElement("div");
    sub.className = "context-action-sub";
    sub.textContent = rowSubtitle(currentContextActionRow) || currentTitle;
    labelWrap.appendChild(kicker);
    labelWrap.appendChild(label);
    labelWrap.appendChild(sub);
    box.appendChild(labelWrap);

    [
      ["play", "play", "Play now"],
      ["playnext", "playnext", "Play next"],
      ["add", "add", "Add to queue"]
    ].forEach(function (spec) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "context-action";
      btn.title = spec[2];
      btn.setAttribute("aria-label", spec[2]);
      btn.innerHTML = iconSvg(spec[1]) + '<span>' + spec[2].replace(" to queue", "") + '</span>';
      if (spec[0] === "play" && currentContextActionRow.canPlayLoad === false) btn.disabled = true;
      if (spec[0] === "playnext" && !(currentContextActionRow.canPlayInsert || currentContextActionRow.canPlayAdd || first(currentContextActionRow.id).match(/^(album|playlist|title|sptrack):/))) btn.disabled = true;
      if (spec[0] === "add" && !(currentContextActionRow.canPlayAdd || first(currentContextActionRow.id).match(/^(album|playlist|title|sptrack):/))) btn.disabled = true;
      btn.onclick = function (ev) {
        ev.stopPropagation();
        if (btn.disabled) return;
        runSpecificRowAction(currentContextActionRow, spec[0]);
      };
      box.appendChild(btn);
    });
    list.appendChild(box);

    var trackCount = currentItems.filter(isLikelyTrackRow).length;
    if (trackCount) {
      var divider = document.createElement("div");
      divider.className = "track-section-head";
      divider.innerHTML = '<span>Tracks</span><b>' + trackCount + '</b>';
      list.appendChild(divider);
    }
  }

  function message(textValue) {
    var el = document.createElement("div");
    el.className = "message";
    el.textContent = textValue;
    return el;
  }

  function renderQueue(payload) {
    var list = $("queueList");
    var drawerList = $("queueDrawerList");
    if (!list && !drawerList) return;
    var rows = Array.isArray(payload.playlist_loop) ? payload.playlist_loop : [];
    if (list) list.innerHTML = "";
    if (drawerList) drawerList.innerHTML = "";
    if (!rows.length) {
      if (list) list.appendChild(message("Queue is empty."));
      if (drawerList) drawerList.appendChild(message("Queue is empty."));
      return;
    }
    var cur = parseInt(first(payload.playlist_cur_index, 0), 10) || 0;
    rows.forEach(function (row, i) {
      row = row || {};
      var rowIndex = parseInt(first(row["playlist index"], row.playlist_index, i), 10);
      var item = document.createElement("div");
      item.className = "row" + (rowIndex === cur ? " now-playing" : "");
      item.dataset.queueIndex = String(rowIndex);
      var img = document.createElement("img");
      img.alt = "";
      img.src = imageUrl(row);
      item.appendChild(img);
      var body = document.createElement("div");
      var title = document.createElement("div");
      title.className = "row-title";
      title.textContent = first(row.title, row.name, "Track");
      var sub = document.createElement("div");
      sub.className = "row-sub";
      sub.textContent = [first(row.artist), first(row.album), first(row.duration) ? fmtTime(row.duration) : ""].filter(Boolean).join(" | ");
      body.appendChild(title);
      body.appendChild(sub);
      item.appendChild(body);
      var action = document.createElement("button");
      action.className = "row-action";
      action.textContent = rowIndex === cur ? "Now" : "Go";
      action.disabled = rowIndex === cur;
      action.onclick = function (ev) {
        ev.stopPropagation();
        transport("queue_goto", [String(rowIndex)]);
      };
      item.onclick = function () { transport("queue_goto", [String(rowIndex)]); };
      item.appendChild(action);
      if (list) list.appendChild(item);
      if (drawerList) drawerList.appendChild(item.cloneNode(true));
    });
    if (drawerList) {
      var drawerRows = drawerList.querySelectorAll(".row");
      for (var j = 0; j < drawerRows.length; j++) {
        (function (rowEl) {
          rowEl.onclick = function () {
            transport("queue_goto", [String(rowEl.getAttribute("data-queue-index") || "0")]);
            setQueueDrawer(false);
          };
          var btn = rowEl.querySelector(".row-action");
          if (btn) btn.onclick = function (ev) {
            ev.stopPropagation();
            rowEl.onclick();
          };
        })(drawerRows[j]);
      }
    }
  }

  function renderDetails(payload) {
    var box = $("details");
    if (!box) return;
    var title = first(payload.current_title, payload.title, payload.remoteMeta && payload.remoteMeta.title, "Now Playing");
    var artist = first(payload.artist, payload.trackartist, payload.remoteMeta && payload.remoteMeta.artist);
    var album = first(payload.album, payload.remoteMeta && payload.remoteMeta.album);
    var station = first(payload.np_station, payload.station, payload.station_name);
    var source = first(payload.np_source, payload.source);
    var genre = first(payload.genre);
    var path = first(payload.np_path, payload.url, payload.path);
    var year = first(payload.year);
    var bitrate = first(payload.bitrate);
    var codec = first(payload.type, payload.codec, payload.content_type);
    var duration = first(payload.duration) ? fmtTime(payload.duration) : "";
    var syncMaster = first(payload.sync_master);
    var syncSlaves = first(payload.sync_slaves);
    var art = first(payload.artwork_url2, payload.artwork_url, payload.remoteMeta && payload.remoteMeta.artwork_url2, payload.remoteMeta && payload.remoteMeta.artwork_url, cfg.defaultArt);
    box.innerHTML = "";
    var primary = detailSection("Track", title, [
      artist ? ("Artist: " + artist) : "",
      album ? ("Album: " + album) : "",
      genre ? ("Genre: " + genre) : "",
      year ? ("Year: " + year) : "",
      duration ? ("Duration: " + duration) : ""
    ]);
    box.appendChild(primary);
    var albumSection = detailSection("Album", album || title, [
      title,
      artist ? ("By " + artist) : "",
      station ? ("Station: " + station) : "",
      source ? ("Source: " + source) : ""
    ]);
    var img = document.createElement("img");
    img.className = "detail-art";
    img.src = art;
    img.alt = "";
    albumSection.insertBefore(img, albumSection.children[1] || null);
    box.appendChild(albumSection);
    box.appendChild(detailSection("Playback", source || "Player", [
      bitrate ? ("Bitrate: " + bitrate) : "",
      codec ? ("Format: " + codec) : "",
      syncMaster ? ("Sync master: " + syncMaster) : "",
      syncSlaves ? ("Synced players: " + syncSlaves) : "",
      path ? ("Path: " + path) : ""
    ]));
  }

  function detailSection(label, heading, lines) {
    var section = document.createElement("section");
    section.className = "detail-section";
    var top = document.createElement("div");
    top.className = "detail-label";
    top.textContent = label;
    var h = document.createElement("div");
    h.className = "detail-heading";
    h.textContent = heading || label;
    section.appendChild(top);
    section.appendChild(h);
    (lines || []).forEach(function (lineText) {
      if (!lineText) return;
      var p = document.createElement("p");
      p.className = "detail-value";
      p.textContent = lineText;
      section.appendChild(p);
    });
    return section;
  }


  function activateRow(row) {
    if (canOpen(row)) openRow(row);
    else playRow(row);
  }

  function openRow(row) {
    var id = first(row.id);
    if (!id) return;
    if (canOpen(row)) {
      pendingContextActionRow = showPlayAction(row) ? row : null;
      if (pendingContextActionRow) setBrowseLayout("list", false);
      send({ t: "menu_select", playerid: playerid, item_id: id, limit: 80 });
    } else if (canPlay(row)) {
      openActionSheet(row);
    } else {
      playRow(row);
    }
  }

  function playRow(row) {
    var id = first(row && row.id);
    if (!id) return;
    if (canPlay(row)) {
      send({ t: "menu_action", playerid: playerid, item_id: id, action: "play" });
      scheduleStatusRefresh();
    } else {
      send({ t: "menu_select", playerid: playerid, item_id: id, limit: 80 });
    }
  }

  function openActionSheet(row) {
    if (!row || !canPlay(row)) return;
    actionSheetRow = row;
    setText("actionTitle", rowTitle(row));
    setButtonEnabled("actionPlay", row.canPlayLoad !== false);
    setButtonEnabled("actionNext", !!(row.canPlayInsert || row.canPlayAdd || first(row.id).indexOf("album:") === 0 || first(row.id).indexOf("playlist:") === 0 || first(row.id).indexOf("title:") === 0 || first(row.id).indexOf("sptrack:") === 0));
    setButtonEnabled("actionAdd", !!(row.canPlayAdd || first(row.id).indexOf("album:") === 0 || first(row.id).indexOf("playlist:") === 0 || first(row.id).indexOf("title:") === 0 || first(row.id).indexOf("sptrack:") === 0));
    var sheet = $("actionSheet");
    if (sheet) sheet.className = "action-sheet open";
  }

  function closeActionSheet() {
    actionSheetRow = null;
    var sheet = $("actionSheet");
    if (sheet) sheet.className = "action-sheet";
  }

  function runRowAction(action) {
    runSpecificRowAction(actionSheetRow, action);
    closeActionSheet();
  }

  function runSpecificRowAction(row, action) {
    if (!row) return;
    var id = first(row.id);
    if (!id) return;
    send({ t: "menu_action", playerid: playerid, item_id: id, action: action });
    scheduleStatusRefresh();
  }

  function doSearch() {
    var q = first($("searchBox") && $("searchBox").value);
    if (!q) return;
    pendingSearch = q;
    var row = null;
    for (var i = 0; i < currentItems.length; i++) {
      var candidate = currentItems[i];
      var label = rowTitle(candidate).toLowerCase();
      if (candidate.can_search || label === "search" || label.indexOf("search") >= 0) {
        row = candidate;
        break;
      }
    }
    send({
      t: "menu_select",
      playerid: playerid,
      item_id: row ? first(row.id) : "cmd:search",
      search: q,
      query: q,
      limit: 80
    });
  }

  function transport(name, args) {
    if (name === "playpause") {
      name = "playpause";
    }
    if (!playerid) return;
    if (name === "volume" && nowState.fixed_volume === true) return;
    setStatus("Sending", true);
    api("/api/panel/control", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ playerid: playerid, name: name, args: args || [] })
    }).then(function (body) {
      ensurePlayer(body.playerid);
      updateNow(body.status || {});
      if (body.queue) updateNow(body.queue);
      setStatus("Connected", true);
    }).catch(function (err) {
      setStatus(err.message || "Control error", false);
      scheduleStatusRefresh();
    });
  }

  function scheduleStatusRefresh() {
    clearTimeout(statusTimer);
    statusTimer = setTimeout(function () {
      refreshState(false);
    }, 450);
  }

  function refreshState(queue) {
    var url = "/api/panel/state" + (playerid ? ("?playerid=" + encodeURIComponent(playerid)) : "") + (queue ? (playerid ? "&" : "?") + "queue=1" : "");
    return api(url).then(function (body) {
      ensurePlayer(body.playerid);
      knownPlayers = Array.isArray(body.players) ? body.players : knownPlayers;
      updateNow(body.status || {});
      if (body.queue) updateNow(body.queue);
      renderSyncList();
      return body;
    }).catch(function (err) {
      setStatus(err.message || "State error", false);
    });
  }

  function connect() {
    if (shuttingDown) return;
    var serial = ++wsSerial;
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = 0;
    }
    if (cfg.enabled === false) {
      setStatus("Web disabled", false);
      return;
    }
    if (!playerid) {
      setStatus("Finding player", false);
    }
    var proto = location.protocol === "https:" ? "wss:" : "ws:";
    var panelSlot = "main";
    try {
      var params = new URLSearchParams(location.search);
      panelSlot = params.get("panel_slot") || params.get("slot") || panelSlot;
    } catch (e) {}
    var wsQuery = "?client=panel&slot=" + encodeURIComponent(panelSlot) + (playerid ? ("&playerid=" + encodeURIComponent(playerid)) : "");
    ws = new WebSocket(proto + "//" + location.host + "/rti" + wsQuery);
    ws.onopen = function () {
      if (serial !== wsSerial) return;
      connected = true;
      setStatus("Connected", true);
      if (playerid) {
        send({ t: "cometd_subscribe_status", playerid: playerid });
        send({ t: "menu_home", playerid: playerid, limit: 80 });
        refreshState(true);
      } else {
        refreshState(true).then(function () {
          if (playerid) {
            send({ t: "cometd_subscribe_status", playerid: playerid });
            send({ t: "menu_home", playerid: playerid, limit: 80 });
          } else {
            send({ t: "get_players" });
          }
        });
      }
    };
    ws.onclose = function (event) {
      if (serial !== wsSerial) return;
      connected = false;
      setStatus("Disconnected", false);
      if (event && event.code === 4001) {
        shuttingDown = true;
        return;
      }
      if (!shuttingDown) {
        reconnectTimer = setTimeout(connect, 1400);
      }
    };
    ws.onerror = function () {
      if (serial !== wsSerial) return;
      setStatus("Connection error", false);
    };
    ws.onmessage = function (event) {
      if (serial !== wsSerial) return;
      var lines = text(event.data).split(/\r?\n/);
      lines.forEach(function (line) {
        if (!line.trim()) return;
        var msg;
        try { msg = JSON.parse(line); } catch (e) { return; }
        try {
          if (msg.t === "players" && !playerid) {
            var players = Array.isArray(msg.players) ? msg.players : [];
            for (var i = 0; i < players.length; i++) {
              if (String(players[i].connected) === "1" && setPlayer(players[i].playerid)) break;
            }
            if (playerid) {
              send({ t: "cometd_subscribe_status", playerid: playerid });
              send({ t: "menu_home", playerid: playerid, limit: 80 });
              refreshState(true);
            } else {
              setStatus("No players", false);
            }
          }
          if (msg.t === "push" && samePlayer(msg.playerid)) updateNow(msg.payload || {});
          if (msg.t === "status" && samePlayer(msg.playerid)) updateNow(msg.status || msg.payload || {});
          if (msg.t === "queue" && samePlayer(msg.playerid)) updateNow(msg.payload || {});
          if (msg.t === "menu" && msg.ok !== false) renderMenu(msg);
          if (msg.t === "err") setStatus(first(msg.error, "Error"), false);
          if (msg.t === "ack" && connected) setStatus("Connected", true);
        } catch (e) {
          setStatus("Panel render error", false);
          if (window.console && console.error) console.error("Lyrion panel message error", e, msg);
        }
      });
    };
  }

  function cleanupPanel() {
    shuttingDown = true;
    wsSerial++;
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = 0;
    }
    if (statusTimer) {
      clearTimeout(statusTimer);
      statusTimer = 0;
    }
    if (volumeTimer) {
      clearTimeout(volumeTimer);
      volumeTimer = 0;
    }
    if (progressTimer) {
      clearInterval(progressTimer);
      progressTimer = 0;
    }
    if (ws) {
      try {
        ws.onopen = ws.onclose = ws.onerror = ws.onmessage = null;
        if (ws.readyState === 0 || ws.readyState === 1) {
          ws.close(1000, "panel closing");
        }
      } catch (e) {}
      ws = null;
    }
  }

  window.addEventListener("pagehide", cleanupPanel);
  window.addEventListener("beforeunload", cleanupPanel);

  function wire() {
    document.documentElement.style.setProperty("--bg", cfg.bg || "#050607");
    document.documentElement.style.setProperty("--content-bg", cfg.contentBg || "#101214");
    document.documentElement.style.setProperty("--accent", cfg.accent || "#b7ff8a");
    document.documentElement.style.setProperty("--accent-rgb", hexToRgb(cfg.accent || "#b7ff8a"));
    var back = $("back");
    var home = $("home");
    var search = $("searchButton");
    var searchToggle = $("searchToggle");
    var searchBox = $("searchBox");
    var layoutToggle = $("layoutToggle");
    var detailsToggle = $("detailsToggle");
    var nowToggle = $("nowToggle");
    if (back) back.onclick = function () { send({ t: "menu_nav", playerid: playerid, cmd: "back" }); };
    if (home) home.onclick = function () { send({ t: "menu_home", playerid: playerid, limit: 80 }); };
    if (search) search.onclick = doSearch;
    if (searchToggle) searchToggle.onclick = function () {
      var row = document.querySelector(".search");
      if (!row) return;
      var open = row.className.indexOf(" open") < 0;
      row.className = "search" + (open ? " open" : "");
      if (open && searchBox) setTimeout(function () { searchBox.focus(); }, 40);
    };
    if (searchBox) searchBox.onkeydown = function (ev) { if (ev.keyCode === 13) doSearch(); };
    if (layoutToggle) layoutToggle.onclick = toggleBrowseLayout;
    if (home) home.innerHTML = iconSvg("home");
    if (back) back.innerHTML = iconSvg("back");
    if (search) search.innerHTML = iconSvg("search");
    if (searchToggle) searchToggle.innerHTML = iconSvg("search");
    if (detailsToggle) {
      detailsToggle.innerHTML = iconSvg("info");
      detailsToggle.onclick = toggleDetails;
    }
    if (nowToggle) {
      nowToggle.innerHTML = iconSvg("now");
      nowToggle.onclick = toggleCover;
    }
    setTransportIcon("thumbUp", "thumbUp");
    setTransportIcon("thumbDown", "thumbDown");

    [
      ["prev", "prev"],
      ["playPause", "playpause"],
      ["next", "next"],
    ].forEach(function (pair) {
      var el = $(pair[0]);
      if (el) el.onclick = function () { transport(pair[1], []); };
    });
    var volume = $("volume");
    if (volume) {
      volume.oninput = function () {
        setText("volumeLabel", volume.value + "%");
        clearTimeout(volumeTimer);
        volumeTimer = setTimeout(function () {
          transport("volume", [String(volume.value)]);
        }, 180);
      };
    }
    var tabs = document.querySelectorAll(".panel-tabs .tab");
    for (var i = 0; i < tabs.length; i++) {
      var viewName = tabs[i].getAttribute("data-view");
      tabs[i].innerHTML = iconSvg(viewName === "details" ? "info" : viewName);
      tabs[i].onclick = function () { setView(this.getAttribute("data-view")); };
    }
    var art = $("art");
    if (art) art.onclick = function () { setCover(true); };
    var queueToggle = $("queueToggle");
    if (queueToggle) {
      queueToggle.innerHTML = iconSvg("queue");
      queueToggle.onclick = toggleQueueDrawer;
    }
    var syncToggle = $("syncToggle");
    if (syncToggle) {
      syncToggle.innerHTML = iconSvg("sync");
      syncToggle.onclick = toggleSyncDrawer;
    }
    var thumbUp = $("thumbUp");
    if (thumbUp) thumbUp.onclick = function () { transport("rate", ["positive"]); };
    var thumbDown = $("thumbDown");
    if (thumbDown) thumbDown.onclick = function () { transport("rate", ["negative"]); };
    var coverClose = $("coverClose");
    if (coverClose) {
      coverClose.innerHTML = iconSvg("close");
      coverClose.onclick = function () { setCover(false); };
    }
    var actionPlay = $("actionPlay");
    if (actionPlay) actionPlay.onclick = function () { runRowAction("play"); };
    var actionNext = $("actionNext");
    if (actionNext) actionNext.onclick = function () { runRowAction("playnext"); };
    var actionAdd = $("actionAdd");
    if (actionAdd) actionAdd.onclick = function () { runRowAction("add"); };
    var actionCancel = $("actionCancel");
    if (actionCancel) actionCancel.onclick = closeActionSheet;
    var actionSheet = $("actionSheet");
    if (actionSheet) actionSheet.onclick = function (ev) {
      if (ev.target === actionSheet) closeActionSheet();
    };
    var queueClose = $("queueClose");
    if (queueClose) {
      queueClose.innerHTML = iconSvg("close");
      queueClose.onclick = function () { setQueueDrawer(false); };
    }
    var syncAll = $("syncAll");
    if (syncAll) syncAll.onclick = function () {
      var action = syncAll.getAttribute("data-action") || "all";
      transport("sync_all", [action]);
      setTimeout(function () { refreshState(false); }, 700);
    };
    [
      ["coverPrev", "prev"],
      ["coverPlayPause", "playpause"],
      ["coverNext", "next"]
    ].forEach(function (pair) {
      var el = $(pair[0]);
      if (el) el.onclick = function () { transport(pair[1], []); };
    });
    document.addEventListener("touchstart", function (ev) {
      if (!ev.touches || !ev.touches.length) return;
      touchStartX = ev.touches[0].clientX;
      touchStartY = ev.touches[0].clientY;
    }, { passive: true });
    document.addEventListener("touchend", function (ev) {
      if (!ev.changedTouches || !ev.changedTouches.length) return;
      var dx = ev.changedTouches[0].clientX - touchStartX;
      var dy = ev.changedTouches[0].clientY - touchStartY;
      if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
      if (touchStartX < 90 && dx > 80) {
        setSyncDrawer(true);
        refreshState(false);
      } else if (isOpen("syncDrawer") && dx < -80) {
        setSyncDrawer(false);
      } else if (touchStartX > window.innerWidth - 90 && dx < -80) {
        setQueueDrawer(true);
        refreshState(true);
      } else if (isOpen("queueDrawer") && dx > 80) {
        setQueueDrawer(false);
      }
      touchStartX = 0;
      touchStartY = 0;
    }, { passive: true });
    document.addEventListener("pointerdown", function (ev) {
      pointerStartX = ev.clientX;
      pointerStartY = ev.clientY;
    });
    document.addEventListener("pointerup", function (ev) {
      if (!pointerStartX) return;
      var dx = ev.clientX - pointerStartX;
      var dy = ev.clientY - pointerStartY;
      if (Math.abs(dx) >= 70 && Math.abs(dx) > Math.abs(dy) * 1.4) {
        if (pointerStartX < 90 && dx > 80) {
          setSyncDrawer(true);
          refreshState(false);
        } else if (isOpen("syncDrawer") && dx < -80) {
          setSyncDrawer(false);
        } else if (pointerStartX > window.innerWidth - 90 && dx < -80) {
          setQueueDrawer(true);
          refreshState(true);
        } else if (isOpen("queueDrawer") && dx > 80) {
          setQueueDrawer(false);
        }
      }
      pointerStartX = 0;
      pointerStartY = 0;
    });
  }

  function renderSyncList() {
    var list = $("syncList");
    if (!list) return;
    list.innerHTML = "";
    if (!playerid) {
      list.appendChild(message("No active player."));
      return;
    }
    var currentMaster = text(nowState.sync_master).toLowerCase();
    var currentSlaves = text(nowState.sync_slaves).toLowerCase().split(",").map(function (v) { return v.trim(); }).filter(Boolean);
    var rows = (knownPlayers || []).filter(function (p) {
      return text(p.playerid).toLowerCase() !== playerid && String(p.connected) !== "0";
    });
    var syncAll = $("syncAll");
    if (!rows.length) {
      if (syncAll) {
        syncAll.textContent = "Sync all";
        syncAll.setAttribute("data-action", "all");
      }
      list.appendChild(message("No other connected players."));
      return;
    }
    var allSynced = rows.every(function (p) {
      var pid = text(p.playerid).toLowerCase();
      return currentMaster === pid || currentSlaves.indexOf(pid) >= 0;
    });
    if (syncAll) {
      syncAll.textContent = allSynced ? "Unsync all" : "Sync all";
      syncAll.setAttribute("data-action", allSynced ? "unsync" : "all");
    }
    rows.forEach(function (p) {
      var pid = text(p.playerid).toLowerCase();
      var synced = currentMaster === pid || currentSlaves.indexOf(pid) >= 0;
      var item = document.createElement("div");
      item.className = "row" + (synced ? " now-playing" : "");
      var img = document.createElement("img");
      img.alt = "";
      img.src = cfg.defaultArt;
      item.appendChild(img);
      var body = document.createElement("div");
      var title = document.createElement("div");
      title.className = "row-title";
      title.textContent = first(p.name, pid);
      var sub = document.createElement("div");
      sub.className = "row-sub";
      sub.textContent = currentMaster === pid ? "Current player follows this player" : (synced ? "Follows current player" : "Tap to sync with current player");
      body.appendChild(title);
      body.appendChild(sub);
      item.appendChild(body);
      var action = document.createElement("button");
      action.className = "row-action";
      action.textContent = synced ? "Unsync" : "Sync";
      action.onclick = function (ev) {
        if (ev) ev.stopPropagation();
        transport("sync_toggle", [pid]);
        setTimeout(function () { refreshState(false); }, 650);
      };
      item.onclick = function () { action.onclick(); };
      item.appendChild(action);
      list.appendChild(item);
    });
  }

  window.addEventListener("load", function () {
    document.body.className = mode + (cfg.cardArt ? " card-art" : "");
    wire();
    loadBrowseLayout();
    setTransportIcon("prev", "prev");
    setTransportIcon("next", "next");
    setTransportIcon("playPause", "play");
    setTransportIcon("coverPrev", "prev");
    setTransportIcon("coverNext", "next");
    setTransportIcon("coverPlayPause", "play");
    setView("browse");
    progressTimer = setInterval(tickProgress, 1000);
    connect();
  });
})();
