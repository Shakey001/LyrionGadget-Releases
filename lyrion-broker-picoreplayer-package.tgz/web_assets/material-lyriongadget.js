(function () {
  "use strict";

  function ready() {
    return window.bus && window.bus.$emit && window.bus.$store && window.bus.$store.state;
  }

  function queryFlag(name) {
    try {
      var value = new URLSearchParams(window.location.search).get(name);
      return value === "1" || value === "true" || value === "yes";
    } catch (e) {
      return false;
    }
  }

  var installedMode = "__LYRION_MATERIAL_MODE__";
  if (installedMode.indexOf("__") === 0) {
    installedMode = "user";
  }
  installedMode = String(installedMode || "user").toLowerCase();
  var appVersion = "__LYRION_APP_VERSION__";
  if (appVersion.indexOf("__") === 0) {
    appVersion = String(Date.now());
  }
  var adminMode = queryFlag("admin") || installedMode === "installer";
  var hideServerItemsQueued = false;
  var managedTimers = [];

  function managedTimeout(fn, delay) {
    var timer = window.setTimeout(function () {
      for (var i = managedTimers.length - 1; i >= 0; i--) {
        if (managedTimers[i] === timer) {
          managedTimers.splice(i, 1);
          break;
        }
      }
      fn();
    }, delay);
    managedTimers.push(timer);
    return timer;
  }

  function cleanupMaterialLayer() {
    for (var i = 0; i < managedTimers.length; i++) {
      window.clearTimeout(managedTimers[i]);
    }
    managedTimers = [];
    hideServerItemsQueued = false;
  }

  window.addEventListener("pagehide", cleanupMaterialLayer);
  window.addEventListener("beforeunload", cleanupMaterialLayer);
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      cleanupMaterialLayer();
    }
  });

  function currentPlayer() {
    try {
      var state = window.bus.$store.state;
      if (state.player && state.player.id) {
        return state.player;
      }
      var stored = window.localStorage ? window.localStorage.getItem("player") : "";
      var players = state.players || [];
      for (var i = 0; i < players.length; i++) {
        if (players[i].id === stored || players[i].name === stored) {
          return players[i];
        }
      }
      return players.length ? players[0] : null;
    } catch (e) {
      return null;
    }
  }

  function rpc(playerId, command) {
    return fetch("/jsonrpc.js", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        id: Date.now(),
        method: "slim.request",
        params: [playerId || "", command]
      })
    }).then(function (response) {
      if (!response.ok) {
        throw new Error("HTTP " + response.status);
      }
      return response.json();
    }).then(function (data) {
      return data && data.result ? data.result : {};
    });
  }

  function ensureSyncDrawer() {
    var existing = document.getElementById("lyrion-gadget-sync-drawer");
    if (existing) {
      return existing;
    }
    var drawer = document.createElement("div");
    drawer.id = "lyrion-gadget-sync-drawer";
    drawer.className = "lyrion-gadget-sync-drawer";
    drawer.innerHTML = [
      '<div class="lyrion-gadget-sync-head">',
      '  <span>Synchronize</span>',
      '  <button type="button" id="lyrion-gadget-sync-close" aria-label="Close"><i class="material-icons">close</i></button>',
      '</div>',
      '<div id="lyrion-gadget-sync-body" class="lyrion-gadget-sync-body">Loading...</div>',
      '<div class="lyrion-gadget-sync-actions">',
      '  <button type="button" id="lyrion-gadget-sync-all">Sync All</button>',
      '  <button type="button" id="lyrion-gadget-sync-apply">Apply</button>',
      '</div>'
    ].join("");
    document.body.appendChild(drawer);
    document.getElementById("lyrion-gadget-sync-close").addEventListener("click", function () {
      drawer.classList.remove("open");
    });
    document.getElementById("lyrion-gadget-sync-all").addEventListener("click", function () {
      var boxes = drawer.querySelectorAll("input[type='checkbox']");
      var anyUnchecked = false;
      for (var i = 0; i < boxes.length; i++) {
        if (!boxes[i].checked) {
          anyUnchecked = true;
          break;
        }
      }
      for (var b = 0; b < boxes.length; b++) {
        boxes[b].checked = anyUnchecked;
      }
      updateSyncAllLabel(drawer);
    });
    document.getElementById("lyrion-gadget-sync-body").addEventListener("change", function () {
      updateSyncAllLabel(drawer);
    });
    document.getElementById("lyrion-gadget-sync-apply").addEventListener("click", applySyncDrawer);
    return drawer;
  }

  function updateSyncAllLabel(drawer) {
    var button = document.getElementById("lyrion-gadget-sync-all");
    if (!button) {
      return;
    }
    var boxes = drawer.querySelectorAll("input[type='checkbox']");
    if (!boxes.length) {
      button.textContent = "Sync All";
      return;
    }
    var allChecked = true;
    for (var i = 0; i < boxes.length; i++) {
      if (!boxes[i].checked) {
        allChecked = false;
        break;
      }
    }
    button.textContent = allChecked ? "Unsync All" : "Sync All";
  }

  function currentPlayerId() {
    var player = currentPlayer();
    if (player && player.id) {
      return player.id;
    }
    try {
      return new URLSearchParams(window.location.search).get("player") || "";
    } catch (e) {
      return "";
    }
  }

  function renderSyncDrawer(drawer, playerId, players, synced) {
    var body = document.getElementById("lyrion-gadget-sync-body");
    var otherPlayers = [];
    for (var i = 0; i < players.length; i++) {
      var p = players[i];
      var id = (p.playerid || p.id || "").toLowerCase();
      if (id && id !== playerId.toLowerCase() && !p.isgroup) {
        otherPlayers.push({
          id: id,
          name: p.name || p.player_name || id,
          checked: synced.indexOf(id) >= 0
        });
      }
    }
    if (!otherPlayers.length) {
      body.innerHTML = '<div class="lyrion-gadget-sync-empty">No other players found.</div>';
      updateSyncAllLabel(drawer);
      return;
    }
    body.innerHTML = otherPlayers.map(function (p) {
      return '<label class="lyrion-gadget-sync-row"><input type="checkbox" value="' +
        p.id.replace(/"/g, "&quot;") + '"' + (p.checked ? " checked" : "") +
        '><span>' + p.name.replace(/&/g, "&amp;").replace(/</g, "&lt;") + '</span></label>';
    }).join("");
    updateSyncAllLabel(drawer);
  }

  function openSync(forceOpen) {
    var playerId = currentPlayerId();
    if (!playerId) {
      return;
    }
    var drawer = ensureSyncDrawer();
    var body = document.getElementById("lyrion-gadget-sync-body");
    drawer.dataset.player = playerId;
    var wasOpen = drawer.classList.contains("open");
    if (forceOpen) {
      drawer.classList.add("open");
    } else {
      drawer.classList.toggle("open");
    }
    if (!drawer.classList.contains("open")) {
      return;
    }
    if (forceOpen && wasOpen) {
      return;
    }
    body.textContent = "Loading...";
    Promise.all([
      rpc("", ["players", 0, 999]),
      rpc(playerId, ["sync", "?"])
    ]).then(function (results) {
      var players = results[0].players_loop || [];
      var syncText = results[1]._sync || "";
      var synced = syncText && syncText !== "-" ? syncText.toLowerCase().split(",") : [];
      renderSyncDrawer(drawer, playerId, players, synced);
    }).catch(function (error) {
      body.textContent = "Sync unavailable: " + error.message;
    });
  }

  function closeSyncDrawer() {
    var drawer = document.getElementById("lyrion-gadget-sync-drawer");
    if (drawer) {
      drawer.classList.remove("open");
    }
  }

  function closeMaterialMenuDrawer() {
    if (adminMode) {
      return;
    }
    try {
      var state = window.bus && window.bus.$store && window.bus.$store.state;
      if (state) {
        if (Object.prototype.hasOwnProperty.call(state, "drawer")) state.drawer = false;
        if (Object.prototype.hasOwnProperty.call(state, "navDrawer")) state.navDrawer = false;
        if (Object.prototype.hasOwnProperty.call(state, "navigationDrawer")) state.navigationDrawer = false;
      }
    } catch (e) {}
    var drawers = document.querySelectorAll(".v-navigation-drawer, aside[class*='navigation-drawer'], nav[class*='navigation-drawer']");
    for (var i = 0; i < drawers.length; i++) {
      var drawer = drawers[i];
      if (drawer.id === "lyrion-gadget-sync-drawer") {
        continue;
      }
      drawer.classList.remove("v-navigation-drawer--open", "v-navigation-drawer--is-mobile", "v-navigation-drawer--temporary");
      drawer.setAttribute("aria-hidden", "true");
      drawer.style.transform = "translateX(-110%)";
      drawer.style.visibility = "hidden";
      drawer.style.pointerEvents = "none";
    }
  }

  function isMaterialControl(target) {
    if (!target || !target.closest) {
      return false;
    }
    return !!target.closest([
      "#back-button",
      "#home-button",
      ".back-button",
      ".toolbar-button",
      ".v-btn",
      "button",
      "a",
      "[role='button']",
      "input",
      "select",
      "textarea"
    ].join(","));
  }

  function applySyncDrawer() {
    var drawer = document.getElementById("lyrion-gadget-sync-drawer");
    if (!drawer || !drawer.dataset.player) {
      return;
    }
    var playerId = drawer.dataset.player;
    var body = document.getElementById("lyrion-gadget-sync-body");
    var boxes = drawer.querySelectorAll("input[type='checkbox']");
    var commands = [function () { return rpc(playerId, ["sync", "-"]); }];
    for (var i = 0; i < boxes.length; i++) {
      if (boxes[i].checked) {
        (function (target) {
          commands.push(function () { return rpc(playerId, ["sync", target]); });
        })(boxes[i].value);
      }
    }
    body.textContent = "Applying...";
    commands.reduce(function (promise, commandFn) {
      return promise.then(commandFn);
    }, Promise.resolve()).then(function () {
      body.textContent = "Sync updated.";
      managedTimeout(function () {
        drawer.classList.remove("open");
      }, 500);
      if (ready()) {
        window.bus.$emit("refreshStatus", playerId);
      }
    }).catch(function (error) {
      body.textContent = "Sync failed: " + error.message;
    });
  }

  function addSyncButton() {
    if (document.getElementById("lyrion-gadget-sync-btn")) {
      return true;
    }
    if (adminMode) {
      return true;
    }

    var button = document.createElement("button");
    button.id = "lyrion-gadget-sync-btn";
    button.type = "button";
    button.className = "lyrion-gadget-sync-float";
    button.title = "Synchronize players";
    button.setAttribute("aria-label", "Synchronize players");
    button.innerHTML = '<i aria-hidden="true" class="v-icon material-icons theme--dark">link</i>';
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      openSync();
    });

    document.body.appendChild(button);
    return true;
  }

  function lockHeaderDrawer() {
    if (adminMode || window.__lyrionGadgetHeaderLocked) {
      return;
    }
    window.__lyrionGadgetHeaderLocked = true;
    document.addEventListener("click", function (event) {
      var sync = event.target && event.target.closest ? event.target.closest("#lyrion-gadget-sync-btn") : null;
      if (sync) {
        return;
      }
      var headerSelector = event.target && event.target.closest ? event.target.closest("#main-toolbar .navdrawer-selector") : null;
      var headerMenu = event.target && event.target.closest ? event.target.closest("#main-toolbar [aria-label='Main Menu']") : null;
      if (headerSelector || headerMenu) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      }
    }, true);
    document.addEventListener("contextmenu", function (event) {
      var headerSelector = event.target && event.target.closest ? event.target.closest("#main-toolbar .navdrawer-selector") : null;
      if (headerSelector) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      }
    }, true);
  }

  function installLockedSwipeGuard() {
    if (adminMode || window.__lyrionGadgetSwipeGuarded) {
      return;
    }
    window.__lyrionGadgetSwipeGuarded = true;
    var edgeTouch = null;
    var drawerTouch = null;
    var opened = false;

    document.addEventListener("touchstart", function (event) {
      var syncButton = event.target && event.target.closest ? event.target.closest("#lyrion-gadget-sync-btn") : null;
      if (syncButton) {
        edgeTouch = null;
        drawerTouch = null;
        opened = false;
        return;
      }
      var touch = event.touches && event.touches[0];
      if (!touch) {
        edgeTouch = null;
        drawerTouch = null;
        return;
      }
      if (isMaterialControl(event.target)) {
        edgeTouch = null;
        drawerTouch = null;
        opened = false;
        return;
      }
      var drawer = event.target && event.target.closest ? event.target.closest("#lyrion-gadget-sync-drawer") : null;
      if (drawer && drawer.classList.contains("open")) {
        edgeTouch = null;
        drawerTouch = { x: touch.clientX, y: touch.clientY };
        opened = false;
        return;
      }
      drawerTouch = null;
      if (touch.clientX <= 84) {
        edgeTouch = { x: touch.clientX, y: touch.clientY, active: false };
        opened = false;
        closeMaterialMenuDrawer();
        return;
      }
      edgeTouch = null;
      opened = false;
    }, { capture: true, passive: false });

    document.addEventListener("touchmove", function (event) {
      var touch = event.touches && event.touches[0];
      if (!touch) {
        return;
      }
      if (drawerTouch) {
        var drawerDx = touch.clientX - drawerTouch.x;
        var drawerDy = Math.abs(touch.clientY - drawerTouch.y);
        if (drawerDx < -44 && drawerDy < 64) {
          if (event.cancelable) {
            event.preventDefault();
          }
          event.stopPropagation();
          event.stopImmediatePropagation();
          closeSyncDrawer();
          drawerTouch = null;
        }
        return;
      }
      if (!edgeTouch) {
        return;
      }
      var dx = touch.clientX - edgeTouch.x;
      var dy = Math.abs(touch.clientY - edgeTouch.y);
      if (dx < -8 || dy > 80) {
        edgeTouch = null;
        return;
      }
      if (!edgeTouch.active && dx < 30) {
        return;
      }
      edgeTouch.active = true;
      if (event.cancelable) {
        event.preventDefault();
      }
      event.stopPropagation();
      event.stopImmediatePropagation();
      closeMaterialMenuDrawer();
      if (!opened && dx > 34 && dy < 72) {
        opened = true;
        openSync(true);
      }
    }, { capture: true, passive: false });

    document.addEventListener("touchend", function () {
      edgeTouch = null;
      drawerTouch = null;
      opened = false;
    }, true);
    document.addEventListener("touchcancel", function () {
      edgeTouch = null;
      drawerTouch = null;
      opened = false;
    }, true);

    document.addEventListener("pointerdown", function (event) {
      if (event.target && event.target.closest && event.target.closest("#lyrion-gadget-sync-btn")) {
        return;
      }
      if (isMaterialControl(event.target)) {
        return;
      }
      if (event.clientX <= 84) {
        closeMaterialMenuDrawer();
      }
    }, true);
    document.addEventListener("pointermove", function (event) {
      if (event.clientX <= 150) {
        closeMaterialMenuDrawer();
      }
    }, true);
  }

  function watchFixedVolume() {
    if (adminMode || !ready() || window.__lyrionGadgetFixedVolumeWatched) {
      return;
    }
    window.__lyrionGadgetFixedVolumeWatched = true;
    window.bus.$on("playerStatus", function (playerStatus) {
      var dvc = playerStatus && typeof playerStatus.dvc !== "undefined" ? Number(playerStatus.dvc) : 0;
      document.body.classList.toggle("lyrion-gadget-fixed-volume", dvc === 1);
    });
  }

  function hideServerItems() {
    if (adminMode) {
      return;
    }
    var blocked = [
      "settings",
      "server settings",
      "interface settings",
      "player settings",
      "application settings",
      "manage players",
      "configuration",
      "extra settings",
      "save as default",
      "revert to default",
      "configure player list",
      "show all players",
      "switch user",
      "transfer playback"
    ];
    var nodes = document.querySelectorAll(".lms-list-item, .image-grid-item, .image-grid-text, .v-list__tile, .v-list-tile, .v-list__tile__content, .v-list__tile__title, .v-list__tile__sub-title, .v-list-tile-title, .v-btn, a, .link-item, .menu-shortcut");
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (node.id === "lyrion-gadget-sync-btn" || node.closest("#lyrion-gadget-sync-btn")) {
        continue;
      }
      var text = [
        node.textContent,
        node.title,
        node.getAttribute("title"),
        node.getAttribute("aria-label"),
        node.getAttribute("data-title")
      ].join(" ").replace(/\s+/g, " ").trim().toLowerCase();
      var href = (node.getAttribute("href") || "").toLowerCase();
      var hit = href.indexOf("/settings/") >= 0 ||
        href.indexOf("settings/index.html") >= 0 ||
        href.indexOf("dlg.open/uisettings") >= 0 ||
        href.indexOf("dlg.open/serversettings") >= 0;
      for (var b = 0; b < blocked.length && !hit; b++) {
        hit = text === blocked[b] || text.indexOf(blocked[b]) >= 0;
      }
      if (hit) {
        var hideNode = node.closest(".lms-list-item, .image-grid-item, .v-list__tile, .v-list-tile, .v-btn, a, .link-item, .menu-shortcut") || node;
        if (hideNode.classList && hideNode.classList.contains("image-grid-item") && hideNode.parentElement && hideNode.parentElement.getAttribute("align")) {
          hideNode = hideNode.parentElement;
        }
        hideNode.classList.add("lyrion-gadget-hidden");
        hideNode.style.setProperty("display", "none", "important");
        hideNode.style.setProperty("visibility", "hidden", "important");
      }
    }
  }

  function patchMaterialPandoraIconMap() {
    var entries = {};
    for (var i = 0; i < 4; i++) {
      var base = "plugins/FR_Pandora_" + i + "/html/";
      ["icon.png", "icon_50x50.png", "icon_100x100.png", "icon_50x50_o.png"].forEach(function (name) {
        entries[base + name] = {svg: "lyrion-pandora", myapps: {svg: "lyrion-pandora"}};
      });
    }

    try {
      if (typeof iconMap !== "undefined") {
        iconMap.endsWith = iconMap.endsWith || {};
        for (var key in entries) {
          if (Object.prototype.hasOwnProperty.call(entries, key)) {
            iconMap.endsWith[key] = entries[key];
          }
        }
      }
    } catch (e) {}

    try {
      if (window.localStorage) {
        var raw = window.localStorage.getItem("misc-icon-map");
        if (raw) {
          var data = JSON.parse(raw);
          data.endsWith = data.endsWith || {};
          for (var storedKey in entries) {
            if (Object.prototype.hasOwnProperty.call(entries, storedKey)) {
              data.endsWith[storedKey] = entries[storedKey];
            }
          }
          window.localStorage.setItem("misc-icon-map", JSON.stringify(data));
        }
      }
    } catch (e2) {}
  }

  function scheduleHideServerItems(delay) {
    if (adminMode || hideServerItemsQueued) {
      return;
    }
    hideServerItemsQueued = true;
    managedTimeout(function () {
      hideServerItemsQueued = false;
      hideServerItems();
      patchMaterialPandoraIconMap();
    }, typeof delay === "number" ? delay : 120);
  }

  function installHideServerHooks() {
    if (adminMode || window.__lyrionGadgetHideServerHooks) {
      return;
    }
    window.__lyrionGadgetHideServerHooks = true;

    document.addEventListener("click", function () {
      scheduleHideServerItems(220);
    }, true);
    window.addEventListener("hashchange", function () {
      scheduleHideServerItems(220);
    });
    window.addEventListener("popstate", function () {
      scheduleHideServerItems(220);
    });

    managedTimeout(function () { scheduleHideServerItems(200); }, 500);
    managedTimeout(function () { scheduleHideServerItems(200); }, 1500);
    managedTimeout(function () { scheduleHideServerItems(200); }, 3500);
    patchMaterialPandoraIconMap();
    if (!window.__lyrionGadgetMaterialIconObserver) {
      window.__lyrionGadgetMaterialIconObserver = new MutationObserver(function () {
        scheduleHideServerItems(120);
      });
      window.__lyrionGadgetMaterialIconObserver.observe(document.body, {childList: true, subtree: true});
    }
  }

  function lockDialogs() {
    if (adminMode || !ready() || window.__lyrionGadgetDialogsLocked) {
      return;
    }
    window.__lyrionGadgetDialogsLocked = true;
    var originalEmit = window.bus.$emit.bind(window.bus);
    window.bus.$emit = function (eventName) {
      if (eventName === "dlg.open") {
        var dialogName = arguments.length > 1 ? String(arguments[1] || "").toLowerCase() : "";
        if (dialogName === "uisettings" ||
            dialogName === "playersettings" ||
            dialogName === "serversettings" ||
            dialogName === "manage" ||
            dialogName === "playerlist") {
          return false;
        }
      }
      return originalEmit.apply(window.bus, arguments);
    };
  }

  function applyClass() {
    document.documentElement.classList.add("lyrion-gadget-material");
    document.body.classList.add(adminMode ? "lyrion-gadget-admin" : "lyrion-gadget-hide-server");
  }

  function boot(tries) {
    applyClass();
    installLockedSwipeGuard();
    closeMaterialMenuDrawer();
    if (ready()) {
      lockDialogs();
      lockHeaderDrawer();
      watchFixedVolume();
      addSyncButton();
    }
    if (tries === 80 || ready()) {
      scheduleHideServerItems(40);
    }
    installHideServerHooks();
    managedTimeout(closeMaterialMenuDrawer, 250);
    managedTimeout(closeMaterialMenuDrawer, 900);
    managedTimeout(closeMaterialMenuDrawer, 2200);
    if ((!ready() || !document.getElementById("lyrion-gadget-sync-btn")) && tries > 0) {
      managedTimeout(function () {
        boot(tries - 1);
      }, 250);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      boot(80);
    });
  } else {
    boot(80);
  }
})();
