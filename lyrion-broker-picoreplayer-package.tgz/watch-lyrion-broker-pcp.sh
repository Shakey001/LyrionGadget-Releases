#!/bin/sh
# piCorePlayer watchdog for the Lyrion RTI Broker.

set -u

APP_DIR="${APP_DIR:-/mnt/mmcblk0p2/tce/lyriongadget}"
LOG_DIR="${LOG_DIR:-$APP_DIR/logs}"
START_SCRIPT="${START_SCRIPT:-$APP_DIR/start-lyrion-broker-pcp.sh}"
ENV_FILE="${ENV_FILE:-$APP_DIR/lyrion-broker.env}"

if [ -f "$ENV_FILE" ]; then
  # shellcheck disable=SC1090
  . "$ENV_FILE"
fi

BROKER_PORT="${BROKER_PORT:-9099}"
HEALTH_URL="${BROKER_HEALTH_URL:-http://127.0.0.1:$BROKER_PORT/health}"
WATCH_INTERVAL_SECS="${BROKER_WATCH_INTERVAL_SECS:-30}"
WATCH_LOG="$LOG_DIR/lyrion-watchdog.log"
LOCK_DIR="/tmp/lyrion-broker-watchdog.lock"
LOCK_PID="$LOCK_DIR/pid"

mkdir -p "$LOG_DIR"

# pCP can send TERM/HUP to startup-spawned children after boot/user-command
# cleanup. The watchdog is intentionally long-lived, so keep it running and
# let it restart the broker if the Python process gets swept up.
trap '' HUP TERM

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  old_pid="$(cat "$LOCK_PID" 2>/dev/null || true)"
  if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
    exit 0
  fi
  rm -rf "$LOCK_DIR" 2>/dev/null || true
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    exit 0
  fi
fi
trap 'rm -rf "$LOCK_DIR" 2>/dev/null || true' EXIT INT
echo "$$" > "$LOCK_PID"

log_watch() {
  printf '%s watchdog: %s\n' "$(date)" "$*" >> "$WATCH_LOG"
}

health_ok() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time 2 "$HEALTH_URL" >/dev/null 2>&1
    return $?
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -T 2 -O /dev/null "$HEALTH_URL" >/dev/null 2>&1
    return $?
  fi
  return 1
}

log_watch "started for $HEALTH_URL"

while :; do
  if ! health_ok; then
    log_watch "health check failed; running start wrapper"
    if [ -x "$START_SCRIPT" ]; then
      "$START_SCRIPT" >> "$WATCH_LOG" 2>&1 || log_watch "start wrapper exited with failure"
    else
      log_watch "start script missing or not executable: $START_SCRIPT"
    fi
  fi
  sleep "$WATCH_INTERVAL_SECS"
done
