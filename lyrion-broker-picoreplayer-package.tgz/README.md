# Lyrion RTI Broker

This folder is the Pi-side broker. It exposes the RTI WebSocket endpoint on port `9099`, sends commands to Lyrion with JSON-RPC, and receives player state through Lyrion CometD long-poll.

## Install On Raspberry Pi OS

```bash
sudo mkdir -p /opt/lyriongadget
sudo cp lyrion_broker.py requirements.txt /opt/lyriongadget/
cd /opt/lyriongadget
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
sudo cp lyrion-broker.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now lyrion-broker
```

## Install On piCorePlayer

piCorePlayer runs from a RAM filesystem, so the broker must live on the persistent
`tce` partition and startup must be saved through Tiny Core's backup system.

Copy this `pi_broker` folder to the piCorePlayer host, SSH in, then run:

```bash
cd /path/to/pi_broker
chmod +x install-picoreplayer.sh start-lyrion-broker-pcp.sh
./install-picoreplayer.sh
```

The installer:

- Copies this project's custom `lyrion_broker.py` into the persistent
  `tce/lyriongadget` folder.
- Creates a Python virtual environment there and installs `requirements.txt`.
- Adds a delayed broker watchdog launch to `/opt/bootsync.sh`.
- Runs `filetool.sh -b` so the boot hook survives reboot.
- Starts the broker immediately.

If `python3` is missing, install a Python 3 extension from the piCorePlayer
Extensions page first, then rerun the installer.

Configuration is stored in:

```text
/mnt/mmcblk0p2/tce/lyriongadget/lyrion-broker.env
```

By default, this assumes Lyrion Music Server is running on the same pCP device:

```text
LMS_BASE=http://127.0.0.1:9000
BROKER_PORT=9099
```

After install, open:

```text
http://<picoreplayer-ip>:9099/health
http://<picoreplayer-ip>:9099/setup
```

For RTI Apex configuration, use the setup page's **RTI Player Mapping** table
or this JSON endpoint:

```text
http://<picoreplayer-ip>:9099/api/players
```

Set the RTI driver `ServerIPAddress` to the piCorePlayer IP. Set each
`PlayerX_MAC` value to the matching LMS `playerid` shown by the broker.

Logs are written to:

```text
/mnt/mmcblk0p2/tce/lyriongadget/logs/lyrion-broker.log
```

The pCP bootsync hook launches the broker watchdog with a model-aware delay:

```text
( sleep <30|45>; /mnt/mmcblk0p2/tce/lyriongadget/launch-lyrion-broker-pcp.sh >/dev/null 2>&1 ) &
```

The broker never consumes pCP user-command slots. Those slots are reserved for
extra Squeezelite players. Local player setup uses direct user commands for
up to four total players and switches to `start-local-stack.sh` for larger
Pi 4/Pi 5 player counts.

## Defaults

The service assumes Lyrion Music Server is on the same Pi:

```text
LMS_BASE=http://127.0.0.1:9000
BROKER_PORT=9099
RESCAN_SECS=0
FORCE_STATUS_AFTER_COMMAND=0
```

With `FORCE_STATUS_AFTER_COMMAND=0`, status comes from CometD long-poll instead of post-command polling.

## Check

```bash
curl http://127.0.0.1:9099/health
sudo journalctl -u lyrion-broker -f
```

RTI should point its driver `ServerIPAddress` setting at the Pi broker IP.
